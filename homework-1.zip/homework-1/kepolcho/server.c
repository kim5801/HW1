#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// max length/size of a row or column
#define MAX_LEN 4
#define BOARD_SIZE 5


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// change the value, used to adjust board
static void swapChars(char *current) {
  if (*current == '.') {
    *current = '*';
  }
  else {
    *current = '.';
  }
}

// change th  e board as indicated, error checking
static bool move(int r, int c, char board[5][5]) {
  // error condition
  // board goes from 0 to 4 (value of max len)
  if (r < 0 || r > MAX_LEN || c < 0 || c > MAX_LEN) {
    return false;
  }

  // values are valid, change board

  // update spot selected
  swapChars(&board[r][c]);

  // check edge locations before changing
  if (r != 0) { // change row above
    swapChars(&board[r - 1][c]);
  }
  if (r != MAX_LEN) { // change row below
    swapChars(&board[r + 1][c]);
  }
  if (c != 0) { // change left column
    swapChars(&board[r][c - 1]);
  }
  if (c != MAX_LEN) { // change right column
    swapChars(&board[r][c + 1]);
  }

  printf("success\n");
  return true;
}

// undo the previous move
// return true if move successful
static bool undo(char currBoard[5][5], char pBoard[5][5]) {
  // loop through and reset the board
  for (int r = 0; r < BOARD_SIZE; r++) {
    for (int c = 0; c < BOARD_SIZE; c++) {
      currBoard[r][c] = pBoard[r][c];
    }
  }
  // DON'T FORGET TO UPDATE FLAG
  return true;
}

// report the current board, probably not done correctly
// go back and fix
static void report(char board[5][5], char buffer[]) {
  strcpy(buffer, "");
  int idx = 0;
  for (int r = 0; r < BOARD_SIZE; r++) {
    for (int c = 0; c < BOARD_SIZE; c++, idx++) {
      buffer[idx] = board[r][c];
    }
    buffer[idx++] = '\n';
  }
  buffer[idx] = '\0';

}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // have the initial/previous board for undoing a move
  char prevBoard[BOARD_SIZE][BOARD_SIZE];
  // create way to store game board
  char board[BOARD_SIZE][BOARD_SIZE];
  // flag to keep track of if undo is valid, can't do 
  // undo twice in a row or if first move
  bool lastMoveUndo = true;
  // buffer to keep track of user messages
  char buffer[MESSAGE_LIMIT];

  // error checking for valid # of arguments
  if (argc != 2) {
    fail("usage: server <board-file>");
  }

  // open file
  FILE *inputFile = fopen(argv[1], "r");
  if (inputFile == NULL) {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    fprintf(stderr, "Errno: %d\n", errno);
    exit(EXIT_FAILURE);
  }

  // read board on file into the game board
  char curr = fgetc(inputFile);
  int row = 0;
  int col = 0;

  // make the board from file, checking if valid while
  // reading in from file
  while (curr != EOF) {
    if (curr == '*' || curr == '.') {
      board[row][col] = curr;
      // increment column to the right
      col++;
    }
    else if (curr == '\n' && col == 5) { // check if at end of column
      row++;
      col = 0;
    }
    else { // file is invalid
      fprintf(stderr, "Invalid input file: %s\n", argv[1]);
      exit(EXIT_FAILURE);
    }

    // check if the values exceed valid amounts
    if (col > BOARD_SIZE || (row > MAX_LEN && curr != EOF && curr != '\n')) {
      fprintf(stderr, "Invalid input file: %s\n", argv[1]);
      exit(EXIT_FAILURE);
    }

    // advance
    curr = fgetc(inputFile);
  }
  
  // check if it's valid, check last char
  if (board[MAX_LEN][MAX_LEN] != '*' && board[MAX_LEN][MAX_LEN] != '.') {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(EXIT_FAILURE);
  }

  // copy initial board to previous board
  for (int i = 0; i < BOARD_SIZE; i++) {
    for (int j = 0; j < BOARD_SIZE; j++) {
      prevBoard[i][j] = board[i][j];
    }
  }

  // Repeatedly read and process client messages.
  while ( running ) {
    int messLen = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);

    if (messLen >= 0) {
      // get client's message
      char space[] = " ";
      char *clientCommand = strtok(buffer, space);

      // make the move, update board as needed
      if (strcmp(clientCommand, "move") == 0) {
        row = 0;
        col = 0;

        // continue moving forward
        // get the row and column numbers, -1 value for invalid
        // value for row/column
        clientCommand = strtok(NULL, space);
        if (!(sizeof(clientCommand) > 1 || clientCommand[0] < '0' || clientCommand[0] > '4')) {
          row = *clientCommand - '0';
        }
        else {
          row = -1;
        }
        // get column
        clientCommand = strtok(NULL, space);
        if (!(sizeof(clientCommand) > 1 || clientCommand[0] < '0' || clientCommand[0] > '4')) {
          col = *clientCommand - '0';
        }
        else {
          col = -1;
        }

        // move returns false if value is invalid
        if (!move(row, col, board)) {
          strcpy(buffer, "fail");
          mq_send(clientQueue, buffer, sizeof(buffer), 0);
        }
        else {
          strcpy(buffer, "success");
          // update flag, last move was successul
          lastMoveUndo = false;
          mq_send(clientQueue, buffer, sizeof(buffer), 0);
        }
      }
      else if(strcmp(clientCommand, "undo") == 0) {
        // check if undo can be done
        if (lastMoveUndo) {
          strcpy(buffer, "fail");
          mq_send(clientQueue, buffer, sizeof(buffer), 0);
        }
        else {
          undo(board, prevBoard);  
          // reset flag
          lastMoveUndo = true;    
          strcpy(buffer, "success");
          mq_send(clientQueue, buffer, sizeof(buffer), 0);  
        }
      }
      else if(strcmp(clientCommand, "report") == 0) {
        // perform report
        report(board, buffer);
        mq_send(clientQueue, buffer, sizeof(buffer), 0);
      } 
    }          
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
