#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// print error and exit
static void fail() {
    fprintf(stdout, "error\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );

    if ( serverQueue == -1 || clientQueue == -1 ) {
        fail("Can't open the needed message queues" );
    }

    char buffer[MESSAGE_LIMIT];
    if (strcmp(argv[1], "move") == 0) {
        if (argc != 4) {
            fail();
        }
        strcat(buffer, argv[1]);
        strcat(buffer, " ");
        strcat(buffer, argv[2]);
        strcat(buffer, " ");
        strcat(buffer, argv[3]);
        strcat(buffer, " ");

        // send message to server
        int response = mq_send(serverQueue, buffer, sizeof(buffer), 0);

        if (response < 0) {
            fail();
        }

        // read message from server
        response = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
        if (response >= 0) {
                if (strcmp(buffer, "fail") == 0) {
                    fail();
                }
                else {
                    printf("succes\n");
                    exit(EXIT_SUCCESS);
                }
            }
    }      
    else if (strcmp(argv[1], "undo") == 0) {
        strcpy(buffer, "undo");
        int response = mq_send(serverQueue, buffer, sizeof(buffer), 0);

        if (response < 0) {
            fail();
        }
        response = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);

        if (response >= 0) {
            if (strcmp(buffer, "fail") == 0) {
                fail();
            }
            else {
                printf("success\n");
            }
        }
    }
    else if (strcmp(argv[1], "report") == 0) {
        strcpy(buffer, "report");
        int response = mq_send(serverQueue, buffer, sizeof(buffer), 0);
        if (response < 0) {
            fail();
        }

        response = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
        printf(buffer);
    }
    else {
        fail();
    }
    mq_close(clientQueue);
    mq_close(serverQueue);
    exit(EXIT_SUCCESS);
}