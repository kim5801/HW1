/**
  @file client.c
  @author Joey Brefka (jrbrefka)
  The client for the lights-out game
*/

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) 
{
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
  The main function of client
  @param argc for the number of arguments
  @param argv for the arguments as strings
  @return the exit status
*/
int main( int argc, char *argv[] ) 
{
  //open the queues
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);
  if ( clientQueue == -1 )
    fail( "failed to open queue" );
  
  
  //read the command line arguments
  char buffer[ MESSAGE_LIMIT + 1 ];
  int bufferIdx = 0;
  for ( int i = 1; i < argc; i++ ) {
    for( int j = 0; j < strlen( argv[ i ] ); j++ ) {
      buffer[ bufferIdx++ ] = argv[ i ][ j ];
    }
    buffer[ bufferIdx++ ] = ' ';
  }
  buffer[ bufferIdx ] = '\0';
  //send the command line arguments to the server
  mq_send( serverQueue, buffer, strlen( buffer ), 0 );
  
  
  //print what the server sends back
  char report[ MESSAGE_LIMIT + 1 ];
  mq_receive( clientQueue, report, sizeof( buffer ), NULL );
  if ( strcmp( report, "error" ) == 0 ) {
    fail( "error" );
  }
  printf("%s\n", report);
  
  mq_close( clientQueue );
  mq_close( serverQueue );
  
  return 0;
  
}