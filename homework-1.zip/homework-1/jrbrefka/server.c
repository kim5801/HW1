/**
  @file server.c
  @author Joey Brefka (jrbrefka)
  The server for the lights-out game
*/

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** The maximum possible number of valid arguments from client.c*/
#define MAX_ARGS 3

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

//The grid for keeping track of which lights are on and off
bool grid[ GRID_SIZE ][ GRID_SIZE ];

void alarmHandler( int sig ) {
  printf("\n");
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      if ( grid[ i ][ j ] == 0 ) {
        printf("%c", '.');
      } else {
        printf("%c", '*');
      }
    }
    printf("%c", '\n');;
  }
  exit( 0 );
}


/**
  The main function of server
  @param argc for the number of arguments
  @param argv for the arguments as strings
  @return the exit status
*/
int main( int argc, char *argv[] ) 
{
  struct sigaction act;
  act.sa_handler = alarmHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction(SIGINT, &act, 0);
  
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  
  //check if command line arguments are valid
  if ( argc <= 1 || argc > 2 ) {
    fprintf( stderr, "usage: server <board-file>\n" );
    exit( 1 );
  }
  //try to open input file
  FILE *fp = fopen( argv[ 1 ], "r" );
  if ( !fp ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( EXIT_FAILURE );
  }
  //read in board from input file
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j <=GRID_SIZE; j++ ) {
      int ch = fgetc( fp );
      if ( ch == '.' ) {
        grid[ i ][ j ] = 0;
      } else if ( ch == '*' ) {
        grid[ i ][ j ] = 1;
      }
    }
  }
  
  int lastr = -1;
  int lastc = -1;
  // Repeatedly read and process client messages.
  while ( running ) {

    //read the arguments that the client sends
    char buffer[ MESSAGE_LIMIT + 1 ] = "";
    mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );
    char args[ MAX_ARGS ][ MESSAGE_LIMIT + 1 ];
    int argsc = 0;
    int j = 0;
    //seperate the arguments into an array to make it easier to use
    for ( int i = 0; buffer[ i ]; i++ ) {
      if ( buffer[ i ] == ' ' ) {
        args[ argsc ][ j ] = '\0';
        argsc++;
        j = -1;
      } else {
        args[ argsc ][ j ] = buffer[ i ];
      }
      j++;
    }
    args[ argsc ][ j ] = '\0';
    
    char *error = "error";
    char *success = "success";
    //check the arguments to see what the program is being told to do
    if ( strcmp( args[ 0 ], "move" ) == 0  ) {
      //check if arguments are valid
      if ( argsc != MAX_ARGS ) {
        mq_send( clientQueue, error, strlen( error ), 0 );
      } else {
        //turn row and column strings to ints
        int r = atoi( args[ 1 ] );
        int c = atoi( args[ 2 ] );
        //make sure it did not parse garbage
        if ( r == 0 && !( strcmp( args[ 1 ], "0" ) == 0 ) ) {
          mq_send( clientQueue, error, strlen( error ), 0 );
        } else if ( c == 0 && !( strcmp( args[ 2 ], "0" ) == 0 ) ) {
          mq_send( clientQueue, error, strlen( error ), 0 );
        } else if ( r >= GRID_SIZE || r < 0 || c >= GRID_SIZE || c < 0 ) {
          //return error if row or column is invalid
          mq_send( clientQueue, error, strlen( error ), 0 );
        } else {
          //update last used row and column for undo functionality
          lastr = r;
          lastc = c;
          //flip lights
          if ( r - 1 >= 0 ) {
            if ( grid[ r - 1 ][ c ] == 0 ) {
              grid[ r - 1 ][ c ] = 1 ;
            } else {
              grid[ r - 1 ][ c ] = 0 ;
            }
          }
          if ( r + 1 < GRID_SIZE ) {
            if ( grid[ r + 1 ][ c ] == 0 ) {
              grid[ r + 1 ][ c ] = 1 ;
            } else {
              grid[ r + 1 ][ c ] = 0 ;
            }
          }
          if ( c - 1 >= 0 ) {
            if ( grid[ r ][ c - 1 ] == 0 ) {
              grid[ r ][ c - 1 ] = 1 ;
            } else {
              grid[ r ][ c - 1 ] = 0 ;
            }
          }
          if ( c + 1 < GRID_SIZE ) {
            if ( grid[ r ][ c + 1 ] == 0 ) {
              grid[ r ][ c + 1 ] = 1 ;
            } else {
              grid[ r ][ c + 1 ] = 0 ;
            }
          }
          if ( grid[ r ][ c ] == 0 ) {
              grid[ r ][ c ] = 1 ;
          } else {
              grid[ r ][ c ] = 0 ;
          }
          //send success to client
          mq_send( clientQueue, success, strlen( success ), 0 );
        } 
      }
    } else if ( strcmp( args[ 0 ], "undo" ) == 0 ) {
      //check if undo is not a valid option at this time
      if ( lastr == -1 || lastc == -1 ) {
        mq_send( clientQueue, error, strlen( error ), 0 );
      } else {
        //undo lights
        if ( lastr - 1 >= 0 ) {
          if ( grid[ lastr - 1 ][ lastc ] == 0 ) {
            grid[ lastr - 1 ][ lastc ] = 1 ;
          } else {
            grid[ lastr - 1 ][ lastc ] = 0 ;
          }
        }
        if ( lastr + 1 < GRID_SIZE ) {
          if ( grid[ lastr + 1 ][ lastc ] == 0 ) {
            grid[ lastr + 1 ][ lastc ] = 1 ;
          } else {
            grid[ lastr + 1 ][ lastc ] = 0 ;
          }
        }
        if ( lastc - 1 >= 0 ) {
          if ( grid[ lastr ][ lastc - 1 ] == 0 ) {
            grid[ lastr ][ lastc - 1 ] = 1 ;
          } else {
            grid[ lastr ][ lastc - 1 ] = 0 ;
          }
        }
        if ( lastc + 1 < GRID_SIZE ) {
          if ( grid[ lastr ][ lastc + 1 ] == 0 ) {
            grid[ lastr ][ lastc + 1 ] = 1 ;
          } else {
            grid[ lastr ][ lastc + 1 ] = 0 ;
          }
        }
        if ( grid[ lastr ][ lastc ] == 0 ) {
            grid[ lastr ][ lastc ] = 1 ;
        } else {
            grid[ lastr ][ lastc ] = 0 ;
        }
        //send success to client
        mq_send( clientQueue, success, strlen( success ), 0 );
        //make sure undo can not be called twice in a row
        lastr = -1;
        lastc = -1;
      }
      
    } else if ( strcmp( args[ 0 ], "report" ) == 0 ) {
      //create a string and fill it will the necessary characters to be able to report the grid
      char reportString[ GRID_SIZE * GRID_SIZE + GRID_SIZE + 1 ];
      int reportStringIdx = 0;
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE; j++ ) {
          if ( grid[ i ][ j ] == 0 ) {
            reportString[ reportStringIdx++ ] = '.';
          } else {
            reportString[ reportStringIdx++ ] = '*';
          }
        }
        reportString[ reportStringIdx++ ] = '\n';
      }
      reportString[ reportStringIdx ] = '\0';
      mq_send( clientQueue, reportString, strlen( reportString ), 0 );
    } else {
      //report error to client if the arguments are not valid
      mq_send( clientQueue, error, strlen( error ), 0 );
    }
    
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
