/**
 * @file server.c
 * @author Jessica Bui (jtbui)
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

//max characters that should be in file (5 rows * 5 columns + a new line char for each line)
#define MAX_CHAR 30

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

char commandSuccess[] = "success";
char commandFail[] = "error";

//Handles the signal user gives when it wants to stop running program
void handleLeave(int signal) {
  running = 0;
}

int main( int argc, char *argv[] ) {
  // fails if user gives more than a file name
  if (argc != 2) {
    fail("usage: server <board-file>");
  }

  // Reading a file
  int forRead = open(argv[1], O_RDONLY);

  if (forRead < 0) {
    close(forRead);
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  char fileStuff[MAX_CHAR];
  int rd = read(forRead, fileStuff, sizeof(fileStuff));
  //not enough characters in file
  if (rd != MAX_CHAR) {
    close(forRead);
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  char boardLook[GRID_SIZE][GRID_SIZE + 2];
  int charCount = 0;
  int lineNum = 0;
  //making sure each character is . or * and making sure there are 6 characters
  for (int i = 0; i < GRID_SIZE; ++i) {
    for (int j = 0; j < GRID_SIZE + 1; ++j) {
      //checking if at end of line
      if (((lineNum % GRID_SIZE) == 0) && charCount != 0 && lineNum != 0) {
        if (fileStuff[charCount] != '\n') {
          close(forRead);
          fprintf(stderr, "Invalid input file: %s\n", argv[1]);
          exit(1);
        }
        lineNum = 0;
      }
      else {
        if (fileStuff[charCount] != '.' && fileStuff[charCount] != '*') {
          close(forRead);
          fprintf(stderr, "Invalid input file: %s\n", argv[1]);
          exit(1);
        }
        ++lineNum;
      }
      boardLook[i][j] = fileStuff[charCount];
      if (j == GRID_SIZE) {
        boardLook[i][j + 1] = '\0';
      }
      ++charCount;
    }
  }
  //if more lines than 5
  if (read(forRead, fileStuff, sizeof(fileStuff)) != 0) {
    close(forRead);
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  close(forRead);

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  struct sigaction act;
  act.sa_handler = handleLeave;
  sigemptyset(&(act.sa_mask));
  act.sa_flags = 0;
  sigaction(SIGINT, &act, 0);  

  char buffer[MESSAGE_LIMIT];
  char prevBoardLook[GRID_SIZE][GRID_SIZE + 2];
  bool moveMade = false;

  // Repeatedly read and process client messages.
  while ( running ) {
    mq_receive(serverQueue, buffer, sizeof(buffer), NULL);

    //make a move
    if (strncmp("move", buffer, GRID_SIZE - 1) == 0) {
      int row;
      int col;
      sscanf(buffer, "%d%d", &row, &col);
      //copying current board to previous board before changing
      for (int i = 0; i < GRID_SIZE; ++i) {
        strcpy(prevBoardLook[i], boardLook[i]);
      }
      moveMade = true;
      
      //changing center grid
      if (boardLook[row][col] == '*') {
        boardLook[row][col] = '.';
      }
      else {
        boardLook[row][col] = '*';
      }

      //changing bottom row
      if ((row + 1) < 5) {
        if (boardLook[row + 1][col] == '*') {
          boardLook[row + 1][col] = '.';
        }
        else {
          boardLook[row + 1][col] = '*';
        }
      }

      //changing top row
      if ((row - 1) >= 0) {
        if (boardLook[row - 1][col] == '*') {
          boardLook[row - 1][col] = '.';
        }
        else {
          boardLook[row - 1][col] = '*';
        }
      }

      //changing next column
      if ((col + 1) < 5) {
        if (boardLook[row][col + 1] == '*') {
          boardLook[row][col + 1] = '.';
        }
        else {
          boardLook[row][col + 1] = '*';
        }
      }

      //changing prev column
      if ((col - 1) >= 0) {
        if (boardLook[row][col - 1] == '*') {
          boardLook[row][col - 1] = '.';
        }
        else {
          boardLook[row][col - 1] = '*';
        }
      }
      mq_send(clientQueue, commandSuccess, strlen(commandSuccess), 0);
    }
    else if (strcmp("undo", buffer) == 0) {
      if (!moveMade) {
        mq_send(clientQueue, commandFail, strlen(commandFail), 0);
      }
      else {
        for (int i = 0; i < GRID_SIZE; ++i) {
          strcpy(boardLook[i], prevBoardLook[i]);
        }
        moveMade = false;
        mq_send(clientQueue, commandSuccess, strlen(commandSuccess), 0);
      }
    }
    else if (strcmp("report", buffer) == 0) {
      for (int i = 0; i < GRID_SIZE; ++i) {
        mq_send(clientQueue, boardLook[i], strlen(boardLook[i]), 0);
      }
    }
    
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  printf("\n");

  for (int i = 0; i < GRID_SIZE; ++i) {
    printf("%s", boardLook[i]);
  }

  return 0;
}
