/**
 * @file maxsum.c
 * @author Jessica Bui (jtbui)
 */
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.
  //overall max found
  int finalMax = 0;

  //anonymous pipe
  int talk[2];
  if (pipe(talk) != 0) {
    fail( "Can't create pipe" );
  }

  //the amount of workers
  for (int i = 0; i < workers; ++i) {
    //creating child processor
    int pid = fork();
    if (pid < 0) {
      fail("Can't create child process");
    }
    //child
    if (pid == 0) {
      //closing reading end
      close(talk[0]);
      int max = 0;

      //for the process to calculate each range
      for (int j = i; j < vCount; j += workers) {
        int total = 0;
        
        //to keep adding
        for (int h = j; h < vCount; ++h) {
          total += vList[h];
          //found a max
          if (total > max) {
            max = total;
          }
        }
      }

      //report process id and sum found if user wants it reported
      if (report) {
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), max);
      }

      //locking pipe so only one worker uses it at a time
      lockf(talk[1], F_LOCK, 0);
      //writing into pipe for parent to read
      int wr = write(talk[1], &max, sizeof(int));
      //unlocking pipe
      lockf(talk[1], F_ULOCK, 0);
      if ( wr < 0 ) {
        fail("Error writing to pipe");
      }
      exit(0);
    }
    //parent
    else {
      int readMax;
      int rd = read(talk[0], &readMax, sizeof(int));

      if (rd < 0) {
        fail("Error reading from pipe");
      }

      if (readMax > finalMax) {
        finalMax = readMax;
      }

    }
  }
  //waiting for each child to finish
  for (int i = 0; i < workers; ++i) {
    wait(NULL);
  }
  printf("Maximum sum: %d\n", finalMax);

  return 0;
}
