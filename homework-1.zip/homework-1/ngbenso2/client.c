/**
  * @author Natasha Benson
  * @file client.c
  * This program opens the client and server message queues created in server.c
  * for requests with specific commands to change the state of the game
  * board or to print out the state of the game board
  * commands
  */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** Max number of arguments for move command */
#define MAX_ARGS_MOVE 4
/** Max number of arguments for report and undo */
#define MAX_ARGS_OTHER 2

/**
  * Prints out an error message and exit
  * @param message error message
  */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
  * Opens the message queues, sends the client requests to the servers, and
  * prints out the status of the request completion.
  * @param argc number of arguments run with program
  * @param argv command line arguments
  * @return exit status
  */
int main( int argc, char *argv[] )
{
  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Holds status message for client to print
  char statusMessage[ MESSAGE_LIMIT ];
  
  // Prepares each valid command for the server
  if ( argc == MAX_ARGS_MOVE && strcmp( argv[ 1 ], "move" ) == 0 ) {
    char buffer[ MESSAGE_LIMIT ]; // Buffer for sending message to server
    buffer[ 0 ] = 'M';
    int startIndex = 1;
    for ( int i = 0; i < strlen( argv[ MAX_ARGS_OTHER ] ); i++ ) {
      buffer[ startIndex++ ] = argv[ MAX_ARGS_OTHER ][ i ];
    }
    for ( int i = 0; i < strlen( argv[ MAX_ARGS_MOVE - 1 ] ); i++ ) {
      buffer[ startIndex++ ] = argv[ MAX_ARGS_MOVE - 1 ][ i ];
    }
    mq_send( serverQueue, buffer, strlen( buffer ), 0 );
    mq_receive( clientQueue, statusMessage, sizeof( statusMessage ), NULL );
  } else if ( argc == MAX_ARGS_OTHER && strcmp( argv[ 1 ], "undo" ) == 0 ) {
    char buffer[ MESSAGE_LIMIT ]; // Buffer for sending message to server
    buffer[ 0 ] = 'U';
    mq_send( serverQueue, buffer, strlen( buffer ), 0 );
    mq_receive( clientQueue, statusMessage, sizeof( statusMessage ), NULL );
  } else if ( argc == MAX_ARGS_OTHER && strcmp( argv[ 1 ], "report" ) == 0 ) {
    char buffer[ MESSAGE_LIMIT ]; // Buffer for sending message to server
    buffer[ 0 ] = 'R';
    mq_send( serverQueue, buffer, strlen( buffer ), 0 );
    mq_receive( clientQueue, statusMessage, sizeof( statusMessage ), NULL );
  } else {
    fail( "error" );
  }

  // Prints out status of command
  printf( "%s\n", statusMessage );

  mq_close( clientQueue );
  mq_close( serverQueue );
}
