/**
  * @author Natasha Benson
  * @file server.c
  * This program creates the client and server message queues, manages the state
  * of the lights-out board game, and handles requests made by client.c regarding
  * changes in the board and information about it
  */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** Max number for the row and columns */
#define MAX_RC_NUM 4
/** Position of column number in array */
#define COL_POS 2
/** Max args for move command */
#define MAX_ARGS 2
/** Index of first newline char */
#define N_INDEX_1 5
/** Index of second newline char */
#define N_INDEX_2 11
/** Index of third newline char */
#define N_INDEX_3 17
/** Index of fourth newline char */
#define N_INDEX_4 23
/** Index of fifth newline char */
#define N_INDEX_5 29
/** ASCII to decimal value conversion for numbers */
#define CHAR_TO_DEC 48

/**
  * Prints out an error message and exit
  * @param message error message
  */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Defines the behvaiors needed to track the board state information */
typedef struct {
  char boardDiagram [ GRID_SIZE ][ GRID_SIZE ];
  int lastMove[ MAX_ARGS ];
  bool moveMade;
} boardState;

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

/**
  * Switches the lights on the board
  * @param row row number of selected cell
  * @param col column number of selected cell
  * @param board board containing the diagram of the lights
  */
void switchLights( int row, int col, boardState *board )
{
  // Middle square switch
  board->boardDiagram[ row ][ col ] = board->boardDiagram[ row ][ col ] == '*' ? '.' : '*';
  // Left square switch
  if ( col - 1 > -1 ) {
    board->boardDiagram[ row ][ col - 1 ] = board->boardDiagram[ row ][ col - 1 ] == '*' ? '.' : '*';
  }
  // Right square switch
  if ( col + 1 < GRID_SIZE ) {
    board->boardDiagram[ row ][ col + 1 ] = board->boardDiagram[ row ][ col + 1 ] == '*' ? '.' : '*';
  }
  // Top square switch
  if ( row - 1 > - 1 ) {
    board->boardDiagram[ row - 1 ][ col ] = board->boardDiagram[ row - 1 ][ col ] == '*' ? '.' : '*';
  }
  // Bottom square switch
  if ( row + 1 < GRID_SIZE ) {
    board->boardDiagram[ row + 1 ][ col ] = board->boardDiagram[ row + 1 ][ col ] == '*' ? '.' : '*';
  }

}

/** Changes the running state to 0 after user signals to end the program  */
void stopHandler()
{
  running = 0;
}

/**
  * Creates the server and client message queues, reads in the board from the 
  * text file, and updates the board based on commands from the client. Prints
  * out a final report of the board state upon exiting the program.
  * @param argc number of arguments run with program
  * @param argv command line arguments
  * @return exit status
  */
int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Checks that server is run with only 2 arguments
  if ( argc != 2 ) {
    fail( "usage: server <board-file>" );
  }

  // Valid file check
  int rfp = open( argv[ 1 ], O_RDONLY );
  if ( rfp == -1 ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }

  // Board struct created to track state of the board
  boardState board;
  // Fills board diagram with status of lights
  char boardChars[ MESSAGE_LIMIT ];
  int length = read( rfp, boardChars, sizeof( boardChars ) );
  if ( length == 0 ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }

  /* Fills the board diagram within the board struct and checks for invalid
    characters from the file */
  int startIndex = 0;
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      char currentChar = boardChars[ startIndex++ ];
      // Ensures input file only contains valid characters
      if ( currentChar != '.' && currentChar != '*' && currentChar != '\n' ) {
        fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
        exit( 1 );
      }
      if ( startIndex == N_INDEX_1 || startIndex == N_INDEX_2 || startIndex == N_INDEX_3 ||
        startIndex == N_INDEX_4 || startIndex == N_INDEX_5 ) {
        startIndex++;
      }
      board.boardDiagram[ i ][ j ] = currentChar;
    }
  }

  board.moveMade = false;
  close( rfp );

  // Prepares signal handler for Ctrl + C
  struct sigaction stopServer;
  stopServer.sa_handler = stopHandler;
  stopServer.sa_flags = 0;
  sigaction( SIGINT, &stopServer, 0 );

  // Repeatedly read and process client messages.
  while ( running ) {

    char command[ MESSAGE_LIMIT ];
    char response[ MESSAGE_LIMIT ];
    mq_receive( serverQueue, command, sizeof( command ), NULL );

    // Handles "move" command and does arror checking on row and col numbers
    if ( command[ 0 ] == 'M' ) {
      if ( strlen( command ) > MAX_ARGS + 1 ) {
        strcpy( response, "error" );
      } else {
        // Convert char values to decimal values
        int rowVal = command[ 1 ] - CHAR_TO_DEC;
        int colVal = command[ COL_POS ] - CHAR_TO_DEC;
        if ( rowVal < 0 || rowVal > MAX_RC_NUM || colVal < 0 || colVal > MAX_RC_NUM ) {
          strcpy( response, "error" );
        } else {
          switchLights( rowVal, colVal, &board );
          board.lastMove[ 0 ] = rowVal;
          board.lastMove[ 1 ] = colVal;
          board.moveMade = true;
          strcpy( response, "success" );
        }
      }
    }

    // Handles "undo" command
    if ( command[ 0 ] == 'U' ) {
      //char response[ MESSAGE_LIMIT ];
      if ( !board.moveMade ) {
        strcpy( response, "error" );
      } else {
        // Move is undone and board status for moveMade changed to false
        switchLights( board.lastMove[ 0 ], board.lastMove[ 1 ], &board );
        board.moveMade = false;
        strcpy( response, "success" );
      }
    }

    // Handles "report" command
    if ( command[ 0 ] == 'R' ) {
      char buffer[ MESSAGE_LIMIT ];
      int position = 0;
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE; j++ ) {
          buffer[ position++ ] = board.boardDiagram[ i ][ j ];
        }
        buffer[ position++ ] = '\n';
      }
      strcpy( response, buffer );
    }

    // Command and response buffers cleared, final response sent to client
    memset( command, 0, MESSAGE_LIMIT );
    mq_send( clientQueue, response, strlen( response ), 0 );
  }

  // Prints final report after program ends
  printf( "\n" );
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      printf( "%c", board.boardDiagram[ i ][ j ] );
    }
    printf( "\n" );
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
