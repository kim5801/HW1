#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();
  // You get to add the rest.

  int trueMax;
  int maxSum;
  int startIndex; // Starting index in number array
  int increments = workers; // Index increments
  int finalMax[ workers ]; // Saved max sum of each worker
  // Ensures increments are od numbers to avoid repeated index assignemnt

  /** Creates number of specified workers and assigns each worker a portion of
  the array to calculate the max */
  for ( int i = 0; i < workers; i++ ) {
    // Creation of pipe by parent
    int pipeBuffer[ 2 ];
    if ( pipe( pipeBuffer ) != 0 ) {
      fail( "Can't create pipe\n" );
    }
    startIndex = i;
    if ( fork() == 0 ) {
      close( pipeBuffer[ 0 ] );
      maxSum = vList[ 0 ];
      while ( startIndex <= vCount ) {
        int sum = 0;
        for ( int j = startIndex; j < vCount; j++ ) {
          sum += vList[ j ];
          maxSum = sum > maxSum ? sum : maxSum;
        }
        startIndex += increments; // Moves to next assigned index for the worker
      }
      if ( report ) {
        printf( "I'm process %d. The maximum sum I found is %d.\n", getpid(), maxSum );
      }
      // Writes max sum found to the parent
      lockf( pipeBuffer[ 1 ], F_LOCK, 0 );
      int stat = write( pipeBuffer[ 1 ], &maxSum, 4 );
      if ( stat < 0 ) {
        fail( "Didn't write to pipe" );
      }
      lockf( pipeBuffer[ 1 ], F_ULOCK, 0 );
      exit( 0 );
    } else {
      // Reads the max sum sent by the children and writes it to an array
      close( pipeBuffer[ 1 ] );
      int stat = read( pipeBuffer[ 0 ], &finalMax[ i ], sizeof( finalMax[ i ] ) );
      if ( stat < 0 ) {
        fail( "Didn't read from pipe" );
      }
      trueMax = finalMax[ 0 ];
      for ( int i = 0; i < workers; i++ ) {
        trueMax = finalMax[ i ] > trueMax ? finalMax[ i ] : trueMax;
      }

      // Wait for all the children to terminate
      for ( int i = 0; i < workers; i++ ) {
        wait( 0 );
      }
    }
  }
  printf( "Maximum Sum: %d\n", trueMax );

  return 0;
}
