/**
 * @file client.c handles the client communication - this is where the user for the light game specifies what actions
 * they would like to perform on the board
 * 
 * @author Sania Bolla (sbolla2)
 * @date 2022-09-15
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** Largest a task can be is three chars - m (for move), int 1, and int 2 */
#define MAX_TASK_SIZE 3
/** If the user inputs report or undo */
#define TWO_COMMAND_ARGS 2
/** If the user inputs move with row and column number */
#define FOUR_COMMAND_ARGS 4
/** Using the command line argument at index 2 */
#define COMMAND_AT_TWO 2
/** Using the command line argument at index 3 */
#define COMMAND_AT_THREE 3

/**
 * @brief Print out an error message and exit.
 * 
 * @param message is the error message that needs to be printed
 */
static void fail() {
  fprintf( stdout, "%s\n", "error" );
  exit( 1 );
}
/**
 * @brief The main method reads the users desired tasks to perform on the board, sets up client-server communication and
 * send the task over to the server so the board may be altered
 * 
 * @param argc is the number of command line arguments
 * @param argv is the array of command line arguments
 * @return int exit status
 */
int main( int argc, char *argv[] ) {
    // The task to be performed on the board
    char task[MAX_TASK_SIZE];
    // What needs to be printed out based on what task was given
    char result[MESSAGE_LIMIT];
    // There needs to be either 2 or 4 command line arguments
    if (argc != FOUR_COMMAND_ARGS && argc != TWO_COMMAND_ARGS) {
        fail();
    }
    // The task given needs to be one of the following : move, undo, or report
    if (strcmp(argv[1], "move") != 0 && strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "report") != 0 ) {
        fail();
    }
    // When the command from the user is move
    if (strcmp(argv[1], "move") == 0) {
        if (argc != FOUR_COMMAND_ARGS) {
            fail();
        }
        // Check that the two values after move are integers
        int dig1;
        int dig2;
        int len1 = sscanf(argv[COMMAND_AT_TWO], "%d", &dig1);
        int len2 = sscanf(argv[COMMAND_AT_THREE], "%d", &dig2);

        if (len1 != 1 || len2 != 1) {
            fail();
        }
        //Putting the task inputted into the command line into an array
        // Using m for simplicity - move
        task[0] = 'm';
        task[1] = argv[COMMAND_AT_TWO][0];
        task[COMMAND_AT_TWO] = argv[COMMAND_AT_THREE][0];
    }
    // When the command from the user is either undo or report
    if (strcmp(argv[1], "undo") == 0 || strcmp(argv[1], "report") == 0) {
        if (argc != TWO_COMMAND_ARGS) {
            fail();
        }
        if (strcmp(argv[1], "undo") == 0) {
            // Using u for simplicity - undo
            task[0] = 'u';
        } else {
            // Using r for simplicity - report
            task[0] = 'r';
        }
        task[1] = 0;
        task[COMMAND_AT_TWO] = 0;
    }

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);
    if ( serverQueue == -1 || clientQueue == -1 )
        fail( "Can't create the needed message queues" );
    mq_send(serverQueue, task, MESSAGE_LIMIT, 0);
    mq_receive(clientQueue, result, MESSAGE_LIMIT, NULL);
    printf("%s", result);
    mq_close(clientQueue);
    mq_close(serverQueue);

    // In the case that error is printed, we need to exit unsuccessfully
    if (result[0] == 'e' && result[1] == 'r' && result[2] == 'r' && result[3] == 'o' && result[4] == 'r') {
        exit(EXIT_FAILURE);
    }
    // When error is not printed and the program is successful
    exit(EXIT_SUCCESS);
}
