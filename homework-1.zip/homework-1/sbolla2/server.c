/**
 * @file server.c creates the server for the lights game. In the server, the lights are changed around
 * based on whatever input the user puts in. The server will get the command from the client which is in a 
 * separate file.
 * @author Sania Bolla (sbolla2)
 * @date 2022-09-15
 * 
 * Sources:
 * https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter03/signalExample.c
 * https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter03/mqSender.c
 * https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter03/mqReceiver.c
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** Width of an ideal row in the game */
#define ROW_WIDTH 5
/** Width of an ideal column in the game */
#define COL_WIDTH 5
/** Converting the 2D 5X5 board into a 1d one with null terminator and newlines */
#define ONE_D_BOARD 31
/** Third position in either row or column */
#define THIRD_POS 3
/** Fourth position in either row or column */
#define FOURTH_POS 4

/** Global variable for how the light board looks currently.
 * This was made global because it is used in many methods like
 * alarm handler
  */
char currBoard[ROW_WIDTH][COL_WIDTH];
/** Global variable for how the light board looked just one move before.
 * This was made global because it is used in many methods like
 * alarm handler
  */
char previousBoard[ROW_WIDTH][COL_WIDTH];
/** Global variable for the 1d array that will be passed between client and server.
 * It will have whatever information needs to be sent back.
  */
char output[ONE_D_BOARD];

/**
 * @brief Print out an error message and exit.
 * 
 * @param message is the error message that needs to be printed
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief Changes the light from either on to off or off to on depending on
 * its current state
 * 
 * @param character is the character that needs to be switched
 * @return char the newly updated light
 */
char changeSign(char character) {
  if (character == '*') {
    character = '.';
  } else if (character == '.') {
    character = '*';
  }
  return character;
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

/**
 * @brief Handles which lights on the board will be switched based on which light is selected
 * 
 * @param board is the board in its current condition
 * @param row is the row selected by the user
 * @param column is the column selected by the user
 */
void changeBoard(char board[ROW_WIDTH][COL_WIDTH], int row, int column) {
  board[row][column] = changeSign(board[row][column]);
  if(row >= 1 && row <= THIRD_POS && column >= 1 && column <= THIRD_POS) {
    board[row - 1][column] = changeSign(board[row - 1][column]);
    board[row + 1][column] = changeSign(board[row + 1][column]);
    board[row][column - 1] = changeSign(board[row][column - 1]);
    board[row][column + 1] = changeSign(board[row][column + 1]);
  } else if (row == 0 && column == 0) {
    board[row][column + 1] = changeSign(board[row][column + 1]);
    board[row + 1][column] = changeSign(board[row + 1][column]);
  } else if (row == 0 && column == FOURTH_POS) {
    board[row][column - 1] = changeSign(board[row][column - 1]);
    board[row + 1][column] = changeSign(board[row + 1][column]);
  } else if (row == FOURTH_POS && column == 0) {
    board[row - 1][column] = changeSign(board[row - 1][column]);
    board[row][column + 1] = changeSign(board[row][column + 1]);
  } else if (row == FOURTH_POS && column == FOURTH_POS) {
    board[row - 1][column] = changeSign(board[row - 1][column]);
    board[row][column - 1] = changeSign(board[row][column - 1]);
  } else if (row == 0) {
    board[row][column - 1] = changeSign(board[row][column - 1]);
    board[row + 1][column] = changeSign(board[row + 1][column]);
    board[row][column + 1] = changeSign(board[row][column + 1]);
  } else if (column == 0) {
    board[row + 1][column] = changeSign(board[row + 1][column]);
    board[row - 1][column] = changeSign(board[row - 1][column]);
    board[row][column + 1] = changeSign(board[row][column + 1]);
  } else if (row == FOURTH_POS){
    board[row][column + 1] = changeSign(board[row][column + 1]);
    board[row][column - 1] = changeSign(board[row][column - 1]);
    board[row - 1][column] = changeSign(board[row - 1][column]);
  } else if (column == FOURTH_POS) {
    board[row + 1][column] = changeSign(board[row + 1][column]);
    board[row - 1][column] = changeSign(board[row - 1][column]);
    board[row][column - 1] = changeSign(board[row][column - 1]);
  }
}

/**
 * @brief Handles printing out the current state of the board after control + c is pressed by user
 * 
 * @param sig is the signal associated with the alarm handler
 * Based on https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter03/signalExample.c
 */
void alarmHandler( int sig ) {
  printf("%c", '\n');
  for (int i = 0; i < ROW_WIDTH; i++) {
    for (int j = 0; j < COL_WIDTH; j++) {
      printf("%c", currBoard[i][j]);
    }
    printf("%c", '\n');
  }
  exit(0);
}

/**
 * @brief Handles all the actions that can happen to the board (move, undo and report) by communicating with the client
 * 
 * @param argc is the number of command line arguments
 * @param argv is the array of command line arguments
 * @return int exit status
 */
int main( int argc, char *argv[] ) {
  // If exactly two command line arguments are not given
  if (argc != 2) {
    fail("usage: server <board-file>");
  }

  // Opening up the board from the file that contains it
  FILE *board = fopen(argv[1], "r");
  if (board == NULL) {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  // Boolean to keep track of if an undo was just called
  bool alreadyHadUndo = false;

  // Making sure the file contents are correct.
  // If the file does not have the board formatted how we want it file content correct turns to false and then invalid file will be printed
  bool fileContentsCorrect = true;
  char curr = fgetc(board);
  int newLineCount = 0;
  int lineCount = 0;
  int rowLoc = 0;
  int colLoc = 0;
  while (curr != EOF) {
    if (curr != '.' && curr != '*' && curr != '\n') {
      fileContentsCorrect = false;
    }
    if (curr == '\n') {
      newLineCount++;
      if (lineCount != COL_WIDTH || newLineCount > ROW_WIDTH) {
        fileContentsCorrect = false;
      }
      lineCount = 0;
      rowLoc++;
      colLoc = 0;
    } else {
      currBoard[rowLoc][colLoc] = curr;
      colLoc++;
      lineCount++;
    }
    curr = fgetc(board);
  }
  // If file contents are messed up (not 5X5 and other things)
  if (!fileContentsCorrect) {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  //Taken from example files on Moodle
  struct sigaction act;
  act.sa_handler = alarmHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;

  // Repeatedly read and process client messages.
  while ( running ) {
    // ...
    char task[MESSAGE_LIMIT];
    char error[ROW_WIDTH + 1] = "error\n";
    mq_receive(serverQueue, task, MESSAGE_LIMIT, NULL);
    // Handles the situation where the user calls "move"
    if (task[0] == 'm') {
      alreadyHadUndo = false;
      int rowVal = task[1] - '0';
      int colVal = task[2] - '0';
      if (rowVal > FOURTH_POS || colVal > FOURTH_POS) {
        mq_send(clientQueue, error, MESSAGE_LIMIT, 0);
        continue;
      }
      // Save the current version inside previousBoard
      for (int i = 0; i < ROW_WIDTH; i++) {
        for (int j = 0; j < COL_WIDTH; j++) {
          previousBoard[i][j] = currBoard[i][j];
        }
      }
      // Adjusts the board accordingly
      changeBoard(currBoard, rowVal, colVal);

      // Moving the 2D board to a 1D version to give back to the client
      int locationInSingle = 0;
      for (int i = 0; i < ROW_WIDTH; i++) {
        for (int j = 0; j < COL_WIDTH; j++){
          output[locationInSingle] = currBoard[i][j];
          locationInSingle++;
        }
        output[locationInSingle] = '\n';
        locationInSingle++;
      }
      output[locationInSingle] = '\0';

      strcpy(output, "success\n");
      mq_send(clientQueue, output, MESSAGE_LIMIT, 0);


    }
    // Handles the situation where the user calls "undo"
    else if (task[0] == 'u') {
      // Making sure the last call was not undo as well else we print error. We set the previous board to the current board
      if (!alreadyHadUndo) {
        for (int i = 0; i < ROW_WIDTH; i++) {
          for (int j = 0; j < COL_WIDTH; j++) {
            currBoard[i][j] = previousBoard[i][j];
          }
        }
        strcpy(output, "success\n");
        alreadyHadUndo = true;
      } else {
        strcpy(output, "error\n");
      }
      mq_send(clientQueue, output, MESSAGE_LIMIT, 0);
    }
    // Handles the situation where the user calls "report"
    else if (task[0] == 'r') {
      alreadyHadUndo = false;
      int locationInSingle = 0;
      // Putting the current board into the ouput array to be sent over to the client
      for (int i = 0; i < ROW_WIDTH; i++) {
        for (int j = 0; j < COL_WIDTH; j++){
          output[locationInSingle] = currBoard[i][j];
          locationInSingle++;
        }
        output[locationInSingle] = '\n';
        locationInSingle++;
      }
      output[locationInSingle] = '\0';
      mq_send(clientQueue, output, MESSAGE_LIMIT, 0);
    }

    sigaction( SIGINT, &act, 0 );
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
