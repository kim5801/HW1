/**
 * @file maxsum.c forks children in order through search through an array and find the largest contiguous sum
 * @author Sania Bolla (sbolla2)
 * 
 * @date 2022-09-15
 * 
 * Source:
 * https://pages.github.ncsu.edu/engr-csc246-staff/web/sample/chapter01/forkExecWait.c
 * 
 */
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

/**
 * @brief Print out an error message and exit.
 * 
 * @param message is the error message that needs to be printed
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Print out a usage message, then exit. */
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
 * @brief Method used by the child processes to go through the array starting at the point they are assigned, all the 
 * way to the end. As they traverse through they find the maxSum in that array
 * 
 * @param arr is the main array that the children will work with
 * @param start is the assigned start for that child
 * @param end is the last index of the array
 * @return int the maxSum of that array that is contiguous
 */
int maxOfSubArray(int arr[], int start, int end) {
  int maxSum = arr[start];
  int currentSum = 0;
  for (int i = start; i <= end; i++) {
    currentSum = currentSum + arr[i];
    if (currentSum > maxSum) {
      maxSum = currentSum;
    }
  }
  return maxSum;
}

/**
 * @brief Forks the child workers and creates assignments for them based on how many workers the user specified.
 * Each worker goes through the array and reports back the maxSum it found. All those maxes are then put into an array
 * and the max out of all of those is then found.
 * 
 * @param argc is the number of command line arguments
 * @param argv is the array of command line arguments
 * @return int exit status
 */
int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // Using exercise examples given on moodle
  int pfd[ 2 ];
  if ( pipe( pfd ) != 0 )
    fail( "Can't create pipe" );

  // You get to add the rest.

  // ...
  int max = 0;
  int curr = 0;
  int workerNumber = 0;
  int workerMax = 0;
  // Creating as many children/workers as the user wants
  for (int i = 0; i < workers; i++) {
    int pid = fork();
    if ( pid == -1 )
      fail( "Can't create child process" );
    if ( pid == 0 ) {
      // Now working with the child worker
      close( pfd[ 0 ] );
      workerMax = 0;
      int pidVal = (int) getpid();
      while (curr < vCount) {
        // Finds the max of one array it is assigned and keeps going through all its assignments
        // It provides the maxSum it could find through all the arrays it checked
        max = maxOfSubArray(vList, curr, vCount - 1);
        if (max > workerMax) {
          workerMax = max;
        }
        curr += workers;
      }
      // If the user wants a child report
      if (report) {
        printf("%s%d%s%d%s", "I'm process ", pidVal, ". The maximum sum I found is ", workerMax, ".\n");
      }
      // Locking the pipe in case the another worker is trying to write in at the same time
      lockf( pfd[1], F_LOCK, 0 );
      write( pfd[ 1 ], &workerMax, sizeof(workerMax));
      lockf( pfd[1], F_ULOCK, 0 );

      close( pfd[1] );
      exit(EXIT_SUCCESS);
    }
    workerNumber += 1;
    curr = workerNumber;

  }

  close( pfd[ 1 ] );
  int lastArray[workers];
  // Waiting for all the workers to finish : asked on piazza 
  for (int i = 0; i < workers; i++) {
    wait(NULL);
  }
  // Reading all the values put into the pipe by the workers, into a lastArray
  read(pfd[0], lastArray, sizeof(lastArray));
  close( pfd[ 0 ] );

  // Finding the overall maxSum from all the maxSum's that the workers found
  int finalMax = lastArray[0];
  for (int i = 0; i < workers; i++) {
    if (lastArray[i] > finalMax) {
      finalMax = lastArray[i];
    }
  }
  // Printing the finalSum
  printf("%s%d\n", "Maximum Sum: ", finalMax);

  return 0;
}
