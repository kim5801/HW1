/**
* @file server.c
* @author dsmathur
* This file includes all the operations of the 
* board game ranging from move to report.
* It also frames an accurate message that is 
* to be sent in response to an operation required.
* This class uses message queues in order to 
* communicate information with the client.
*/

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/**
* Print out an error message and exit.
* @param message the fail message to present
*/
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying t o print in the signal handler.
static int running = 1;

/**
* This function is called in response when 
* the user pressed the control C key as an
* interrupt on the server terminal.
* It sets running to zero , so the while loop
* can finally stop iterating 
* @param sig the signal handler
*
*/
 void alarmHandler(int sig){
    running = 0;   
}

/**
* The main method includes the primary 
* functioning of the server . It initializes
* the message queues and handles the request posed
* by the client. Furthermore, it sends an appropriate
* message back to the client regarding success or failure.
* @param argc  the number of command line arguments
* @param argv the command line argument
* @return an integer with regards to whether the program executed successfully or not
*
*/
int main( int argc, char *argv[] ) {
    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );
    
    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;
    
    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 )
        fail( "Can't create the needed message queues" );
        
    //Fill in the structure to redirect the alarm signal
    struct sigaction act;
    
    //Fill in a structure to redirect the alarm signal
    act.sa_handler = alarmHandler;
    sigemptyset(&(act.sa_mask));
    act.sa_flags = 0;
    sigaction(SIGINT, &act, 0);
    
    /* Defining the struct for the board*/
    typedef struct{
        char currentboard[GRID_SIZE][GRID_SIZE];
        char previousboard[GRID_SIZE][GRID_SIZE];
        bool undo;
    }Board;
    
    /** Mallocing space for the board*/
    Board *board = ( Board *) malloc(sizeof(Board));
    
    //Initializing the undo operation to be false
    board -> undo = 0;
    
    // Repeatedly read and process client messages.
    //Performing the invalid checks
    
    //Too many arguments or  missing the board file name
    if ( argc !=2){
        printf("usage: server <board-file>\n");
        //Free the struct created
        free(board);
        exit( 1 );
    }
    int fd = open(argv[1],O_RDONLY);
    
    //If the given board file is invalid (if the file does not exist)
    if(fd < 0){
        printf("Invalid input file: %s\n",argv[1]);
        //Free the struct created
        free(board);
        exit(1);
    }
    
    //If the file format consists of characters other than '.' , ' *' , and newline
    char readArray[GRID_SIZE + 1];
    bool invalidfile = 0;
    int countrows =0;
    int len =  read(fd,readArray,sizeof(readArray));
    
    while(len > 0){
        //if 6 columns are not read then that indicates this is an invalid file
        
        if(len != GRID_SIZE + 1){
            invalidfile = 1;
            break;
        }
        //Go through all the characters and check if they match the requirements
        // for the board file
        for(int i = 0 ; i < len;i++){
            if(readArray[i] != '\n'){
                board->currentboard[countrows][i] = readArray[i];
            }
            if(readArray[i] != '*' && readArray[i] != '\n' && readArray[i] != '.'){
                invalidfile = 1;
                break;
            }
        }
        if(invalidfile){
            break;
        }
        countrows++;
        
        //Continue reading from the file
        len =  read(fd,readArray,sizeof(readArray));
    }
    if(countrows != GRID_SIZE){
        invalidfile = 1;
    }
    
    //If the file is invalid, exit 
    if(invalidfile){
        printf("Invalid input file: %s\n",argv[1]);
        //Free the struct created
        free(board);
        exit(1);
    }
    
    while ( running ) {
    
        //Reading from the message queue
        char buffer[MESSAGE_LIMIT];
        
        //Try to get a message (this will wait until one arrives)
        len = mq_receive(serverQueue,buffer,sizeof(buffer),NULL);
        
        //If the program's running variable is zero that indicates 
        // that the alarm handler was called. Thus, the program requires
        //to print the final report along with a new line before exiting.
        if(running  == 0){
            printf("\n");
            char sendReport[MESSAGE_LIMIT];
            int charcount = 0;
            for(int i = 0 ; i < GRID_SIZE;i++){
                for(int j = 0 ; j < GRID_SIZE;j++){
                    sendReport[charcount++] = board -> currentboard[i][j];
                }
                sendReport[charcount++] = '\n';
            }
            //Adding a null terminator to the char array to make it a string
            sendReport[charcount] = '\0';
        
            printf("%s",sendReport);
        
        }
        
        //The character 'm' indicates the move command
        else if(buffer[0] == MOVE_SERVER_COMMAND){
            
            // first value will be the row to move
            //The row was stored in as an ASCII in the message 
            // so now we need to subtract '0' from it
            int row = buffer[1] - '0';
            
            //Second value will be the column to move
            //The column was stored in as an ASCII in the message 
            // so now we need to subtract '0' from it
            int column = buffer[2] -'0';
            
            //Save the previous state of the board
            for(int i = 0 ; i < GRID_SIZE;i++){
                for(int j=0; j < GRID_SIZE;j++){
                    board-> previousboard[i][j] = board ->currentboard[i][j];
                }
            }
            
            
            //Perform the move operations required for the
            // current place in the board
            if(board -> currentboard[row][column] == '.'){
                board->currentboard[row][column] = '*'; 
            }
            else if(board->currentboard[row][column] == '*'){
                board->currentboard[row][column] = '.';
            }
            
            //Check the place above, the current row,column index
            //Perform this only if there is an available row above
            if(row -1 >= 0 ){
                if(board->currentboard[row -1][column] == '.'){
                    board->currentboard[row-1][column] = '*';
                }
                else if(board->currentboard[row - 1][column] == '*'){
                    board->currentboard[row-1][column] = '.';
                }
                
            }
            
            //Check the place below
            //Perform this only when a row is available below
            if(row + 1 <= GRID_SIZE -1  ){
                if(board->currentboard[row + 1][column] == '.'){
                    board->currentboard[row+1][column] = '*';
                }
                else if(board->currentboard[row + 1][column] == '*'){
                    board->currentboard[row+1][column] = '.';
                } 
            }
            
            //Check the place to the right
            //Perform this only when a column is available to the right
            if(column + 1 <= GRID_SIZE -1){
                if(board->currentboard[row][column + 1] == '.'){
                    board->currentboard[row][column + 1] = '*';
                }
                else if(board->currentboard[row][column + 1] == '*'){
                    board->currentboard[row][column + 1] = '.';
                }
            }
            
            //Check the place to the left
            //Perform this only when a column is available to the left 
            if(column - 1 >= 0 ){
                if(board->currentboard[row][column - 1] == '.'){
                    board->currentboard[row][column - 1] = '*';
                }
                else if(board->currentboard[row][column -1] == '*'){
                    board->currentboard[row][column - 1] = '.';
                }
            }
            
            //Since a move operation has been performed 
            // we can set undo to true indicating that an undo  
            // operation can be performed after this
            board->undo = 1;
            
            //Server needs to send message to the client that move succeeded
            //The error handling for this operation is  contained within the client class 
            char sendStatus [MESSAGE_LIMIT];
            sendStatus[0] = MESSAGE_SUCCESS;
            
            
            //Send message to the client, that the operation succeeded
            mq_send(clientQueue,sendStatus,strlen(sendStatus),0);
        }
        
        //Need to perform the undo operation  
        else if(buffer[0] == UNDO_SERVER_COMMAND){
            char sendStatus[MESSAGE_LIMIT];
            
            if(board->undo == 0){
                // invalid as an undo operation as already been performed
                sendStatus[0] = MESSAGE_FAILURE;
            }
            else{
                //Need to undo 
                for(int i = 0  ; i < GRID_SIZE;i++){
                    for(int j = 0; j < GRID_SIZE;j++){
                        board->currentboard[i][j] = board->previousboard[i][j];
                    }
                } 
                //Set undo back to false as undo has been performed now
                board->undo = 0;
                
                //Server needs to send message to the client that move succeeded
                //The error handling for this operation is  contained within the client class 
                sendStatus[0] = MESSAGE_SUCCESS;
            }
            //Send the message to the client
            mq_send(clientQueue,sendStatus,strlen(sendStatus),0);
        } 
        
        //Need to perform the report operation
        else if(buffer[0] == REPORT_SERVER_COMMAND){
            //This char array includes all a report 
            //of the current board and adds new line 
            //characters accordingly
            char sendReport[MESSAGE_LIMIT];
            int charcount = 0;
            for(int i = 0 ; i < GRID_SIZE;i++){
                for(int j = 0 ; j < GRID_SIZE;j++){
                    sendReport[charcount++] = board -> currentboard[i][j];
                }
                sendReport[charcount++] = '\n';
            }
            //Putting a null terminator at the end of this character array
            sendReport[charcount] = '\0';
            
            //Sending the report to the client 
            mq_send(clientQueue,sendReport,strlen(sendReport),0);  
        }
        
        else {
            //If there was some other operation , send the character 'F' to indicate that
            // the command failed
            char sendStatus[MESSAGE_LIMIT];
            sendStatus[0] = MESSAGE_FAILURE;
            mq_send(clientQueue,sendStatus,strlen(sendStatus),0);
        }    
    }
    
    //Free the board struct created
    free(board);    
    
    // Close our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );    
    
    //Unlink or delete both of the queues
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );
    
    return 0;
}

