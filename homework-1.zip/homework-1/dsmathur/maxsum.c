/**
* @file maxsum.c
* @author dsmathur
* This program known as maxsum.c obtains the largest sum 
* from a sequence of provided integers , using multiple
* CPU cores to computationally solve this problem more
* efficiently and in less amount of time
*/

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
    printf( "usage: maxsum <workers>\n" );
    printf( "       maxsum <workers> report\n" );
    exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
    // Set up initial list and capacity.
    vCap = 5;
    vList = (int *) malloc( vCap * sizeof( int ) );
    
    // Keep reading as many values as we can.
    int v;
    while ( scanf( "%d", &v ) == 1 ) {
        // Grow the list if needed.
        if ( vCount >= vCap ) {
            vCap *= 2;
            vList = (int *) realloc( vList, vCap * sizeof( int ) );
        }
           
        // Store the latest value in the next array slot.
        vList[ vCount++ ] = v;
    }
}

int main( int argc, char *argv[] ) {
    bool report = false;
    int workers = 4;
    // Parse command-line arguments.
    if ( argc < 2 || argc > 3 )
        usage();
        
    if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
        workers < 1 )
        usage();

    // If there's a second argument, it better be the word, report
    if ( argc == 3 ) {
        if ( strcmp( argv[ 2 ], "report" ) != 0 )
        usage();
        report = true;
    }
    readList();

    //Make a pipe for talking with the children
    int pfd[2];
  
    //If the pipe creation is unsuccessful, exit out 
    if(pipe(pfd) !=0 ){
        fail("Can't create pipe");
    }
    
    // This variable holds the start index of the range 
    // Each child will get a copy of the parent's memory including 
    // the variables , hence it will also get its specific copy of the
    // range start index and will stick to it ,that is,  even if the parent updates
    // its range start index
    int rangeStartIndex  = 0;
    
    //Storing the number of workers 
    int  numWorkers = workers;
    
    //Make the child process
    pid_t id = fork();
    
    while(numWorkers > 0 ){
        
        //If it is the parent, make a child if it has not reached the limit yet
        if(id != 0 ){
            if(numWorkers -1  == 0 ){
                break;
            }
            //Increment the range start index for the next process
            rangeStartIndex++;
            
            //Creating a new process
            id = fork();
            if ( id == -1 ){
                fail( "Can't create child process" );
            }
            //Decrement the number of workers upon making a child
            numWorkers--;
        }
        
        //It is the child
        if( id == 0){
            // I am the child , hence i do not require the reading end of the pipe
            close(pfd[0]);
            //A variable to hold the maximum sum
            int maxSum = 0;
             
            //  A for loop that starts at the rangeStartIndex , but increments according
            // to the number of workers present.
            //  Through this way, each worker will get an equal share in the number 
            //  of operations it requires to perform
            for(int i  = rangeStartIndex;i < vCount;){
                int sum = 0;
                for(int j = i ; j < vCount; j++){
                    sum = sum + vList[j];
                    if(sum > maxSum){
                        maxSum = sum;
                    }
                }
                //Go to next range start index
                i = i + workers;
            }
            //If the command line argument has specified to include a report 
            // print the process ID of the current process
            if(report){
                pid_t  currentprocessID = getpid();
                printf("I'm process %d. The maximum sum I found is %d\n",currentprocessID,maxSum);
            }
            
            // Before writing the results the worker will lock the pipe
            lockf(pfd[1],F_LOCK,0);
            
            //Write the contents to the pipe
            int len  = write(pfd[1], &maxSum,sizeof(int) );
            if(len < 0){
                fail("Error writing to pipe");
            }
            
            //Unlock the pipe for other workers
            lockf(pfd[1],F_ULOCK,0);
            
            //Child is done
            _exit( EXIT_SUCCESS );
        }
    
    }
    
    // Wait for all the children to terminate before calculating the maximum sum
    for(int i = 0 ; i < workers;i++){
        wait(NULL);
    }
    
    //The parent can close the writing end of the pipe
    close(pfd[1]);
    
    
    //Keeping an array to read the local largest sum from each child
    int maxArray [ workers];
    
    //Reading the maximum values from the pipe
    int len  = read(pfd[0], maxArray, workers * sizeof(int));
    if(len < 0){
        fail("Error reading from pipe");
    }
    
    //Go through all of the values and find the max among them
    int max = maxArray[0];
    for(int i = 1 ; i < workers; i ++){
        if( maxArray[i] > max){
            max  = maxArray[i];
        }
    }
       
    //Print the maximum sum 
    printf("Maximum Sum: %d\n",max );
    
    return EXIT_SUCCESS;
}
