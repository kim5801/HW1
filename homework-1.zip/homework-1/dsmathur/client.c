/**
* @file client.c
* @author dsmathur
* This program client.c is an approach of interacting with 
* the server with the assistance of a message queue in order
* to perform operations such as move, undo , and report.
* The sole purpose of this class is to handle calls 
* to the server to perform operations and receive the results 
* as well as to do some error checks.
*/

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** The constant for holding the error message */
#define ERROR_MESSAGE "error"

/** A constant for holding the success message */
#define SUCCESS_MESSAGE "success\n"

/** A constant for holding the move command */
#define MOVE "move"

/** A constant for holding the undo command */
#define UNDO "undo"

/** A constant for holding report command */
#define REPORT "report"

/**
* Print out an error message and exit.
* @param message the fail message to present
*/
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

/**
* This incorporates most of the communication
* features required to contact the server 
* through the message queue and receive information
* from it simultaneously.
* @param argc  the number of command line arguments
* @param argv the command line argument
* @return an integer with regards to whether the program executed successfully or not
*/
int main( int argc, char *argv[] ) {
    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;
    
    //Opening the server message queue for writing purposes
    // This message queue is eventually read by the sever 
    // which will read the message/command to be processed
    mqd_t serverQueue = mq_open(SERVER_QUEUE,O_WRONLY,&attr);
    
    //Opening the client message queue for reading purposes
    mqd_t clientQueue = mq_open(CLIENT_QUEUE,O_RDONLY,&attr);
    
    if(clientQueue == -1 || serverQueue == -1){
        printf("haha");
    }
    
    // To represent whether a given command entered is valid or not
    bool invalidCommand = 0;
    
    if(argc  == 1){
      fail(ERROR_MESSAGE);
    }
    //If the given command is move , perform invalid checks 
    // and send the message to the server through the message
    // queue with regards to what command to execute
    if(strcmp(argv[1],MOVE) == 0){
        char buffer [MESSAGE_LIMIT];
        
        //Sending the character m to the server  to indicate
        // that a move operation requires to be performed
        buffer[0] = MOVE_SERVER_COMMAND;
        if(argc != 4){
               fail(ERROR_MESSAGE);
        }
        
        //Read the arguments related to the rows and columns
        // in integer terms
        int intRows = atoi(argv[2]);
        int intColumns = atoi(argv[3]);
        
        //Performing some invalid checks
        //If the row was not zero and the return value of 
        // atoi() function is 0 , this indicates that 
        // an error occurred with regards to processing the 
        // row value as an integer.
        if(strcmp(argv[2], "0") != 0){
            if(intRows <= 0  || intRows >= GRID_SIZE){
                invalidCommand = 1;
            }
        }
        
        //If the column was not zero and the return value of 
        // atoi() function is 0 , this indicates that 
        // an error occurred with regards to processing the 
        // column value as an integer.
        if(strcmp(argv[3], "0") != 0){
            if(intColumns<=0  || intColumns >= GRID_SIZE){
                invalidCommand = 1;
            }
        }
        
        //Since these integers are going to be sent in as characters 
        // to the server , we can insert the '0' along to convert 
        // them to ASCII characters
        buffer[1] = intRows + '0';
        buffer[2] = intColumns + '0';
        
        if(invalidCommand){
            fail(ERROR_MESSAGE);
        }
        else{
            //If the command was not invalid, send the message to the 
            // server queue, with the buffer set as the maximum 
            // message length
            mq_send(serverQueue,buffer,strlen(buffer),0 );
            
            //Receive the report from the server through the client 
            // queue regarding whether the process succeeded or not
            int len = mq_receive(clientQueue,buffer,sizeof(buffer),NULL);
            if(len < 0){
                printf("message queue failed\n");
            }
            
            //If the character in the buffer was 'S' , it indicates success
            if (buffer[0] == MESSAGE_SUCCESS){
                printf(SUCCESS_MESSAGE);
            }
            //If the character in the buffer was 'F', it indicates failure
            else if(buffer[0] == MESSAGE_FAILURE){
                fail(ERROR_MESSAGE);
            }
        }
    }
    
    //If the command to be performed is undo
    else if(strcmp(argv[1],UNDO) == 0){
        char buffer [MESSAGE_LIMIT];
        //Sending the character 'u' to the server to indicate
        // that an undo operation requires to be performed
        buffer[0] = UNDO_SERVER_COMMAND;
        if(argc != 2){
            fail(ERROR_MESSAGE);
        }
        else{
            //send the message to the sever through the server message queue
            mq_send(serverQueue,buffer,strlen(buffer),0 );
             
            //Receive the message regarding success or failure on the undo operation
            int len = mq_receive(clientQueue,buffer,sizeof(buffer),NULL);
            if(len < 0){
                printf("message queue failed");
            }
            //If the character in the buffer was 'S' , it indicates success
            if (buffer[0] == MESSAGE_SUCCESS){
                printf(SUCCESS_MESSAGE);
            }
            //If the character in the buffer was 'F', it indicates failure
            else if(buffer[0] == MESSAGE_FAILURE){
                fail(ERROR_MESSAGE);
            }
        }
    }
    //If the command to be performed is report
    else if(strcmp(argv[1],REPORT) == 0){
        char buffer [MESSAGE_LIMIT];
        //Sending the character 'r' to the server to indicate
        // that a report operation requires to be performed
        buffer[0] = REPORT_SERVER_COMMAND;
        char reportPrint[MESSAGE_LIMIT];
        
        if(argc != 2){
            fail(ERROR_MESSAGE);
        }
        else{
            //send the message to the sever through the server message queue
            mq_send(serverQueue,buffer,strlen(buffer),0 );
            //Receive the message consisting of the report 
            int len = mq_receive(clientQueue,reportPrint,sizeof(reportPrint),NULL);
             
            if(len < 0){
                printf("message queue failed\n");
            }
            //If the character in the reportPrint was 'F', it indicates failure
            if(reportPrint[0] == MESSAGE_FAILURE){
                fail(ERROR_MESSAGE);
            }
            //print out the report 
            printf("%s",reportPrint);
        }
    }
    else{ 
        fail(ERROR_MESSAGE);
    }
    
    // Close our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );
    
    return EXIT_SUCCESS;
}
