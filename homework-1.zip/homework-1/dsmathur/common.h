/**
* @file common.h
* @author dsmathur
* The common.h is a header file 
* that includes most of the constants
* that are utilized by both the classes,
* that is, client.c and server.c
*/

// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/dsmathur-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/dsmathur-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5

/** Character used for representing the move command in the server message queue*/
#define MOVE_SERVER_COMMAND 'm'

/** Character used for representing the undo command in the server message queue*/
#define UNDO_SERVER_COMMAND 'u'

/** Character used for representing the report command in the server message queue*/
#define REPORT_SERVER_COMMAND 'r'

/** The character used to represent success  in the message queue */
#define MESSAGE_SUCCESS 'S'

/** The character used to represent failure in the message queue*/
#define MESSAGE_FAILURE 'F'


