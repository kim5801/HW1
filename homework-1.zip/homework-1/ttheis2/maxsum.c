#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
 * Starting point of the program. Reads in args from the user and handles errors for 
 * incorrect output. Calculates the max of the given list using the specified number
 * of child processes.
 *
 * @param argc number of args
 * @param argv array of char pointers of all args
 * @return exit status 0 if successful, or 1 if there was an error.
 */
int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

  //make a pipe for children to talk to parent
  int p[ 2 ];
  if ( pipe( p ) != 0 ) {
    fail( "Can't create pipe" );
  }
  
  //first loop that loops through the workers (only the parent goes through this)
  for(int i = 0; i < workers; i++) {
  
    //creating the child processes need a number to reference later
    int isChild = fork();
    
    if(isChild == -1) {
      fail("Can't create child");
    }
    
    //catches all the children so they can calculate the maximums
    if(isChild == 0) {
      close(p[0]); //don't need to read because only children here
      int globalMax = 0;
      //Iterates through different starting points for each child based on what worker
      //(i) it is and increments by the number of workers, as described in the write up.
      for(int j = i; j < vCount; j += workers) {
        //initialize global max to the first index checked by this child
        if(j == i) {
          globalMax = vList[j];
        }
        //the current max for this particular value of j has to be reset before each nested 
        //loop
        int currentMax = 0;
        //Starts at the value of j (index we want to count from) and ends at the end of 
        //the list adding at each index so that each individual 'max' calculation is linear
        for(int k = j; k < vCount; k++) {
          if(k >= vCount) {
            //prevents overflow
            break;
          }
          //increment the current max
          currentMax += vList[k];
          
          //update the global max if necessary
          if(currentMax > globalMax) {
            globalMax = currentMax;
          }
        }
      }
      
      if(report) {
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), globalMax);
      }

      //locking the file descriptor so no other child process can write at the same time
      lockf( p[1] , F_LOCK, 0 );
        
      //writing this child's max to the other end of the pipe
      write(p[1], &globalMax, sizeof(int));
        
      //Unlocking the file descriptor
      lockf( p[1], F_ULOCK, 0 );

      exit(0);
    }
  }
  
  close(p[1]); //don't need to write because only parent here
  for(int i = 0; i < workers; i++) {
    wait(NULL); //wait until all the child processes are done running
  }
  
  int globalMax;
  int currentMax;
  //loop through all the workers and get their global maximums, compare them as we go
  //and replace parents global max if necessary.
  for(int i = 0; i < workers; i++) {
    //read the max values written in from the child processes
    read(p[0], &currentMax, sizeof(int));
    if(i == 0) {
      globalMax = currentMax;
    }
    //update global max if necessary
    if(currentMax > globalMax) {
      globalMax = currentMax;
    }
  }
  
  //report the final parent global max
  printf("Maximum Sum: %d\n", globalMax);

  return EXIT_SUCCESS;
}
