#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);
  if ( serverQueue == -1 || clientQueue == -1 ) {
    fail( "Can't create the needed message queues" );
  }

  if (argc == 4) {
    if (strcmp("move", argv[1])) {
      printf("error\n");
      exit(1);
    }

    char row;
    char col;
    if (argv[2][0] < '0' || argv[2][0] > '4') {
      printf("Invalid row\n");
      exit(1);
    }
    if (argv[3][0] < '0' || argv[3][0] > '4') {
      printf("Invalid col\n");
      exit(1);
    }
    if (strlen(argv[2]) != 1 || strlen(argv[3]) != 1) {
      printf("Invalid args\n");
      exit(1);
    }

    row = argv[2][0];
    col = argv[3][0];
    char buff[ 3 ];
    buff[0] = row;
    buff[1] = col;
    buff[2] = '\0';
    
    mq_send( serverQueue, buff, strlen(buff), 0);
    
    char buffer[ MESSAGE_LIMIT ];

    int len = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
    
    if (len >= 0) {
      for (int i = 0; i < len; i++) {
        printf("%c", buffer[i]);
      }
      printf("\n");
    } else {
      mq_close( clientQueue );
      mq_close( serverQueue );
      printf("Error receiving\n");
    }
    
    if (buffer[0] == 'e') {
//      free(buffer);
      exit(1);
    } else {
//      free(buffer);
      exit(0);
    } 
  }
  
  if (argc == 2) {
  
    if(strcmp("undo", argv[1]) && strcmp("report", argv[1])) {
      mq_close( clientQueue );
      mq_close( serverQueue );
      printf("error\n");
      exit(1);
    }
    
    if (!strcmp("undo", argv[1])) {
     //  printf("got to undo\n");
      char *u = "undo";
      mq_send(serverQueue, u, strlen(u), 0);  
      
      char buffer[ MESSAGE_LIMIT ];

      int len = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);

      if (len >= 0) {
        for (int i = 0; i < len; i++) {
          printf("%c", buffer[i]);
        }
        printf("\n");
      
      }else {
        mq_close( clientQueue );
        mq_close( serverQueue );
        printf("Error receiving\n");
      }
      
      if (buffer[0] == 'e') {
        exit(1);
      } else {
        exit(0);
      }
    }
    
    if (!strcmp("report", argv[1])) {
      //printf("got to report\n");
      char *r = "report";
      mq_send(serverQueue,r, strlen(r), 0);
    
      char buff[ MESSAGE_LIMIT ];
      //char *buffer = malloc(sizeof(char) * MESSAGE_LIMIT);
      
      int len = mq_receive(clientQueue, buff, sizeof(buff), NULL);
     //  printf("%d\n", len);
      if (len >= 0) {
        int linecnt = 0;
        //printf("1\n");
        for (int i = 0; i <= 24; i++) {
          if (linecnt == 5) {
            printf("\n");
            linecnt = 0;
            i--;
            //printf("2\n");
            continue;
          }
          printf("%c", buff[i]);
          //printf("3\n");
          linecnt++;
        }
        printf("\n");
        //free(buffer);
        exit(0); 
      } else {
        mq_close( clientQueue );
        mq_close( serverQueue );
        printf("Error receiving\n");
        //free(buffer);
        exit(1);
      }
    }
  } else {
    mq_close( clientQueue );
    mq_close( serverQueue );
    printf("error\n");
    exit(1);
  }
}