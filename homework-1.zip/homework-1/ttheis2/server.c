#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

static int gotSignal = 0;

void alarmHandler( int sig ) {
  gotSignal = 1;
}

//free the board struct and its fields
static void freeBoard(board *game) {
  free(game->oldGame);
  free(game->newGame);
  free(game);
}

static void makeMove(board *game, int idx) {
  if(game->newGame[idx] == '*') {
    game->newGame[idx] = '.';
  } else if (game->newGame[idx] == '.') {
    game->newGame[idx] = '*';
  }
}

static void undoMove(board *game) {
  for(int i = 0; i < 25; i++) {
    game->newGame[i] = game->oldGame[i];
  }
}

static void newBoard(board *game) {
  for(int i = 0; i < 25; i++) {
    game->oldGame[i] = game->newGame[i];
  }
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main( int argc, char *argv[] ) {

  struct sigaction act;
  act.sa_handler = alarmHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  if(argc != 2) {
    fail("usage: server<board-file>");
  }
  
  FILE* read = fopen(argv[1], "r");
  if(read == NULL) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }
  
  board* game = malloc(sizeof(board));
  game->oldGame = malloc(25 * sizeof(char));
  game->newGame = malloc(25 * sizeof(char));
  
  int cnt = 0;
  char ch = fgetc(read);
  bool newLine = true;
  
  while(ch != EOF) {
    if(cnt > 25) { //more than 25 chars
      freeBoard(game);
      fprintf( stderr, "Invalid input file: %s\n", argv[1]);
      exit(1);
    }
    
    if(ch != '.' && ch != '*' && ch != '\n') { //invalid character
      freeBoard(game);
      fprintf( stderr, "Invalid input file: %s\n", argv[1]);
      exit(1);
    }
    
    //if the count is at a "newLine" marker, but the new line has already passed
    //else if there is no newLine yet and it does not equal '\n' fail
    if(cnt % 5 == 0 && (ch == '*' || ch == '.') && newLine) {
      game->newGame[cnt] = ch;
      //printf("Count: %d, and ch: %c\n", cnt, ch);
      cnt++;
      ch = fgetc(read);
      newLine = false;
      continue;
    } else if ((cnt % 5 == 0 && ch != '\n') || ((cnt % 5 != 0) && ch == '\n')) {
      //printf("Count: %d, and ch: %c\n", cnt, ch);
      freeBoard(game);
      fprintf( stderr, "Invalid input file: %s\n", argv[1]);
      exit(1);
    }
    

    //don't increment cnt and don't add to array make newLine true
    if(ch == '\n') {
      ch  = fgetc(read);
      newLine = true;
      continue;
    }

    //add to array and increment count
    game->newGame[cnt] = ch;
    //printf("Count: %d, and ch: %c\n", cnt, ch);
    cnt++;
    ch = fgetc(read);
  }
  
//   int linecnt = 0;
//   for (int i = 0; i <= 24; i++) {
//     if (linecnt == 5) {
//       printf("\n");
//       linecnt = 0;
//       i--;
//       continue;
//     }
//     printf("%c", game->newGame[i]);
//     linecnt++;
//   }
//   printf("\n");

//     for (int i = 0; i <= 24; i++) {
//       printf("%d %c", i, game->newGame[i]);
//       printf("\n");
//     }
        

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // // Repeatedly read and process client messages.
  bool undo = false;
  while ( running ) {

    char buffer[ MESSAGE_LIMIT ];

    int len = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);
    //printf("%d\n", len);
    if (len == 2) {
      int row;
      int col;
      row = buffer[0] - '0';
      col = buffer[1] - '0';

      newBoard(game);

      int idx = (row * 5) + col;
      if (col > 0 && col < 4) {
        makeMove(game, idx);
        
        if (idx - 5 >= 0) {
          makeMove(game, idx - 5);
        }
        
        if (idx + 5 <= 24) {
          makeMove(game, idx + 5);
        }
        
        if (idx - 1 >= 0) {
          makeMove(game, idx - 1);
        }
        
        if (idx + 1 <= 24) {
          makeMove(game, idx + 1);
        }

      }
      else if (col == 0) {
        makeMove(game, idx);
        
        if (idx - 5 >= 0) {
          makeMove(game, idx - 5);
        }
        
        if (idx + 5 <= 24) {
          makeMove(game, idx + 5);
        }
        
        if (idx + 1 >= 0) {
          makeMove(game, idx + 1);
        }
      }
      else if (col == 4) {
        makeMove(game, idx);
        
        if (idx - 5 >= 0) {
          makeMove(game, idx - 5);
        }
        
        if (idx + 5 <= 24) {
          makeMove(game, idx + 5);
        }
        
        if (idx - 1 >= 0) {
          makeMove(game, idx - 1);
        }
      }
      undo = true;
      mq_send(clientQueue, "success", strlen("success"), 0);
    }
 
    if (len == 4) {
      if (undo) {
        undoMove(game);
        undo = false;
        mq_send(clientQueue, "success", strlen("success"), 0);    
      } else {
        mq_send(clientQueue, "error", strlen("error"), 0); 
      }
    }
    if (len == 6) {
      char buff[ MESSAGE_LIMIT ];
      for(int i = 0; i < 25; i++) {
        buff[i] = game->newGame[i];
      }
      buff[25] = '\0';
//     int linecnt = 0;
//     for (int i = 0; i <= 24; i++) {
//       if (linecnt == 5) {
//         printf("\n");
//         linecnt = 0;
//         i--;
//         continue;
//       }
//       printf("%c", buff[i]);
//       linecnt++;
//     }
//     printf("\n");
//     
//     for (int i = 0; i <= 24; i++) {
//       printf("%d %c", i, buff[i]);
//       printf("\n");
//     }
      mq_send(clientQueue, buff, strlen(buff), 0);
      //free(buffer);
    }
    if(gotSignal) {
      printf("\n");
      int linecnt = 0;
      for (int i = 0; i <= 24; i++) {
        if (linecnt == 5) {
          printf("\n");
          linecnt = 0;
          i--;
          continue;
        }
        printf("%c", game->newGame[i]);
        linecnt++;
      }
      printf("\n");
      mq_close( clientQueue );
      mq_close( serverQueue );

      mq_unlink( SERVER_QUEUE );
      mq_unlink( CLIENT_QUEUE );
      return 0;
    }
  }

  // if(gotSignal) {
//     printf("\n");
//     int linecnt = 0;
//     for (int i = 0; i <= 24; i++) {
//       if (linecnt == 5) {
//         printf("\n");
//         linecnt = 0;
//         i--;
//         continue;
//       }
//       printf("%c", game->newGame[i]);
//       linecnt++;
//     }
//     printf("\n");
//   }
  
  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
