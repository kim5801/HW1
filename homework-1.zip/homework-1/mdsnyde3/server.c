/*
   Stores the state of the lights out game board and receives commands from client
   to make moves, report the state of the board, and undo the previous move if possible
   Runs indefinitely until ^C is pressed
   @file server.c
   @author Madeline Snyder (mdsnyde3)
*/
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out an error message and exit.
static void failFile ( char const *message ) {
  fprintf( stderr, "Invalid input file: %s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

void sigHandler( int sig ) {
  running = 0;
}

int main( int argc, char *argv[] ) {
  //if we have too few arguments, give a usage statement
  if( argc != 2 ) {
    fail( "usage: server <board-file>" );
  }
  //create the board and the undo state of the board
  char board[ GRID_SIZE ][ GRID_SIZE ];
  char undoBoard[ GRID_SIZE ][ GRID_SIZE ];
  //open the file
  FILE *fp = fopen( argv[ 1 ], "r" );
  char ch;
  //check if the file is valid
  if( !fp ) {
    failFile( argv[ 1 ] );
  }
  //create counters to populate the board
  int rCounter = 0;
  int cCounter = 0;
  //read in file line by line
  while( ( (ch = fgetc( fp ) ) != EOF && rCounter < GRID_SIZE ) ) {
    //if we get a character other than . or * and are not expecting /n, error
    if ( cCounter < GRID_SIZE && ( ( ch != '.' ) && ( ch != '*' ) ) ) {
      failFile( argv[ 1 ] );
    }
    //if we get a newline, move to the next row and reset column counter
    if ( cCounter == GRID_SIZE && ( ch == '\n' ) ) {
      rCounter++;
      cCounter = 0;
    }
    //if we don't get a newline where we want one, error
    else if( cCounter == GRID_SIZE && ( ch != '\n' ) ) {
      failFile( argv[ 1 ] );
    }
    //set the board space to the char and move forward in the row
    else {
      board[ rCounter ][ cCounter ] = ch;
      cCounter++;
    }
  }
  //if we still have characters to read, invalid
  if( rCounter == GRID_SIZE && (ch = fgetc( fp ) ) != EOF ) {
    failFile( argv[ 1 ] );
  }
  
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );
    
  //strings for success and error
  char *success = "success";
  char *error = "error";
  //bit to tell if we're allowed to use undo command
  int undoBit = 1;
  // Repeatedly read and process client messages.
  while ( running ) {
    //handle possibility of ^C
    signal( SIGINT, sigHandler );
    
    //read in the command message
    char cmd[ MESSAGE_LIMIT + 1 ];
    int len = mq_receive( serverQueue, cmd, sizeof( cmd ), NULL );
    cmd[ len ] = '\0';
    //case for report command
    if ( strcmp( cmd, "report" ) == 0 ) {
      // turn the board into a string to send as a message
      char boardString[ 31 ];
      int counter = 0;
      //populate the string with the board elements, adding \n when appropriate
      for( int i = 0; i < GRID_SIZE; i++ ) {
        for( int j = 0; j < GRID_SIZE; j++ ) {
          boardString[ counter ] = board[ i ][ j ];
          counter++;
        }
        boardString[ counter ] = '\n';
        counter++;
      }
      boardString[ counter ] = '\0';
      //send back the string to the client
      mq_send( clientQueue, boardString, strlen( boardString ), 0 );
      
    }
    //case for undo command
    else if( strcmp( cmd, "undo" ) == 0 ) {
      //if we have just called undo, error
      if( undoBit ) {
        mq_send( clientQueue, error, strlen( error ), 0 );
      }
      // set the board to its previous state
      else {
        for( int i = 0; i < GRID_SIZE; i++ ) {
          for( int j = 0; j < GRID_SIZE; j++ ) {
            board[ i ][ j ] = undoBoard[ i ][ j ];
          }
        }
        //indicate we have just called undo
        undoBit = 1;
        //report success
        mq_send( clientQueue, success, strlen( success ), 0 );
      }
    }
    //case for move command
    else {
      //populate state of undo board
      for( int i = 0; i < GRID_SIZE; i++ ) {
        for( int j = 0; j < GRID_SIZE; j++ ) {
          undoBoard[ i ][ j ] = board[ i ][ j ];
        }
      }
      //make it safe to undo
      undoBit = 0;
      //get the row number
      char rowString[ MESSAGE_LIMIT ];
      int rLen = mq_receive( serverQueue, rowString, sizeof( rowString ), NULL );
      rowString[ rLen ] = '\0';
      int row = atoi( rowString );
      
      //get the col number
      char colString[ MESSAGE_LIMIT ];
      int cLen = mq_receive( serverQueue, colString, sizeof( colString ), NULL );
      colString[ cLen ] = '\0';
      int col = atoi( colString );
      
      //change surrounding spaces on the board
      for( int k = -1; k < 2; k++ ) {
        //make sure we are in bounds for the array, then flip the . to * and vice versa
        if( (row + k ) >= 0 && (row + k) < GRID_SIZE ) {
          if ( board[ row + k ][ col ] == '.' ) {
            board[ row + k ][ col ] = '*';
          }
          else {
            board[ row + k ][ col ] = '.';
          }
        }
        //make sure we are in bounds and we haven't already changed the space, then flip the characters
        if( ( ( col + k ) >= 0 && ( col + k) < GRID_SIZE ) && k != 0 ) {
          if ( board[ row ][ col + k ] == '.' ) {
            board[ row ][ col + k ] = '*';
          }
          else {
            board[ row ][ col + k ] = '.';
          }
        }
      }
      //send success message
      mq_send( clientQueue, success, strlen( success ), 0 );
      
    }
    
  }
  
  //print state of board
  printf( "\n" );
  for( int a = 0; a < GRID_SIZE; a++ ) {
    for( int b = 0; b < GRID_SIZE; b++ ) {
      printf( "%c", board[ a ][ b ] );
    }
    printf( "\n" );
  }
  //close file pointer
  fclose( fp );
  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
