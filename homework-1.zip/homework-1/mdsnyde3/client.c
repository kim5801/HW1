/*
   Communicates with the server via message queues, taking command line arguments
   and passing them to the server to make moves in the game, then waits for a response
   and prints out the success or error.
   @file client.c
   @author Madeline Snyder (mdsnyde3)
*/
#include "common.h"
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );


  //if we have less than 2 command line arguments (including ./client), we have an error
  if ( argc < 2 ) {
    printf( "error\n" );
    exit( 1 );
  }
  // see if we have the report command
  if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    // if we do not have exactly 2 args, we have an error
    if ( argc != 2 ) {
      printf( "error\n" );
      exit( 1 );
    } 
    //send the command line argument to the server
    mq_send( serverQueue, argv[ 1 ], strlen( argv[ 1 ] ), 0 );
    char cmd[ MESSAGE_LIMIT ];
    //receive the state of the board as a string
    int len = mq_receive( clientQueue, cmd, sizeof( cmd ), NULL );
    
    //fill board with the message
    char board[ GRID_SIZE ][ GRID_SIZE ];
    int counter = 0;
    int rC = 0;
    int cC = 0;
    //work our way through the string, and move to the next row if we get a newline
    while( counter < len ) {
      if( cmd[ counter ] == '\n' ) {
        rC++;
        cC = 0;
        counter++;
      }
      else {
        board[ rC ][ cC ] = cmd[ counter ];
        counter++;
        cC++;
      }
    }
    
    //print out the state of the board character by character with newlines when appropriate
    for( int i = 0; i < GRID_SIZE; i++ ) {
      for( int j = 0; j < GRID_SIZE; j++ ) {
        printf( "%c", board[ i ][ j ] );
      }
      printf( "\n" );
    }
  }
  // see if we have the undo command
  else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    // if we do not have exactly 2 args, we have an error
    if ( argc != 2 ) {
      printf( "error\n" );
      exit( 1 );
    }
    
    //send the command line argument to server
    mq_send( serverQueue, argv[ 1 ], strlen( argv[ 1 ] ), 0 );
    char cmd[ MESSAGE_LIMIT ];
    //receive either a success or error
    int len = mq_receive( clientQueue, cmd, sizeof( cmd ), NULL );
    //print out the success or error
    for( int i = 0; i < len; i++ ) {
      printf( "%c", cmd[ i ] );
    }
    printf( "\n" );
  }
  // see if we have the move command
  else if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
    // if we do not have the move command plus two values for row and column, we have an error
    if ( argc != 4 ) {
      printf( "error\n" );
      exit( 1 );
    }
    // if the args are not valid digits, print an error
    if ( ( (strlen( argv[ 2 ] ) != 1) && !isdigit( argv[ 2 ][ 0 ] ) ) || ( (strlen( argv[ 3 ] ) != 1) && !isdigit( argv[ 3 ][ 0 ] ) ) ) {
      printf( "error\n" );
      exit( 1 );
    }
    // if the args are not between 0 and 4, print an error
    if ( atoi( argv[ 2 ] ) < 0 || atoi( argv[ 2 ] ) > 4 ) {
      printf( "error\n" );
      exit( 1 );
    }
    if ( atoi( argv[ 3 ] ) < 0 || atoi( argv[ 3 ] ) > 4 ) {
      printf( "error\n" );
      exit( 1 );
    }
    
    //send the move command, then the row, then the column to the server
    mq_send( serverQueue, argv[ 1 ], strlen( argv[ 1 ] ), 0 );
    mq_send( serverQueue, argv[ 2 ], strlen( argv[ 2 ] ), 0 );
    mq_send( serverQueue, argv[ 3 ], strlen( argv[ 3 ] ), 0 );
    char cmd[ MESSAGE_LIMIT ];
    //wait for a message of success/failure after the move
    int len = mq_receive( clientQueue, cmd, sizeof( cmd ), NULL );
    //print out response (success or failure)
    for( int i = 0; i < len; i++ ) {
      printf( "%c", cmd[ i ] );
    }
    printf( "\n" );
  }
  // if we did not get any of the above commands, it is invalid and we print an error
  else {
    printf( "error\n" );
    exit( 1 );
  }
  //close the message queues
  mq_close( serverQueue );
  mq_close( clientQueue );
  // exit successfully
  exit( EXIT_SUCCESS );
  
}
