/*
   Takes in a list of integer values and finds the largest possible sum using multiple child processes.
   @file maxsum.c
   @author Madeline Snyder (mdsnyde3)
*/

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

  //create pipe
  int pfd[2];
  
  if ( pipe( pfd ) != 0 ) {
    fail( "Can't create pipe" );
  }
  // initialize the max sum to the first value in the list as a placeholder
  int maxSum = vList[ 0 ];
  // counter for how many times one child process must execute
  int divCount = 0;
  // for loop for creating "workers" aka child processes
  for( int w = 0; w < workers; w++ ) {
    // check if we are the child process
    if ( fork() == 0 ) {
      // close the end of the pipe we don't need
      close( pfd[ 0 ] );
      
      // variable for the maximum sum each child process can find
      int subMax = vList[ w ];
      // variable for the sum on each pass through the array
      int miniSum = 0;
      // iterate through the list of values, starting at the index corresponding to the worker number
      for( int i = w; i < vCount; i++ ) {
        // add the current value to the miniSum
        miniSum += vList[ i ];
        // check if we have found a greater sum
        if ( miniSum > subMax ) {
          subMax = miniSum;
        }
        //if we have made it through one iteration, adjust the starting point of this for loop
        if ( i == vCount - 1 ) {
          // increase how many times we are using this worker
          divCount++;
          // we now start the loop at our original point plus the product of how many workers we have and how many times we will use the worker
          i = w + ( workers * divCount );
          // reset the mini sum
          miniSum = 0;
        }
      }
      // lock pipe
      lockf( pfd[ 1 ], F_LOCK, 0 );
      
      // write into the pipe if possible
      int len = write( pfd[ 1 ], &subMax, sizeof( int ) );
      if ( len < 0 ) {
        fail( "Error writing to pipe" );
      }
      // unlock pipe
      lockf( pfd[ 1 ], F_ULOCK, 0 );
      
      // if the report flag is on, print out what process you are and the max sum you found
      if ( report ) {
        printf( "I'm process %d. The maximum sum I found was %d.\n", getpid(), subMax );
      }
      // exit successfully
      exit( EXIT_SUCCESS );
    }
    // we are the parent
  }
  // loop through and wait
  for( int j = 0; j < workers; j++ ) {
    // read in the sum from the pipe
    int newSum;
    int len = read( pfd[ 0 ], &newSum, sizeof( int ) );
    if ( len < 0 ) {
      fail( "Error reading from pipe" );
    }
    // if we have found a greater sum, replace the maxSum value
    if ( newSum > maxSum ) {
      maxSum = newSum;
    }
    wait( NULL );
  }
  // print out final maximum sum
  printf( "Maximum Sum: %d\n", maxSum );
  
  // close the pipe
  close( pfd[ 1 ] );
  close( pfd[ 0 ] );

  return EXIT_SUCCESS;
}
