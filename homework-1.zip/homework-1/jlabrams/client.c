/**
    sends game info to the server and receives the results from the server
    @file client.c
    @author Jaden Abrams (jlabrams)
*/
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/**
    Prints a custom error message and exits.
    @param message the error message
*/
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

/**
    Diagnoses what could have made mq_receive fail.
*/
static void mqDiagnose() {
    int errsv = errno;
    if(errsv == EAGAIN) {
        fail("we're in non-blocking mode");
    }
    else if(errsv == EINTR) {
        fail("There was an interrupt");
    }
    else if(errsv == EMSGSIZE) {
        fail("The third parameter controlling message length is not correct");
    }
    else {
        fail("We're getting a weird error");
    }
}

/**
    cleans up the connections to the queues
    @param one the first queue
    @param two the second queue
*/
static void closeQueues(mqd_t one, mqd_t two) {
    mq_close( one );
    mq_close( two );
}

/**
    The main part of the client that does things.
    @param argc number of args given
    @param argv the args given
    @return the program exit status
*/
int main(int argc, char *argv[]) {
    // handle weird inputs
    if(argc != 2 && argc != 4) {
        fail("Invalid command.");
    }


    // Make both the server and client message queues.
    // send data to the server
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
    // receive data from the server
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);

    // this is where we execute our commands

    // performs move operations
    if(argc == 4) {
        if(strcmp("move", argv[1]) != 0) {
            fail("Invalid command");
        }
        int r;
        int c;

        if(sscanf(argv[2], "%d", &r) != 1 || sscanf(argv[3], "%d", &c) != 1) {
            fail("Invalid command");
        }
        
        if(r < 0 || r > (GRID_SIZE - 1) || c < 0 || c > (GRID_SIZE - 1)) {
            fail("Grid coordinates out of bounds");
        }

        char msg[2] = {'0' + r, '0' + c};
        mq_send( serverQueue, msg, sizeof(msg), 0);
        char response[8];

        int numRec = mq_receive(clientQueue, response, sizeof(char) * MESSAGE_LIMIT, NULL);
        if(numRec == -1) {
            mqDiagnose();
        }

        printf("%s\n", response);
        closeQueues(serverQueue, clientQueue);
        return 0;
    }

    // do the report
    if(strcmp("report", argv[1]) == 0) {
        // NOTE: we may need to standardize how much we send to the server to make things easier
        mq_send(serverQueue, "r", 1, 0);
        // sleep(10);
        char board[GRID_SIZE * GRID_SIZE];

        int numRec = mq_receive(clientQueue, board, sizeof(char) * MESSAGE_LIMIT, NULL);
        if(numRec == -1) {
            mqDiagnose();
        }
        int pos = 0;
        for(int i = 0; i < GRID_SIZE; i++) {
            for(int j = 0; j < GRID_SIZE; j++) {
                putchar(board[pos]);
                pos++;
            }
            printf("\n");
        }
        printf("\n");
        closeQueues(serverQueue, clientQueue);
        return 0;
    }

    if(strcmp("undo", argv[1]) == 0) {
        mq_send(serverQueue, "s", 1, 0);

        char response[8];

        int numRec = mq_receive(clientQueue, response, sizeof(char) * MESSAGE_LIMIT, NULL);
        if(numRec == -1) {
            mqDiagnose();
        }

        printf("%s\n", response);
        closeQueues(serverQueue, clientQueue);
        return 0;
    }

    closeQueues(serverQueue, clientQueue);
    fail("Invalid command.");
}