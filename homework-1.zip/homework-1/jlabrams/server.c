/**
  Server for processing moves from the client.
  @file server.c
  @author Jaden Abrams (jlabrams)
*/

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/**
  Exits the program for us with a custom message in standard error.
  @param message message to print
*/
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

static char board[GRID_SIZE][GRID_SIZE];

/**
  Change the variable that keeps the server running.
  @param sig the signal handle (not used)
*/
static void intHandler(int sig) {
  running = 0;
}

/**
  Helps make flipper code cleaner.
  @param j row
  @param k column
*/
static void flipHelper(int j, int k) {
  if(board[j][k] == '.') {
    board[j][k] = '*';
  }
  else {
    board[j][k] = '.';
  }
}

/**
  Flips the lights on the board
  @param j row to flip
  @param k column to flip
*/
static void flipper(int j, int k) {
  flipHelper(j, k);
  // corners
  if( j == 0 && k == 0) {
    flipHelper(j, k+1);
    flipHelper(j+1, k);
  }
  else if( j == 0 && k == (GRID_SIZE - 1) ) {
    flipHelper(j, k + 1);
    flipHelper(j + 1, k);

  }
  else if(j == (GRID_SIZE - 1) && k == 0) {
    flipHelper(j - 1, k);
    flipHelper(j, k + 1);
  }
  else if(j == (GRID_SIZE - 1) && k == (GRID_SIZE - 1)) {
    flipHelper(j - 1, k);
    flipHelper(j, k - 1);
  }
  // edges
  else if(j == 0) {
    flipHelper(j, k - 1);
    flipHelper(j + 1, k);
    flipHelper(j, k + 1);
  }
  else if(j == (GRID_SIZE - 1)) {
    flipHelper(j, k - 1);
    flipHelper(j - 1, k);
    flipHelper(j, k + 1);
  }
  else if(k == 0) {
    flipHelper(j - 1, k);
    flipHelper(j, k + 1);
    flipHelper(j + 1, k);
  }
  else if(k == (GRID_SIZE - 1)) {
    flipHelper(j - 1, k);
    flipHelper(j, k - 1);
    flipHelper(j + 1, k);
  }
  // everything else
  else {
    flipHelper(j - 1, k);
    flipHelper(j, k - 1);
    flipHelper(j + 1, k);
    flipHelper(j, k + 1);
  }

}

/**
  runs the server.
  @param argc number of arguments fed to the program
  @param argv the arguments fed to the program
  @return exit status
*/
int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;


  // check that the arguments are correct
  if(argc != 2) {
    fail("usage: server <board-file>");
  }

  FILE *fp = NULL;

  char failMessageInput[] = "Invalid input file: ";
  strcat(failMessageInput, argv[1]);
  fp = fopen(argv[1], "r");

  if(fp == NULL) {
    fail(failMessageInput);
  }


  // read in the board and check for validity
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      char fromIO = fgetc(fp);
      if(fromIO == '\n') {
        fromIO = fgetc(fp);
      }
      if(fromIO == '.' || fromIO == '*') {
        board[i][j] = fromIO;
      }
      else if(fromIO != '\n') {
        fail(failMessageInput);
      }
    }
  } // check file end behavior
  char lastChar = fgetc(fp);
  if(lastChar != '\n' && lastChar != EOF) {
    fclose(fp);
    fail(failMessageInput);
  }
  lastChar = fgetc(fp);
  if(lastChar != EOF) {
    fclose(fp);
    fail(failMessageInput);
  }
  fclose(fp);
  // at this point we should have everything loaded from files

  // Make both the server and client message queues.
  // receive data from the client
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  // sends data to the client
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );


  // set up the handler for signal interrupts
  struct sigaction act;
  act.sa_handler = intHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction(SIGINT, &act, 0);

  // keep track of the last move
  int last[2] = {-1, -1};
  // holds the sent message
  char msg[2];
  while ( running ) {

    int len = mq_receive(serverQueue, msg, sizeof(int) * MESSAGE_LIMIT, NULL);
    if(len == 1) { // we must have gotten someone asking for a report or to undo
      // send the board
      if(msg[0] == 'r') {// we must have gotten a report request
        char sendBoard[GRID_SIZE * GRID_SIZE];
        int pos = 0;
        for(int i = 0; i < GRID_SIZE; i++) {
          for(int j = 0; j < GRID_SIZE; j++) {
            sendBoard[pos] = board[i][j];
            pos++;
          }
        }
        mq_send(clientQueue, sendBoard, GRID_SIZE * GRID_SIZE, 0);
      }
      else { // we must have gotten an undo request
        if(last[0] == -1 || last[1] == -1) {
          char failure[] = "ERROR  ";
          mq_send(clientQueue, failure, strlen(failure) + 1, 0);
        }
        else { // there is a previous action to rever to
          flipper(last[0],last[1]);
          char success[] = "SUCCESS";
          last[0] = -1;
          last[1] = -1;
          mq_send(clientQueue, success, strlen(success) + 1, 0);
        }
      }
    }
    if(len == 2) {
      // get the int versions of the input
      int r = msg[0] - '0';
      int c = msg[1] - '0';
      flipper(r, c);
      char success[] = "SUCCESS";
      mq_send(clientQueue, success, strlen(success) + 1, 0);
      last[0] = r;
      last[1] = c;
    } // attempt to report errors we get
    if(len == -1) {
      int errsv = errno;
      if(errsv == EAGAIN) {
        mq_close( clientQueue );
        mq_close( serverQueue );

        mq_unlink( SERVER_QUEUE );
        mq_unlink( CLIENT_QUEUE );
        fail("The program is in non-blocking mode\n");
      }
      else if(errsv == EINTR) { // this is so we don't fail under normal circumstances
        continue; // if you need to keep track of interrupts, just add in a print statement.
      }
      else if(errsv == EMSGSIZE) {
        mq_close( clientQueue );
        mq_close( serverQueue );

        mq_unlink( SERVER_QUEUE );
        mq_unlink( CLIENT_QUEUE );
        fail("the third parameter in mq_receive is not right compared to queue msg length");
      }
      else {
        mq_close( clientQueue );
        mq_close( serverQueue );

        mq_unlink( SERVER_QUEUE );
        mq_unlink( CLIENT_QUEUE );
        fail("We're getting a weird error.");
      }
    }
  }

  printf("\n");// print out board after execution
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      putchar(board[i][j]);
    }
    putchar('\n');
  }
  printf("\n");
  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
