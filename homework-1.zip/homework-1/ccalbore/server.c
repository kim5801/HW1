/**
 * @file server.c
 * @author Christina Albores (ccalbore)
 * @brief Continuously takes in messages from client for game commands,
 * executes them and messages back if they are successful or not.
 * @date 2022-09-15
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>


// GameBoard representation for storing the state of the board in the server. 
typedef struct game_board
{
    char board[GRID_SIZE][GRID_SIZE];

}GameBoard;


// Print out an error message with file name and exit.
static void failFile( char const *message, char const *fileName ) {
  fprintf( stderr, "%s%s\n", message, fileName);
  exit( 1 );
}


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief If the given board file is invalid (if the file doesn’t exist, if it isn’t in this format or it contains
 * characters other than ’.’, ’*’ and newlines) the server should terminate unsuccessfully and print the
 * following usage message to standard error, where filename is the name of the name of the board file
 * given on the command line:
 * Invalid input file: filename
 * 
 * @param board the board
 * @param readFile the file to read
 * @param fileName the file name
 */
void setGameBoard(GameBoard* board, FILE **readFile, char* fileName)
{
    // Open the file
    *readFile = fopen(fileName, "r");

    // If problem opening the file, print error and exit
    if(readFile == NULL)
    {
        failFile("Invalid input file1: ", fileName);
    }
    
    // Get the char in the file
    char c = fgetc(*readFile);
  
    // Keeps count of row 
    int rowIndex = 0; 
     // Keeps count of column 
    int colIndex = 0;
    // While the char is not EOF
    while (c != EOF) {
        
        // If the symbol is valid, print error and exit
        if (c != '.' && c != '*' && c != '\n') {
            failFile("Invalid input file2: ", fileName);
        }
        // If the char is a new line
        if (c == '\n') {
            
            // If there has not been exactly 5 chars, print error and exit
            if (colIndex != 5) {
                failFile("Invalid input file3: ", fileName);
            } else {
                // Rewind the column index
                colIndex = 0;
                // Update the row index
                rowIndex++;
                // If the row index is about 5, print error and exit
                if (rowIndex > 5) {
                    failFile("Invalid input file4: ", fileName);
                }
            }
        } else {
            // Keep printing the char to the board and update column index
            board->board[rowIndex][colIndex] = c;
            colIndex++;
        }
        // Get the next char
        c = fgetc(*readFile);
    }
    
}

/**
 * @brief Prints out the game board
 * 
 * @param board the board to print
 */
void printGameBoard(GameBoard* board)
{
    for (int i = 0; i < GRID_SIZE; i++)
    {
        for (int j = 0; j < GRID_SIZE; j++)
        {
            char c = board->board[i][j];
            printf("%c", c);
            
        }
        printf("\n");
    }
}

/**
 * @brief Updates the game board by performing the given move
 * 
 * @param board the board to update
 * @param row the row the move is on
 * @param col the column the move is on
 * @return int returns status
 */
int updateGameBoard(GameBoard* board, int row, int col) 
{
    // Alwasy return successful since the moves are checked before hand
    int status = 0;

    // Toggles the on/off for row and col
    if (board->board[row][col] == '.') {
        board->board[row][col] = '*';
    } else {
        board->board[row][col] = '.';
    }

    // Toggles the on/off for row - 1 and col if possible
    if ((row - 1) >= 0) {
      if (board->board[(row - 1)][col] == '.') {
        board->board[(row - 1)][col] = '*';
      } else {
          board->board[(row - 1)][col] = '.';
      }
    }

    // Toggles the on/off for row + 1 and col if possible
    if ((row + 1) <= 4) {
      if (board->board[(row + 1)][col] == '.') {
        board->board[(row + 1)][col] = '*';
      } else {
          board->board[(row + 1)][col] = '.';
      }
    }

    // Toggles the on/off for row and col + 1 if possible
    if ((col + 1) <= 4) {
      if (board->board[row][(col + 1)] == '.') {
        board->board[row][(col + 1)] = '*';
      } else {
          board->board[row][(col + 1)] = '.';
      }
    }

    // Toggles the on/off for row and col - 1 if possible
    if ((col - 1) >= 0) {
      if (board->board[row][(col - 1)] == '.') {
        board->board[row][(col - 1)] = '*';
      } else {
          board->board[row][(col - 1)] = '.';
      }
    }
    
    return status;
}


// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

/**
 * @brief If ^C detected this stops the while loop
 * 
 * @param sig signal parameter
 */
void alarmHandler(int sig) {
  running = 0;
}

/**
 * @brief Continuously takes in messages from client for game commands,
 * executes them and messages back if they are successful or not.
 * 
 * @param argc the number of arguments
 * @param argv the list of arguments
 * @return int returns success
 */
int main( int argc, char *argv[] ) {

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );


  // If the user runs the server with bad command-line arguments (e.g., too many arguments or missing
  // the board file name), it should exit unsuccessfully and print the usage message to standard
  // error.
  if (argc != 2) {
    fail("usage: server <board-file>");
  }


  struct sigaction act;
  // Fill in a structure to redirect the alarm signal.
  act.sa_handler = alarmHandler;
  sigemptyset(&(act.sa_mask));
  act.sa_flags = 0;
  sigaction(SIGINT, &act, 0);

  // Read the file and start the board

  // Your server will be responsible for storing the state of the game board and keeping up with the most
  // recent move to support the undo operation. 

  // File to read in baord
  FILE* readFile;
  char* fileName = argv[1];
  // GameBoard struct board
  GameBoard board;
  // Takes in the file and constructs the board
  setGameBoard(&board, &readFile, fileName);

  // Buffer to receive the message
  char bufferRev[MESSAGE_LIMIT];
  // Buffer to hold the command
  char command[MESSAGE_LIMIT];
  // Message to send back to client if the move failed.
  char fail[] = "failure";
  // Message to send back to client if the move succeeded.
  char success[] = "success";
  // The current row
  int row = 0;
  // The current column
  int col = 0;
  // Flag for if undo command has already been done
  int undoFlag = 0;
  // The last move for row
  int oldRow = 0;
  // Th elast move for column
  int oldCol = 0;

  // While no ^C signal detected
  while ( running ) {
  
    // Try to get a message 
    int lenRev = mq_receive( serverQueue, bufferRev, sizeof( bufferRev ), NULL );
     printf("passed\n");
    if ( lenRev >= 0 ) {
        printf("%s\n", bufferRev);
    } else{
        printf("Receiving error\n");
    }
  
    // String length of the buffer
    int len = strlen(bufferRev);

    // If the length is 8, the command is move
    if (len == 8) {

        strcpy(command, "move");
        // Get the row and column values in integer
        row = bufferRev[5] - '0';
        col = bufferRev[7] - '0';
        // Back up the move
        oldRow = row;
        oldCol = col;
        
    } else if (len == 6) {
        // If the command length is 6, the command is report
        strcpy(command, "report");
        
    } else if (len == 4) {
      // If the command length is 4, the command is report
        strcpy(command, "undo");
    }

    // Use the command buffer to execute the command
    if (strcmp(command, "move") == 0) {
      // The the status of the move
      int status = updateGameBoard(&board, row, col);
      // Indicate that there has not been an undo move
      undoFlag = 0;

      // Send status success or fail
      if (status == 0) {
        if (mq_send( clientQueue, success, strlen( success ), 0 ) == -1) {
            printf(("Sending error\n"));
        }
      } else {
        
        if (mq_send( clientQueue, fail, strlen( fail ), 0 ) == -1) {
            printf(("Sending error\n"));
        }
        
      }

    } else if (strcmp(command, "report") == 0) {
      // Print the board
      printGameBoard(&board);
      // Indicate that there has not been an undo move
      undoFlag = 0;

    } else if (strcmp(command, "undo") == 0) {
      
      // Send status success or fail
      if (undoFlag == 0) {
          // Execute the undo move
          updateGameBoard(&board, oldRow, oldCol);
          if (mq_send( clientQueue, success, strlen( success ), 0 ) == -1) {
            printf(("Sending error\n"));
          }
          // Indicate that there has been an undo move
          undoFlag = 1;
      } else {
        if (mq_send( clientQueue, fail, strlen( fail ), 0 ) == -1) {
            printf(("Sending error\n"));
        }
      }
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Reporting a final state of the board before the program exits.
  printf("\n");
  printGameBoard(&board);

  return 0;
}