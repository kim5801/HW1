/**
 * @file maxsum.c
 * @author Christina Albores (ccalbore)
 * @brief This program finds a contiguous non-empty
 * subsequence within the sequence that has the largest sum.
 * 
 */
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}
/**
 * @brief The main program.
 * 
 * @param argc The number of arguments
 * @param argv The list of arguments
 * @return returns 0 if executed correctlu
 */
int main( int argc, char *argv[] ) {
  // Flag for if the child needs to report its pid ID
  bool report = false;
  // The number of workers to use
  int workers = 4;
  
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it betteint r be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Call readList and get the number sequence 
  readList();
  // The size of the list of ints
  int size = vCount;

  //Make a pipe
  int pfd[2];
  if ( pipe( pfd ) != 0 ) {
    fail( "Can't create pipe" );
  }


  //After reading the input sequence, the parent will fork() to create each worker

  // A list of workers
  pid_t pid[workers];

  // Iterate through each worker
  for (int i = 0; i < workers; i++) {
      // Fork to create the worker
      pid_t child = fork();
      pid[i] = child;

      if (pid[i] == -1) {
        // fail
          fail( "Can't create child process" );

      } else if (pid[i] == 0) {
        // child 
        // Close the reading end of the pipe 
        close(pfd[0]);
        
        // The max sum found
        int maxSum = 0;
        // The index to start at in the range for this worker
        int startIndex = i;
        
        //For each index this worker has to calculate the range
        for (int j = 0; j < (size / workers); j++) {
            
            // Keeps track of the current sum of the range
            int totalSum = 0;
            
            // For each k get the sum of the range from j to k
            for (int k = 0; k < size - startIndex; k++) {
                // The current sum of the range
               int sumRange = totalSum;
                
                // Add the value at the index to the range
               sumRange += vList[startIndex + k];
               // Add that sum range to the total range
               totalSum = sumRange;
                
                // If the current sum range is bigger than the max sum
                // make that the new max sum range
                if (sumRange > maxSum) {
                    maxSum = sumRange;
                }
            }
            // Move the start index forward based on worker position
            startIndex += workers;
        }

        // If the report flag is true, print out the pid ID of the worker
        // Else just print the max sum for that range found
        if (report == true) {

            printf("I’m process %d. The maximum sum I found is %d.\n", getpid(), maxSum);
            
        } else {
            printf("The maximum sum I found is. %d.\n", maxSum);
        }

        // Make it so the worker writes to the writing end of the pipe 
        dup2(pfd[1], STDOUT_FILENO);
        // Send out lock signal for starting
        lockf( pfd[1], F_LOCK, 0 );
        // Write the max sum to the pipe
        write(pfd[1], &maxSum, sizeof(maxSum));
        // Send out lock signal for finished
        lockf( pfd[1], F_ULOCK, 0 );
        // Close the writing end of the pipe for the worker
        close(pfd[1]);
        // The worker is done
         _exit(EXIT_SUCCESS);
      }
   }

//parent

    // Wait for each worker to finish
    for (int i = 0; i < workers; i++) {
        wait(NULL);
    }
    // Close the writing end of the pipe for the parent
    close(pfd[1]);
    // The final max sum found from the workers 
    int finalMaxSum = 0;
    // The worker max sum found
    int childMax = 0;
    
    // Make it so the parent reads from the reading end of the pipe
    dup2(pfd[0], STDIN_FILENO);
    
    // The statue of the read() function. End when no more reads from the workers
    int status = read(pfd[0], &childMax, sizeof(childMax));
    while ( status > 0) {
        
        // If the worker max sum is bigger update the final max sum value
        if (childMax > finalMaxSum) {
            finalMaxSum = childMax;
        }
        
        // Take in another reading
        status = read(pfd[0], &childMax, sizeof(int));
    }
   
    // Close the reading end of the pipe for the parent
    close(pfd[0]);
    
    printf("Maximum Sum: %d\n", finalMaxSum);

  return 0;
}