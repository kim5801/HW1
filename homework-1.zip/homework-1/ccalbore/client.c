/**
 * @file client.c
 * @author Christina Albores (ccalbore)
 * @brief Sends the valid client move to the server.
 * @date 2022-09-15
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/**
 * @brief Sends the valid client move to the server.
 * 
 * @param argc the number of arguments
 * @param argv the list of arguments
 * @return int returns success
 */
int main( int argc, char *argv[] ) {

    // Open the message queue for talking.
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY);
    if ( clientQueue == -1 ) {
        printf("error\n");
        exit(1);
    }

    // Open the message queue for reading.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY);
    if ( serverQueue == -1 ) {
        printf("error\n");
        exit(1);
    }

    // The message to send out
    char bufferSend[MESSAGE_LIMIT] = "";
    // The message to receive
    char bufferRev[MESSAGE_LIMIT];

    // If there are 4 arguments, that means its a move command
    if (argc == 4) {
        
        // Error checking. If the command is not move, print error
        if (strcmp(argv[1], "move") != 0) {
            printf("error\n");
        } else {
            // Get the int values for row and column
            int row = atoi(argv[2]);
            int col = atoi(argv[3]);

            // If the row or col are not betwee 0-4 print error
            if (row < 0 || row > 4) {
                printf("error\n");
            }

            if (col < 0 || col> 4) {
                printf("error\n");
            }

            // Build the move message and send the move to the server

            strcat(bufferSend, argv[1]);
            strcat(bufferSend, " ");
            strcat(bufferSend, argv[2]);
            strcat(bufferSend, " ");
            strcat(bufferSend, argv[3]);
            
            // Send the message
            if (mq_send( clientQueue, bufferSend, strlen( bufferSend ), 0 ) == -1) {
                printf(("Sending error\n"));
            }

            // Wait for response back. Success or fail print
            int len = mq_receive( serverQueue, bufferRev, sizeof( bufferRev ), NULL );

            if ( len >= 0 ) {
                printf("%s\n", bufferRev);
            } else{
                printf("Receiving error\n");
            }
        }
    } else if (argc == 2) {
        // If there are 2 arguments, that means its a report or undo command
        if (strcmp(argv[1], "report") == 0) {
            
            // Send the move to the server
            strcpy(bufferSend, "report");
            if (mq_send( clientQueue, bufferSend, strlen( bufferSend ), 0 ) == -1) {
                printf(("Sending error\n"));
            }

        } else if (strcmp(argv[1], "undo") == 0) {

            // Send the move to the server
            strcpy(bufferSend, "undo");
            if (mq_send( clientQueue, bufferSend, strlen( bufferSend ), 0 ) == -1) {
                printf(("Sending error\n"));
            }
            // Wait for response back. Success or fail print
            int len = mq_receive( serverQueue, bufferRev, sizeof( bufferRev ), NULL );

            if ( len >= 0 ) {
                printf("%s\n", bufferRev);
            } else{
                printf("Receiving error\n");
                exit(-1);
            }

        } else {
            printf("error\n");
        }
    } else {
        printf("error\n");
        exit(1);
    }

    // Close our two message queues.
    mq_close( clientQueue );
    mq_close( serverQueue );

    return 0;
}