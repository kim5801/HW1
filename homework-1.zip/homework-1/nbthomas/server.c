/** 
  @file server.c
  @author Noah Thomas (nbthomas)
  The server takes messages and commands from the client to perform tasks in the lights out game such as move,
  undo, and report. Each task is performed using the details given by client and once completed or should an
  error occur, the server informs the client of this which is then written to the user.
  */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** index position for the column in the move message given to the server */
#define COLUMN_INDEX 7
/** exit returned in case of error */
#define UNSUCCESSFUL_EXIT 1
/** indicates successful completion of program */
#define SUCCESSFUL_EXIT 0
/** Number of rows in the table */
#define ROW_SIZE 5
/** number of character inside a row representation of the table */
#define ROW_SIZE_LINE 6
/** size allocated to format the table as a String */
#define BOARD_SIZE 31
/** largest column/row index */
#define MAX_ROW_COLUMN 4

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( UNSUCCESSFUL_EXIT );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

char *board_State[ROW_SIZE]; //array of strings to hold the current state of board and record any changes as commands are performed

/** 
  Handles the signal sent when user wishes to terminate the program via Ctrl+C
  sets the running variable to 0 to evaluate as false during the while loop to take
  in commands and also provide the subsequential steps of printing the board state
  @param sig signal from Ctrl+C
  */
void termhandler(int sig) {
  running = 0; //sets the running to 0 to end the loop
}

/** 
  Performs the majority of functionality and sets up the intial board from the file
  given and provides error checking as well. It then receives the message from the client
  parses it for key phrases and executes tasks on the board based on the messages and then
  sends the status of each commands
  @param argc number of arguments
  @param argv collection of arguments
  @return successful exit
  */
int main( int argc, char *argv[] ) {
  if(argc != 2) { //checks that only two arguments are given on command line
    fail("usage: server <board-file>");
  }

  int inp = open(argv[1], O_RDONLY); //opens board file
  if(inp < 1) { //informs if unable to open board file
    fprintf(stderr, "Invalid input file: %s", argv[1]);
    fail("");    
  }

  char *prevBoard[ROW_SIZE]; //array of strings to hold the previous state of the board, may not be initialized if no moves have been made

  bool cantUndo = true; //informs if the board can be undone, when not initialized or if a recent undo was performed, it should not be allowed

  for(int c = 0; c < ROW_SIZE; c++) {
    prevBoard[c] = (char *)malloc(ROW_SIZE_LINE * sizeof(char)); //allocating space for the previous board space
    board_State[c] = (char *)malloc(ROW_SIZE_LINE * sizeof(char)); //allocating space for the current board space
    read(inp, board_State[c], sizeof(char) * ROW_SIZE_LINE); //filling the current board with the file contents
    for(int b = 0; b < ROW_SIZE; b++) { //checks if the file given has any invalid characters
      if(board_State[c][b] != '\n' && board_State[c][b] != '*' && board_State[c][b] != '.') { //also checks if the new line character maybe in an incorrect position
        fprintf(stderr, "Invalid input file: %s", argv[1]);
        fail(""); 
      }
    }
  }

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  struct sigaction term; //sigaction to handle termination by ctrl+c
  term.sa_handler = termhandler; //provides the termhandle
  sigemptyset( &( term.sa_mask ) );
  term.sa_flags = 0;
  sigaction(SIGINT, &term, 0); //sigaction call to handle termination

  // Repeatedly read and process client messages.
  while ( running ) {


    char buffer[MESSAGE_LIMIT + 1]; //buffer to receive client messages

    mq_receive(serverQueue, buffer, sizeof(buffer), NULL); //receiving any messages sent to through the server queue

    if(buffer[0] == 'm') { //checks for move command
      for(int p = 0; p < 5; p++) { //saves the state of the board before this move
        strcpy(prevBoard[p], board_State[p]);
      }

      cantUndo = false; //allows for an undo

      int row = buffer[ROW_SIZE] - '0'; //retrieves the integer representation of the row
      int column = buffer[COLUMN_INDEX] - '0'; //retrieves the integer representation of the column

      if(board_State[row][column] == '.') { //changes current position
        board_State[row][column] = '*';
      } else {
        board_State[row][column] = '.';
      }

      if(row + 1 <= MAX_ROW_COLUMN ) { //changes position below
        if(board_State[row + 1][column] == '.') {
          board_State[row + 1][column] = '*';
        } else {
          board_State[row + 1][column] = '.';
        }
      }

      if(row - 1 >= 0) { //changes position above
        if(board_State[row - 1][column] == '.') {
          board_State[row - 1][column] = '*';
        } else {
          board_State[row - 1][column] = '.';
        }
      }

      if(column + 1 <= MAX_ROW_COLUMN) { //changes position to the right
        if(board_State[row][column + 1] == '.') {
          board_State[row][column + 1] = '*';
        } else {
          board_State[row][column + 1] = '.';
        }
      }

      if(column - 1 >= 0) { //changes position to the left
        if(board_State[row][column - 1] == '.') {
          board_State[row][column - 1] = '*';
        } else {
          board_State[row][column - 1] = '.';
        }
      }
      
      //sends the success message once move is complete, should not need to indicate failure because this is prevented through the error handling in client
      mq_send(clientQueue, "success", strlen("success"), 0);

    } else if (buffer[0] == 'u') { // checks for undo command
      if(cantUndo) { //see if board can't currently be undone
        mq_send(clientQueue, "error", strlen("error"), 0); //informs of failure
      } else {
        for(int u = 0; u < ROW_SIZE; u++) { //replaces current board with previous board state
          strcpy(board_State[u], prevBoard[u]);
        }

        cantUndo = true; //ensures board can't be undone again until a new move is performed
        mq_send(clientQueue, "success", strlen("success"), 0); //informs of success
      }
    } else if (buffer[0] == 'r') { //checks report command
      char *board = (char *)malloc(BOARD_SIZE * sizeof(char)); //string to hold the representation fo the board
      strcpy(board, board_State[0]); //copies first rows

      for(int b = 1; b < ROW_SIZE; b++) { //concatenates the string with each row
        strcat(board, board_State[b]);
      }

      mq_send(clientQueue, board, strlen(board), 0); //sends representation to the client
    }
    
  }
  
  printf("\n");
  for(int t = 0; t < ROW_SIZE; t++) {
    fprintf(stdout, "%s", board_State[t]); //prints current state of the board with termination
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return SUCCESSFUL_EXIT; //successful exit
}
