/** 
  @file client.c
  @author Noah Thomas (nbthomas)
  The client takes commands for the lights out game from the user and then writes them to the server program
  the result of these actions are then received by the server and written back to the user.
  */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** indicate error in program completion */
#define UNSUCCESSFUL_EXIT 1
/** indicates successful program completion */
#define SUCCESSFUL_EXIT 0
/** the most arguments that can be given in a client command*/
#define ARG_MAX 4
/** index of the argument that provides the column in move */
#define COLUMN_ARG 3

/** 
  Prints the provided message to standard error, used largely for command-line errors and exits the program
  */
static void failC( char const *message ) {
  fprintf( stderr, "%s", message );
  exit( UNSUCCESSFUL_EXIT );
}

int main(int argc, char *argv[]) {
    if(argc != ARG_MAX && argc != 2) {//checks to ensure they only provided 2 or 4 arguments on the command line
        failC("error\n");
    }

    if(strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "report") != 0 && strcmp(argv[1], "move")) {//makes sure the first argument is one of the client commands
        failC("error\n");
    }

    if((argc != 2 && (strcmp(argv[1], "undo") == 0 || strcmp(argv[1], "report") == 0)) || (argc != ARG_MAX && strcmp(argv[1], "move") == 0)) { //makes sure they did not give the wrong amount of arguments for each command
        failC("error\n");
    }

    if(strcmp(argv[1], "move") == 0) { //checks the coordinates given to move
        if(atoi(argv[2]) == 0 && strcmp(argv[2], "0") != 0) { //makes sure the row given is an actual number
            failC("error\n");
        }

        if(atoi(argv[COLUMN_ARG]) == 0 && strcmp(argv[COLUMN_ARG], "0") != 0) { //makes sure the column given is an actual number
            failC("error\n");
        }
    }

    if(strcmp(argv[1], "move") == 0 && (atoi(argv[2]) > ARG_MAX || atoi(argv[2]) < 0 || atoi(argv[COLUMN_ARG]) > 4 || atoi(argv[COLUMN_ARG]) < 0)) { //confirms that a valid row and column position are given to move
        failC("error\n");
    }

    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY, 0600); //open a queue to write to the server, should be created by the server beforehand
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY, 0600); //open a queue to receive messages for the client, created by server beforehand

    char cmnd[MESSAGE_LIMIT - 1]; //buffer to send messages to the server

    if(strcmp(argv[1], "move") == 0) { //shares the command "move" along with the row and column into  a string to be sent to the server
        strcpy(cmnd, "move ");
        strcat(cmnd, argv[2]);
        strcat(cmnd, " "); //allows for easier parsing
        strcat(cmnd, argv[COLUMN_ARG]);
        cmnd[COMMAND_LIMIT - 1] = '\0';// provides null termination
        mq_send(serverQueue, cmnd, strlen(cmnd), 0);
    } else { //the undo and report commands only need the commands themselves sent to confirm what the server needs to do        
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0);
    }

    char bufferResp[MESSAGE_LIMIT + 1]; //buffer to hold any messages sent from the server to the client

    mq_receive(clientQueue, bufferResp, sizeof(bufferResp), NULL); //receive message

    if(strcmp(argv[1], "report") == 0) { //prints what was written by the server into standard output to inform user of success/failure or a report
        fprintf(stdout, "%s", bufferResp);   
    } else {
        fprintf(stdout, "%s\n", bufferResp);
    }

    mq_close( clientQueue ); //closes message queue for this command
    mq_close( serverQueue ); //closes message queue for this command

    return SUCCESSFUL_EXIT; //successful exit
}