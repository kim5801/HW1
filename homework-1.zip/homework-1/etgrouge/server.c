/**
  @file server.c
  @author Erin Grouge & David Sturgill
  The server keeps track of the status of the board and performs desired operations
  communicated by the client.
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** The exact length of the string containing the board report.
  5 rows x (5 cols + newline char) + null terminator = 31 */
#define REPORT_LEN 31

/** Integer representation for light off */
#define OFF 0

/** Integer representation for light on */
#define ON 1

/** 
  Board Struct. 
  It stores the status of the board in a 2d int array, its
  last move, and if an undo can be performed.
 */
typedef struct {
  int lastMove[2]; /** The last move performed by the player */
  int gameboard[GRID_SIZE][GRID_SIZE]; /** The board stored as 0s and 1s */
  bool canUndo; /** Whether or not the player can perform an undo */
}BoardState;

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Board struct storing the state of the board.
static BoardState board;

// String to store the board report visual
char reportMsg[REPORT_LEN];

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out the usage and exit
static void usage(){
  fprintf(stderr, "usage: server <board-file>\n");
  exit( 1 );
}

// Reads the board file and stores it in the board struct
static void readFile(const char *file){
  FILE * fp = fopen(file, "r");
  char ch;
  // Sets up error message by adding filename to error string
  char *msg = "Invalid input file: ";
  char errmsg[strlen(msg) + strlen(file) + 1];
  strcpy(errmsg, msg);
  strcat(errmsg, file);
  // If file doesn't exist, exit with error.
  if(fp == NULL)
    fail(errmsg);
  // Read file character by character assigning proper value to 
  // the board struct, failing if in improper format. 
  for(int i = 0; i < GRID_SIZE; i++){
    for(int j = 0; j < GRID_SIZE; j++){
      if(fscanf(fp, "%c", &ch) == -1)
        fail(errmsg);
      if(ch == '.'){
        board.gameboard[i][j] = OFF;
      } else if (ch == '*'){
        board.gameboard[i][j] = ON;
      } else {
        fail(errmsg);
      }
    }
    if(fscanf(fp, "%c", &ch) == -1){
      fail(errmsg);
    } else if ( ch != '\n'){
      fail(errmsg);
    }
  }
  // Check to make sure there are no more characters.
  if(fscanf(fp, "%c", &ch) != EOF){
    fail(errmsg);
  }
}

// Constructs the report message based on board status.
static void printBoard(){
  int index = 0;
  for(int i = 0; i < GRID_SIZE; i++){
    for(int j = 0; j < GRID_SIZE; j++){
      if(board.gameboard[i][j] == ON){
        reportMsg[index] = '*';
      } else {
        reportMsg[index] = '.';
      }
      index++;
    }
    reportMsg[index] = '\n';
    index++;
  }
  reportMsg[index] = '\0';
}

// Performs the move operation by updating the board status. 
static void move(int r, int c){
  // Switch the pressed tile
  if(board.gameboard[r][c] == ON){
    board.gameboard[r][c] = OFF;
  } else {
    board.gameboard[r][c] = ON;
  }

  //Switch tile above if exists
  if(r - 1 >= 0){
    if(board.gameboard[r - 1][c] == ON){
      board.gameboard[r - 1][c] = OFF;
    } else {
      board.gameboard[r - 1][c] = ON;
    }
  }

  //Switch tile below if exists
  if(r + 1 <= 4){
    if(board.gameboard[r + 1][c] == ON){
      board.gameboard[r + 1][c] = OFF;
    } else {
      board.gameboard[r + 1][c] = ON;
    }
  }

  //Switch tile left if exists
  if(c - 1 >= 0){
    if(board.gameboard[r][c - 1] == ON){
      board.gameboard[r][c - 1] = OFF;
    } else {
      board.gameboard[r][c - 1] = ON;
    }
  }

  //Switch tile right if exists
  if(c + 1 <= 4){
    if(board.gameboard[r][c + 1] == ON){
      board.gameboard[r][c + 1] = OFF;
    } else {
      board.gameboard[r][c + 1] = ON;
    }
  }
}

// End while loop and print the board. 
// Citation: From Process slides
void sig_handler(int signal){
  running = 0;
  printBoard();
  fprintf(stdout, "\n%s", reportMsg);
}

int main( int argc, char *argv[] ) {
  // Set up signal handler for Ctrl C termination
  // Citation: From Processes Notes
  struct sigaction sig;
  sig.sa_handler = &sig_handler;
  sigemptyset(&sig.sa_mask);
  sig.sa_flags = 0;
  sigaction(SIGINT, &sig, NULL);

  if(argc != 2)
    usage();

  // Read in the input file, storing the initial board in the struct.
  readFile(argv[1]);

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Repeatedly read and process client messages.
  while ( running ) {
    // Receiver message from client
    char msg[MESSAGE_LIMIT];
    mq_receive(serverQueue, msg, sizeof(msg), NULL);

    // Interpret message from client. 
    // "r" = report so send back the board report message. 
    if(msg[0] == 'r'){
      printBoard();
      mq_send(clientQueue, reportMsg, sizeof(reportMsg), 0);
    } // "u" = undo so check if an undo can be performed and report back to client
    else if(msg[0] == 'u'){
      if(board.canUndo){
        // Update the board struct fields and report success back to client. 
        move(board.lastMove[0], board.lastMove[1]);
        board.canUndo = false;
        mq_send(clientQueue, "success\n", sizeof("success\n"), 0);
      } else {
        mq_send(clientQueue, "error\n", sizeof("error\n"), 0);
      }
    } // "m" = move so switch the desired tiles
    else if(msg[0] == 'm'){
      // Convert to int. Error checking done in client so this is sufficient.
      int row = msg[1] - '0';
      int col = msg[2] - '0';
      // Set the boards last move to this move and update that it can undo.
      board.lastMove[0] = row;
      board.lastMove[1] = col;
      board.canUndo = true;
      // Perform the move operation and report back to client success.
      move(row, col);
      mq_send(clientQueue, "success\n", sizeof("success\n"), 0);
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return EXIT_SUCCESS;
}
