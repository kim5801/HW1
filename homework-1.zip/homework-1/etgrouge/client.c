/**
  @file client.c
  @author Erin Grouge
  The client class receives input from the user on whether they want
  to move, undo or report the status of the board. It communicates this
  to the server who performs the necessary operations to do so and reports
  back to the client to communicate with the user. 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** Checks if the character is a valid number (0-9)
  @param ch the character to check
  @return true if the character is valid
 */
static int isValid(char ch)
{
  return (ch >= '0' && ch <= '9');
}

/** Parses the given string to an integer value
  @param the string to parse
  @return val the integer value of the string
 */
static int parse(char * str)
{
  int val = 0;
  int i = 0;
  // While not at the end, read digits left to right, updating decimal value as you go.
  while(str[i] != '\0'){
    // If not valid characters, return -1
    if(!isValid(str[i])){
      return -1;
    }
    // Convert to integer value
    int num = str[i] - '0';
    // Shift left digits over by multiplying by 10
    val = val * 10 + num;
    i++;
  }
  return val;
}

/**
  Starting point for the program.
  Reads in user input and reports it to the server.
  Prints out returning message back to user.
  @param argc the number of arguments
  @param argv the array of arguments
 */
int main( int argc, char *argv[] ) {
  // The message that will be sent to the server.
  // One letter indicating report, undo or move and then 
  // two numbers if it is the move command. 
  char msg[4];
  // Check number of arguments
  if(argc < 2 || argc > 4){
    fail("error");
  }
  // Check arguments and construct message to server
  // If report, set msg to "r"
  if(strcmp(argv[1], "report") == 0){
    if(argc != 2)
      fail("error");
    
    msg[0] = 'r';
    msg[1] = '\0';
    msg[2] = '\0';
  } // If undo, set message to "u"
  else if(strcmp(argv[1], "undo") == 0){
    if(argc != 2)
      fail("error");

    msg[0] = 'u';
    msg[1] = '\0';
    msg[2] = '\0';
  } // If move set message to "m(r)(c)"
  else if(strcmp(argv[1], "move") == 0){
    if(argc != 4)
      fail("error");

    int row = parse(argv[2]);
    int col = parse(argv[3]);

    if(row < 0 || row > 4 || col < 0 || col > 4)
      fail("error");

    msg[0] = 'm';
    msg[1] = argv[2][0];
    msg[2] = argv[3][0];
  } // If the argument is anything else, fail.
  else {
    fail("error");
  }
  // Null terminate the msg.
  msg[3] = '\0';

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);

  // Send the msg to the server
  mq_send( serverQueue, msg, sizeof(msg), 0);

  // Receive the server's response
  char buffer[MESSAGE_LIMIT];
  mq_receive(clientQueue, buffer, sizeof(buffer), NULL);

  // Print response to standard output.
  fprintf(stdout, "%s", buffer);

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  return EXIT_SUCCESS;

}