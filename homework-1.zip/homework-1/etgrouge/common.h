/**
  @file common.h
  @author David Sturgill
  Defines common constants and the server names.
 */

// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/etgrouge-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/etgrouge-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5
