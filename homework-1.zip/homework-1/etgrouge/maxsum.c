/**
  @file maxsum.c
  @author Erin Grouge & David Sturgill
  The Max Sum program reads a list of integers from file and find the greatest
  sum that can be produced from adding up a row of adjacent numbers in the list. 
  Citations: OS notes, example files, and my previous exercises. 
 */
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

/** Reads the list of values from file */
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/** 
  Find the maximum by starting at the given index and finding
  the sum from start to end of the list, reporting the greatest
  sum found 
  @param start the starting index
  @return max the maximum sum found
 */
int findMax(int start){
  int max = 0;
  int sum = 0;
  for(int i = start; i < vCount; i++){
    sum += vList[i];
    if(sum > max)
      max = sum;
  }
  return max;
}

/**
  Starting point for the program.
  Reads the list of integers and reports the greatest sum to the
  user using multiple working threads.
  @param argc the number of arguments
  @param argv the array of arguments 
  @return exit status
 */
int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Check number of arguments
  if ( argc < 2 || argc > 3 )
    usage();
  
  // Parse command-line arguments.
  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 || workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
  //Read the list of integers
  readList();

  // Make pipe
  pid_t pid = 1; // Initialize to 1 so it doesn't perform child work before it forks
  int pfd[2];
  pipe(pfd);

  // Create child processes - start at -1 because first iteration only creates 
  // the first child and we want it to start at 0. 
  for(int i = -1; i < workers; i++){
    if(pid == -1){
      fail("Can't create child process.\n");
    }
    // Child Process
    else if(pid == 0){
      // Close reader because it isn't needed
      close(pfd[0]);

      // Loop through the list finding sums. Start at the i the initial index
      // and jump by worker count so that every worker gets an equal share of work.
      int max = 0;
      for(int j = i; j < vCount; j += workers){
        int sum = findMax(j);
        //If the sum found is greater than the max, replace it.
        if(sum > max)
          max = sum;
      }

      // Lock the pipe before writing the local max to the parent process.
      lockf(pfd[1], F_LOCK, 0);
      write(pfd[1], &max, sizeof(max));
      lockf(pfd[1], F_ULOCK, 0);

      // If the report flag is true, report the local max.
      if(report){
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), max);
      }

      // Close the pipe because it is no longer needed and exit successfully.
      close(pfd[1]);
      exit(0);

    } // Parent Process
    else {
      // If it's not the last iteration of the loop, create another child.
      if(i != workers - 1)
        pid = fork();
    }
  }
  // Set up variables to store sums from children
  int max = 0;
  int sum = 0;

  // Close writer end of the pipe because it is no longer needed.
  close(pfd[1]);

  // Read all local maximums from children and determine which is the global max.
  for(int i = 0; i < workers; i++){
    read(pfd[0], &sum, sizeof(int));
    if(sum > max){
      max = sum;
    }
  }
  // Wait for all children to terminate and close the pipe
  while(wait(NULL) > 0);
  close(pfd[0]);

  // Print the global max and exit successfully.
  printf("Maximum Sum: %d\n", max);

  return 0;
}
