/**
 * @file maxsum.c
 * @author Ethan Treece (eltreece)
 * 
 * The maxsum program's job is to use multiple processes and multiple CPU cores to solve
 * a computationally expensive problem more quickly. The task is to find a contiguous non-empty
 * subsequence within a sequence of positive and negative integer values that has the largest
 * sum. 
 * 
 */
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // Make a pipe for our children to talk over.
  int pfd[ 2 ];
  if ( pipe( pfd ) != 0 )
    fail( "Can't create pipe" );

  pid_t pid;

  for(int w = 0; w < workers; w++) {
    if ((pid = fork()) == 0) {

      // Child does not require the read portion of the pipe
      close(pfd[0]);

      int id = getpid();
      int max = 0;

      for (int i = w; i < vCount; i += workers) {
        int total = 0;
        for (int j = i; j < vCount; j++) {
          total += vList[j];
          if (total > max) {
            max = total;
          }
        }
      }

      // Write the max integer in binary into the pipe
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &max, sizeof(max));
      lockf( pfd[1], F_ULOCK, 0 );

      if (report) {
        printf("I’m process %d. The maximum sum I found is %d.\n", id, max);
      }
      
      // Close the write descriptor for the child
      close(pfd[1]);

      exit( EXIT_SUCCESS );
    }
  }

  // Wait until all children are exited 
  while ((wait(NULL)) > 0);

  // Parent does not require the write portion of the pipe
  close(pfd[1]);

  int max = 0;
  int arr[workers];
  read(pfd[0], arr, sizeof(arr));
  for (int i = 0; i < workers; i++) {
    if (arr[i] > max) {
      max = arr[i];
    }
  }

  printf( "Maximum Sum: %d\n", max );
  
  // Close the read descriptor for the parent
  close(pfd[0]);

  return 0;
}
