/**
 * @file server.c
 * @author Ethan Treece (eltreece)
 * 
 * The server is responsible for storing the state of the game board and keeping up with the most
 * recent move to support the undo operation.
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void invalidInput(char *c) {
    fprintf( stderr, "Invalid input file: %s\n", c );
    exit( 1 );
}

// Flips the 'light' by switching * and . characters
void flip(char *c) {
  if (*c == '*') {
    *c = '.';
  } else {
    *c = '*';
  }
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;


// Sets running to 0
void alarmHandler( int sig ) {
  running = 0;
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Usage too many arguments
  if (argc != 2)
    fail("usage: server <board-file>");

  // Open the input file for reading.
  FILE *fp = fopen( argv[1], "r" );
  if ( !fp ) 
    invalidInput(argv[1]);

  char arr[5][5];
  char backup[5][5];
  int undo = 1;

  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      char c = fgetc(fp);
      if (c != '*' && c != '.')
        invalidInput(argv[1]);
      arr[i][j] = c;
      backup[i][j] = c;
    }
    char c = fgetc(fp);
      if (c != '\n')
        invalidInput(argv[1]);
  }

  struct sigaction act;

  // Fill in a structure to redirect the alarm signal.
  act.sa_handler = alarmHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Repeatedly read and process client messages.
  while ( running ) {

    char cmd[MESSAGE_LIMIT] = {0};
    mq_receive(serverQueue, cmd, MESSAGE_LIMIT, 0);

    if (strcmp(cmd, "report") == 0) {
      char grid[25] = {0};
      int counter = 0;
      for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
          grid[counter++] = arr[i][j];
        }
      }
      mq_send(clientQueue, grid, strlen(grid), 0);
    } else if (strcmp(cmd, "undo") == 0) {
      if (undo == 0) {
        for (int i = 0; i < 5; i++) {
          for (int j = 0; j < 5; j++) {
            arr[i][j] = backup[i][j];
          }
        }
        undo = 1; 
        mq_send(clientQueue, "success", strlen("success"), 0);
      } else {
        mq_send(clientQueue, "error", strlen("error"), 0);
      }
    } else if (strcmp(cmd, "move") == 0) {
      char row[MESSAGE_LIMIT];
      mq_receive(serverQueue, row, MESSAGE_LIMIT, 0);
      char col[MESSAGE_LIMIT];
      mq_receive(serverQueue, col, MESSAGE_LIMIT, 0);

      int r = row[0] - 48;
      int c = col[0] - 48;

      undo = 0;
      for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
          backup[i][j] = arr[i][j];
        }
      }
      
      if (r == 0 && c == 0) { // top left
        flip(&arr[0][0]);
        flip(&arr[0][1]);
        flip(&arr[1][0]);
      } else if (r == 0 && c == 4) { // top right
        flip(&arr[0][4]);
        flip(&arr[0][3]);
        flip(&arr[1][4]);
      } else if (r == 4 && c == 4) { // bottom right
        flip(&arr[0][0]);
        flip(&arr[0][1]);
        flip(&arr[1][0]);
      } else if (r == 4 && c == 0) { // botttom left
        flip(&arr[4][0]);
        flip(&arr[3][0]);
        flip(&arr[4][1]);
      } else if (r == 0) { // top edge
        flip(&arr[0][c]);
        flip(&arr[0][c + 1]);
        flip(&arr[0][c - 1]);
        flip(&arr[1][c]);
      } else if (r == 4) { // bottom edge
        flip(&arr[4][c]);
        flip(&arr[4][c + 1]);
        flip(&arr[4][c - 1]);
        flip(&arr[3][c]);
      } else if (c == 0) { // left edge
        flip(&arr[r][0]);
        flip(&arr[r + 1][0]);
        flip(&arr[r - 1][0]);
        flip(&arr[r][1]);
      } else if (c == 4) { // right edge
        flip(&arr[r][4]);
        flip(&arr[r + 1][4]);
        flip(&arr[r - 1][4]);
        flip(&arr[r][3]);
      } else { // middle area
        flip(&arr[r][c]);
        flip(&arr[r + 1][c]);
        flip(&arr[r - 1][c]);
        flip(&arr[r][c + 1]);
        flip(&arr[r][c - 1]);
      }
    }
    
  }

  // Prints the board upon exitting the program
  printf("\n");
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      printf("%c", arr[i][j]);
    }
    printf("\n");
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
