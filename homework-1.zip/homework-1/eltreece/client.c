/**
 * @file client.c
 * @author Ethan Treece (eltreece)
 * 
 * The client will send commands to the server to make a move, undo the most recent
 * move or check the current state of the board.
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out a usage message, then exit.
static void usage() {
  printf( "error\n" );
  exit( EXIT_FAILURE );
}

int main( int argc, char *argv[] ) {

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );

  // If there's a second argument, it better be the word, report or undo
  // If there's four arguments, the second should be the word move
  // Any other number of arguments in invalid
  if ( argc == 2 ) {

    if (strcmp( argv[ 1 ], "report" ) == 0) {
      mq_send(serverQueue, argv[1], strlen(argv[1]), 0);
      char grid[25];
      mq_receive(clientQueue, grid, MESSAGE_LIMIT, 0);
      for (int i = 1; i < 26; i++) {
        printf("%c", grid[i - 1]);
        if (i % 5 == 0)
          printf("\n");
      }
    } else if (strcmp( argv[ 1 ], "undo" ) == 0) {
      mq_send(serverQueue, argv[1], strlen(argv[1]), 0);
      char message[MESSAGE_LIMIT];
      mq_receive(clientQueue, message, MESSAGE_LIMIT, 0);
      printf("%s\n", message);
    } else {
      usage();
    }

  } else if (argc == 4) {
    if ( strcmp( argv[ 1 ], "move" ) != 0 ) {
      usage();
    } else {
      if (strlen(argv[2]) > 1 || strlen(argv[3]) > 1)
        usage();
      if (argv[2][0] < 48 || argv[2][0] > 52 || argv[3][0] < 48 || argv[3][0] > 52)
        usage();
      mq_send(serverQueue, argv[1], strlen(argv[1]), 0);
      
      mq_send(serverQueue, argv[2], 1, 0);
      mq_send(serverQueue, argv[3], 1, 0);
      printf("success\n");
    }
  } else {
    usage();
  }

  // Close our two message queues
  mq_close( clientQueue );
  mq_close( serverQueue );

}