/**
 * @file server.c
 * @author Osama Albahrani (osalbahr)
 * This server stores a lights-out board
 * that can be played via message queues.
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Maximum mq message buffer size
#define MAX_SIZE 1024

// Useful for debugging
#define REPORT_I( X ) //printf( "%s = %d\n", #X, (X) )
#define REPORT_S( S ) //printf( "%s = %s\n", #S, (S) )
#define REPORT_C( C ) //REPORT_I( C ), printf( "%s = %c\n", #C, (C) )

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  fail( "usage: server <board-file>" );
}

// Reads the board from the file into the argument, checking for errors
// Returns true if the board is valid, false otherwise
static bool readBoard( FILE *in, char board[ BOARD_LENGTH ][ BOARD_LENGTH + 1 ] )
{
  for ( int i = 0; i < BOARD_LENGTH; i++ ) {
    char line[ BOARD_LENGTH + 1 ];
    char check;
    if ( fscanf( in, "%5s%c", line, &check ) != 2 || check != '\n' )
      return false;
    
    for ( int j = 0; j < BOARD_LENGTH; j++ ) {
      char ch = line[ j ];
      if ( ch != '.' && ch != '*' )
        return false;
    }

    // Line is safe
    strcpy( board[ i ], line );
  }

  // File is too big
  if ( getc( in ) != EOF )
    return false;

  return true;
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Handles ctrl-c by changing the loop condition
void handler( int notUsed )
{
  running = 0;
}

// Inverts the current location, if it is valid
bool invert( char board[ BOARD_LENGTH ][ BOARD_LENGTH + 1 ], int r, int c )
{
  if ( r < 0 || r >= BOARD_LENGTH
    || c < 0 || c >= BOARD_LENGTH ) {
    return false;
  }
  
  REPORT_I( r );
  REPORT_I( c );
  
  if ( board[ r ][ c ] == '.' ) {
    board[ r ][ c ] = '*';
  } else {
    board[ r ][ c ] = '.';
  }
  
  return true;
}

// Simulates clicking on a spot
bool processMove( char board[ BOARD_LENGTH ][ BOARD_LENGTH + 1 ], int r, int c )
{
  invert( board, r + 1, c );
  invert( board, r - 1, c );
  invert( board, r, c + 1 );
  invert( board, r, c - 1 );
  
  return invert( board, r, c );
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Validate args
  if ( argc != 2 ) {
    usage();
  }

  // Read the input file
  char board[ BOARD_LENGTH ][ BOARD_LENGTH + 1 ];
  FILE *in = fopen( argv[ 1 ], "r" );
  if ( in == NULL || !readBoard( in, board ) ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }
  fclose( in );

  // Handle ctrl-c
  // signal(SIGINT, handler);
  struct sigaction act;
  act.sa_handler = handler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, NULL );

  // Repeatedly read and process client messages.
  bool canUndo = false;
  int lastMove[ 2 ];
  while ( running ) {
    char buffer[ MAX_SIZE ];
    int len = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );

    // If ctrl-c
    if ( running == 0 )
        break;

    if ( len == -1 )
      fail( "Error receiving message" );
    
    char command[ MAX_SIZE ];
    int r, c;

    // args should be 3 for move, 1 for report/undo.
    // Note: client guarantees that if the buffer starts with report/undo
    // as the first word, then the command is in a valid format.
    // check should never be updated, this means bad extra input
    char check;
    int args = sscanf( buffer, "%s%d%d %c", command, &r, &c, &check );
    REPORT_S( command );
    REPORT_I( args );
    
    // Commands are:
    // move int1 int2
    // undo (and canUndo is true)
    // report
    // otherwise, error
    if ( strcmp( command, "move" ) == 0
	      && args == 3
	      && processMove( board, r, c ) ) {
      REPORT_S( command );
      canUndo = true;
      lastMove[ 0 ] = r;
      lastMove[ 1 ] = c;
      len = mq_send( clientQueue, "success", strlen( "success" ) + 1, 0 );
      canUndo = true;
    } else if ( strcmp( command, "undo" ) == 0 && canUndo ) {
      processMove( board, lastMove[ 0 ], lastMove[ 1 ] );
      len = mq_send( clientQueue, "success", strlen( "success" ) + 1, 0 );
      canUndo = false;
    } else if ( strcmp( command, "report" ) == 0 ) {
      len = mq_send( clientQueue, (char *)board, sizeof( board ), 0 );
    } else {
      len = mq_send( clientQueue, "error", strlen( "error" ) + 1, 0 );
    }

    if ( len == -1 )
      fail( "Error sendinf message" );
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Print the board then exit
  printf( "\n" );
  for ( int i = 0; i < BOARD_LENGTH; i++ )
    printf( "%s\n", board[ i ] );
  return 0;
}
