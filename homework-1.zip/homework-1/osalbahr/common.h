/**
 * @file common.h
 * @author Osama Albahrani (osalabhr)
 * Constants needed for server/client communication
 */
// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/osalbahr-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/osalbahr-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define BOARD_LENGTH 5

// Bytes in a grid
#define BOARD_SIZE ( sizeof( char ) * BOARD_LENGTH * ( BOARD_LENGTH + 1 ) )
