/**
 * @file client.c
 * @author Osama Albahrani (osalbahr)
 * This client plays lights-out by sending
 * message queues.
 */
#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <errno.h>

// Maximum mq message buffer size
#define MAX_SIZE 1024

// Useful for debugging
#define REPORT_I( X ) //printf( "%s = %d\n", #X, (X) )
#define REPORT_S( S ) //printf( "%s = %s\n", #S, (S) )
#define REPORT_C( C ) //REPORT_I( C ), printf( "%s = %c\n", #C, (C) )

// Print the error message to stderr and exit
void fail( char *message )
{
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Starting point of the program
int main( int argc, char *argv[] )
{
  if ( argc < 2 || argc > 4 )
    fail( "error" );
    
  // Partially validates the command
  // If argv[ 1 ] is valid check argc
  if ( ( strcmp( argv[ 1 ], "report" ) == 0 || strcmp( argv[ 1 ], "undo" ) == 0 )
        && argc != 2 ) {
    fail( "error" );
  } else if ( ( strcmp( argv[ 1 ], "move" ) == 0 )
        && argc != 4 ) {
    fail( "error" );
  }
  // } else {
  //   // Server will do the rest
  // }

  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't open the needed message queues" );

  // Send arg1, arg2, ... space-seperated
  char message[ MAX_SIZE ];
  message[ 0 ] = '\0';
  for( int i = 1; i < argc; i++ ) {
    strcat( message, argv[ i ] );
    if ( i != argc - 1 ) // No space at the end
      strcat( message, " " );
  }

  // Send the message null-terminated
  int len = mq_send( serverQueue, message, strlen( message ) + 1, 0 );
  if ( len == - 1 )
    fail( "Error sending message" );
  
  // Be prepared to receive a board if requested
  char board[ BOARD_LENGTH ][ BOARD_LENGTH + 1 ];
  if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    len = mq_receive( clientQueue, (char *)board, MAX_SIZE, 0 );    
    for ( int i = 0; i < BOARD_LENGTH; i++ )
      printf( "%s\n", board[ i ] );
  } else {
    // This could be success or error, print it
    char response[ MAX_SIZE ];
    len = mq_receive( clientQueue, (char *)response, MAX_SIZE, 0 );
    printf( "%s\n", response );
  }

  if ( len == - 1 )
    fail( "Error reading message" );


  // We're done, close our copy of the queue (which would happen when we exit anyway).
  mq_close( clientQueue );
  return 0;
}
