#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}
// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}
// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

/**
 * Finds and returns the sum of two integers
 * 
 * @param one first integer to be computed
 * @param two second integer to be computed
 * @return int largest number
 */
int max(int one, int two) {
  if (one > two) {
    return one;
  }
  else if (two > one) {
    return two;
  }
  else {
    return one;
  }
}

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
 * Creates child processes to calculate the maximum sum of consecutive integers
 * 
 * @param argc number of command line arguments
 * @param argv command line input array
 * @return int 0 upon success
 */
int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

  // ...

  //create pipe
  int pfd[ 2 ];
  if ( pipe( pfd ) != 0 )
    fail( "Can't create pipe" );

  //this represents the number of integers each worker will skip over
  int workerOffset = workers;

  for (int i = 0; i < workers; i++) {
    //first, fork
    if (fork() == 0) {
      int sum = 0;
      //close reading end
      close(pfd[0]);

      //compute sum

      int idx = i;
      int totalSum = 0;
      while(idx <= vCount) {
        //loop through each subset
        for (int j = idx; j < vCount; j++) {
          sum = max(sum , totalSum + vList[j]);
          totalSum = totalSum + vList[j];
        }
        idx += workerOffset;
        //reset the total sum but keep largest value in sum
        totalSum = 0;
      }

      if (report) {
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), sum);
      }
      //lock then write to pipe and unlock
      lockf(pfd[1], F_LOCK, 0);
      write(pfd[1], &sum, sizeof(sum));
      lockf(pfd[1], F_ULOCK, 0);
      exit(EXIT_SUCCESS);
    }

  }
  //close writing end of the pipe in parent process
  close(pfd[1]);
  int currentSum = 0;
  int childSum = 0;
  while(wait(NULL) >= 0) {
    read(pfd[0], &currentSum, sizeof(int));
    childSum = max(childSum, currentSum);
  }
  
  printf("Maximum Sum: %d\n", childSum);

  return 0;
}
