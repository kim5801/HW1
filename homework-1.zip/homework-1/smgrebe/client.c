#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  if (argc == 1) {
    fail("error");
  }
  if (strcmp(argv[1], "move") == 0) {
    if (argc != 4) {  //wrong number of arguments
      fail("error");
    }
    char row = argv[2][0];
    char col = argv[3][0];
    if (row < '0' || row > '4' || col < '0' || col > '4') { //arguments not valid
      fail("error");
    }
    
    //Copy command into buffer
    char buffer[ MESSAGE_LIMIT + 1 ];
    buffer[0] = '\0';
    strcat(buffer, argv[1]);
    strcat(buffer, " ");
    strcat(buffer, argv[2]);
    strcat(buffer, " ");
    strcat(buffer, argv[3]);
    strcat(buffer, "\0");

    // Send the message to the receiver.
    mq_send( serverQueue, buffer, strlen( buffer ), 0 );
  }
  else if (strcmp(argv[1], "undo") == 0) {
    //Copy command into buffer
    char buffer[ MESSAGE_LIMIT + 1 ];
    strcpy(buffer, "undo\0");

    // Send the message to the receiver.
    mq_send( serverQueue, buffer, strlen( buffer ), 0 );
  }
  else if (strcmp(argv[1], "report") == 0) {
    //Copy command into buffer
    char buffer[ MESSAGE_LIMIT + 1 ];
    strcpy(buffer, "report\0");

    // Send the message to the receiver.
    mq_send( serverQueue, buffer, strlen( buffer ), 0 );
  }
  else {  //invalid command
    fail("error");
  }
  
  //Buffer for reading a message from the queue
  char buffer[ MESSAGE_LIMIT ];
  //Waiting for a message to arrive and reading it into buffer
  int len = mq_receive( clientQueue, buffer, sizeof( buffer ), NULL );
  if (len >= 0) {
    printf("%s", buffer);
  }
  else {
    fail("unable to receive message");
  }

  // Close our two message queues
  mq_close( clientQueue );
  mq_close( serverQueue );

  return 0;
}
