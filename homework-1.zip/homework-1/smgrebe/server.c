#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//Takes in a character, either '.' or '*' and returns the opposite.
//Equal to turning a light off or turning a light on.
char opposite( char const state ) {
  if (state == '.') {
    return '*';
  }
  return '.';
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

//Tells the while loop below to stop running so the program can terminate because
//a signal was given
void signalHandler (int signal) {
  printf("\n");
  running = 0;
}

int main( int argc, char *argv[] ) {
  //Checking the number of command line arguments
  if (argc != 2) {
    fprintf(stderr, "usage: server <board-file>\n");
    exit( EXIT_FAILURE );
  }
  
  //Creating an input file
  FILE *in = fopen(argv[1], "r");
  //Exits if the input file given cannot be opened or doesn't exist
  if ( !in ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( EXIT_FAILURE );
  }
  
  //Creating a board struct
  typedef struct {
    char contents[5][5];
    int rowUndo;
    int colUndo;
    bool canUndo;
  } Board;
  
  Board *b = malloc(sizeof(Board));
  b->rowUndo = -1;
  b->colUndo = -1;
  b->canUndo = false;
  
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      char c = fgetc(in);
      //checking for invalid characters
      if (c != '.' && c != '*' && c != '\n') {
        fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
        exit( EXIT_FAILURE );
      }
      b->contents[i][j] = c;
    }
    fgetc(in);  //gets the newline character
  }
  
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  signal(SIGINT, signalHandler);

  // Repeatedly read and process client messages.
  while ( running ) {

    //Buffer for reading a message from the queue
    char buffer[ MESSAGE_LIMIT ];
  
    //Waiting for a message to arrive and reading it into buffer
    int len = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );
    
    if (len >= 0) {
      //splitting up the message into strings which were seperated by a space in the message
      //and counting how many words
      int numWords = 0;
      char *token = strtok(buffer, " ");
      char *word1 = &(*token);
      while (token != NULL) {
        numWords++;
        token = strtok(NULL, " ");
      }
      printf("%s\n", word1);
      
      if (numWords == 1) {
        if (word1[0] == 'u') {  //undo command
          if (b->canUndo) { //makes sure we can undo, else return error message to client
            b->canUndo = false;
            int rowUndo = b->rowUndo;
            int colUndo = b->colUndo;
            //inverting the row and column
            b->contents[rowUndo][colUndo] = opposite(b->contents[rowUndo][colUndo]);
            if (rowUndo - 1 > -1) { //trying to invert the square above
              b->contents[rowUndo - 1][colUndo] = opposite(b->contents[rowUndo - 1][colUndo]);
            }
            if (rowUndo + 1 < 5) {  //trying to invert the square below
              b->contents[rowUndo + 1][colUndo] = opposite(b->contents[rowUndo + 1][colUndo]);
            }
            if (colUndo - 1 > -1) { //trying to invert the left square
              b->contents[rowUndo][colUndo - 1] = opposite(b->contents[rowUndo][colUndo - 1]);
            }
            if (colUndo + 1 < 5) {  //trying to invert the right square
              b->contents[rowUndo][colUndo + 1] = opposite(b->contents[rowUndo][colUndo + 1]);
            }
            mq_send( clientQueue, "success\n\0", 9, 0 );
          }
          else {
            mq_send( clientQueue, "error\n\0", 7, 0 );
          }
        }
        else if (strcmp(word1, "report") == 0) {
          //copying the board contents into a string
          char board[37];
          board[37] = '\0';
          for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
              board[(i * 6) + j] = b->contents[i][j];
            }
            board[(i * 6) + 5] = '\n';
          }
          mq_send( clientQueue, (const char *) board, 37, 0 );
        }
        else {
          mq_send( clientQueue, "error\n\0", 7, 0 );
        }
      }
      else {
        //move command
        int row = atoi(&buffer[5]);
        int col = atoi(&buffer[7]);
        b->contents[row][col] = opposite(b->contents[row][col]);
        if (row - 1 > -1) { //trying to invert the square above
          b->contents[row - 1][col] = opposite(b->contents[row - 1][col]);
        }
        if (row + 1 < 5) {  //trying to invert the square below
          b->contents[row + 1][col] = opposite(b->contents[row + 1][col]);
            }
        if (col - 1 > -1) { //trying to invert the left square
          b->contents[row][col - 1] = opposite(b->contents[row][col - 1]);
        }
        if (col + 1 < 5) {  //trying to invert the right square
          b->contents[row][col + 1] = opposite(b->contents[row][col + 1]);
        }
        b->rowUndo = row;
        b->colUndo = col;
        b->canUndo = true;
        mq_send( clientQueue, "success\n\0", 9, 0 );
      }
    }
    
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );
  
  //Printing out board after ^C is called.
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 5; j++) {
      printf("%c", b->contents[i][j]);
    }
    printf("\n");
  }

  return 0;
}
