/**
 * @file server.c
 * @author Sarvesh Somasundaram
 * This file is the server file for the lights out game
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// The struct to store the state of the board, it stores a 5x5 array of the current state and the previous state of the board
typedef struct Board {
  char boardState[ 5 ][ 5 ];
  char prevBoard[ 5 ][ 5 ];
} Board;

// function to return a string value of the board to send to the client and to print
char *printBoard(Board board) {
  char *boardString = (char *) malloc( 30 * sizeof(char));
  int k = 0;
  for ( int i = 0; i < 5; i++ ) {
    for ( int j = 0; j < 5; j++ ) {
      boardString[k] = board.boardState[i][j];
      k++;
    }
    boardString[k] = '\n';
    k++;
  }
  return boardString;
}

// a void function to clear the message after each use so that it can be used again
static void *clearMessage( char *message ) {
  for (int i = 0 ; i < sizeof (message); i++ ) {
    message[i] = '\0';
  }
  return NULL;
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Intializing the current board
Board board;

// This is the signal handler for the server
void signalHandler() {
  running = 0;
}

// a function to update the previous board after each move so that an undo move can restore the old board
void *updatePrevBoard() {
  for ( int i = 0; i < 5; i++ ) {
    for ( int j = 0; j < 5; j++ ) {
      board.prevBoard[i][j] = board.boardState[i][j];
    }
  }

  return NULL;
}

// a function to change the value from an asterisk to a period for any given index
void *changeValue(int i, int j) {
  if ( i >= 0 && i <= 4 && j >= 0 && j <= 4 ) {
    if(board.boardState[i][j] == '*') {
      board.boardState[i][j] = '.';
    }
    else {
      board.boardState[i][j] = '*';
    }
  }

  return NULL;
}

// the main function which has a loop to run indefintely until ctrl-c
int main( int argc, char *argv[] ) {

  // check for the correct number of args
  if (argc != 2 ) {
    fail("usage: server <board-file>");
  }

  // The signal handler for when the user quits
  signal(SIGINT, signalHandler);

  // open the file to load the board
  FILE *fp = fopen( argv[ 1 ], "r" );
  if ( fp == NULL) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1] );
    exit( 1 );
  }
  
  // load the values into the Board struct
  for ( int i = 0; i < 5; i++ ) {
    fgets( board.boardState[i], 6, fp );
    // check that the characters are valid in the board
    for ( int j = 0; j < 5; j++ ) {
      // update the previous board as well
      board.prevBoard[i][j] = board.boardState[i][j];
      // if a charater is invaid exit
      if (board.boardState[i][j] != '.' && board.boardState[i][j] != '*') {
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        exit( 1 );
      }
    }
    // skip the new line character at the end
    fgetc( fp );
  }

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Is an undo move possible checker
  bool undo = false;
  
  // instantiate the message with limit
  char message[MESSAGE_LIMIT];

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Repeatedly read and process client messages.
  while ( running ) {
    clearMessage(message);
    // receive the message from the queue in the order they were sent
    mq_receive( serverQueue, message, sizeof( message ), NULL );

    // check if the command is report
    if ( strcmp( message, "report") == 0 ) {
      // send back a string of the board in its current state
      if (mq_send( clientQueue, printBoard(board), strlen( printBoard(board) ), 0 ) == -1) {
        fail("Failed to communicate with client to send current state of the board");
      }
    }

    // check if the message is undo
    else if ( strcmp( message, "undo") == 0 ) {
      // if an undo operation is allowed then reset the current state to the previous state
      if (undo) {
        for ( int i = 0; i < 5; i++ ) {
          for ( int j = 0; j < 5; j++ ) {
            board.boardState[i][j] = board.prevBoard[i][j];
          }
        }
        // send a success message
        if (mq_send( clientQueue, "success", strlen("success"), 0 ) == -1) {
          fail("failed to communicate with client to send success message");
        }
      } 
      // if an undo is not allowed send an error message
      else {
        if (mq_send( clientQueue, "error", strlen("error"), 0 ) == -1) {
          fail("failed to communicate with client to send error message");
        }
      }
      // undo only has a one step use so another move must be made before undo can be called again
      undo = false;
    }

    // check if the message is to make a move
    else if ( strcmp( message, "move") == 0 ) {
      // if so clear the message so that the index values can populate the message string
      clearMessage( message );
      // receive the index values from the queue in the order they were sent in
      mq_receive( serverQueue, message, sizeof( message ), NULL );

      int index1 = atoi(message);
      clearMessage( message );
      mq_receive( serverQueue, message, sizeof(message), NULL );
      int index2 = atoi(message);
      
      // check the index values to make sure they are valid
      if (index1 < 0 || index1 > 4 || index2 < 0 || index2 > 4) {
        mq_send( clientQueue, "error", sizeof("error"), 0);
      }

      // update the previous board first to save vals, then change the current values based on which index is chosen
      else {
        updatePrevBoard();
        changeValue(index1, index2);
        changeValue(index1 - 1, index2);
        changeValue(index1 + 1, index2);
        changeValue(index1, index2 - 1);
        changeValue(index1, index2 + 1);

        // set undo to true since a move has been made
        undo = true;
        // send a success message to the client
        if (mq_send( clientQueue, "success", strlen("success"), 0 ) == -1) {
          fail("failed to communicate with client server to send success message");
        }
      }
    }
  }

  // in the even that ctrl-c was pressed, print the current state of the board
  printf("\n%s\n", printBoard(board));

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );
  
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
