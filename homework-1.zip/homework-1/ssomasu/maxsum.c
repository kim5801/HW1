#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

    // a list of pid values for each worker
    pid_t *pid = (pid_t *) malloc( workers * sizeof( pid_t ) );

    // an anonymous pipe to report values to the parent
    int pfd[2];
    if ( pipe( pfd ) != 0 ) {
        fail("Can't create pipe");
    }

    // number of indices to start from
    int numSplits = vCount / workers;

    // create a child for the number of workers desired
    for ( int i = 0; i < workers; i++ ) {
      pid[i] = fork();

      // check to make sure the child was created
      if( pid[ i ] < 0 ) {
          fail( "Can't create a child process ");
      }

      // check to see if the current process is a child process
      if( pid[ i ] == 0 ) {
        // close the read end
        close( pfd[ 0 ]);

        // set the max value to the smallest possible value
        int max = INT_MIN;

        // determine the start index for the worker
        int startIndex = 0 + ( i * numSplits );
        // determine the index to go to for each worker
        int endIndex = numSplits + startIndex;
        int sum = 0;

        for ( int i = startIndex; i < endIndex; i ++ ) {
          sum = 0;
          for ( int j = i; j < vCount; j++ ) {
            sum += vList[ j ];
            if ( sum > max ) {
              max = sum;
            }
          }
        }

        // lock the write end so that other children can't write simultaneously
        lockf( pfd[ 1 ], F_LOCK, 0 );
        if ( write(pfd[ 1 ], &max, sizeof( int )) < 0 ) {
          fail( "Error writing to pipe" );
        }
        // unlock so that other children can have access again
        lockf( pfd[ 1 ], F_ULOCK, 0 );

        // if the report flag is on, print 
        if ( report ) {
          printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), max );
        }

        // exit out of the child process
        exit( EXIT_SUCCESS );
      }

  }

  // the parent process
  int sum; // the sum value

  // the max value
  int max = INT_MIN;

  close(pfd[ 1 ]);

  // loop through and read all values from pipe
  for ( int i = 0; i < workers; i++ ) {
    if ( read( pfd[ 0 ] , &sum, sizeof(int) ) < 0 ) {
      fail("Error reading from pipe");
    }
    // check the sum and set the max
    if ( sum > max ) {
      max = sum;
    }
  }
  // report the maximum
  printf( "Maximum Sum: %d\n", max );

  // wait for each process to finish
  for ( int i = 0; i < workers; i++ ) {
    wait( NULL );
  }

  return 0;
}