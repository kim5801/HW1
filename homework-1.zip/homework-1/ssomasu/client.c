/**
 * @file client.c
 * @author Sarvesh Somasundaram
 * This is the client side code for the lights out game, this talks to the server side code for commands
 */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// main method to send commands from client to the server
int main( int argc, char *argv[] ) {
    
  // check if the number of arguments is correct, either one argument or 3 arguments
  if (argc != 2 && argc != 4) {
    fail("Invalid number of arguments given");
  }


  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );



  // instantiate the message with limit
  char message[MESSAGE_LIMIT];


  // check if the first argument matches report
  if ( strcmp( argv[ 1 ], "report" ) == 0) {
    // send the report command and receive the current state of the board
    mq_send( serverQueue, argv[1], strlen(argv[1]), 0 );
    mq_receive( clientQueue, message, sizeof(message), NULL );
        
  } 
  
  // check if the argument is undo
  else if ( strcmp( argv[ 1 ], "undo") == 0) {
    // check to make sure correct number of args are present
    if (argc != 2) {
      fail( "Invalid number of arguments" );
    }
    // send the command and recieve whether it was a success or error
    mq_send( serverQueue, argv[1], strlen(argv[1]), 0 );
    mq_receive( clientQueue, message, sizeof(message), NULL );
  }


  // check to see if the argument was move
  else if ( strcmp( argv[1], "move") == 0) {
    // check to make sure the index values are present as well
    if (argc != 4) {
      fail( "Invalid number of arguments" );
    }

    // check to make sure no nonsense values get through as index values
    if (atoi(argv[2]) == 0 && strcmp(argv[2], "0") != 0) {
      fail("error");
    }
    else if (atoi(argv[3]) == 0 && strcmp(argv[3], "0") != 0) {
      fail("error");
    }
    // send the move command, index1, and index2 to the queue
    mq_send( serverQueue, argv[1], strlen(argv[1]), 0 );
    mq_send( serverQueue, argv[2], strlen(argv[2]), 0);
    mq_send( serverQueue, argv[3], strlen(argv[3]), 0);

    // receive the result
    mq_receive( clientQueue, message, sizeof(message), NULL );
  }
  // if an invalid command is entered, fail
  else {
    fail("error");
    exit( 1 );
  }
  // print the result and exit
  printf("%s\n", message);
  return 0;
}