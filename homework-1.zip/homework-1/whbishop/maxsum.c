#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.
  
  //Create a new pipe for the children to communicate with the parent
  int pfd[2];
   if (pipe(pfd) != 0) {
        fail ("can't create pipe");
  }
  
  //int spacingOfIndicies = vCount / workers;

  //pid_t *ids = (pid_t *)malloc(workers * sizeof( pid_t ));
  
  
  /*
  for (int i = 0; i < workers; i++) {
    if (getpid() == 0) break;
    pid_t id = fork();
    if (id == 0) {
      break;
    }
    ids[i] = id;
    printf("This is the child process. My pid is %d and my parent's id is %d.\n", getpid(), fork());
  }

  //wait(NULL);
  //wait(NULL);
  //for (int i = 0; i < workers; i++) {
  //  printf("I am process: %d\n", ids[i]);
  //}

  
    
    int maxSumChild = 0;
    int currentSumChild = 0;
    for (int j = i; j < vCount; j+= workers) {
      
      for (int k = 0; k < workers; k++) {
        
        currentSumChild += vList[k + j];
        if (currentSumChild > maxSumChild) {
          maxSumChild = currentSumChild;
        }

      }

    }
    printf(: %d\n", maxSumChild);

  }
  */

  
  //over-arching loop, this first layer will iterate through how many workers is necessary
  //and the parent will loop and create workers amount of child processes, and will not enter the nested loop
  for (int i = 0; i < workers; i++) {
    
    //Fork, and check if a child process
    if (fork() == 0) {
      
      //Child processes will continue through, we begin by closing the reading end
      close(pfd[0]);
      //dup2(pfd[1], STDOUT_FILENO);
      //close(pfd[1]);
      

      //This second level of the loop will iterate through the indicies, incrementing by workers amount
      //in order to ensure each child proccess is starting on a different index, as provided in the writeup
      //int currentSumChild = 0;
      int maxSumChild = 0;
      for (int j = i; j < vCount; j += workers) {

        if (j == i) {
          maxSumChild = vList[j];  
        }
        int currentSumChild = 0;

        //The final level of the loop indexes into every int, and adds it to the currents um of the child. 
        for (int k = j; k < vCount; k++) {
          
          if ((k) >= vCount) break;
          currentSumChild += vList[k];
          //printf("%d\n", currentSumChild);
          
          //If the current sum is greater than the max sum, set the new max sum
          if (currentSumChild > maxSumChild) maxSumChild = currentSumChild;
       }
      }
      
      //If the user requests a report, print out that report for the child
      if (report) printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), maxSumChild);
      
      //Lock the pipe to avoid collision. 
      lockf( pfd[1] , F_LOCK, 0 );

      //Write to the pipe the address of the maximum sum that the child process obtained
      write(pfd[1], &maxSumChild, sizeof(int));

      //Unlock the pipe
      lockf( pfd[1], F_ULOCK, 0 );

      //Exit the child process
      exit(0);
    }
  }
  
  //Loop through the number of workers and have the parent wait for all of them to finish
  for (int i = 0; i < workers; i++) wait(NULL);
  

  //Initialize vals for the parent to use
  int parentMaxSum;
  int currentMaxSum;

  //Loop again through the workers
  for (int i = 0; i < workers; i++) {

    //Read the value that each of them sent
    read(pfd[0], &parentMaxSum, sizeof(int));

    //if the current sum is greater than the max sum, set that
    if (i == 0) currentMaxSum = parentMaxSum;
    if (parentMaxSum > currentMaxSum) currentMaxSum = parentMaxSum;
  }
  
  //Not sure if it's necessary to close these, but I'm doing it just in case.
  close(pfd[0]);
  close(pfd[1]);
  
  //Print out the maximum sum found by all the children
  printf("Maximum Sum: %d\n", currentMaxSum);

  //free(ids);
  return 0;
}
