#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>



// Dear TA, This doesnt work at all, couldn't get it to work, spent too long trying
// to get it to work. I've narrowed down the issue to the fact that my server isn't waiting
// for the client to send it something. I will add comments in the hopes that I will get some measly 
// credit. Thank you.

static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}


//Main method for the program
int main( int argc, char *argv[] ) {
  
  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY); // | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY); // | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );
  
  //Check if the user wanted the move command
  if (argc == 4) {
    if (strcmp("move", argv[1])) {
      printf("error\n");
      exit(1);
    }

    char rows;
    char columns;
    
    //Check to make sure the indicies of the rows columns are right
    if (argv[2][0] < '0' || argv[2][0] > '4') {
      printf("error\n");

      exit(1);
    }


    //Error handling
    if (argv[3][0] < '0' || argv[3][0] > '4') {
      printf("error\n");
      //mq_close( clientQueue );
      //mq_close( serverQueue );

      //mq_unlink( SERVER_QUEUE );
      //mq_unlink( CLIENT_QUEUE );
      exit(1);
    }
    
    //Error handling
    if (strlen(argv[2]) > 1 || strlen(argv[3]) > 1) {
      printf("error\n");
      //mq_close( clientQueue );
      //mq_close( serverQueue );

      //mq_unlink( SERVER_QUEUE );
      //mq_unlink( CLIENT_QUEUE );
      exit(1);
    }
    

    //Store the rows and columns to send to the server
    rows = argv[2][0];
    columns = argv[3][0];

    
    //Send this to the server
    //char *send = (char *)malloc(3*sizeof(char));
    char send[3];
    send[0] = rows;
    send[1] = columns;
    send[2] = '\0';
    
    //send the message to the server
    int leng = mq_send( serverQueue, send, strlen(send), 0);
    
    //allocate the buffer to receive
    printf("%d", leng);
    //char *buffer = (char *)malloc(MESSAGE_LIMIT * sizeof(char));
    char buffer[MESSAGE_LIMIT];
    //Receive the message back from the server
    int len = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
    if (len >= 0) {
      for (int i = 0; i < len; i++) {
        printf("%c", buffer[i]);
      }
      printf("\n");
    }
    else {
      printf("Unable to recieve\n");
    }
    if (buffer[0] == 's') {
      
      //mq_close( clientQueue );
      //mq_close( serverQueue );

      //mq_unlink( SERVER_QUEUE );
      //mq_unlink( CLIENT_QUEUE );
      exit(0);
    }
    else {
      
      //mq_close( clientQueue );
      //mq_close( serverQueue );

      //mq_unlink( SERVER_QUEUE );
      //mq_unlink( CLIENT_QUEUE );
      exit(1);
    } 
  
    //Read if its undo
  if (argc == 2) {
    if (!strcmp("undo", argv[1])) {
      mq_send(serverQueue, "undo", strlen("undo"), 0);  

      //Malloc a buffer to read in
      //char *buffer = (char *)malloc(MESSAGE_LIMIT * sizeof(char));
      char buffer[MESSAGE_LIMIT];
      //Receive the message from the server
      int len = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
      if (len >= 0) {
        for (int i = 0; i < len; i++) {
          printf("%c", buffer[i]);
        }
        printf("\n");
      
      }
      else {
        printf("Unable to recieve\n");
      }
      if (buffer[0] == 's') {
        
        //mq_close( clientQueue );
        //mq_close( serverQueue );

        //mq_unlink( SERVER_QUEUE );
        //mq_unlink( CLIENT_QUEUE );
        exit(0);
     
      }
      else {
        
        //mq_close( clientQueue );
        //mq_close( serverQueue );

        //mq_unlink( SERVER_QUEUE );
        //mq_unlink( CLIENT_QUEUE );
        exit(1);
      }
    }

    //Check if its report
    else if (!strcmp("report", argv[1])) {

      //Send the message
      mq_send(serverQueue, "report", strlen("report"), 0);
      
      //Malloc a buffer and receive
      //char *buffer = (char *)malloc(MESSAGE_LIMIT * sizeof(char));
      char buffer[MESSAGE_LIMIT];
      int len = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
    
//      int count = 0;
      if (len >= 0) {
        for (int i = 0; i < len; i++) {
          printf("%c", buffer[i]);
        }
      }
      
      //mq_close( clientQueue );
      //mq_close( serverQueue );

      //mq_unlink( SERVER_QUEUE );
      //mq_unlink( CLIENT_QUEUE );
      exit(0);    
    }
    else {
      printf("error\n");
      //mq_close( clientQueue );
      //mq_close( serverQueue );

      //mq_unlink( SERVER_QUEUE );
      //mq_unlink( CLIENT_QUEUE );
      exit(1);
    }

  }
  printf("error");
  //mq_close( clientQueue );
  //mq_close( serverQueue );

  //mq_unlink( SERVER_QUEUE );
  //mq_unlink( CLIENT_QUEUE );
  exit(1);
  }
} 


