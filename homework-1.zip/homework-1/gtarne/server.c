/**
 * @file server.c
 * @author Grant Arne gtarne
 * Communicates with clients to play a game of lights out. This holds and modifies the game status.
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );
  exit( 1 );
}

/**
 * Represents the status of the game.
 * Holds the board, the last move, and whether there is a last move that can be undone
 * 
 */
typedef struct {
  char board[ GRID_SIZE ][ GRID_SIZE ];
  int lastMove[ 2 ];
  bool canUndo;
} *GameStatus;



/**
 * Completes one move on the given game at the given row and column, toggling 
 * surrounding lights if they are in the board
 * 
 * @param r the row to move at
 * @param c the column to move at
 * @param game the game to move in
 */
void move( int r, int c, GameStatus game ) {
  // Center piece
  if ( game->board[ r ][ c ] == '.' ) {
    game->board[ r ][ c ] = '*';
  } else {
    game->board[ r ][ c ] = '.';
  }
  // Above
  if ( r - 1 > 0 ) {
    if( game->board[ r - 1][ c ] == '.' ) {
      game->board[ r - 1 ][ c ] = '*';
    } else {
      game->board[ r - 1 ][ c ] = '.';
    }
  }
  // Below
  if ( r + 1 < GRID_SIZE ) {
    if( game->board[ r + 1][ c ] == '.' ) {
      game->board[ r + 1 ][ c ] = '*';
    } else {
      game->board[ r + 1 ][ c ] = '.';
    }
  }
  // Left
  if ( c - 1 > 0 ) {
    if( game->board[ r ][ c - 1 ] == '.' ) {
      game->board[ r ][ c - 1] = '*';
    } else {
      game->board[ r ][ c - 1] = '.';
    }
  }
  // Right
  if ( c + 1 < GRID_SIZE ) {
    if( game->board[ r ][ c + 1 ] == '.' ) {
      game->board[ r ][ c + 1] = '*';
    } else {
      game->board[ r ][ c + 1] = '.';
    }
  }
}

/**
 * Undoes the last move and returns true, or false if it could not be undone
 * 
 * @param game the game to undo the last move in
 * @return true if the move was undone, false otherwise
 */
bool undoMove( GameStatus game ) {
  if ( game->canUndo ) {
    move( game->lastMove[ 0 ], game->lastMove[ 1 ], game );
    game->canUndo = false;
    return true;
  } else {
    return false;
  }
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Stops the server from looping
void sigHandler( int sig ) {
  running = 0;
}

/**
 * Recieves and writes messages to clients to play lights out
 * 
 * @param argc the number of arguments
 * @param argv the arguments
 * @return int exit status
 */
int main( int argc, char *argv[] ) {
  // Set up handler for SIGINT
  struct sigaction act;
  act.sa_handler = sigHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Check argument number
  if ( argc != 2 ) {
    fail( "usage: server <board-file>" );
  }

  // Open file and check it exists
  FILE *boardFile = fopen( argv[ 1 ], "r" );
  if ( boardFile == NULL ) {
    char *message = "Invalid input file: ";
    strcat( message, argv[ 1 ] );
    fclose( boardFile );
    fail( message );
  }

  // Instantiate board struct
  GameStatus game = ( GameStatus )malloc( sizeof( *game ) );
  game->canUndo = false;
  char cur;
  // Loop through each row and column of input file
  for ( int r = 0; r < GRID_SIZE; r++ ) {
    for ( int c = 0; c < GRID_SIZE + 1; c++ ) {
      // Get next character
      cur = fgetc( boardFile );
      if ( ( c < GRID_SIZE ) && ( cur == '*' || cur == '.' ) ) { // If character is in grid and valid light
        // Add to board
        game->board[ r ][ c ] = cur;
      } else if ( !( c == GRID_SIZE && cur == '\n' ) ) { // If character is not a newline on the last column
        // Invalid file
        char message[ MESSAGE_LIMIT ];
        snprintf( message, MESSAGE_LIMIT - 1, "Invalid input file: %s", argv[ 1 ] );
        free( game );
        fclose( boardFile );
        fail( message );
      }
    }
  }
  // Close file
  fclose( boardFile );

  // Repeatedly read and process client messages.
  while ( running ) {

    char response[ MESSAGE_LIMIT + 1 ];
    int len = mq_receive( serverQueue, response, MESSAGE_LIMIT + 1, NULL );

    // Handle request to move
    if ( len == 3 ) {
      // Get row and col from response
      int row = response[ 1 ] - '0';
      int col = response[ 2 ] - '0';
      // Make move and set undo status and last move
      move( row, col, game );
      game->canUndo = true;
      game->lastMove[ 0 ] = row;
      game->lastMove[ 1 ] = col;

    } else {
      // Handle undo request
      if ( response[ 0 ] == 'u' ) {
        // Try to undo move
        bool undid = undoMove( game );
        // Return result of undo
        if ( undid ) {
          mq_send( clientQueue, "s", 1, 0 );
        } else {
          mq_send( clientQueue, "f", 1, 0 );
        }
      // Handle request for report
      } else {
        // Setup buffer
        char boardBuffer[ GRID_SIZE * ( GRID_SIZE + 1 ) ];
        int index = 0;
        // Load game board into buffer
        for ( int r = 0; r < GRID_SIZE; r++ ) {
          for ( int c = 0; c < GRID_SIZE + 1; c++ ) {
            if ( c == GRID_SIZE ) {
              boardBuffer[ index ] = '\n';
            } else {
              boardBuffer[ index ] = game->board[ r ][ c ];
            }
            index++;
          }
        }
        // Send game board
        mq_send( clientQueue, boardBuffer, GRID_SIZE * ( GRID_SIZE + 1 ), 0 );
      }
    }
    
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );


  // Print the game board
  printf( "\n" );
  for ( int r = 0; r < GRID_SIZE; r++ ) {
    for ( int c = 0; c < GRID_SIZE + 1; c++ ) {
      if ( c == 5 ) {
        putchar( '\n' );
      } else {
        putchar( game->board[ r ][ c ] );
      }
    }
  }

  free( game );

  return 0;
}
