/**
 * @file client.c
 * @author Grant Arne gtarne
 * A client which can issue a single command to the server to play lights out
 * 
 */

#include "common.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>

/** The maximum number of arguments to be valid */
#define MAX_ARGS 4
/** The minimum number of valid args */
#define MIN_ARGS 2


// Prints the error message to stdout
void error( ) {
  fprintf( stdout, "error\n" );
  exit( EXIT_FAILURE );
}

/**
 * Checks for valid arguments and sends a single request to sever for one action in the game of lights out
 * 
 * @param argc the number of arguments
 * @param argv the arguments
 * @return int the exit status
 */
int main( int argc, char *argv[] ) {
  // Check valid number of args
  if ( argc > MAX_ARGS || argc < MIN_ARGS ) {
    error();
  }

  // Open message queues
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );

  // Check first arg
  if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
    // Check for too few args
    if ( argc != MAX_ARGS ) {
      mq_close( serverQueue );
      mq_close( clientQueue );
      error();
    }
    // Check that row and column entries are a single character
    if ( strlen( argv[ 2 ] ) != 1  || strlen( argv[ 3 ] ) != 1 ) {
      mq_close( serverQueue );
      mq_close( clientQueue );
      error();
      // Check if row and column are invalid characters
    } else if ( ( argv[ 2 ][ 0 ] < '0' || argv[ 2 ][ 0 ] > '4' ) || ( argv[ 3 ][ 0 ] < '0' || argv[ 3 ][ 0 ] > '4' ) ) {
      mq_close( serverQueue );
      mq_close( clientQueue );
      error();
    } else {
      // Set row and column chars
      char row = argv[ 2 ][ 0 ];
      char col = argv[ 3 ][ 0 ];

      // Send move request
      char buffer[ 3 ] = { 'm', row, col };
      mq_send( serverQueue, buffer, 3, 0 );

      // Indicate success and exit
      printf( "success\n" );
      mq_close( serverQueue );
      mq_close( clientQueue );
      exit( EXIT_SUCCESS );
    }

  } else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    // Check for too many args
    if ( argc > MIN_ARGS ) {
      mq_close( serverQueue );
      mq_close( clientQueue );
      error();
    } else {
      // Send undo request
      char buffer[ 1 ] = { 'u' };
      mq_send( serverQueue, buffer, 1, 0 );

      // Recieve response
      char response[ MESSAGE_LIMIT + 1 ];
      int len = mq_receive( clientQueue, response, MESSAGE_LIMIT + 1, NULL );
      // Check for appropriate response length
      if ( len != 1 ) {
        printf( "Undo response length from server not 1\n");
        mq_close( serverQueue );
        mq_close( clientQueue );
        error();
        // Success
      } else if ( response[ 0 ] == 's' ){
        printf( "success\n" );
        // Failure
      } else {
        mq_close( serverQueue );
        mq_close( clientQueue );
        error();
      }
    }

  } else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    // Check for too many args
    if ( argc > MIN_ARGS ) {
      mq_close( serverQueue );
      mq_close( clientQueue );
      error();
    } else {
      // Send report request
      char buffer[ 1 ] = { 'r' };
      mq_send( serverQueue, buffer, 1, 0 );

      // Recieve response
      char response[ MESSAGE_LIMIT + 1 ];
      int len = mq_receive( clientQueue, response, MESSAGE_LIMIT + 1, NULL );

      // Check for correct response size
      if ( len != GRID_SIZE * ( GRID_SIZE + 1 ) ) {
        printf( "Incorrect report from server\n");
        mq_close( serverQueue );
        mq_close( clientQueue );
        error();
      } else {
        // Print out board recieved
        for ( int i = 0; i < len; i++ ) {
          putchar( response[ i ] );
        }
        mq_close( serverQueue );
        mq_close( clientQueue );
        exit( EXIT_SUCCESS );
      }
    }
    
  } else {
    // Invalid input
    mq_close( serverQueue );
    mq_close( clientQueue );
    error();
  }
}