#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <stdbool.h>

//board global variable
char board[5][5];

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}
//Executes when user hits CTRL+C
static void quitProgram() {
    printf("\n");
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            printf("%c", board[i][j]);
        }
        printf("\n");
    }
    exit(0);
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  if (argc != 2) {
    printf("usage: server <board-file>\n");
    exit(1);
  }
  //get the board
  
  FILE *fp = fopen(argv[1], "r");
  if (fp == NULL) {
    printf("Invalid input file: filename\n");
    exit(1);
  }
  char ch;
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
        ch = fgetc(fp);
        board[i][j] = ch;
    }
    ch = fgetc(fp); //get rid of newline char
  }
  fclose(fp);
  // Repeatedly read and process client messages.
  struct sigaction act;
  act.sa_handler = quitProgram;
  int xPos = 0;
  int yPos = 0;
  bool undoOk = false;
  while ( running ) {
    char buffer[500];
    sigaction(SIGINT, &act, NULL);

    int len = mq_receive( serverQueue, buffer, MESSAGE_LIMIT, NULL );

    if ( len <= 0 ) {
        perror("Error: ");
    }

    //break up each arg
    char *words[4];
    int wordCount = 0;
    char *word;
    word = strtok(buffer, " ");
    while (word != NULL) {
        words[wordCount] = word;
        word = strtok(NULL, " ");
        wordCount++;
    }

    char sendBuffer[1]; //buffer to send back to client
    bool move = false;
    
    bool undo = false;
    bool report = false;
    if (strcmp(words[1], "undo") == 0) {
        undo = true;
    } else if (strcmp(words[1], "report") == 0) {
        report = true;
    } else if (strcmp(words[1], "move") == 0) {
        move = true;
        if (words[2][0] < '0' || words[2][0] > '9' ||words[3][0] < '0' || words[3][0] > '9') {
            xPos = -1;
            yPos = -1;
        } else {
            xPos = atoi(words[2]);
            yPos = atoi(words[3]);
        }
    } else {
       sendBuffer[0] = '3';
       mq_send( clientQueue, sendBuffer, strlen( sendBuffer ) + 1, 0 );
    }

    
    sendBuffer[0] = '0'; //1 indicates success, 0 failure
    if (move) {
        if ((xPos < GRID_SIZE && xPos >= 0) && (yPos < GRID_SIZE && yPos >= 0)) {
            board[xPos][yPos] = '*';
            sendBuffer[0] = '1';
            undoOk = true;
        } else {
            sendBuffer[0] = '3';
        }
        mq_send( clientQueue, sendBuffer, strlen( sendBuffer ) + 1, 0 );
    }
    if (undo) {
        if (undoOk) {
            board[xPos][yPos] = '.';
            sendBuffer[0] = '1';
        } else {
            sendBuffer[0] = '3';
        }
        undoOk = false;
        mq_send( clientQueue, sendBuffer, strlen( sendBuffer ) + 1, 0 );
    }
    if (report) {
        sendBuffer[0] = '2';
        mq_send( clientQueue, sendBuffer, strlen( sendBuffer ) + 1, 0 );
        for (int i = 0; i < GRID_SIZE; i++) {
            mq_send( clientQueue, board[i], strlen( board[i] ) + 1, 0 );
        }
        
    }
  }
    

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
