#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);
    if ( serverQueue == -1 )
        fail( "Can't open message queue" );

    int len = 0;
    for (int i = 0; i < argc; i++) { //find length of the new buffer
        len += strlen(argv[i]);
        len++; //extra space... for a space.
    }
    len++; //space for null terminator
    //copy over args to the sending buffer.
    char buffer[len];
    int currentIdx = 0;
    for (int i = 0; i < argc; i++) {
        for (int j = 0; j < strlen(argv[i]); j++) {
            buffer[currentIdx] = argv[i][j];
            currentIdx++;
        }
        buffer[currentIdx] = ' '; //put a space between args
        currentIdx++;
    }
    buffer[currentIdx + 1] = '\0';

    mq_send( serverQueue, buffer, strlen( buffer ) + 1, 0 );

    char recBuffer[2];
    recBuffer[0] = '2';
    int bufLen = mq_receive(clientQueue, recBuffer, MESSAGE_LIMIT, 0);

    if (bufLen <= 0 ) {
        perror("Error: ");
    }

    if (recBuffer[0] == '1') {
        printf("success\n");
    } else if (recBuffer[0] == '0') {
        printf("failure\n");
    } else if (recBuffer[0] == '3') {
        printf("error\n");
    }

    if (strstr(buffer, "report")) {
        char boardRow[MESSAGE_LIMIT];
        for (int i = 0; i < GRID_SIZE; i++) {
            int bufLen2 = mq_receive(clientQueue, boardRow, MESSAGE_LIMIT, 0);
            if (bufLen2 <= 0 ) {
                perror("Error: ");
            }
            for (int j = 0; j < GRID_SIZE; j++) {
                printf("%c", boardRow[j]);
            }
            printf("\n");
        }
    }


    mq_close( serverQueue );
    mq_close( clientQueue );
}