#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

void sigHandler( int sig ) {
    running = 0;
    printf( "\n" );
}

typedef struct {
    char board[ 5 ][ 5 ];
    int row;
    int col;
    _Bool undoAllowed;
} Board;

void makeMove( Board *b, int row, int col ) {
    if ( b->board[ row ][ col ] == '.' ) {
        b->board[ row ][ col ] = '*';
    } else {
        b->board[ row ][ col ] = '.';
    }
    if ( row != 0 ) {
        if ( b->board[ row - 1 ][ col ] == '.' ) {
            b->board[ row - 1 ][ col ] = '*';
        } else {
            b->board[ row - 1 ][ col ] = '.';
        }                    
    }
    if ( col != 0 ) {
        if ( b->board[ row ][ col - 1 ] == '.' ) {
            b->board[ row ][ col - 1] = '*';
        } else {
            b->board[ row ][ col - 1] = '.';
        }                    
    }
    if ( row != 4 ) {
        if ( b->board[ row + 1 ][ col ] == '.' ) {
            b->board[ row + 1 ][ col ] = '*';
        } else {
            b->board[ row + 1 ][ col ] = '.';
        }                    
    }
    if ( col != 4 ) {
        if ( b->board[ row ][ col + 1 ] == '.' ) {
            b->board[ row ][ col + 1 ] = '*';
        } else {
            b->board[ row ][ col + 1 ] = '.';
        }                    
    }  
}

int main( int argc, char *argv[] ) {   
    errno = 0;
    struct sigaction act;
    act.sa_handler = sigHandler;
    sigemptyset( &( act.sa_mask ) );
    act.sa_flags = 0;
    sigaction( SIGINT, &act, 0);
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );
  
    int boardFile = open( argv[ 1 ], O_RDWR, 0600 );
    if ( argc != 2 ) {
        fail( "usage: server <board-file>" );
    } else if ( boardFile == -1 ) {
        fail( "Invalid input file: filename" );
    }
    
  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );
    
    Board b = { .row = 0, .col = 0, .undoAllowed = 1 };
    
    char *format = malloc( sizeof( char ) );
    for ( int i = 0; i < 5; i++ ) {
        for ( int j = 0; j < 6; j++ ) {
            read( boardFile, format, 1 );
            if ( *format != '*' && *format != '.' && *format != '\n' ) {
                fail( "Invalid input file: filename" );
            } else if ( *format == '\n' && j != 5 ) {
                fail( "Invalid input file: filename" );
            } else if ( j != 5 ) {
                b.board[ i ][ j ] = *format;
            }
        }
    }    
    free( format );

  // Repeatedly read and process client messages.
  char buf[ MESSAGE_LIMIT + 1 ];
  char word[ MESSAGE_LIMIT + 1 ];
  int num1;
  int num2;
  while ( running ) {
    
    mq_receive( serverQueue, buf, MESSAGE_LIMIT, NULL );
    
    if ( sscanf( buf, "%s", word ) == 1 ) {
        if ( strcmp( word, "move" ) == 0 ) {
            if ( sscanf( buf, "%s %d %d", word, &num1, &num2 ) != 3  || 
                 num1 < 0 || num1 > 4 || num2 < 0 || num2 > 4 ) {
                mq_send( clientQueue, "error\n", 6, 0 );
            } else {
                b.row = num1;
                b.col = num2;
                b.undoAllowed = 0;
                
                makeMove( &b, num1, num2 );
                mq_send( clientQueue, "success\n", 8, 0 );   
            }
        } else if ( strcmp( word, "undo" ) == 0 ) {
            if ( b.undoAllowed == 1 ) {
                mq_send( clientQueue, "error\n", 6, 0 );
            } else {
                b.undoAllowed = 1;
                makeMove( &b, b.row, b.col );
                mq_send( clientQueue, "success\n", 8, 0 );   
            }
        } else if ( strcmp( word, "report" ) == 0 ){
            char board[ 30 ];
            int place = 0; 
            for ( int i = 0; i < 5; i++ ) {
                for ( int j = 0; j < 5; j++ ) {
                    *( board + place ) = b.board[ i ][ j ];
                    place++;
                }
                *( board + place ) = '\n';
                place++;
            }
            *( board + place ) = '\0';
            mq_send( clientQueue, board, MESSAGE_LIMIT, 0 );
        } else {
            mq_send( clientQueue, "error\n", 6, 0 );
        }
    } else {
        mq_send( clientQueue, "error\n", 6, 0 );
    }
  }


    for ( int i = 0; i < 5; i++ ) {
        for ( int j = 0; j < 5; j++ ) {
            printf( "%c", b.board[ i ][ j ] );
        }
        printf( "\n" );
    }
    
  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
