#include "common.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <mqueue.h>
#include <string.h>

int main( int argc, char *argv[] ) {
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
    
    if ( serverQueue == -1 || clientQueue == -1 ) {
        printf( "Message queue could not be created\n" );
        exit( 1 );
    }
    
    if ( argc != 2 && argc != 4 ) {
        printf( "error\n" );
        exit( 1 );
    }
    
    char command[ MESSAGE_LIMIT + 1 ];
    int place = 0;
    int idx = 0;
    
    for ( int i = 1; i < argc; i++ ) {
        while ( *( argv[ i ] + place ) != '\0' && *( argv[ i ] + place ) != '\n' ) {
            command[ idx ] = *( argv[ i ] + place );
            place++;
            idx++;
        } 
        if ( i != argc - 1) {
            command[ idx ] = ' ';
        }
        place = 0;
        idx++;
    }
    command[ idx ] = '\0';
    
    int error = mq_send( serverQueue, command, MESSAGE_LIMIT, 0 );
    if ( error == -1 ) {
        perror( "Error sending message" );
    }
    
    char message[ MESSAGE_LIMIT ];
    error = mq_receive( clientQueue, message, MESSAGE_LIMIT, 0 );
    if ( error == -1 ) {
        perror( "Error receiving message" );
    }
    printf( "%s", message );
    
    mq_close( clientQueue );
    mq_close( serverQueue );
    
    return 0;
}