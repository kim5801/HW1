#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

//including the null terminators, this is the size of board as a string
#define BOARD_SIZE 30

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: server <board-file>\n" );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// old board stores the value of the version of the board that is changed, so that undo can be used
char board[BOARD_SIZE] = "";
char oldBoard[BOARD_SIZE] = "";

/**
 * this method is called when ctrl + C is clicked on the server
 */
void sigintHandler() {
  running = 0;
  printf("\n%s\n", board);
}

/**
 * main method evaluates the string for the board
 * gets the messages from the client using a queue and evaluates and executes the command
 * @param argc the number of arguments given when the program is initially run
 * @param argv pointer to an array of all the arguments that were given by the user when running the program
 * @return int exit status
 */
int main( int argc, char *argv[] ) {
  // this bool keeps track of whether or not the undo command is valid to use
  bool undoAvailable = false;
  signal(SIGINT, sigintHandler);

  // making sure correct number of arguments were given
  if (argc < 2 || argc > 2) {
    usage();
  }

  // opening a file stream to read the txt file for the board
  FILE *fp;
  char rawBoard[6];
  if ((fp = fopen(argv[1],"r")) == NULL) {
    fail("Invalid input file: filename");
  }
  // reading in the txt file line by line, 6 chars including the newline char
  while (fgets(rawBoard, 6, fp)) {
    strcat(board, rawBoard);
  }
  // making sure the chars in the board are valid
  for (int i = 0; i < BOARD_SIZE; i++) {
    if (board[i] != '.' && board[i] != '*' && board[i] != '\n') {
      fprintf( stderr, "Invalid input file: %s\n", argv[1] );
      exit( 1 );
    }
  }

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  char command[MESSAGE_LIMIT];
  // Repeatedly read and process client messages, until user enters ctrl+C
  while ( running ) {
    mq_receive( serverQueue, command, sizeof(command), NULL );
    if (strcmp(command, "report") == 0) {
      if (mq_send( clientQueue, board, strlen(board), 0 ) == -1) {
        fail("could not send 'report' message from server to client");
      }
    }
    else if (strcmp(command, "undo") == 0) {
      // if available, copy current board over to old board
      if (undoAvailable) {
        for (int i = 0; i < BOARD_SIZE; i++) {
          board[i] = oldBoard[i];
        }
        if (mq_send( clientQueue, "success", strlen("success"), 0 ) == -1) {
          fail("could not send 'undo success' message from server to client");
        }
      } else {
        if (mq_send( clientQueue, "error", strlen("error"), 0 ) == -1) {
          fail("could not send 'undo error' message from server to client");
        }
      }
      //undo has been used, so the user can't use it anymore
      undoAvailable = false;

    } else if (isdigit(command[0])) {
      for (int i = 0; i < BOARD_SIZE; i++) {
        oldBoard[i] = board[i];
      }
      int index = atoi(command);
      int up, down, left, right;

      if (board[index] == '*') {
        board[index] = '.';
      } else {
        board[index] = '*';
      }
      // calculating the position to be changed, and making sure that the positon is valid
      up = index - 6;
      if (up >= 0) {
        if (board[up] == '*') {
          board[up] = '.';
        } else {
          board[up] = '*';
        }
      }

      down = index + 6;
      if (down < BOARD_SIZE - 1) {
        if (board[down] == '*') {
          board[down] = '.';
        } else {
          board[down] = '*';
        }
      }

      left = index - 1;
      if (left >= 0 && board[left] != '\n') {
        if (board[left] == '*') {
          board[left] = '.';
        } else {
          board[left] = '*';
        }
      }

      right = index + 1;
      if (right < BOARD_SIZE - 1 && board[right] != '\n') {
        if (board[right] == '*') {
          board[right] = '.';
        } else {
          board[right] = '*';
        }
      }
      // set bool to true when the move command is used
      undoAvailable = true;
      if (mq_send( clientQueue, "success", strlen("success"), 0 ) == -1) {
        fail("could not send 'move success' message from server to client");
      }
    }
    for (int i = 0; i < MESSAGE_LIMIT; i++) {
      command[i] = '\0';
    }
  }
  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
