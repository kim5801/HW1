/**
 * @file client.c
 * @author Arul Sharma (asharm52)
 * This program is the client program which processes commands given by the user
 * It sends messages through the message queue to the server, where commands are executed
 */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "incorrect number of arguments given\n" );
  exit( 1 );
}

/**
 * main method reads commands from user and sends them through message queue for the server
 * @param argc the number of arguments given when the program is initially run
 * @param argv pointer to an array of all the arguments that were given by the user when running the program
 * @return int exit status
 */
int main( int argc, char *argv[] ) {

  // making sure correct number of arguments were given
  if (argc != 2 && argc != 4) {
    usage();
  }

  // Open the message queue for talking to the receiver.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
  if (serverQueue == -1)
    fail( "Can't open server queue" );
  if (clientQueue == -1)
    fail( "Can't open client queue" );
  // the response sent back from the server
  char response[MESSAGE_LIMIT];
  if (strcmp(argv[1], "report") == 0) {
    mq_send( serverQueue, "report", strlen("report"), 0 );
    mq_receive( clientQueue, response, sizeof(response), NULL );
  } else if (strcmp(argv[1], "move") == 0) {
    if (argc != 4) {
      usage();
    }
    int rows, cols;
    // converting the row number string to an int
    if (strcmp(argv[2], "0") != 0) {
      rows = atoi(argv[2]);
      if (rows == 0) {
        fail("error");
      }
    } else {
      rows = 0;
    }

    //converting the col number string to an int
    if (strcmp(argv[3], "0") != 0) {
      cols = atoi(argv[3]);
      if (cols == 0) {
        fail("error");
      }
    } else {
      cols = 0;
    }
    // checking bounds
    if (rows < 0 || rows > 4 || cols < 0 || cols > 4) {
      fail("error");
    }
    // I chose to store the board as a string, the string has 30 chars including the newline chars
    // by finding the index of the given position on the board, I can calculate the indexes of the values that need to be changed
    int index = (rows * 6) + cols;
    char str[3];
    sprintf(str, "%d", index);
    mq_send( serverQueue, str, strlen(str), 0 );
    mq_receive( clientQueue, response, sizeof(response), NULL );
  } else if (strcmp(argv[1], "undo") == 0) {
    if (argc != 2) {
      usage();
    }
    mq_send( serverQueue, "undo", strlen("undo"), 0 );
    mq_receive( clientQueue, response, sizeof(response), NULL );
  } else {
    fprintf(stdout, "%s\n", "error");
    exit( 1 );
  }
  printf("%s\n", response);
  return 0;
}