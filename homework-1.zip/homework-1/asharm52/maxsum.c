/**
 * @file maxsum.c
 * @author Arul Sharma (asharm52)
 * This program reads input from a file and finds the larget continous sum from all the numbers
 * The program uses parallel processing, number of children/processes are decided by the user
 */

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>
#include <errno.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
 * main method forks depending on number of required children and finds lagest continous sum in list of numbers
 * @param argc the number of arguments given when the program is initially run
 * @param argv pointer to an array of all the arguments that were given by the user when running the program
 * @return int exit status
 */
int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // initializing pipes, there are as many pipes as workers
  int pfd[workers][2];
  // initializing an array of ints, wil hold pid value when a new child is created via fork
  int pids[workers];
  // creating pipes based on the number of workers
  for (int i = 0; i < workers; i++) {
    if ( pipe(pfd[i]) != 0 ) {
      fail("Can't create pipe");
    }
  }

  //creating as many children as the user wants
  for (int i = 0; i < workers; i++) {
    pids[i] = fork();
    if (pids[i] == -1) {
      fail("Can't create child process");
    }
    if (pids[i] == 0) {
      // logic for each child process
      int max = -100000;
      int workerIndex = i;
      int workerIndex2 = i;
      int sum = 0;
      // iterating through the list of numbers trying to find the highest sum
      while (workerIndex < vCount) {
        while (workerIndex2 < vCount) {
          sum += vList[workerIndex2];
          if (sum > max) {
            max = sum;
          }
          workerIndex2++;
        }
        workerIndex += workers;
        workerIndex2 = workerIndex;
        sum = 0;
      }
      
      if (report) {
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), max);
      }
      
      dup2(pfd[i][1], STDOUT_FILENO);

      lockf(pfd[i][1], F_LOCK, 0);
      if (write(pfd[i][1], &max, sizeof(int)) == -1) {
        fail("Error writing to pipe");
      }
      lockf(pfd[i][1], F_ULOCK, 0);
      close(pfd[i][1]);

      exit(EXIT_SUCCESS); 
    }
  }

  //logic for parent process here
  int sum = 0;
  int max;
  for (int i = 0; i < workers; i++) {
    dup2(pfd[i][0], STDIN_FILENO);
    if (read(pfd[i][0], &sum, sizeof(int)) == -1) {
      printf("Oh dear, something went wrong with read()! %s\n", strerror(errno));
      fail("Error reading from pipe");
    }
    if (sum > max) {
      max = sum;
    }
  }
  printf("Maximum Sum: %d\n", max);

  // waiting for all children to terminate
  for (int i = 0; i < workers; i++) {
    wait(NULL);
  }
  return 0;
}
