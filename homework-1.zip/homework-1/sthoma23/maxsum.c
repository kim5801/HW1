#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // Create the pipe
  int pfd[ 2 ];
  if ( pipe( pfd ) != 0 ) {
    fail( "Can't create pipe" );
  }

  int pid = getpid(); //Get the ID of the parent
  int maxsum = 0;

  for ( int i = 0; i < workers; i++ ) {

    if ( pid != 0 ) { //Check if parent

      pid = fork(); //Create child process from parent
      if ( pid == -1 ) {
        fail( "Can't create child process" );
      }
    }

    if ( pid == 0 ) { //fork() returns 0 to children

      //Children do not need to read
      close( pfd[ 0 ] );

      if ( vCount > workers ) { 

        //Make sure each worker gets an equal workload
        for ( int j = 0; j < vCount / workers; j++ ) {

          int sum = 0;
          int start = i + ( j * workers ); //Index in vList to start at

          for ( int x = start; x < vCount; x++ ) { 

            //Start at assigned index and continue to the end
            sum += vList[ x ];

            if ( maxsum < sum ) {

              //A larger sum has been found!
              maxsum = sum;
            }
          }
        }

      }
      else if ( i < vCount ) { //Prevent looking out of bounds

        //( workers >= vCount ) == true , so workers can just
        //get one task each (until there are no more indeces)

        int sum = 0;
        for ( int j = i; j < vCount; j++ ) {   

          //Just keep assigning one start index
          //to each worker until we run out of 
          //indeces in vList

          sum += vList[ j ];
          if ( maxsum < sum ) {

            //A larger sum has been found!
            maxsum = sum;
          }
        }
        
      }

      break; //Children do not need to continue the loop
    }
  }

  if ( pid != 0 ) { 
    //Parent does not need to write
    close( pfd[ 1 ] );
  } 
  else {

    if ( report ) { //true if program is started with 'report' arg 

      //Print out program ID and respective max number found
      printf( "I’m process %d. ", getpid() );
      printf( "The maximum sum I found is %d.\n", maxsum );
    }

    //Make sure processes do not crash into
    //each other when trying to write to pipe
    lockf( pfd[ 1 ], F_LOCK, 0 );
    write( pfd[ 1 ], &maxsum, sizeof( int ) );
    lockf( pfd[ 1 ], F_ULOCK, 0 );

    //Child is successful 
    exit( EXIT_SUCCESS );
  }

  for ( int i = 0; i < workers; i++ ) {

    //Parent will wait for each worker
    wait( NULL );
  }

  int max = 0;

  for ( int i = 0; i < workers; i++ ) {

    //Read all the separate maximum the children found
    read( pfd[ 0 ], &maxsum, sizeof( int ) );


    if ( max < maxsum ) {

      //Maximum integer of the found maximums
      max = maxsum;
    }
  }

  //Print out the absolute maximum
  printf( "Maximum: %d\n", max );

  //Program successful
  return 0;
}
