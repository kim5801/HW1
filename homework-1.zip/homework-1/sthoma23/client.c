/**
* Sends a single command with each program execution
* to the server to complete a command in a game of 
* "lights-out"
*
* @file client.c
* @author Seth Thomas sthoma23
*/
#include "common.h"
#include <stdlib.h>
#include <stdio.h>
#include <mqueue.h>
#include <string.h>

/** Required number of arguments for 'move' command */
#define MOVE_NUM_ARGS 4

/** Number of arguments for 'undo' and 'report' commands */
#define NUM_ARGS 2

/** row number argv index for 'move' command */
#define ROW_IDX 2 

/** col number argv index for 'move' command */
#define COL_IDX 3

/**
* Print out an error message and exit
* unsuccessfully
*
* @param message error message
*/
static void fail( char const *message ) 
{
  fprintf( stdout, "%s\n", message );
  exit( 1 );
}

/**
* Print out the game board
* 
* @param board string representing the "lights" of the board
*/
static void print( char *board )
{
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) { //Print out 5 chars
      int idx = ( GRID_SIZE * i ) + j;
      printf( "%c", board[ idx ] );
    }
    //Print a newline every 5 chars
    printf( "\n" );
  }
}

/**
* Parse command line arguments and relay the command
* to the server via message queue pipe
*
* @param argc number of arguments
* @param argv array of null-terminated arguments
* @return 0 if no errors occur
*/
int main( int argc, char *argv[] ) 
{

  //Initialize struct variables for the message queue
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  //Open the message queue pipes
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
      
  if ( serverQueue == -1 || clientQueue == -1 ) { //Make sure the queues were made
    fail( "Can't create the needed message queues" );
  }
    
  //Create the buffers for the message queues
  int len = 0;
  char cbuffer[ MESSAGE_LIMIT ];
  char sbuffer[ MESSAGE_LIMIT ];

  if ( strcmp( argv[ 1 ], "move" ) == 0 ) { //"move" command

    if ( argc != MOVE_NUM_ARGS ) { 
      //Invalid number of command line args
      fail("error");
    }

    //Check for valid row and column indeces
    int row = 0;
    int col = 0;
    int rmatch = sscanf( argv[ ROW_IDX ], "%d", &row );
    int cmatch = sscanf( argv[ COL_IDX ], "%d", &col );

    if ( !rmatch || !cmatch ) {
      //Not an integer
      fail("error");
    }
    else if ( row < 0 || col < 0 ) {
      //Negative index
      fail("error");
    }
    else if ( row >= GRID_SIZE || col >= GRID_SIZE ) {
      //Index too large
      fail("error");
    }
    else {
      //Command is valid

      //Send the "move" command to the server
      strncpy( sbuffer, argv[ 1 ], sizeof( sbuffer ) );
      mq_send( serverQueue, sbuffer, MESSAGE_LIMIT, 0 );

      //Send the row index to the server
      strncpy( sbuffer, argv[ ROW_IDX ], sizeof( sbuffer ) );
      mq_send( serverQueue, sbuffer, MESSAGE_LIMIT, 0 );

      //Send the column index to the server
      strncpy( sbuffer, argv[ COL_IDX ], sizeof( sbuffer ) );
      mq_send( serverQueue, sbuffer, MESSAGE_LIMIT, 0 );

      //Retrieve the reply from the server
      len = mq_receive( clientQueue, cbuffer, MESSAGE_LIMIT, NULL );

      if ( len != -1 ) { 
        //Print out the reply from server
        printf( "%s\n", cbuffer );
      }
    }
  } 
  else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) { //"undo" command

    if ( argc != NUM_ARGS ) {
      //Invalid number of command line args
      fail("error");
    }
    else { 

      //Load the message queue to the server with the command
      strcpy( sbuffer, argv[ 1 ] );
      mq_send( serverQueue, sbuffer, MESSAGE_LIMIT, 0 );

      //Retrieve the reply from the server
      len = mq_receive( clientQueue, cbuffer, MESSAGE_LIMIT, NULL );

      if ( len != -1 ) {
        //Print out the reply from server
        printf( "%s\n", cbuffer );
      }
    }
  }
  else if ( strcmp( argv[ 1 ], "report" ) == 0 ) { //"report" command

    if ( argc != NUM_ARGS ) {
      //Invalid number of command line args
      fail( "error" );
    }
    else {

      //Load the message queue to the server with the command
      strcpy( sbuffer, argv[ 1 ] );
      mq_send( serverQueue, sbuffer, MESSAGE_LIMIT, 0 );

      //Retrieve the reply from the server
      len = mq_receive( clientQueue, cbuffer, MESSAGE_LIMIT, NULL );

      if ( len != -1 ) {
        //Print out the current state of the board
        print( cbuffer );
      }
    }
  }
  else { //Invalid command
    fail( "error" );
  }

  // Close our two message queues 
  mq_close( clientQueue );
  mq_close( serverQueue );

  if ( len < 0 ) { 
    //Error while trying to get reply from server
    fail( "Could not receive message from pipe" );
  }

  return 0;
}
