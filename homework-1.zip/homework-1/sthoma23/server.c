/**
* Starts a game of "lights-out", receives game 
* commands from clients via a message queue pipe,
* and handles gameplay based on the commands.
*
* Will continue running and receiving commands 
* until terminated by user with "ctrl-c"
*
* @file server.c
* @author Dr. David Sturgill
* @author Seth Thomas sthoma23
*/
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** Number of bytes in the string "move" excluding null */
#define NUM_BYTES_MOVE 4

/** Required number of command line arguments */
#define NUM_ARGS 2

/** True if the process receives a signal */
static bool gotSignal = false;

/**
* Keep track of the current state of the
* board and the previous state (if there
* is one)
*/
struct GameState
{
  char cells[ GRID_SIZE ][ GRID_SIZE ];
  char prev[ GRID_SIZE ][ GRID_SIZE ];
};

static struct GameState game; //Start a new game

/**
* Print out an error message and exit.
*
* @param message error message
*/
static void fail( char const *message ) 
{
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
* Print out the final/current state of the board 
* when user wants to exit program
*/
static void print() 
{

  printf( "\n" ); //Don't clutter the terminal

  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      printf( "%c", game.cells[ i ][ j ] );
    }
    printf( "\n" );
  }

  gotSignal = true; 
}

/**
* Change the char at the specified index
* in the board as well as adjacent chars
*
* @param row index of the row in the board
* @param col index of the column in the board
*/
static void move( int row, int col ) 
{

  for ( int i = row - 1; i <= row + 1; i++ ) {

    //Flip "on/off" at the named index,
    //the index above (if in bounds), and
    //the index below (if in bounds) 

    if ( i >= 0 && i < GRID_SIZE ) { //Bound check
      if ( game.cells[ i ][ col ] == '.' ) {
        game.cells[ i ][ col ] = '*'; //Switch on
      }
      else {
        game.cells[ i ][ col ] = '.'; //Switch off
      }
    }
  }

  for ( int i = col - 1; i <= col + 1; i += 2 ) {

    //Flip "on/off" at the left and
    //the right of the named index
    //if they are in bounds

    if ( i >= 0 && i < GRID_SIZE ) { //Bound check
      if ( game.cells[ row ][ i ] == '.' ) {
        game.cells[ row ][ i ] = '*'; //Switch on
      }
      else {
        game.cells[ row ][ i ] = '.'; //Switch off
      }
    }
  }
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

/**
* Receive command line arguments, parse input from board files,
* parse commands from clients, and handle commands/gameplay
*
* @param argc number of arguments
* @param argv array of null-terminated arguments
* @return 0 if no errors occur
*/
int main( int argc, char *argv[] ) 
{
//   Remove both queues, in case, last time, this program terminated
//   abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );
  
  if ( argc != NUM_ARGS ) { 
    //Invalid number of command line args
    fail( "usage: server <board-file>" ); 
  }
  
  //Open the named board file 
  char *file = argv[ 1 ];
  int fd = open( file, O_RDONLY, 0600 );

  if ( fd < 0 ) {
    //Could not open the file
    char err[ MESSAGE_LIMIT ] = "Invalid input file: ";
    strcat( err, file );
    fail( err );
  }

  int fsize = ( GRID_SIZE + 1 ) * GRID_SIZE;
  char fbuffer[ fsize + 1 ];

  //Read in the starting state of the game
  read( fd, fbuffer, fsize );

  if ( strlen( fbuffer ) != fsize ) {
    //Invalid number of characters in board file
    char err[ MESSAGE_LIMIT ] = "Invalid input file: ";
    strcat( err, file );
    fail( err );
  }

  //Verify that the provided file has
  //the proper board file format
  for ( int i = 0; i < GRID_SIZE; i++ ) { //Board has 5 rows

    int j = 0;
    int idx = 0;
    char ch = '\0';

    for ( j = 0; j < GRID_SIZE; j++ ) { //Board has 5 columns

      idx = i * ( GRID_SIZE + 1 ) + j;
      ch = fbuffer[ idx ];

      //Only '.' and '*' are valid 
      if ( ch != '*' && ch != '.' ) { 

        //Illegal character in the board
        char err[ MESSAGE_LIMIT ] = "Invalid input file: ";
        strcat( err, file );
        fail( err );
      }
    }

    //Newline chars are required and 
    //only allowed at the end of each
    //sequence of '*' and '.'
    idx = i * ( GRID_SIZE + 1 ) + j;
    ch = fbuffer[ idx ];
    if ( ch != '\n' ) {

      //Newline not found
      char err[ MESSAGE_LIMIT ] = "Invalid input file: ";
      strcat( err, file );
      fail( err );
    }
  }

  //Divide the string into substrings
  char *buffer = strtok( fbuffer, "\n" );
  int row = 0;
  
  //Iterate through strings with a buffer
  while ( buffer != NULL ) {

    //Initialize the board and copy from
    //buffer to board cells
    for ( int col = 0; col < GRID_SIZE; col++ ) {
      game.cells[ row ][ col ] = buffer[ col ];
    }
    row++;
    buffer = strtok( NULL, "\n" ); 
  }

  bool canUndo = true; //True until 'undo' command

  // Repeatedly read and process client messages.
  while ( running ) {

    //code to read, process and respond to messages and handle
    //the SIGINT sent when ctrl-C is pressed
    struct sigaction act;

    //Allow the user to exit by pressing "ctrl-C"
    act.sa_handler = print;
    sigemptyset( &( act.sa_mask ) );
    act.sa_flags = 0;
    sigaction( SIGINT, &act, 0 );

    if ( gotSignal ) {
      break;
    }

    //Create buffers for the pipes
    char sbuffer[ MESSAGE_LIMIT ];
    char cbuffer[ MESSAGE_LIMIT ];

    //Get a message from the client
    int len = 0;
    len = mq_receive( serverQueue, sbuffer, MESSAGE_LIMIT, NULL );

    //Check if the we were able to retrieve from the pipe
    if ( !gotSignal && len < 0 ) {
      fail( "Could not receive message from pipe" );
    }

    if ( strncmp( sbuffer, "move", NUM_BYTES_MOVE ) == 0 ) { //"move" command

      //Initialize/update the previous state of the board
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        strcpy( game.prev[ i ], game.cells[ i ] );
      }

      int r = 0;
      int c = 0;

      //Get the row number and convert to int
      mq_receive( serverQueue, sbuffer, MESSAGE_LIMIT, NULL );
      sscanf( sbuffer, "%d", &r );
      
      //Get the column number and convert to int
      mq_receive( serverQueue, sbuffer, MESSAGE_LIMIT, NULL );
      sscanf( sbuffer, "%d", &c );

      //Helper method will handle "flipping" the chars
      move( r, c );

      //User can undo this move
      canUndo = true;

      strcpy( cbuffer, "success" ); //Reply to client
      mq_send( clientQueue, cbuffer, MESSAGE_LIMIT, 0 );
    }

    else if ( strcmp( sbuffer, "undo" ) == 0 ) { //"undo" command

      if ( canUndo ) {

        //Copy the previous state to the current state
        for ( int i = 0; i < GRID_SIZE; i++ ) {
          strcpy( game.cells[ i ], game.prev[ i ] );
        }

        canUndo = false; //Cannot undo twice in a row

        strcpy( cbuffer, "success" ); //Reply to client
        mq_send( clientQueue, cbuffer, MESSAGE_LIMIT, 0 );
      }
      else {
        strcpy( cbuffer, "error" ); //Reply to client
        mq_send( clientQueue, cbuffer, MESSAGE_LIMIT, 0 );
      }
    }

    else if ( strcmp( sbuffer, "report" ) == 0 ) { //"report" command

      //Copy the current state of the board to a buffer
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        int offset = GRID_SIZE * i;
        strncpy( cbuffer + offset, game.cells[ i ], GRID_SIZE );
      }

      //Send the current board to the client
      mq_send( clientQueue, cbuffer, MESSAGE_LIMIT, 0 );
    }   
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
