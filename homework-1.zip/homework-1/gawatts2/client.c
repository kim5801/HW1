#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <errno.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
 //  mq_unlink( "/gawatts2-s" );
//   mq_unlink( "/gawatts2-c" );
  bool move = false;
  bool undo = false;
  bool report = false;
  
  //check if argument is ./client move r c
  if ( argc == 4) {
    int comparason = strcmp(argv[1], "move");
    //check if move is correct
    if ( comparason != 0 ) {
      fail("error");
    } else {
      //now check the position
      int row = atoi(argv[2]);
      int col = atoi(argv[3]);
      //row
      if ( row < 0 || row > 4) {
        fail("error");
      }
      //col
      if ( col < 0 || col > 4) {
        fail("error");
      }
    }
    move = true;
  }//END OF 4 ARG  CHECK  
  else if ( argc == 2) { //either undo or report
    //check if move is correct
    if ( strcmp(argv[1], "undo") == 0 ) {
      undo = true;
    }
    else if (strcmp(argv[1], "report") == 0) {
      report = true; 
    } else {
      fail("error"); //the one word wasn't one of the options
    }
  } else {
    fail("error"); //no other possible options for other lengths
  }
  
  
  // !AT THIS POINT WE KONW COMMAND LINE ARGUMENT IS CORRECT !
  
  mqd_t myQueue = mq_open( "/gawatts2-s", O_WRONLY );
  mqd_t clientQueue = mq_open( "/gawatts2-c", O_RDONLY);
  if ( myQueue == -1 ||  clientQueue == -1) {
    printf( "Can't create the needed message queues" );
    exit(1);
  }

 
  
  
  //    OPTION REPORT   ///
  if (report) {
    //notify server
    char buffer[ MESSAGE_LIMIT + 1 ] = "r\n";
    mq_send( myQueue, buffer, strlen( buffer ), 0 );
    
    //receive grid
    char received[ MESSAGE_LIMIT ];
    int len = mq_receive( clientQueue, received, sizeof( received ), NULL );
    //print it out 
    if ( len >= 0 ) {
      for ( int i = 0; i < len; i++ )
      printf( "%c", received[ i ] );
    } else {
      fail("no");
    }
  }
  
  
  
  
  //    OPTION UNDO   ///
  if (undo) {
    //notify server - 
    char buffer[ MESSAGE_LIMIT + 1 ] = "u\n";
    mq_send( myQueue, buffer, strlen( buffer ), 0 );
    
    char received[ MESSAGE_LIMIT ];
    int len = mq_receive( clientQueue, received, sizeof( received ), NULL );
    if ( len >= 0 ) {
      if (received[0] == 'y') {
        printf( "%s\n", "success" );
      } else if (received[0] == 'n') {
        fail("error");
      } else {
        printf("%s\n", "hola");
      }
    } else {
      fail("no");
    }
  } 
  
  
  
  
  //    OPTION MOVE   ///
  if (move) {

    char buffer[ MESSAGE_LIMIT + 1 ];
    buffer[0] = 'm'; //command
    buffer[1] = argv[2][0];
    buffer[2] = argv[3][0];
    buffer[3] = '\n';
    // send move instruction to instruction with position
    mq_send( myQueue, buffer, strlen( buffer ), 0 ); 
    char received[ MESSAGE_LIMIT ];
    // server now gives back after move opertation is performed
    int len = mq_receive( clientQueue, received, sizeof( received ), NULL );
    if ( len >= 0 ) {
      // for ( int i = 0; i < len; i++ ) // to test only print success for move
          //printf( "%c", received[ i ] );
      printf( "%s\n", "success" );
    } else {
      fail("no");
    }
  }
  // We're done, close our copy of the queue (which would happen when we exit anyway).
  mq_close( myQueue );
  mq_close( clientQueue );
  
  return 0;
}