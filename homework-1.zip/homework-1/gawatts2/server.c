#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// move operation based on position given, assumed position is correct; take advantage
//of referene semantics 
void move(int rowIdx, int colIdx, char* lineRepofGrid  ) {
  //game matrix is in grid
  int tick = 0;
  char grid[5][6];
  for (int row = 0; row < 5; row++) {
    for (int col = 0; col < 6; col++) {
      grid[row][col] = lineRepofGrid[tick];
      //putchar(grid[row][col]); //to test in printing
      tick++;
    }
  }
  // putchar('\n'); //to test in printing
  //!!grid[][] mirrors like how it is in game here !!
  bool top = false;
  bool bottom = false;
  bool left = false;
  bool right = false;
  //top row
  if (rowIdx == 0) {
    //top left corner
    if (colIdx == 0 ) {
      bottom = true;
      right = true;
    }
    //top right corner
    else if (colIdx == 4) {
      bottom = true;
      left = true;
    }
    //top internal
    else {
      bottom = true;
      left = true;
      right = true;
    } 
  } //top row close
  //bottom row
  else if ( rowIdx == 4) { 
    //bottom left corner
    if ( colIdx == 0 ) {
      top = true;
      right = true;
    }
    //bottom right corner
    else if (colIdx == 4) {
      left = true;
      top = true;
    } 
    //bottom internal
    else {
      left = true;
      top = true;
      right = true;
    }
  } //bottom row close
  //in middle
  else {
  //middle left side
    if ( colIdx == 0 ) {
      bottom = true;
      top = true;
      right = true;
    }
    //middle right side
    else if ( colIdx == 4 ) {
      bottom = true;
      top = true;
      left = true;
    }
    //internal middle - all change
    else {
      bottom = true;
      top = true;
      left = true;
      right = true;
    }
  }
  //!up to here determined the valid changeable positions
  if (top) {
    if (grid[rowIdx - 1][colIdx] == '.') {
      grid[rowIdx - 1][colIdx] = '*';
    } else {
      grid[rowIdx - 1][colIdx] = '.';
    }
  }
  if (bottom) {
    if (grid[rowIdx + 1][colIdx] == '.') {
      grid[rowIdx + 1][colIdx] = '*';
    } else {
      grid[rowIdx + 1][colIdx] = '.';
    }
  }
  if (left) {
    if (grid[rowIdx][colIdx - 1] == '.') {
      grid[rowIdx][colIdx - 1] = '*';
    } else {
      grid[rowIdx][colIdx - 1] = '.';
    }
  }
  if (right) {
    if (grid[rowIdx][colIdx + 1] == '.') {
      grid[rowIdx][colIdx + 1] = '*';
    } else {
      grid[rowIdx][colIdx + 1] = '.';
    }
  }
  //now change the position itself given
  if (grid[rowIdx][colIdx] == '.') {
    grid[rowIdx][colIdx] = '*';
  } else {
    grid[rowIdx][colIdx] = '.';
  }
  //!! AT THIS POINT ALL MOVES PUT IN GRID[][]
  tick = 0;
  for (int row = 0; row < 5; row++) {
    for (int col = 0; col < 6; col++) {
      lineRepofGrid[tick] = grid[row][col];
      //putchar(lineRepofGrid[tick]); //to test in printing
      tick++;
    }
  }
  
}





// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;
char readInput[31];
char backup[31];

//handler for sigaction
void handler( int sig ) {
  putchar('\n');//^C followed by newline
  int tick = 0;
  for (int row = 0; row < 5; row++) {
    for (int col = 0; col < 6; col++) {
      putchar(readInput[tick]); //to test in printing
      tick++;
    }
  }
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( "/gawatts2-s" );
  mq_unlink( "/gawatts2-c" );



  //setting up the board - incorrect arg
  if ( argc != 2 ) {
    fail("usage: server <board-file>");
  }
  //incorrect file
  int readFile = open( argv[1], O_RDONLY );
  if ( readFile < 0 ) {
    printf("Invalid input file: %s\n", argv[1]);
    exit(1);
  }
  
  
  bool valid = true;
  int counter = 0;
  //read from file
  int readLength = read( readFile, readInput, sizeof(readInput) );
  //check
  if (readLength != 30) { //30 is EOF / null? 31 is for us
    fail("Invalid input file: filename");
  }
  //check elements in the input
  for ( int i = 0; i < readLength; i++ ) {
    counter++;
    if (counter == 6) {
      if ( readInput[i] != '\n') {
        valid = false;
        break;
      } else {
        counter = 0;
      }
    } else {
     // cant be other than . or *
      if ( readInput[i] == '.' || readInput[i] == '*' ) {
      
      } else {
         putchar('A');
        valid = false;
        break;
      }
    }
  }
  //not 5 char per line
  if (!valid) {
    printf("Invalid input file: %s\n", argv[1]);
    exit(1);
  } 
  
  //!!up to this point we know that input file is good and readInput is good!!
 
  //move(4,4,readInput);
  
  struct mq_attr attr;
  attr.mq_flags = 0;          // No special flags. 
  attr.mq_maxmsg = 1;        // 10 messages of buffer capacity. w/o blocking
  attr.mq_msgsize = MESSAGE_LIMIT; // Maximum size of each message.

  mqd_t serverQueue = mq_open( "/gawatts2-s", O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( "/gawatts2-c", O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create request queue" );

  // Buffer for reading a message from the sender, this must be at least as large as the
  // size bound on the queue.
  char buffer[ MESSAGE_LIMIT ] = "";
  
  bool isMoved = false;  //must be maintained in server
  
  struct sigaction sa;
  sa.sa_handler = handler;
  sigemptyset( &( sa.sa_mask ) );
  sa.sa_flags = 0;

  
  while ( running ) {
    sigaction( SIGINT, &sa, 0 );
    // Try to get a message (this will wait until one arrives).
    int len = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );
    
    if ( len >= 0 ) {
      // The message isn't null terminated (we don't send the null in this example)
      // We could add a null terminator; instead, we just print it a char at a time.
      
      // RECIEVED REPORT //
      if (buffer[0] == 'r') {
      
        mq_send( clientQueue, readInput, strlen( readInput ), 0 ); //sending to client
        
      }
      
      
      // RECIEVED UNDO //
      if (buffer[0] == 'u') {
     
        if ( !isMoved ) { //fail
          char isValid[MESSAGE_LIMIT] = "n";
          mq_send( clientQueue, isValid, sizeof(isValid), 0 );
        } else { //success
          int tick = 0;
          for (int row = 0; row < 5; row++) {
            for (int col = 0; col < 6; col++) {
              readInput[tick] = backup[tick];
              //putchar(readInput[tick]); //to test in printing
              tick++;
            }
          }
          isMoved = false;
          char isValid[MESSAGE_LIMIT] = "y";
          mq_send( clientQueue, isValid, sizeof(isValid), 0 );
        }
       
      }
      
      
      // RECIEVED MOVE //
      if (buffer[0] == 'm') {
        int r = buffer[1] - '0';
        int c = buffer[2] - '0';
        //call helper method
 
        //back up readInput
        int tick = 0;
        for (int row = 0; row < 5; row++) {
          for (int col = 0; col < 6; col++) {
            backup[tick] = readInput[tick];
            //putchar(lineRepofGrid[tick]); //to test in printing
            tick++;
          }
        }
        isMoved = true;
        move( r, c, readInput);
        mq_send( clientQueue, readInput, strlen( readInput ), 0 ); //sending to client
      }

    } else
      fail( "Unable to receive message." );
  }
  
  // Close and delete the message queue.
  mq_close( serverQueue );
  mq_unlink( "/gawatts2-s" ); // Really, we should use a constant here.
  mq_close( clientQueue );
  mq_unlink( "/gawatts2-c" ); // Really, we should use a constant here.

  // Close our two message queues (and delete them).
  //mq_close( clientQueue );
  //mq_close( serverQueue );

//  mq_unlink( SERVER_QUEUE );
 // mq_unlink( CLIENT_QUEUE );

  return 0;
}
