#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>
#include <fcntl.h> //nonblocking

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

//helper method for finding the greatest sum
int findGreatest(int startIndex) {
  //printf("hola");
  //sum of all elements in range
  int sum = 0;
  //greatest sum from range
  int greatest = 0;
  //number of values in list
  int n = vCount;
  for (int i = startIndex; i < n; i++) {
    sum = vList[i] + sum;
    if (sum > greatest) {
      greatest = sum;
    }
  }
  return greatest;
}


//start of the program
int main( int argc, char *argv[] ) {

  
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

  //HAVE VALIDADED THE COMMAND LINE
  
  // create same amount of processes as workers
  pid_t pid;
  int max;
  int currentMax = 0;
  //create a pipe. new instance created
  int pfd[ 2 ];
  if ( pipe( pfd ) != 0 )
    fail( "Can't create pipe" );
  // NONBLOCKING 
  fcntl(pfd[0], F_SETFL, O_NONBLOCK);
//   fcntl(pfd[1], F_SETFL, O_NONBLOCK);
  //how many child created is the workers
  for (int i = 0; i < workers; i++) {
    
    pid = fork();
    //check if current process is ok
    if ( pid < 0) {
      fail( "Not able to fork a child" );
    } 
    
    //work with the child created- each worker shares like described in writeup
    if ( pid == 0 ) { 
      int largestSum = 0;
      int currentSum = 0;
      for (int c = i; c < vCount - 1; c += workers) {
        //calls to helper method
        currentSum = findGreatest(c);
        if (currentSum > largestSum) {
          largestSum = currentSum;
        }
      }
     
      
      //if report is true
      if (report) {
        int p = getpid();
        printf("I’m process %d. The maximum sum I found is %d.\n", p, largestSum);
      }
      //child just writes, so it does not need the reading end of pipe, which is 0
      //close( pfd[0] );
      //lock the pipe before writing
      lockf( pfd[1], F_LOCK, 0);
     
      write(pfd[1], &largestSum, sizeof(largestSum));
      
      //lock the pipe after writing
      lockf( pfd[1], F_ULOCK, 0);
      // Child is done.  Exiting will close pfd[ 1 ].
      exit( 0 );
    } else {
      //work with the parent
      //the parent does not need write, it reads
      
      //close( pfd[1] ); DONT DO THIS
       
      //IMPORTANT normally will cause blocking, reading must be set as nonblocking
   
    }  
    
    
  }//for loop ends
     
  //wait for all done then read
  for (int w = 0; w < workers; w++) {
    wait(NULL);  
    read( pfd[0], &max, sizeof(max) );
      if (currentMax < max) {
        currentMax = max;
      }
   
  }
  printf("Maximum Sum: %d\n", currentMax);
  return 0;
}
