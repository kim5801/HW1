/**
  @file maxsum.c
  @author Cade Cuddy (cjcuddy)
  This program uses child processes to
  parallelize the computation of the largest
  subsequence sum of an array of integers.
*/
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Print out a usage message, then exit.
static void usage()
{
  printf("usage: maxsum <workers>\n");
  printf("       maxsum <workers> report\n");
  exit(1);
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList()
{
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *)malloc(vCap * sizeof(int));

  // Keep reading as many values as we can.
  int v;
  while (scanf("%d", &v) == 1)
  {
    // Grow the list if needed.
    if (vCount >= vCap)
    {
      vCap *= 2;
      vList = (int *)realloc(vList, vCap * sizeof(int));
    }

    // Store the latest value in the next array slot.
    vList[vCount++] = v;
  }
}

/// Algorithm for finding the max sum in O(n^2) time,
/// as exectued across a range of (endIndex - startIndex) values.
/// @param startIndex Index of the first value in the subsequence
/// @param endIndex Starting index of the next set of subsequences (checked by a different child process)
/// @return maximum sum found in the subsequences checked
int findMaxSum(int startIndex, int endIndex)
{
  int max = vList[0];
  for (int i = startIndex; i < endIndex; i++)
  {
    int sum = 0;
    for (int j = i; j < vCount; j++)
    {
      sum += vList[j];
      if (max < sum)
      {
        max = sum;
      }
    }
  }

  return max;
}

/// Main starting point of the program, checks arg amounts
/// and then creates workers to spread across different
/// subsequence indexes.
/// @param argc Number of arguments
/// @param argv Arguments themselves
/// @return exit status
int main(int argc, char *argv[])
{
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if (argc < 2 || argc > 3)
    usage();

  if (sscanf(argv[1], "%d", &workers) != 1 ||
      workers < 1)
    usage();

  // If there's a second argument, it better be the word, report
  if (argc == 3)
  {
    if (strcmp(argv[2], "report") != 0)
      usage();
    report = true;
  }

  readList();

  // make pipe for communicating children's maxsum back to parent
  // send max sum in binary over pipe
  int pfd[2];
  if (pipe(pfd) != 0)
  {
    fail("Couldn't create pipe!");
  }

  // give worker a start & stop 'starter' index
  // they solve max sum starting on all indexes until the stop index
  int indexesPerWorker = (vCount + workers - 1) / workers;
  int startIndex = 0;
  int maxSum = vList[0];
  for (int i = 0; i < workers; i++)
  {
    int pid = fork();
    if (pid == -1)
    {
      fail("Cant create child process");
    }

    if (pid == 0)
    {
      // Don't need to read from pipe
      close(pfd[0]);
      // calculate end index
      int endIndex = startIndex + indexesPerWorker;
      if (endIndex >= vCount)
      {
        endIndex = vCount;
      }
      // find max sum
      int max = findMaxSum(startIndex, endIndex);
      // report found max sum if desired by user
      if (report)
      {
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), max);
      }
      // lock pipe, send max
      lockf(pfd[1], F_LOCK, 0);
      write(pfd[1], &max, sizeof(max));
      lockf(pfd[1], F_ULOCK, 0);
      // exit
      exit(0);
    }
    startIndex += indexesPerWorker;
  }

  close(pfd[1]);
  // wait for all child processes to finish
  while (wait(NULL) > 0)
  {
    // read reported max-sum values from children
    // and find the largest one
    int localMax = vList[0];
    int r = read(pfd[0], &localMax, sizeof(localMax));
    if (r != -1 && localMax > maxSum)
    {
      maxSum = localMax;
    }
  };

  // report the max sum and exit
  printf("Maximum Sum: %d\n", maxSum);

  return 0;
}
