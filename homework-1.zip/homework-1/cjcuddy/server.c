/**
  @file server.c
  @author Cade Cuddy (cjcuddy)
  This program acts as the server for the
  lights-out game where the state of the
  board is stored. It carries out all the requested
  commands from the client.
*/
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

#define LIGHT_ON '*'
#define LIGHT_OFF '.'
#define GRID_TOTAL 25

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// print out the state of the board
static void reportBoard(char *board)
{
  for (int r = 0; r < GRID_SIZE; r++) {
    for (int c = 0; c < GRID_SIZE; c++) {
      printf("%c", board[GRID_SIZE * r + c]);
    }
    printf("\n");
  }
}

/// Reads the board from an input file into a
/// character array
/// @param fd file descriptor number for the file containing the board
/// @param board buffer that will hold the board state for the duration of the game
/// @param filename name of the file being read, used for error reporting
static void readBoard(int fd, char *board, char *filename)
{
  char buffer;
  int i = 0;
  while ((read(fd, &buffer, 1) == 1) && i < GRID_TOTAL)
  {
    if (buffer == '\n')
      continue;
    if (buffer == LIGHT_OFF || buffer == LIGHT_ON) {
      board[i++] = buffer;
    }
    else {
      char message[] = "Invalid input file: ";
      fail(strcat(message, filename));
    }
  }
}
// changes the light as per the 'lights out' rules
static void invertLight(char *board, int row, int col) {
  int lightIndex = GRID_SIZE * row + col;
  if (board[lightIndex] == LIGHT_OFF) {
    board[lightIndex] = LIGHT_ON;
  } else {
    board[lightIndex] = LIGHT_OFF;
  }
}

// checks for edge cases and then inverts the light's state
static void editNeighbor(char *board, int row, int col) {
  if (row < 0 || col < 0 || row >= GRID_SIZE || col >= GRID_SIZE) 
    return;
  
  invertLight(board, row, col);
}

/// Edits all the chosen light's neighbors to be inverted
/// @param board board array
/// @param message move command received from client containing move row & col
/// @return status of the success of the move
bool makeMove(char *board, char *message) {
  // directional array representing positions of neighbors
  int dirs[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
  // get row an column of move
  int r = message[1] - '0';
  int c = message[2] - '0';
  if (r < 0 || r >= GRID_SIZE || c < 0 || c >= GRID_SIZE)
    return false;
  // make the initial move
  invertLight(board, r, c);
  for (int i = 0; i < GRID_SIZE - 1; i++) {
    // change state of left, right, up, and down neighbors
    editNeighbor(board, r + dirs[i][0], c + dirs[i][1]);
  }

  return true;
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;
// Success status passed to client in event of successful command execution
static char successBuffer[] = {SUCCESSFUL};
// Error status passed to client in event of unsuccessful command execution
static char errorBuffer[] = {ERROR};
// Global board state
char board[GRID_TOTAL];
// Undo board state, holds state of board from 1 move ago
char undoBoard[GRID_TOTAL];

// Handles CTRL+C press, prints a newline
// and then the board and exits
void signalHandler(int sig)
{
  printf("\n");
  reportBoard(board);
  exit(0);
}

int main(int argc, char *argv[])
{
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink(SERVER_QUEUE);
  mq_unlink(CLIENT_QUEUE);

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open(SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
  mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
  if (serverQueue == -1 || clientQueue == -1)
    fail("Can't create the needed message queues");

  // prepare action and handler
  struct sigaction act;
  // set to empty
  sigemptyset(&(act.sa_mask));
  act.sa_handler = &signalHandler;
  act.sa_flags = 0;
  // set action to look for as CTRL+C
  sigaction(SIGINT, &act, 0);

  // error handling for args
  if (argc != 2)
    fail("usage: server <board-file>");

  // file error handling
  int readFile = open(argv[1], O_RDONLY);
  if (readFile == -1) {
    fail("Error opening file.");
  }

  // establish undo variable and command variable
  bool lastMoveUndo = false;
  char command[MESSAGE_LIMIT];
  
  // Read board from input file and copy to undo board as well
  readBoard(readFile, board, argv[1]);
  memcpy(undoBoard, board, sizeof(board)); // undo board starts as copy of start board

  // Repeatedly read and process client messages.
  while (running)
  {
    // wait for client commands
    int len = mq_receive(serverQueue, command, sizeof(command), NULL);
    if (len < 0) {
      mq_send(clientQueue, errorBuffer, sizeof(errorBuffer), 0);
    }
    // move request - mRC (move[row][col])
    // move response - s (successful) e (error)
    if (command[0] == MOVE_COMMAND) {
      // save state of board before the move to undo board
      memcpy(undoBoard, board, sizeof(board));
      if (makeMove(board, command)) {
        // undo is off cooldown since a move has been made
        if (lastMoveUndo) {
          lastMoveUndo = false;
      }
      mq_send(clientQueue, successBuffer, sizeof(successBuffer), 0);
      } 
      else {
        mq_send(clientQueue, errorBuffer, sizeof(errorBuffer), 0);
      }
    }
    // undo request - u
    // undo response - s (successful) e (error)
    else if (command[0] == UNDO_COMMAND) {
        // check if lastMoveUndo is true, if so, return error
      if (lastMoveUndo) {
        mq_send(clientQueue, errorBuffer, sizeof(errorBuffer), 0);
      } else {
        // set board state to undoBoard, set lastMoveUndo to true
        memcpy(board, undoBoard, sizeof(undoBoard));
        mq_send(clientQueue, successBuffer, sizeof(successBuffer), 0);
        lastMoveUndo = true;
      }
    }
    // report request - r
    // report response - board state, formatted in client
    else if (command[0] == REPORT_COMMAND) {
      printf("report request received\n");
      char response[MESSAGE_LIMIT];
      memcpy(response, board, sizeof(board));
      mq_send(clientQueue, response, sizeof(response), 0);
    }
  }

  // Close our two message queues (and delete them).
  mq_close(clientQueue);
  mq_close(serverQueue);

  mq_unlink(SERVER_QUEUE);
  mq_unlink(CLIENT_QUEUE);

  return 0;
}
