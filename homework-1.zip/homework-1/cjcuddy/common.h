// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/cjcuddy-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/cjcuddy-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5

// Messaging queue code for move
#define MOVE_COMMAND 'm'

// Messaging queue code for undo
#define UNDO_COMMAND 'u'

// Messaging queue code for report
#define REPORT_COMMAND 'r'

// Messaging queue code for success
#define SUCCESSFUL 's'

// Messaging queue code for error
#define ERROR 'e'