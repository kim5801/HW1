/**
  @file client.c
  @author Cade Cuddy (cjcuddy)
  This program acts as the client for
  the lights-out game. It interacts with the server to
  send moves, request the state of the board, and undo moves.
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <mqueue.h>
#include "common.h"

#define MOVE "move"
#define UNDO "undo"
#define REPORT "report"

/// Exits the program with a failing
/// status message.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

/// Prints the 5x5 board out to stdout
/// @param board board represented as a 1D array of lights
static void reportBoard(char *board)
{
  for (int r = 0; r < GRID_SIZE; r++) {
    for (int c = 0; c < GRID_SIZE; c++) {
      printf("%c", board[GRID_SIZE * r + c]);
    }
    printf("\n");
  }
}

/// Processes the server's response to commands issued
/// by the client and prints the corresponding output to stdout.
/// @param buffer 
static void readResponse(char *buffer)
{
  if (buffer[0] == SUCCESSFUL) {
    printf("success\n");
  }
  else if (buffer[0] == ERROR) {
    printf("error\n");
  }
  else {
    printf("response broke: %c\n", buffer[0]);
  }
}

/// Main running point of the program. Simple command parsing
/// that issues the desired command provided the appropriate
/// args and rules are being followed.
/// @param argc Number of args.
/// @param argv Args array
/// @return exit status
int main(int argc, char *argv[])
{
  // Connect to messaging queues
  mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY);
  mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY);

  if (argc < 2) {
    fail("No args given.");
  }

  // Move command
  // Send format: mRC [R - row, C - col] i.e m10
  if (strcmp(argv[1], MOVE) == 0) {
    // missing coordinate args
    if (argc < 4) {
      fail("Not enough coordinates provided for move.");
    }
    // check that coords are within bounds
    int r = argv[2][0] - '0';
    int c = argv[3][0] - '0';
    if (r < 0 || r > 4 || c < 0 || c > 4) {
      fail("Coordinate(s) out of range.");
    }
    // package and send the move command
    char command[MESSAGE_LIMIT] = {MOVE_COMMAND, *argv[2], *argv[3], '\0'};
    char response[MESSAGE_LIMIT];
    if (mq_send(serverQueue, command, sizeof(command), 0) != 0) {
      fail("Failed to send move.");
    }
    // recieve server response
    int len = mq_receive(clientQueue, response, sizeof(response), 0);
    if (len < 0) {
      fail("Couldn't receive command response message.");
    }
    // prints success or error of server's response
    readResponse(response);
  }
  // Undo command
  // Send format: u
  else if (strcmp(argv[1], UNDO) == 0) {
    // package and send the undo command
    char command[MESSAGE_LIMIT] = {UNDO_COMMAND, '\0'};
    char response[MESSAGE_LIMIT];
    if (mq_send(serverQueue, command, sizeof(command), 0) != 0) {
      fail("Failed to send move.");
    }
    // recieve server response
    int len = mq_receive(clientQueue, response, sizeof(response), 0);
    if (len < 0)
      fail("Couldn't receive command response message.");
    // prints success or error of server's response
    readResponse(response);
  }
  // report - requests current state of the board 
  // Send format: r
  // print 5x5 board sent over by server or nothing at all (if unsucessful)
  else if (strcmp(argv[1], REPORT) == 0) {
    // package and send the report command
    char command[MESSAGE_LIMIT] = {REPORT_COMMAND, '\0'};
    char responseBoard[MESSAGE_LIMIT];
    if (mq_send(serverQueue, command, sizeof(command), 0) != 0) {
      fail("Failed to send move.");
    }
    // recieve board state from server and write to responseBoard buffer
    int len = mq_receive(clientQueue, responseBoard, sizeof(responseBoard), 0);
    if (len < 0) {
      fail("Couldn't receive command response message.");
    } 
    else {
      // print the responseBoard to stdout
      reportBoard(responseBoard);
    }
  }
  // Command issued isn't in scope of client
  else {
    fail("Invalid command.");
  }
  exit(0);
}