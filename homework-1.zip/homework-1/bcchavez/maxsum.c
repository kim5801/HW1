#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 || workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.
  int finalMax = 0;
  int temp = 0;
  int maxRangeSum = 0; // holds the max sum for a specific range 
  int size = sizeof(vList) / sizeof(*vList); // grab the size of the values list 
  pid_t ids[workers];
  // Create a pipe for talking with the children, it holds all the children info
  int pfd[ 2 ];
  if ( pipe( pfd ) != 0 )
    fail( "Can't create pipe" ); // be careful about where the pipe ends get closed 
    
  // Make all the child processes/workers
  pid_t worker;
  int k = 0;
  int idx = 0; 
  
  start_of_loop;
  for ( int i = 0; i < workers; i++ ) {
    worker = fork();
    // Error check 
    if ( worker < 0 ) 
      fail( "Can't create child process" );
    ids[ i ] = getpid(); // store the worker ids 
  }
    
  if ( worker == 0 ) {
    for ( k = 0; k < size; k++ ) {
      for ( int j = 0; j < size; j++ ) {
        // see if the ids are the same 
        if ( getpid() == ids[k] ) {
          // see what the index is to see which index is passed to the child process
          if ( j % workers ==  )
        
        }
        // calculate the max range sum
          if (  % workers == 0 )
        }
        
      }  
    }
      
    
    // close reading end of the pipe
    close( pfd[ 0 ]);
    // lock the pipe
    lockf(fd, F_LOCK, 0);
      
    // puts results into writing end of the pipe with starting address of sum and # of bytes
    if ( write( pfd[ 1 ], &sum, sizeof(sum) ) != sizeof(sum) )
      fail( "Can't write to the pipe" );
        
    if ( report ) {
      printf("I'm process %d. The maximum sum I found is %d\n", getpid(), maxRangeSum );
      exit(0); // May need to be return 0
    }
  }
  else {
    // close writing end of the pipe 
    close( pfd[ 1 ] );
      
    // uses reading end of the pipe
    if ( read( pfd[ 0 ], finalMax, sizeof(finalMax) ) != sizeof(finalMax) )
      fail( "Can't read from the pipe" );
      
    // parent will wait for workers to find their max sums 
    printf("Maximum Sum: %d\n", finalMaxSum); 
        
    // wait for the children to exit before parent exits
    wait( NULL );
  }
  goto start_of_loop;

  return 0;
}
