#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stdout, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  bool report = false;
  // bool move = false;
  // bool undo = false;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 4 ) {
    fail("error");
  }

  // If the second argument is "move" it should have 2 more commands for row and collumn. 
  if ( argc == 4 ) {
    if ( strcmp( argv[ 1 ], "move" ) != 0 ) {
      fail("error");
    }
  }

  // open the server and client queues for communication between client and server.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );

  // create the message that will be sent to the server
  char buffer[MESSAGE_LIMIT];
  if (strcmp( argv[ 1 ], "move" ) == 0) {
    const char space = ' ';
    strcpy(buffer, argv[ 1 ]);
    strncat(buffer, &space, 1);
    strncat(buffer, argv[2], strlen(argv[2]));
    strncat(buffer, &space, 1);
    strncat(buffer, argv[3], strlen(argv[3]));
  }
  else {
    strcpy(buffer, argv[ 1 ]);
  }

  if (strcmp( argv[ 1 ], "report" ) == 0) {
    report = true;
  }

  // send the server the command to run on the board
  mq_send(serverQueue, buffer, strlen( buffer ), 0);
  
  // Create a buffer to recieve the output to print from the server.
  char serverBuffer[MESSAGE_LIMIT];
  // Recieve the output that is to be printed from the server.
  mq_receive( clientQueue, serverBuffer, sizeof(serverBuffer), NULL );
  // print the output from the server (may have to modify this code to print correctly later).
  // if (len != 0) {
  //   fail("message not recieved");
  // }

  if (report) {
    printf("\n");
    int count = 0;
    for (int row = 0; row < GRID_SIZE; row ++)
    {
      for(int col = 0; col < GRID_SIZE; col++)
      {
        printf("%c", serverBuffer[count]);
        count++;
      }
      printf("\n");
    }
  }
  else {
    printf("%s\n", serverBuffer);
  }

}