#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

char board[GRID_SIZE][GRID_SIZE];
const char on = '*';
const char off = '.';

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

void exit_handler(int sig){
  printf("\n");
  for (int row = 0; row < GRID_SIZE; row ++)
  {
    for(int col = 0; col < GRID_SIZE; col++)
    {
      printf("%c", board[row][col]);
    }
    printf("\n");
  }
  exit(0); 

}


// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main( int argc, char *argv[] ) {

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  //this bit should catch a ctrl+C signal and print the state of the board while exiting
  struct sigaction act;
  act.sa_handler = exit_handler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Parse the command-line arguments, and initialize the board.
  if ( argc != 2 ) {
    fail("usage: server <board-file>");
  }

  // Open a file to read.
  int readFile = open( argv[1], O_RDONLY );

  // Check that the input file is valid.
  if ( readFile < 0 ) {
    fprintf( stderr, "Invalid input file: %s", argv[1] );
  }

  // Read in the input from the input file:
  char longBoard[25];
  int i = 0;
  int readLen = read( readFile, &longBoard[i], 1 );

  while ( readLen > 0) {
    if (longBoard[i] != '\n') {
      i++;
    }
    readLen = read( readFile, &longBoard[i], 1 );
  }

  // for (int i = 0; i < 25; i++) {
  //   if (strcmp(&longBoard[i], &on) != 0 && strcmp(&longBoard[i], &off) != 0) {
  //     fprintf( stderr, "Invalid input file: %s", argv[1] );
  //   }
  // }

  // These booleans should keep track of if the board has had a move made yet, or if the previous move was already 
  // undone, making it easier to track if the user can use the undo function at any given time.
  bool moved = false;
  bool undone = false;
  //bool report = false;

  // Empty board is a 2D array of length and width 5. The loop should read in rows of input to initialize the board
  //char board[GRID_SIZE][GRID_SIZE];
  int count = 0;
  for (int row = 0; row < GRID_SIZE; row ++)
  {
    for(int col = 0; col < GRID_SIZE; col++)
    {
      board[row][col] = longBoard[count];
      count++;
    }
  }

  // this will be the board that is saved before every move so the undo function can work
  char backupBoard[GRID_SIZE][GRID_SIZE];
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      backupBoard[i][j] = board[i][j];
    }
  }


  // Repeatedly read and process client messages.
  while ( running ) {

    char buffer[ MESSAGE_LIMIT ];
    // recieve the client messages.
    int len = mq_receive( serverQueue, buffer, sizeof(buffer), NULL );

    const char space[2] = " ";
    char *command;
    int col1 = 0;
    int row1 = 0;
  
    if ( len >= 0 ) {
      command = strtok(buffer, space);
      char *possRow = strtok(NULL, space);
      if (possRow != NULL) {
        row1 = atoi(possRow);
        col1 = atoi(strtok(NULL, space));
      }
    }
    else {
      mq_send(clientQueue, "error", sizeof("error"), 0 );
    }

    // make sure the row1 and col1 are valid for a move command
    if (row1 < 0 || row1 > 4 || col1 < 0 || col1 > 4) {
      mq_send(clientQueue, "error", sizeof("error"), 0 );
    }

    // checks what command was run and runs it.
    if (strcmp(command, "move") == 0) {

      // save the original state of the board
      for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
          backupBoard[i][j] = board[i][j];
        }
      }

      // switches the selected light
      if (board[row1][col1] == '*') {
        board[row1][col1] = '.';
      }
      else {
        board[row1][col1] = '*';
      }
      // switches the light below the selected light
      if (row1 < GRID_SIZE - 1) {
        if (board[row1 + 1][col1] == '*') {
          board[row1 + 1][col1] = '.';
        }
        else {
          board[row1 + 1][col1] = '*';
        }
      }
      // switches the light above the selected light
      if (row1 > 0) {
        if (board[row1 - 1][col1] == '*') {
          board[row1 - 1][col1] = '.';
        }
        else {
          board[row1 - 1][col1] = '*';
        }
      }
      // switches the light to the right of the selected light
      if (col1 < GRID_SIZE - 1) {
        if (board[row1][col1 + 1] == '*') {
          board[row1][col1 + 1] = '.';
        }
        else {
          board[row1][col1 + 1] = '*';
        }
      }
      // switches the light to the left of the selected light
      if (col1 > 0) {
        if (board[row1][col1 - 1] == '*') {
          board[row1][col1 - 1] = '.';
        }
        else {
          board[row1][col1 - 1] = '*';
        }
      }

      moved = true;
      mq_send(clientQueue, "success", sizeof("success"), 0 );
      undone = false;
    }
    else if (strcmp(command, "report") == 0) {
      char messageBoard[25];
      int count = 0;
      for (int row = 0; row < GRID_SIZE; row ++)
      {
        for(int col = 0; col < GRID_SIZE; col++)
        {
          messageBoard[count] = board[row][col];
          count++;
        }
      }
      //sends the current board back to the client in the form of one longer single dimension array.
      mq_send(clientQueue, messageBoard, sizeof(messageBoard), 0 );
    }
    else if (strcmp(command, "undo") == 0) {
      if (moved && !undone) {
        
        // return to the original state of the board
        for (int row = 0; row < GRID_SIZE; row ++)
        {
          for(int col = 0; col < GRID_SIZE; col++)
          {
            board[row][col] = backupBoard[row][col];
          }
        }
        mq_send(clientQueue, "success", sizeof("success"), 0 );
        undone = true;
      }
      else {
        mq_send(clientQueue, "error", sizeof("error"), 0 );
      }
    }
    else {
      mq_send(clientQueue, "error", sizeof("error"), 0 );
    }
    
    
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
