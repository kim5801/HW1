/**
 * Server for lights out game
 * @file server.c
 * @author Noah Lichlyter nalichly
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

//number of rows
#define ROWS 5
//number of columns
#define COLS 5

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Print out an error message and exit.
static void fail(char const *message) {
    fprintf(stderr, "%s\n", message);
    exit(1);
}

//handles printing message for bad file
void badFile(char const *filepath) {
    fprintf(stderr, "Input file invalid: %s\n", filepath);
    exit(1);
}

//makes a board from a given file
char **makeBoard(FILE *fp) {
    //malloc board
    char** board = (char **) calloc(ROWS, sizeof(char *));
    for (int i = 0; i < ROWS; i++) {
        board[i] = (char *) calloc (COLS, sizeof(char));
    }

    //make vars for parsing
    char ch;
    int r = 0;
    int c = 0;

    //import board
    while ((ch = fgetc(fp)) != EOF) {
        if ((r > 4 || c > 4) && ch != '\n') {
            return NULL;
        } else if (ch == '\n') {
            r++;
            c = 0;
        } else if (ch == '.' || ch == '*') {
            board[r][c] = ch;
            c++;
        } else { //not one of the approved chars
            return NULL;
        }
    }

    return board;

}

//frees the given board from memory
void freeBoard (char ** board) {
    for (int i = 0; i < COLS; i++) {
        free(board[i]);
    }
    free(board);
}

//prints the given board to stdout
void printBoard(char **board) {
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            printf("%c", board[i][j]);
        }
        printf("\n");
    }
}

//returns printable str holding the board
boardToStr(char **board) {
    int idx = 0;
    strcpy(str, "");
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            str[idx] = '\n';
            idx++;
        }
        str[idx] = '\n';
        idx++;
    }
    str[idx] = '\0';
}

//checks if the user has won
bool checkWin (char **board) {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            if (board[i][j] == '*')
                return false;
        }
    }
    return true;
}

//executes a valid move given by the client
bool executeMove(char **board, int r, int c) {
    for (int i = r - 1; i < r + 1; i++) {
        for (int j = c - 1; j < r + 1; j++) {
            if (r < ROWS && c < COLS) {
                if (board[i][j] == '*')
                    board[i][j] = '.';
                else //period - change to star
                    board[i][j] = '*';
            }
        }
    }
    return  true;
}

//handles sigint alarm
void alarmHandler() {
    printf("\n");
    running = 0;
}

int main( int argc, char *argv[] ) {
    //check number of arguments
    if (argc != 2)
        fail("usage: server <board-file>");

    //try to open the given file
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL)
        badFile(argv[1]);

    //make board
    char **board = makeBoard(fp);
    if (board == NULL)
        fail("null board\n");
        //badFile(argv[1]);
    //other stuff for dealing with board
    char buffer[MESSAGE_LIMIT]; //buffer to hold message
    int last[2]; //holds the row and column of last valid move
    char lcmd; //holds what last command was 

    //printBoard(board);
    
    //sig handler
    struct sigaction act;
    act.sa_handler = alarmHandler;
    act.sa_flags = 0;
    sigaction(SIGINT, &act, 0);

    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 )
        fail( "Can't create the needed message queues" );

    char *report;

    // Repeatedly read and process client messages.
    while (running) {
        //var to track this command's success/failure
        //bool success = false;

        // Try to get a message (this will wait until one arrives).
        int len = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);

        //vars to hold chunks of command
        char cmd;
        int r;
        int c;

        //process message
        int rec = sscanf(buffer, "%c%d%d", &cmd, &r, &c);
        if (cmd == 'm' && rec == 3) { //valid move
            //execute command
            executeMove(board, r, c);
            //save this command 
            last[0] = r;
            last[1] = c;
            lcmd = 'm';
            //flip success to true
            //success = true;
            //send message to client
            mq_send(clientQueue, "success", strlen("succcess"), 0);
        } else if (cmd == 'u' && lcmd != cmd) { //valid undo
            //re-execute move
            executeMove(board, last[0], last[1]);
            //save last command
            lcmd = 'u';
            //flip success to true
            //success = true;
            //send message to client
            mq_send(clientQueue, "success", strlen("success"), 0);
        } else if (cmd == 'r') { //valid report
            //print board
            report = boardToStr(board);
            fprintf(stdout, "board to str result: %s\n", buffer);
            //flip success to true
            //success = true;
            //send message to client
            mq_send(clientQueue, buffer, strlen(buffer), 0);
        } else {
            //not successful
            //success = false; //redundant?
            //send message to client
            mq_send(clientQueue, "failure", strlen("failure"), 0);
        }

        // //set message to report
        // char *msg;
        // if (success) {
        //     msg = "success\n";
        //     printf("msg: %s", msg);
        // } else {
        //     msg = "failure\n";
        // }

        // //send message to client
        // mq_send(clientQueue, msg, strlen(msg), 0);
    }

    //done with the board
    printBoard(board);
    freeBoard(board);

    // Close our two message queues (and delete them).
    mq_close( clientQueue );//save last command before getting next one
    mq_close( serverQueue );

    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    return 0;
}
