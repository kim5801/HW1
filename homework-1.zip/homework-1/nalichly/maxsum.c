/**
 * This is a program that determines which non-empty subsequence within a user-given
 * sequence of ints has the largest sum. It tries to split the work evenly among a
 * user-given number of wokrer processes.
 * 
 * @file maxsum.c
 * @author Noah Lichlyter nalichly
 */

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
 * Creates a number of children equal to the arg given by the user for workers.
 * Reads in a list of numbers typed by the user or redirected to the program by a file.
 * Determines which contiguous, non-sequential sequence within the list of numbers given
 * that has the largest sum, and then reports that sum. Splits up adding the sum together
 * somewhat evenly between processes (some may get p little extra input if number of workers
 * does not divide evenly into the length of the sequence). If report arg was given,
 * the program also reports the id of each worker and the highest sum it found.
 * 
 * @param argc number of command line args recieved
 * @param argv array of strings of args recieved 
 * @return 0 if exits successfully, without error, or another val otherwise
 */
int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  //My code starts here

  //Variable to hold the maximum sum
  int result = INT_MIN;

  //Make a pipe
  int pfd[2];
  if (pipe(pfd) != 0)
    fail("Can't create pipe");

  //Helps each child know 
  int pNum = 0;

  //make first child
  pid_t pid = fork();
  if (pid == -1)
    fail( "Can't create child process" );

  //Make more children if needed
  if (workers > 1) {
    for (int i = 1; i < workers; i++) {
      if (pid != 0) {
        pNum++;
        pid = fork();
      }
    }
  }

  if (pid == 0) { // child processes
    // pipe setup
    close(pfd[0]); //close read end of pipe
    
    //printf("my process number is: %d\n", pNum);

    // find max sum within its portion of the array
    int max = 0;
    //starts at idx = process number and increments by number of workers
    for (int i = pNum; i < vCount; i += workers) {
      int sum = 0;
      for (int j = i; j < vCount; j++) { //sum every idx between here and end
        sum += vList[j]; //check along the way for new max
        if (sum > max)
          max = sum; //save this sum if it is
      }
    }

    //report process id and max found if asked for
    if (report)
      printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), max);

    //write to pipe
    
    // error reporting for write
    lockf( pfd[1], F_LOCK, 0 );
    int status = write(pfd[1], &max, sizeof(int));
    lockf( pfd[1], F_ULOCK, 0);

    if (status == 0)
      printf("Nothing read from pipe.\n");
    if (status == -1)
      printf("Error encountered while reading from pipe.\n");
    
    //exit when finished -- should close pipe
    exit(0); 

  } else { //parent
    close(pfd[1]); //close write end of pipe

    //read results from children
    for (int i = 0; i < workers; i++) {
      int num = 0;
      //read(pfd[0], &num, sizeof(int));

      // error reporting for read
      int status = read(pfd[0], &num, sizeof(int));

      if (status == 0)
        printf("Nothing read from pipe.\n");
      else if (status == -1)
        printf("Error encountered while reading from pipe.\n");
      //else
      //  printf("Num read from pipe: %d\n", num);

      // update overall max if new one is found
      if (num > result)
        result = num;
    }
    
  }

  //wait for all child processes to close
  for (int i = 0; i < workers; i++) {
    wait(NULL);
  }

  //close in pipe for parent
  close(pfd[0]);

  //print result
  printf("Maximum Sum: %d\n", result);

  return 0;
}
