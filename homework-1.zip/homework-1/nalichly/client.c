/**
 * Client for lights out game
 * @file client.c
 * @author Noah Lichlyter nalichly
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

/**
 * Prints out an error message and exits.
 * @param message the message to print
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main (int argc, char* argv[]) {
    //vars for params
    int row;
    int col;

    //check number of args
    if (argc < 2 || argc > 4)
        fail("error");

    //check that command word is valid
    if (strcmp(argv[1], "move") != 0 && strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "report") != 0)
        fail("error");

    if (argc == 2)
        if (strcmp(argv[1], "move") == 0)
            fail("error");

    //check that right amount of args were given for move command
    if (argc > 2) {
        if (strcmp(argv[1], "move") != 0)
            fail("error");
        if (sscanf(argv[2], "%d", &row) != 1 ||
             row < 0 || row > GRID_SIZE - 1)
            fail("error");
        if (sscanf(argv[3], "%d", &col) != 1 ||
             col < 0 || col > GRID_SIZE - 1)
            fail("error");
    }

    //open message queues
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_WRONLY);
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_RDONLY);
    if (clientQueue == -1)
        fail("Can't open message queue");
    if (serverQueue == -1)
        fail("Can't open server queue");

    int bCount = 0; //num chars in buffer
    char *buffer = (char *) calloc (MESSAGE_LIMIT, sizeof(char));
    //buffer += argv[1];
    for (int i = 0; i < strlen(argv[1]); i++) {
        if (!isspace(argv[1][i])) {
            buffer[0] = argv[1][i];
            bCount++;
            break;
        }
    }

    if (buffer[0] == 'm') { //move
        //get other two commands
        if (argc == 4) {
            char c;

            sscanf(argv[2], " %c", &c);
            buffer[bCount] = c;
            bCount++;

            sscanf(argv[3], " %c", &c);
            buffer[bCount] = c;
            bCount++;
        }
    }

    //send command to the server
    mq_send(serverQueue, buffer, strlen(buffer), 0);
    //wait for response
    //char *msg;
    mq_receive(clientQueue, buffer, MESSAGE_LIMIT, 0);
    if (strcmp(buffer, "failure") == 0) { //check that val recieved is ok
            fail("error");
    }

    //print message recieved
    printf("%s\n", buffer);

    //buffer[bCount] = '\0'; //newline so we can parse it as a string

    //printf("buffer: %s\n", buffer);
    free(buffer);
    mq_close(clientQueue);
    mq_close(serverQueue);
    
    //return
    return 0;
}