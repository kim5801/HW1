/** 
    @file server.c
    @author Srinath Vasudevan (svasude5)
    This code contains server functionality for the lights out
    game. The server processes client commands and sends back
    a success or failure indication. The server also stores
    the state of the game board. Starter file provided by Dr. David
    Sturgill.
*/

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out usage message then exit
static void usage() {
  fail("usage: server <board-file>");
}

// Prints invalid input error message then exits
static void invalid(char const *filename) {
  fprintf( stderr, "Invalid input file: %s\n", filename );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Struct to hold board state
typedef struct board {
  // 2D array to hold state of game board lights
  bool **lights;
  // The row of the last move
  int lastRow;
  // The column of the last move
  int lastCol;
  // Whether the user can undo or not
  bool canUndo;
} board;

// Global board variable
static board *b;

/**
  Moves the given board at the positions x and y as 
  provided.

  @param x the x position to move at
  @param y the y position to move at
  @param b the board pointer to edit.
*/
void move(int x, int y, board *b) {
  // Reverse the light at the given position
  b->lights[x][y] = !b->lights[x][y];
  // Check position above and update
  if (x+1 < 5) {
    b->lights[x+1][y] = !b->lights[x+1][y];
  }
  // Check position below and update
  if (x-1 >= 0) {
    b->lights[x-1][y] = !b->lights[x-1][y];
  }
  // Check position to the right and update
  if (y+1 < 5) {
    b->lights[x][y+1] = !b->lights[x][y+1];
  }
  // Check position to the left and update
  if (y-1 >= 0) {
    b->lights[x][y-1] = !b->lights[x][y-1];
  }
  // Update last moved row and column
  b->lastRow = x;
  b->lastCol = y;
  // Update whether the user can undo or not
  b->canUndo = true;
}

/**
  Undos the last move of the given board at the 
  positions x and y as provided.

  @param x the x position to move at
  @param y the y position to move at
  @param b the board pointer to edit.
*/
void undo(int x, int y, board *b) {
  // Use the move function to undo the last move
  move(x, y, b);
  // Set canUndo to false
  b->canUndo = false;
}

// Function to handle the SIGINT interrupt to print out the board
void interrupt(int sig) {
  // Print newline
  printf("\n");
  // Loop through and print board
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      printf("%c", b->lights[i][j] ? '*' : '.');
    }
    printf("\n");
  }
  for (int col = 0; col < GRID_SIZE; col++) {
    free(b->lights[col]);
  }
  free(b->lights);
  free(b);
  // Exit with success status
  exit(0);
}

/**
  The main process for the server. Stores the state of the game and
  processes client commands and sends output back to the client.
  @param argc number of command line args
  @param argv the command line args
  @return exit status
*/
int main( int argc, char *argv[] ) {

  // Parse command-line arguments.
  if ( argc != 2 )
    usage();

  char *filename = argv[1];
  FILE *fp = NULL;
  if ((fp = fopen(filename, "r")) == NULL) {
    invalid(filename);
  }

  // Create sigaction struct to handle SIGINT interrupt
  struct sigaction act;
  // Assign struct fields
  act.sa_handler = interrupt;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Malloc room for all necessary board struct fields
  b = (board *) malloc(sizeof(board));
  b->lights = (bool **) malloc(GRID_SIZE * sizeof(bool *));
  for (int col = 0; col < GRID_SIZE; col++) {
    b->lights[col] = (bool *) malloc(GRID_SIZE * sizeof(bool));
  }
  // Set default values for board fields
  b->lastRow = 0;
  b->lastCol = 0;
  b->canUndo = false;
  
  int i = 0;
  int j = 0;
  char c;
  // While there is a valid character in the file
  while(fscanf(fp, "%c", &c) != EOF) {
    // If the light is off
    if (c == '.') {
      // If the file is invalid, terminate
      if (j == GRID_SIZE || i == GRID_SIZE) {
        for (int col = 0; col < GRID_SIZE; col++) {
          free(b->lights[col]);
        }
        free(b->lights);
        free(b);
        invalid(filename);
      }
      // Set the appropriate index of the board to false
      b->lights[i][j] = false;
      j++;
    } else if (c == '*') {
      //If the light is on
      //If the file is invalid, terminate
      if (j == GRID_SIZE || i == GRID_SIZE) {
        for (int col = 0; col < GRID_SIZE; col++) {
          free(b->lights[col]);
        }
        free(b->lights);
        free(b);
        invalid(filename);
      }
      // Set the appropriate index of the board to true
      b->lights[i][j] = true;
      j++;
    } else if (c == '\n') {
      // Move to next row if char is newline
      i++;
      j = 0;
    } else {
      // Invalid character, terminate
      for (int col = 0; col < GRID_SIZE; col++) {
        free(b->lights[col]);
      }
      free(b->lights);
      free(b);
      invalid(filename);
    }
  }

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  char *msg = (char *) malloc(sizeof(char) * MESSAGE_LIMIT + 1);
  // Repeatedly read and process client messages.
  while ( running ) {
    // Receive the command from the client
    mq_receive(serverQueue, msg, MESSAGE_LIMIT * sizeof(char) + 1, NULL);
    // Check if command is report
    if (msg[0] == 'r') {
      // Create string representation of grid
      char grid[26] = {};
      // Populate grid string with values
      for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
          if (b->lights[i][j] == true) {
            grid[(i*GRID_SIZE)+j] = '*';
          } else {
            grid[(i*GRID_SIZE)+j] = '.';
          }
        }
      }
      // Add null terminator
      grid[26] = '\0';
      // Send stringified grid to client
      mq_send(clientQueue, grid, (GRID_SIZE * GRID_SIZE + 1) * sizeof(char), 0);
    } else if (msg[0] == 'u') {
      // If the command is undo, check if user can undo
      if (b->canUndo == true) {
        // Undo the last move
        undo(b->lastRow, b->lastCol, b);
        // Send success status to client
        mq_send(clientQueue, SUCCESS, strlen(SUCCESS) * sizeof(char), 0);
      } else {
        // Send error status to client since user can't undo
        mq_send(clientQueue, ERR, strlen(ERR) * sizeof(char), 0);
      }
    } else if (msg[0] == 'm') {
      // If command is move
      char x = msg[1];
      char y = msg[2];
      // Use move() to make the move on the board
      move(x - '0', y - '0', b);
      // Send success status to client
      mq_send(clientQueue, SUCCESS, strlen(SUCCESS) * sizeof(char), 0);
    }
    
  } 
  // Free message buffer
  free(msg);
  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
