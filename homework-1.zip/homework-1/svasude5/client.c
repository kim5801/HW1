/** 
    @file client.c
    @author Srinath Vasudevan (svasude5)
    This code contains client functionality for the lights out
    game. The client is able to make commands to the server through
    a message queue and output whether the command was
    succesful or not.
*/

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <string.h>
#include <errno.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
  The main process for the client. Processes and sends
  commands to the server.
  @param argc number of command line args
  @param argv the command line args
  @return exit status
*/
int main( int argc, char *argv[] ) {
  char msg[MESSAGE_LIMIT];
  bool report = false;

  // Parse command-line arguments.
  if ( argc != 2 && argc != 4 ) {
    fail("error");
  }

  // If command number is potentially undo or report
  if (argc == 2) {
    // Check each option and set message accordingly
    if (strcmp("undo", argv[1]) == 0) {
      strncpy(msg, "u", 1);
    } else if (strcmp("report", argv[1]) == 0) {
      strncpy(msg, "r", 1);
      report = true;
    } else {
      // Not a valid command
      fail("error");
    }
  } else if (argc == 4) {
    // Check for potential move command
    if (strcmp("move", argv[1]) == 0) {
      // Check if the coordinates are valid
      if (argv[2][0] >= '0' && argv[2][0] <= '4' && strlen(argv[2]) == 1
          && argv[3][0] >= '0' && argv[3][0] <= '4' && strlen(argv[3]) == 1) {
        strcpy(msg, "m");
        strncat(msg, argv[2], 1);
        strncat(msg, argv[3], 1);
      } else {
        // Coords are not valid so error out
        fail("error");
      }
    } else {
      // Coords are not valid, so error out
      fail("error");
    }
  }
  

  // Open the server and client queues which the server made
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
  // Ensure they are open
  if ( serverQueue == -1 || clientQueue == -1 ) {
    fail( "Can't create the needed message queues" );
  }
  // Send the command message to the server
  int sent = mq_send(serverQueue, msg, strlen(msg), 0);
  // Fail is message not sent
  if (sent == -1) {
    fail("Can't send message in server queue");
  }
  // Buffer for the server response
  char msg2[MESSAGE_LIMIT + 1];
  // Parse the server's response message
  mq_receive(clientQueue, msg2, sizeof(char) * MESSAGE_LIMIT + 1, NULL);

  // If the function wasn't report, check for a success/error message
  if (!report) {
    if (strcmp("e", msg2) == 0) {
      fail("error");
    } else if (strcmp("s", msg2) == 0) {
       printf("success\n");
    }
  } else {
    // If the function was report, parse the board
    // in the provided string format and print it
    for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
        printf("%c", msg2[(GRID_SIZE * i)+j]);
      }
      printf("\n");
    }
  }

  // Close our two message queues
  mq_close( clientQueue );
  mq_close( serverQueue );
  
  // return success
  return 0;    
}