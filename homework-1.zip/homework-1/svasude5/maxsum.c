/** 
    @file maxsum.c
    @author Srinath Vasudevan (svasude5)
    This code calculates the maximum contiguous subarray
    sum using a specified number or processes.
*/
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
  Function to calculate the maximum int given a list of indexes to start
  searching from.
  
  @param indexes the list of indexes to start searching from.
  @param count the amount of indexes in the list.
  @param report the flag indicating whether a report should be printed.
  @param pfd the pipe to output information to.
  @return status of termination for the child process..
*/
int findMax( int *indexes, int count, bool report, int pfd[2]) {
  int max = 0;
  int sum = 0;
  // Start searching at each index in the list
  for (int i = 0; i < count; i++) {
    int index = indexes[i];
    for (int j = index; j < vCount; j++) {
      // Add to sum
      sum += vList[j];
      // Update max if necessary
      if (sum > max) {
        max = sum;
      }
    }
    // Reset sum
    sum = 0;
  }
  // Print message if report flag is true
  if (report) {
    printf("I'm process %d. The maximum sum I found is %d\n", getpid(), max);
  }

  // Lock writing end
  lockf( pfd[1], F_LOCK, 0 );
  int *maxp = malloc(sizeof(int));
  *maxp = max;
  // Write the data to the pipe/parent
  write(pfd[1], maxp, sizeof(int));
  free(maxp);
  // Unlock pipe
  lockf( pfd[1], F_ULOCK, 0 );
  // Close resources and free memory
  free(indexes);
  free(vList);
  close(pfd[1]);
  return 0;
}

/**
  The main function of the file which contains code to read and 
  parse arguments as well as splits up the work to find the maximum
  sum in a contiguous subarray for effeciency.

  @param argc the amount of command line arguments.
  @param argv the command line arguments list.
  @return the exit status of the program.
*/
int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

  // Minimum amount of indexes to check for each worker
  int split = vCount / workers;
  // Remainder indexes which need to be assigned
  int rem = vCount % workers;

  // Var for pipe
  int pfd[2];
  // Open a pipe for communication
  if (pipe(pfd) != 0) {
    fail("Can't create a pipe.");
  }

  // Start creating a process for each worker
  for (int i = 0; i < workers; i++) {
    // Calculate the indexes needed for each worker to check
    int indexsize = split;
    if (rem > 0) {
      indexsize += rem--;
    }
    int *indexes = malloc(sizeof(int) * indexsize);
    int loop = 0;
    for (int j = i; j < vCount; j += workers) {
      indexes[loop] = j;
      loop++;
    }
    // Create child
    pid_t pid = fork();
    if (pid == 0) {
      // Close reading end
      close(pfd[0]);
      // Return the result of the function
      return findMax(indexes, indexsize, report, pfd);
    } else if (pid == -1) {
      // Error creating process
      fail("Cannot create process.");
    }
    // Free malloc'd memory
    free(indexes);


  }
  // Close writing end
  close(pfd[1]);

  // Variables to check maximum among workers
  int *maxb = malloc(sizeof(int));
  int max = 0;
  // For each worker created
  for (int i = 0; i < workers; i++) {
    // Wait for the process to terminate
    wait(NULL);
    // Read the process's input into the pipe
    read(pfd[0], maxb, sizeof(int));
    // Update max if necessary
    if (*maxb > max) {
      max = *maxb;
    }
  }
  // Free memory and close resources
  free(maxb);
  free(vList);
  close(pfd[0]);
  // Print maximum
  printf("Maximum Sum: %d\n", max);
  return 0;
}
