/**
 * @file client.c
 * @author Eduardo Martinez (elmarti4)
 * @brief client.c provides commands that change the 
 *        board provided by server.c through message queues
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail() {
  printf( "error\n" );
  exit( 1 );
}

/**
 * @brief Starting point of the program
 * 
 * @param argc Amount of arguments
 * @param argv List of arguments
 * @return 0 on success, 1 on failure
 */
int main( int argc, char *argv[] ) {
    // Set up the buffer to receive and send messages from
    char buffer[ MESSAGE_LIMIT ];
    buffer[ 0 ] = '\0';

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );

    if ( argc == 1 || 4 < argc ) {
        fail();
    } else if ( strcmp( argv[ 1 ], "move" ) == 0 && argc == 4 ) {
        strcat( buffer, argv[ 1 ] );
        // Check if the first provided value is a single digit
        if ( strlen( argv[ 2 ] ) != 1 ) {
            fail();
        } else {
            int value1 = argv[ 2 ][ 0 ] - '0';
            // Check if the value fits in the 0 -> 4 range
            if ( 0 <= value1 && value1 < GRID_SIZE ) {
                int len = strlen( buffer );
                buffer[ len ] = ' ';
                buffer[ len + 1 ] = '\0';
                strcat( buffer, argv[ 2 ] );
                // Check if the first provided value is a single digit
                if ( strlen( argv[ 3 ] ) != 1 ) {
                    fail();
                } else {
                    int value2 = argv[ 3 ][ 0 ] - '0';
                    // Check if the value fits in the 0 -> 4 range
                    if ( 0 <= value2 && value2 < GRID_SIZE ) {
                        len = strlen( buffer );
                        buffer[ len ] = ' ';
                        buffer[ len + 1 ] = '\0';
                        strcat( buffer, argv[ 3 ] );
                    } else {
                        fail();
                    }
                }
            } else {
                fail();
            }
        }
        // Send the valid message to the server
        mq_send( serverQueue, buffer, MESSAGE_LIMIT, 0 );
        printf( "success\n" );
    } else if ( strcmp( argv[ 1 ], "undo" ) == 0 && argc == 2 ) {
        // Send message, and receive confirmation on failure or success
        strcat( buffer, argv[ 1 ] );
        mq_send( serverQueue, buffer, MESSAGE_LIMIT, 0 );
        mq_receive( clientQueue, buffer, MESSAGE_LIMIT, 0 );
        printf( "%s\n", buffer );
    } else if ( strcmp( argv[ 1 ], "report" ) == 0 && argc == 2 ) {
        // Only need to send the command, nothing else is required.
        strcat( buffer, argv[ 1 ] );
        mq_send( serverQueue, buffer, MESSAGE_LIMIT, 0 );
        mq_receive( clientQueue, buffer, MESSAGE_LIMIT, 0 );
        // Print board
        for ( int i = 0; i < strlen( buffer ); i++ ) {
            printf( "%c", buffer[ i ] );
        }
    } else {
        fail();
    }
    // Close our two message queues.
    mq_close( clientQueue );
    mq_close( serverQueue );

    return EXIT_SUCCESS;
}
