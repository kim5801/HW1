/**
 * @file server.c
 * @author Eduardo Martinez (elmarti4)
 * @brief server.c uses message queueing in order
 *        to let a client play Light Out!
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Function called when the ctrl+C is inputed
void exitHandler( int sig ) {
  printf( "\n" );
  running = 0;
}

/**
 * @brief Prints the provided board to standard output
 * 
 * @param board 2D array of board chosen
 */
void printBoard( char board[ GRID_SIZE ][ GRID_SIZE + 1 ] ) {
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE + 1; j++ ) {
      printf( "%c", board[ i ][ j ] );
    }
  }
  printf( "\n" );
}

/**
 * @brief Copy the provided board to the buffer
 * 
 * @param board 2D array of board chosen
 */
void bufferBoard( char board[ GRID_SIZE ][ GRID_SIZE + 1 ], char buffer[ MESSAGE_LIMIT ] ) {
  int len = 0;
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE + 1; j++ ) {
      buffer[ len ] = board[ i ][ j ];
      len++;
    }
  }
}

void createBoard( char *fileName, char board[ GRID_SIZE ][ GRID_SIZE + 1 ] ) {
  int fd = open( fileName, O_RDONLY );
  if ( !fd ) {
    fprintf( stderr, "Invalid input file: %s\n", fileName );
    exit( 1 );
  }
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE + 1; j++ ) {
      int check = read( fd, &board[ i ][ j ], 1 );
      if ( check == EOF ) {
        fprintf( stderr, "Invalid input file: %s\n", fileName );
        exit( 1 );
      }
      if ( board[ i ][ j ] != '*' && board[ i ][ j ] != '.' && j != 5 ) {
        fprintf( stderr, "Invalid input file: %s\n", fileName );
        exit( 1 );
      }
      if ( board[ i ][ j ] != '\n' && j == 5 ) {
        fprintf( stderr, "Invalid input file: %s\n", fileName );
        exit( 1 );
      }
    }
  }
  close( fd );
}

/**
 * @brief Starting point of the program
 * 
 * @param argc Amount of arguments
 * @param argv List of arguments
 * @return 0 on success or 1 on failure 
 */
int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  if ( argc != 2 ) {
    fail( "usage: server <board-file>" );
  }

/* Code for using fail() in invalid input file error
    int argSize = strlen( argv[ 1 ] );
    char fileError[ 21 + argSize + 1 ];
    strcpy( fileError, "Invalid input file: " );
    strcat( fileError, argv[ 1 ] );
    fileError[ 21 + argSize ] = '\n';
    fail( fileError )
*/

  // Create board from a file
  char boardOld[ GRID_SIZE ][ GRID_SIZE + 1 ];
  char boardCurrent[ GRID_SIZE ][ GRID_SIZE + 1 ];
  createBoard( argv[ 1 ], boardCurrent );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  struct sigaction act;
  act.sa_handler = exitHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Flag to keep track of if an undo move is valid yet
  bool undoVal = false;

  // Repeatedly read and process client messages.
  while ( running ) {
    // Set up the buffer to receive and send messages from
    char buffer[ MESSAGE_LIMIT ];

    int len = mq_receive( serverQueue, buffer, MESSAGE_LIMIT, NULL );
    // If the message is to move
    if ( strstr( buffer, "move" ) ) {
      // Store the old version of the board for the undo command
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE + 1; j++ ) {
          boardOld[ i ][ j ] = boardCurrent[ i ][ j ];
        }
      }
      // Find the x and y that has been chosen by
      int value1 = -1;
      int value2 = -1;
      int i = 0;
      while ( ( value1 == -1 || value2 == -1 ) && i < len ) {
        if ( buffer[ i ] >= '0' && '9' >= buffer[ i ] ) {
          if ( value1 == -1 ) {
            value1 = buffer[ i ] - '0';
          } else if ( value2 == -1 ) {
            value2 = buffer[ i ] - '0';
          }
        }
        i++;
      }
      // Change the center of the cross
      if ( boardCurrent[ value1 ][ value2 ] == '*' ) {
        boardCurrent[ value1 ][ value2 ] = '.';
      } else {
        boardCurrent[ value1 ][ value2 ] = '*';
      }
      // Change the value above the center
      if ( value1 - 1 > 0 && value1 - 1 < GRID_SIZE ) {
        if ( boardCurrent[ value1 - 1 ][ value2 ] == '*' ) {
          boardCurrent[ value1 - 1 ][ value2 ] = '.';
        } else {
          boardCurrent[ value1 - 1 ][ value2 ] = '*';
        }
      }
      // Change the value below the center
      if ( value1 + 1 > 0 && value1 + 1 < GRID_SIZE ) {
        if ( boardCurrent[ value1 + 1 ][ value2 ] == '*' ) {
          boardCurrent[ value1 + 1 ][ value2 ] = '.';
        } else {
          boardCurrent[ value1 + 1 ][ value2 ] = '*';
        }
      }
      // Change the value to the left of the center
      if ( value2 - 1 > 0 && value2 - 1 < GRID_SIZE ) {
        if ( boardCurrent[ value1 ][ value2 - 1 ] == '*' ) {
          boardCurrent[ value1 ][ value2 - 1 ] = '.';
        } else {
          boardCurrent[ value1 ][ value2 - 1 ] = '*';
        }
      }
      // Change the value to the right of the center
      if ( value2 + 1 > 0 && value2 + 1 < GRID_SIZE ) {
        if ( boardCurrent[ value1 ][ value2 + 1 ] == '*' ) {
          boardCurrent[ value1 ][ value2 + 1 ] = '.';
        } else {
          boardCurrent[ value1 ][ value2 + 1 ] = '*';
        }
      }
      undoVal = true;
    }
    if ( strstr( buffer, "undo" ) && undoVal == true ) {
      // Override old board
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE; j++ ) {
          boardCurrent[ i ][ j ] = boardOld[ i ][ j ];
        }
      }
      undoVal = false;
      mq_send( clientQueue, "success", strlen( "success" ), 0 );
    } else if ( strstr( buffer, "undo" ) && undoVal == false ) {
      // Return error message
      mq_send( clientQueue, "error", strlen( "error" ), 0 );
    }
    if ( strstr( buffer, "report" ) ) {
      bufferBoard( boardCurrent, buffer );
      mq_send( clientQueue, buffer, strlen( buffer ), 0 );
    }
  }

  printBoard( boardCurrent );

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
