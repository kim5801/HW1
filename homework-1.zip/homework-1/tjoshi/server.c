/**
 * @file server.c
 * @author your name (you@domain.com)
 * This file acts as the server for the popular game "lights out". It communicates with the client which determines
 * the moves and functions on the board while this file stores and performs all logic on the board. This file uses 
 * mqueue to communicate between the client and server.
 * 
 * Sources:
 * This file was made with inspiration from the following example files from moodle:
 * signalExample.c
 * mqReciever.c
 * mqSender.c
 * Additionally used the man pages for the following functions: 
 * mq_send
 * mq_receive 
 * 
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * a global variable to keep while loop running
 * 
 */
static int running = 1;
/**
 * stores the current board 
 * 
 */
char currArray[5][5];
/**
 * stores the previous board  
 * 
 */
char prevArray[5][5];

/**
 * saves the current array into the previous array
 * 
 * @param currArray the array needed to be saved
 * @param prevArray the location of saving the previous array
 */
void saveCurr(char currArray[5][5],char prevArray[5][5]) {
  for (int r = 0; r < 5; r++) {
    for (int c = 0; c < 5; c++) {
      prevArray[r][c] = currArray[r][c];
    }
  }
}
 
/**
 * Performs the move functions on the current Board
 * 
 * @param row the row of the move
 * @param col the column of the move
 */
void changeCurr(int row, int col) {
  int left = col - 1;
  int right = col + 1;
  int up = row - 1;
  int down = row + 1;
  //changes the current index of the move
  if(currArray[row][col] == '.') {
    currArray[row][col] = '*';
  } else {
    currArray[row][col] = '.';
  }
  //changes the left index of the change (if necessary)
  if (left < 5 && left >= 0) {
    if(currArray[row][left] == '.') {
      currArray[row][left] = '*';
    } else {
      currArray[row][left] = '.';
    }
  }
  //changes the right index of the change (if necessary)
  if (right < 5 && right >= 0) {
    if(currArray[row][right] == '.') {
      currArray[row][right] = '*';
    } else {
      currArray[row][right] = '.';
    }
  }
  //changes the upper index of the change (if necessary)
  if (up < 5 && up >= 0) {
    if(currArray[up][col] == '.') {
      currArray[up][col] = '*';
    } else {
      currArray[up][col] = '.';
    }
  }
  //changes the lower index of the change (if necessary)
  if (down < 5 && down >= 0) {
    if(currArray[down][col] == '.') {
      currArray[down][col] = '*';
    } else {
      currArray[down][col] = '.';
    }
  }
}


/**
 * moves the current board into a 1D array to be sent in 
 * mq_receive
 * 
 * @param queueSend the 1D output array
 */
void outputCurr(char *queueSend) {
  int outputIndex = 0;
  for (int r = 0; r < 5; r++) {
    for (int c = 0; c < 5; c++) {
      queueSend[outputIndex++] = currArray[r][c];
    }
    queueSend[outputIndex++] = '\n';
  }
  queueSend[outputIndex++] = '\0';
}

/**
 * Function that handles the sigaction by moving the board 
 * 
 * @param sig 
 */
void ccHandler(int sig) {
  char queueSend[31];
  printf("\n");
  outputCurr(queueSend);
  printf("%s", queueSend);
  exit(0);
}
/**
 * The method where the main error checking and input handling of the file and client input from the queue
 * 
 * @param argc the number of command line arguments
 * @param argv the string command line arguments 
 * @return int the exit code 
 */
int main( int argc, char *argv[] ) {
  if ( argc != 2 ) {
    fail("usage: server <board-file>");
  }
  FILE *fp = fopen(argv[1], "r");
  // checks the command line argument had a valid file input
  if (!fp) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1] );
    exit( 1 );
  }
  //Reads the file character by character to check if it meets 
  //the given board requirements and unsuccessfully exits if not.
  //Additionally it reads in the characters into the current character
  //array.
  char ch = fgetc(fp);
  int colCount = 0;
  int rowCount = 0;
  while (ch != EOF) {
    if (ch == '\n') {
      rowCount++;
      if (colCount != 5 || rowCount > 5) {
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        exit( 1 );
      }
      colCount = 0;
    }
    else if (ch == '.' || ch == '*') {
      currArray[rowCount][colCount++] = ch;
    }
    else {
      fprintf( stderr, "Invalid input file: %s\n", argv[1] );
      exit( 1 );
    }
    ch = fgetc(fp);
  }

  

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );
  
  

  
  bool prevUndo = false;
  //declares and intializes some fields of the struct needed to do signal handling
  struct sigaction act;
  act.sa_handler = ccHandler;
  sigemptyset(&(act.sa_mask));
  act.sa_flags = 0;
  // Repeatedly recieves and processes client messages.
  while ( running ) {
    // if signal recieved, then goes to ccHandler function
    sigaction( SIGINT, &act, 0 );
    char queueRecieve[MESSAGE_LIMIT];
    char queueSend[31];
    int len = mq_receive(serverQueue, queueRecieve, sizeof(queueRecieve), NULL);
    if (len < 0) {
      fprintf(stderr, "Error opening file: %s\n", strerror( errno ));
      exit(errno);
    }
    // the logic for a move command
    if (queueRecieve[0] == 'm') {
      // converts the characters into ints
      int row = queueRecieve[1] - 48;
      int col = queueRecieve[2] - 48;
      // saves the current board into the previous board array
      saveCurr(currArray, prevArray);
      // changes the current board
      changeCurr(row, col);
      // saves "success" into the array that will be sent in the queue
      strcpy(queueSend, "success\n");
      // stores in a boolean that the previous board edit was not an undo
      prevUndo = false;
    }
    // stores logic for report command
    else if (queueRecieve[0] == 'r') {
      // stores the current array into the array sent into the queue
      outputCurr(queueSend);
    }
    // logic for undo
    else if (queueRecieve[0] == 'u') {
      if (!prevUndo) {
        //moves the previous board array into the current board array
        saveCurr(prevArray, currArray);
        // stores "success" in the output array
        strcpy(queueSend, "success\n");
        // stores true in a boolean previous board edit was an undo 
        prevUndo = true;
      }
      else {
        // if prev board edit was undo then store "error" in output array
        strcpy(queueSend, "error\n");
      }
    }
    else {
      fail("queue issue");
    }
    // sends the output array to the client
    mq_send(clientQueue, queueSend, strlen(queueSend), 0);
    // ...
  }
  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
