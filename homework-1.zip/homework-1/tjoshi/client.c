/**
 * @file client.c
 * @author your name (you@domain.com)
 * The client for the "lights out game" which communicates with a server using an mqueue
 * 
 * Sources:
 * This file was made with inspiration from the following example files from moodle:
 * signalExample.c
 * mqReciever.c
 * mqSender.c
 * Additionally used the man pages for the following functions: 
 * mq_send
 * mq_receive 
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void error() {
  printf( "error\n" );
  exit( 1 );
}
/**
 * This method is used to convert the numbers given in move 
 * This method was pulled from hw 0 from my previous submission
 * 
 * @param input 
 * @return int 
 */
int atoiTej(char input[]) {
    // the counter for index in the while loop of input
    int i = 0;
    //the output number
    int number = 0;
    // if first value is negative, switch the value to negative one so we can multiply that value at the end to convert the value to a negative number
    while (input[i] != '\0') {
        if (input[i] < '0' || input[i] > '9') {
            //error message if the string contains any non integers and exits
            error();
        }
        //operation to add the consecutive digits of the number (first part multiplies the existing number by 10 to clear a space in the ones space)
        // second part converts the input number into an ascii value and adds it to the existing number (filling the number in the ones place)
        number = number * 10 + (input[i] - '0');
        i++;
    }
    return number;
}

/**
 * Has the main logic of handling the client arguments
 * 
 * @param argc number of client arguments
 * @param argv the arguments
 * @return int the exit code of the function
 */
int main( int argc, char *argv[] ) {
  char queueSend[4];
  // checks if the code has more than 4 arguments (which it shouldn't have)
  char queueRecieve[MESSAGE_LIMIT];
  if (argc > 4) {
    error();
  }
  // logic for move when move is the first command line argument
  if (strcmp(argv[1], "move") == 0) {
    // error checking to see if the second and third command line arguments the right numbers
    int row = atoiTej(argv[2]);
    int col = atoiTej(argv[3]);
    if (row > 4 || col > 4) {
      error();
    }
    //loading the message into the sending buffer for mq_send
    strcpy(queueSend, "m");
    strcat(queueSend, argv[2]);
    strcat(queueSend, argv[3]);
  }
  //logic for report
  else if (strcmp(argv[1], "report") == 0) {
    if (argc > 2) {
      error();
    }
    strcpy(queueSend, "rep");
  }
  // logic for undo
  else if (strcmp(argv[1], "undo") == 0) {
    if (argc > 2) {
      error();
    }
    strcpy(queueSend, "und");
  }
  else {
    error();
  }

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
  if ( serverQueue == -1 || clientQueue == -1 )
    error();
  //sending the queue message found after parsing through the command line arguments
  int sendLen = mq_send(serverQueue, queueSend, strlen(queueSend), 0);
  // getting the output from the server after sending the input
  int len = mq_receive(clientQueue, queueRecieve, sizeof(queueRecieve), NULL);
  if (sendLen < 0) {
    error();
  }
  if (len < 0) {
    error();
  }
  //printing the output from the server
  printf("%s", queueRecieve);
  // closing the queue
  mq_close( serverQueue );
  mq_close( clientQueue );
  // if server outputted error, exit unsuccessfully
  if (strcmp(queueRecieve, "error\n") == 0) {
    exit(EXIT_FAILURE);
  }
  return 0;
}