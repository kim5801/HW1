/**
 * @file maxsum.c
 * @author tjoshi Tej Joshi
 * @brief this file finds the max subarray from a list of integers in a file using child processes 
 * and a pipe to communicate between child processes and parent processes
 * 
 * Sources: 
 * Used the following example files from moodle as inspiration in creating this file:
 * PipeIPC.c
 * miniForkBomb.c
 * Additionally used the man pages for the following: 
 * wait()
 * fork()
 * pipe()
 */
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
 * Finds the max subarray given a start point of an array
 * 
 * @param start the starting index of the subarray
 * @return int the maximum sum
 */
int maxSubarray(int start) {
  int currSum = 0;
  int maxSum = vList[start];
  for (int i = start; i < vCount; i++) {
    currSum += vList[i];
    if (currSum > maxSum) {
      maxSum = currSum;
    }
  }
  return maxSum;
}

/**
 * the main method
 * 
 * @param argc number of commandline arguments
 * @param argv arguments
 * @return int exit code
 */
int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }
  readList();
  // creating the pipe and file pointers
  int pfd[2];
  if (pipe(pfd) != 0) {
    fail("Cannot create pipe");
  }
  // iterating through the number of workers the user has inputted as a commandline argument
  for (int i = 0; i < workers; i++) {
    //creating one child process
    pid_t pid = fork();
    if ( pid == -1 )
      fail( "Can't create child process" );
    // logic for within the process
    if (pid == 0) {
      close(pfd[0]);
      int currMax = 0;
      int actMax = 0;
      // this loop defines the start indexes for the subarrays this child process has 
      // find the maximum subarray of
      for (int j = i; j < vCount; j += workers) {
        currMax = maxSubarray(j);
        // if the current max subarray found is bigger than the old max subarray,
        // store the current max subarray as the maximum subarray found
        if (currMax > actMax) {
          actMax = currMax;
        }
      }
      // if user says to report the processes, then the following will be printed
      if (report) {
        printf("I’m process %d. The maximum sum I found is %d. \n", getpid(), actMax);
      }
      // this writes the max found into the pipe and exiting the child process
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &actMax, sizeof(actMax));
      lockf( pfd[1], F_ULOCK, 0 );
      close(pfd[1]);
      exit(EXIT_SUCCESS);
    }
  }
  // waits for all of the child processes to finish before executing the parent process code
  for (int i = 0; i < workers; i++) {
    wait(NULL);
  }
  close(pfd[1]);
  int currMax = -1;
  int actualMax = 0;
  // reads from the pipe and finds the max subarray from all of the processes
  for(int i = 0; i < workers; i++) {
    read(pfd[0], &currMax, sizeof(currMax));
    if (currMax > actualMax) {
      actualMax = currMax;
    }
  }
  close(pfd[0]);
  // prints the max subarray
  printf("Maximum Sum: %d\n", actualMax);
  

  // You get to add the rest.

  // ...

  return 0;
}
