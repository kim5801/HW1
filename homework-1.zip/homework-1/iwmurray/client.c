/**
 * client.c
 * Homework 1 - Problem 4 - CSC 246
 * @author Ian Murray (iwmurray)
 */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <mqueue.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

// Print out 'error' and exit
static void err() {
  printf( "error\n" );
  exit( 1 );
}

/**
 * Function to recieve a interger from the given message queue.
 * @param mqdes message queue descriptor
 * @return interger received or -1 on failure.
 */
int mq_receive_int( mqd_t mqdes ) {
  char buffer[ MESSAGE_LIMIT ];
  int reciv = mq_receive( mqdes, buffer, sizeof( buffer ), NULL );

  if( reciv  < 0)
    err();

  buffer[reciv] = '\0';
  return atoi(buffer);
}

/**
 * Function to send a interger to the given message queue.
 * @param mqdes message queue descriptor
 * @param number interger to send
 */
void mq_send_int( mqd_t mqdes, int number ) {
  char buffer[ MESSAGE_LIMIT ];
  sprintf(buffer, "%d", number);

  if( mq_send( mqdes, buffer, strlen( buffer ), 0 ) < 0)
    err();
}

/**
 * Parse a string to an interger, with error checking.
 * @return parsed interger
 */
int atoi_chk( char *str ) {
  char *ch = str;
  
  // Check for non digits
  while( *ch != '\0')
    if( isdigit(*ch) )
      ch++;
    else
      err();
  
  return atoi(str);
}

int main( int argc, char *argv[] ) {
  // Check arguments
  if ( argc < 2 || argc > 4)
    err();

  // Open queues
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
  if ( serverQueue == -1 || clientQueue == -1 )
    err();

  
  if( strcmp(argv[1], "move") == 0 ) { // Move command
      // Parse arguments
      if ( argc != 4 )
        err();

      int row = atoi_chk(argv[2]);
      int col = atoi_chk(argv[3]);

      if(row == -1 || col == -1)
        err();

      // Send move command and cooords
      mq_send_int( serverQueue, 'm' );
      mq_send_int( serverQueue, row );
      mq_send_int( serverQueue, col );

      // Read back success
      if( mq_receive_int( clientQueue ))
        printf("success\n");
      else
        printf("error\n");
  } else if( strcmp(argv[1], "undo") == 0 ) { // Undo command
      // Parse arguments
      if ( argc != 2 )
        err();

      // Send undo command
      mq_send_int( serverQueue, 'u' );

      // Read back success
      if( mq_receive_int( clientQueue) )
        printf("success\n");
      else
        printf("error\n");
  } else if( strcmp(argv[1], "report") == 0 ) { // Report command
      // Parse arguments
      if ( argc != 2 )
        err();

      // Send undo command
      mq_send_int( serverQueue, 'r' );

      // Read back the report
      char board[ MESSAGE_LIMIT ];
      if( mq_receive( clientQueue, board, sizeof( board ), NULL ) < 0)
        err();

      // Print report
      printf("%s", board);
  } else // Invalid argument
    err();


  // Close our two message queues.
  mq_close( clientQueue );
  mq_close( serverQueue );

  return EXIT_SUCCESS;
}