/**
 * server.c 
 * Homework 1 - Problem 4 - CSC 246
 * @author Ian Murray (iwmurray)
 */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  printf("%s\n",strerror(errno));
  exit( 1 );
}

// Print out an error message with extra info and exit.
static void failEx(char const *message, char const *extra) {
  fprintf( stderr, "%s: %s\n", message, extra );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: server <board-file>\n" );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Game board
bool board[GRID_SIZE][GRID_SIZE];

// Last move made
int lastMove[2] = {-1, -1};

/**
 * Function to handle SIGINT.
 * @param sig signal number
 */
void sigIntHandler( int sig ) {
  running = 0;
}

/**
 * Load a game board from a file.
 * @param filename file filename
 */
void load_board(char* filename) {
  // Open file
  FILE *fp = fopen(filename, "r");
  if(!fp)
    failEx("Invalid input file", filename);

  // Read each character in rows and column order
  for (size_t i = 0; i < GRID_SIZE; i++) {
    for (size_t j = 0; j < GRID_SIZE; j++) {
      char ch = fgetc(fp);

      // Vaildate character and set board segment
      if(ch == '*')
        board[i][j] = true;
      else if(ch == '.')
        board[i][j] = false;
      else
        failEx("Invalid input file", filename);
    }

    // Vaildate newline
    char ch = fgetc(fp);

    if(ch != '\n')
      failEx("Invalid input file", filename);
  }
}

/**
 * Generate a game board and insert it in the given sting buffer.
 * The buffer should be least size (1 + GRID_SIZE ) * GRID_SIZE + 1.
 * @param buffer string buffer to insert to
 */
void draw_board(char* buffer) {
  char *ch = buffer;

  for (size_t i = 0; i < GRID_SIZE; i++) {
    for (size_t j = 0; j < GRID_SIZE; j++) {
      *ch++ = board[i][j] ? '*' : '.';
    }

    *ch++ = '\n';
  }

  *ch++ = '\0';
}

/**
 * Invert a cell on the game board if the coordinates are vaild.
 * @param row row to effect.
 * @param col column to effect.
 */
void invert(int row, int col) {
  // Check for invaild coordinates
  if(row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE)
    return;

  board[row][col] = !board[row][col];
}

/**
 * Performs a move on the game board at the given coordinates.
 * @param row row to make move on
 * @param col column to make move on.
 * @return return false if coordinates were invalid
 */
bool preformMove(int row, int col) {
  // Check for invaild coordinates
  if(row < 0 || row >= GRID_SIZE || col < 0 || col >= GRID_SIZE)
    return false;

  // Invert target and any adj cells, invalid ones will just be ignoroed.
  invert(row, col);
  invert(row-1, col);
  invert(row+1, col);
  invert(row, col-1);
  invert(row, col+1);

  return true;
}

/**
 * Function to recieve a interger from the given message queue.
 * @param mqdes message queue descriptor
 * @return interger received or -1 on failure.
 */
int mq_receive_int( mqd_t mqdes ) {
  char buffer[ MESSAGE_LIMIT ];
  int reciv = mq_receive( mqdes, buffer, sizeof( buffer ), NULL );

  if( reciv  < 0)
    return -1; // If we used fail(), we can't catch the sigint

  buffer[reciv] = '\0';
  return atoi(buffer);
}

/**
 * Function to send a interger to the given message queue.
 * @param mqdes message queue descriptor
 * @param number interger to send
 */
void mq_send_int( mqd_t mqdes, int number ) {
  char buffer[ MESSAGE_LIMIT ];
  sprintf(buffer, "%d", number);

  if( mq_send( mqdes, buffer, strlen( buffer ), 0 ) < 0)
    fail( "Unable to send interger data to message queue." );
}

int main( int argc, char *argv[] ) {
  // Check arguments
  if ( argc != 2 )
    usage();

  // Load board from file
  load_board(argv[1]);

  // Register sigint handler (adapted from signalExample.c)
  struct sigaction act;
  act.sa_handler = sigIntHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Repeatedly read and process client messages.
  while ( running ) {

    // Receive command as a single byte
    char command = (char) mq_receive_int( serverQueue );

    if(command == 'm') { // Move command
      // Receive parameters for target row and column as seperate messages
      int move[2];
      move[0] = mq_receive_int( serverQueue );
      move[1] = mq_receive_int( serverQueue );

      // Preform the move and send the boolean success back.
      bool success = preformMove(move[0], move[1]);
      mq_send_int(clientQueue, (int)success);

      // If it was successful, update the undo buffer.
      if(success) {
        lastMove[0] = move[0];
        lastMove[1] = move[1];
      }

    } else if(command == 'u') { // Undo command
      // Really, in light's out, undoing a move is just doing the same move
      // again. So we can just use preformMove(), it'll handle the error
      // checking for us, because a blank undo buffer is stored as -1, -1.

      // Preform the move and sent the boolean success back.
      bool success = preformMove(lastMove[0], lastMove[1]);
      mq_send_int(clientQueue, (int)success);

      // If it was successful, update the undo buffer.
      if(success) {
        lastMove[0] = -1;
        lastMove[1] = -1;
      }

    } else if(command == 'r') { // Report command
      // Just draw the board and send the board string to the client.
      char boardString[(1 + GRID_SIZE ) * GRID_SIZE + 1];
      draw_board(boardString);

      if( mq_send( clientQueue, boardString, sizeof(boardString), 0 ) < 0)
        fail( "Unable to send board string to client." );
    
    }
  }

  // Print board on SIGINT
  char boardString[(1 + GRID_SIZE ) * GRID_SIZE + 1];
  draw_board(boardString);
  printf("\n%s", boardString);

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
