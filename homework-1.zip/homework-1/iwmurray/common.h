/**
 * common.h
 * Homework 1 - Problem 4 - CSC 246
 * @author Ian Murray (iwmurray)
 */

// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/iwmurray-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/iwmurray-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5
