#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <mqueue.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

// Print out a usage message, then exit.
static void usage()
{
    fprintf(stderr, "usage: server <board-file>\n");
    exit(1);
}

// struct to hold the information
struct serverInfo {
    char board[GRID_SIZE][GRID_SIZE]; // 2d array used ot store the board info

    int lastMove[2]; // the row and column coordinates of the last move played
};

// helper function to swap a char from '*' to '.' and vis versa
void swapChar(char *swapee)
{
    if (*swapee == '.') {
        *swapee = '*';
    } else {
        *swapee = '.';
    }
}

// performs a move operation on the specified row and col on the board in the si
// param
void move(struct serverInfo *si, int r, int c)
{
    if (r > 0) {
        swapChar(&(si->board[r - 1][c]));
    }
    if (r < 4) {
        swapChar(&(si->board[r + 1][c]));
    }
    if (c > 0) {
        swapChar(&(si->board[r][c - 1]));
    }
    if (c < 4) {
        swapChar(&(si->board[r][c + 1]));
    }
    swapChar(&(si->board[r][c]));
    si->lastMove[0] = r;
    si->lastMove[1] = c;
}

// returns a string representation of the board ready for printing, takes in the
// board to print and a malloced string to be stored in
char *boardToString(struct serverInfo *si, char *str)
{
    for (size_t i = 0; i < GRID_SIZE; i++) {
        strncat(str, si->board[i], GRID_SIZE);
        strncat(str, "\n", 1);
    }
    str[31] = '\0'; // sets the null terminator of the string
    return str;
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// interrupt function to be called when ^C is pressed
void interrupted(int sig) { running = 0; }

int main(int argc, char *argv[])
{
    // use SIGINT to detect when ^C is pressed so you can print the board
    struct sigaction act;
    act.sa_handler = interrupted;
    __sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGINT, &act, 0);

    // checks that the correct number of args are used
    if (argc != 2)
        usage();

    // opens the board as a file pointer
    FILE *fp = fopen(argv[1], "r");

    // fail if the file pointer is not valid
    if (fp == NULL) {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(1);
    }

    // set up the struct to put the board into
    struct serverInfo si = {};

    for (size_t i = 0; i < GRID_SIZE; i++) {
        for (size_t j = 0; j < GRID_SIZE + 1; j++) {
            char ch = 0;
            // fail if the char read is not valid or you run out of chars too
            // soon
            if (fread(&ch, 1, 1, fp) == 0 ||
                (ch != '*' && ch != '.' && ch != '\n')) {
                fprintf(stderr, "Invalid input file: %s\n", argv[1]);
                exit(1);
            }
            // if ch is a board piece add it to the board
            if (ch == '*' || ch == '.') {
                si.board[i][j] = ch;
            }
        }
    }

    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
    if (serverQueue == -1 || clientQueue == -1)
        fail("Can't create the needed message queues");

    bool undoOK = false; // If it is ok to undo

    // Repeatedly read and process client messages.
    while (running) {
        char recievedMessage[MESSAGE_LIMIT] = {};
        if (mq_receive(serverQueue, recievedMessage, MESSAGE_LIMIT, NULL) ==
            -1) {
            // perror("failed to receive message");
            // fail("failed to receive message");
        } else {
            char type = recievedMessage[0]; // type of command to run
            switch (type) {
            case 'm':;
                int r = recievedMessage[1] - '0';
                int c = recievedMessage[2] - '0';

                move(&si, r, c);

                undoOK = true;
                mq_send(clientQueue, "success", 8, 0);
                break;
            case 'u':
                if (undoOK) {
                    move(&(si), si.lastMove[0], si.lastMove[1]);
                    undoOK = false;
                    mq_send(clientQueue, "success", 8, 0);
                } else {
                    mq_send(clientQueue, "error", 6, 0);
                }
                break;
            case 'r':;
                char *msgStr = malloc(
                    (GRID_SIZE) * (GRID_SIZE + 1) +
                    1 * sizeof(char)); // mallocs the string to be printed with
                boardToString(&si, msgStr); // puts the board into the string
                mq_send(clientQueue, msgStr, MESSAGE_LIMIT,
                        0);   // sends the string to the client
                free(msgStr); // frees the message string
                break;
            default:
                break;
            }
        }
    }

    // Close our two message queues (and delete them).
    mq_close(clientQueue);
    mq_close(serverQueue);

    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    char *str =
        malloc((GRID_SIZE) * (GRID_SIZE + 1) +
               1 * sizeof(char)); // mallocs the string to be printed with
    printf("\n%s", boardToString(&si, str));
    free(str); // frees the malloced string

    return 0;
}
