#define _SVID_SOURCE 1
#include <ctype.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

// Print out a usage message, then exit.
static void usage()
{
    printf("usage: maxsum <workers>\n");
    printf("       maxsum <workers> report\n");
    exit(1);
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList()
{
    // Set up initial list and capacity.
    vCap = 5;
    vList = (int *)malloc(vCap * sizeof(int));

    // Keep reading as many values as we can.
    int v;
    while (scanf("%d", &v) == 1) {
        // Grow the list if needed.
        if (vCount >= vCap) {
            vCap *= 2;
            vList = (int *)realloc(vList, vCap * sizeof(int));
        }

        // Store the latest value in the next array slot.
        vList[vCount++] = v;
    }
}

int main(int argc, char *argv[])
{
    bool report = false;
    int workers = 4;

    // Parse command-line arguments.
    if (argc < 2 || argc > 3)
        usage();

    if (sscanf(argv[1], "%d", &workers) != 1 || workers < 1)
        usage();

    // If there's a second argument, it better be the word, report
    if (argc == 3) {
        if (strcmp(argv[2], "report") != 0)
            usage();
        report = true;
    }

    readList();

    // You get to add the rest.

    // sets up the pipe where each of the workers will report their
    // findings
    int pfd[2];
    if (pipe(pfd) != 0) {
        fail("Can't create pipe");
    }

    pid_t pid = -1;
    int idxOffset;

    for (size_t i = 0; i < workers; i++) {
        // forks the number of workers needed if you are the parent process
        if (pid != 0) {
            pid = fork();
            if (pid == -1) {
                // close both ends of the pipe before exiting
                close(pfd[0]);
                close(pfd[1]);
                perror("fork failed");
            }
            // if you are the child sets the idx offset to check
            if (pid == 0) {
                // close the reading end of the pipe
                close(pfd[0]);
                idxOffset = i;

                // if you're the child start processing data
                // if (pid == 0) {
                int maxSum = -1;
                for (size_t i = idxOffset; i < vCount; i += workers) {
                    int sum = 0;
                    for (size_t j =  i; j < vCount; j++) {

                        // functionality for finding the sum for each offsetted
                        // index
                        if (j < vCount) {
                            sum += vList[j];
                            // printf("for process with offset: %d, idx location
                            // = %zu,
                            // "
                            //        "and new sum = %d\n",
                            //        idxOffset, i + j + idxOffset, sum);

                            // if the newest found sum > the max sum found so
                            // far then set it = to that OR if a sum has not
                            // been found yet then set it
                            if (sum > maxSum || maxSum == -1) {
                                maxSum = sum;
                            }
                        }
                    }
                }

                // if report was true explain what your pid num was and your max
                // sum
                if (report) {
                    printf("I'm process %d. The maximum sum I found is %d.\n",
                           getpid(), maxSum);
                }
                lockf(pfd[1], F_LOCK, 0);
                write(pfd[1], &maxSum, sizeof(int));
                lockf(pfd[1], F_ULOCK, 0);
                close(pfd[1]);
                // }
            }
        }
    }
    // close parent's writing end of pipe
    if (pid != 0)
        close(pfd[1]);

    if (pid != 0) {
        int *maxVals = malloc(workers * sizeof(int));
        int maxSum = -1;

        // waits for all the children to finish processing
        for (size_t i = 0; i < workers; i++) {
            wait(NULL);
            read(pfd[0], &(maxVals[i]), sizeof(int));

            // checks all the children's maxSum's found
            // if the considered position in the buffer is greater than maxSum
            // set maxSum = sbuffer[i] OR if you are on the first iteration
            if (maxVals[i] > maxSum || i == 0) {
                maxSum = maxVals[i];
            }
        }

        close(pfd[0]);
        free(maxVals);
        // reports the largest maxSum that was found by the children
        printf("Maximum Sum: %d\n", maxSum);
    }

    return 0;
}
