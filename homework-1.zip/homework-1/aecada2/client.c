#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <mqueue.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stdout, "%s\n", message);
    exit(1);
}

int main(int argc, char *argv[])
{

    // open both the server and client message queues.
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY);

    if (argc < 2 || argc > 4) {
        mq_close(serverQueue);
        mq_close(clientQueue);
        fail("error");
    }
    // Move command: sends "mrc"
    // Where m sigifies that the move command is the one to run and r and c are
    // the row and column of the place to move at
    if (strcmp(argv[1], "move") == 0) {
        if (argc != 4) {
            mq_close(serverQueue);
            mq_close(clientQueue);
            fail("error");
        }
        // int r = 0, c = 0;

        if (*(argv[2]) < '0' || *(argv[2]) > '4' || *(argv[3]) < '0' ||
            *(argv[3]) > '4') {
            mq_close(serverQueue);
            mq_close(clientQueue);
            fail("error");
        }

        // if (sscanf(argv[2], "%d", &r) == 0 || r > 4 || r < 0) {
        //     mq_close(serverQueue);
        //     mq_close(clientQueue);
        //     fail("error");
        // }

        // if (sscanf(argv[3], "%d", &c) == 0 || c > 4 || c < 0) {
        //     mq_close(serverQueue);
        //     mq_close(clientQueue);
        //     fail("error");
        // }

        char msg[3] = {};
        strcat(strcat(strcat(msg, "m"), argv[2]), argv[3]);
        mq_send(serverQueue, msg, 4, 0);

        char *recievedMessage = calloc(MESSAGE_LIMIT, 1);
        if (mq_receive(clientQueue, recievedMessage, MESSAGE_LIMIT, NULL) != -1)
            printf("%s\n", recievedMessage);

    } else if (strcmp(argv[1], "undo") == 0) { // undo command: sends "u"
        if (argc != 2) {
            mq_close(serverQueue);
            mq_close(clientQueue);
            fail("error");
        }
        mq_send(serverQueue, "u", 2, 0);
        char *recievedMessage = calloc(MESSAGE_LIMIT, 1);
        if (mq_receive(clientQueue, recievedMessage, MESSAGE_LIMIT, NULL) != -1)
            printf("%s\n", recievedMessage);
    } else if (strcmp(argv[1], "report") == 0) {
        if (argc != 2) {
            mq_close(serverQueue);
            mq_close(clientQueue);
            fail("error");
        }

        mq_send(serverQueue, "r", 2, 0);
        char *recievedMessage = calloc(MESSAGE_LIMIT, 1);
        if (mq_receive(clientQueue, recievedMessage, MESSAGE_LIMIT, NULL) !=
            -1) {
            printf("%s", recievedMessage);
        } else {
            // perror("Couldnt receive message");
            mq_close(serverQueue);
            mq_close(clientQueue);
            fail("error");
        }

    } else {
        mq_close(serverQueue);
        mq_close(clientQueue);
        fail("error");
    }

    mq_close(serverQueue);
    mq_close(clientQueue);

    return 0;
}