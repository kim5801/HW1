#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

  // Create a pipe to retreive sums
  int pfd[ 2 ];
  if ( pipe( pfd ) != 0 ) {
    fail( "Failed to create pipe" );
  }
  
  // Create workers
  for ( int i = 0; i < workers; i++ ) {
    pid_t pid = fork();
    if ( pid == -1 )
      fail( "Failed to create child process" );

    if ( pid == 0 ) {
      // this is the child, start by closing reading end of pipe
      close( pfd[ 0 ] );

      // now, find the max sum
      int max = 0;
      
      // iterate over evenly spaced starting indices
      for ( int j = i; j < vCount; j += workers ) {
        int currentSum = 0;

        // iterate from starting index to end of array
        for ( int k = j; k < vCount; k++ ) {
          currentSum += vList[ k ];
          if ( currentSum > max ) {
            max = currentSum;
          }
        }
      }

      // if requested, report max from this worker
      if ( report ) {
        printf( "I'm process %d. The maximum sum I found is %d.\n", getpid(), max );
      }

      // lock pipe, write max, then unlock
      lockf( pfd[ 1 ], F_LOCK, 0 );
      write( pfd[ 1 ], &max, sizeof(max) );
      lockf( pfd[ 1 ], F_ULOCK, 0 );

      // return to prevent recursive forking
      return 0;
    }
  }

  // this is the parent, close writing end of pipe
  close( pfd[ 1 ] );

  // wait for each child and get each local max
  int globalMax = 0;
  for ( int i = 0; i < workers; i++ ) {
    wait( NULL );
    int localMax;
    read( pfd[ 0 ], &localMax, sizeof(localMax) );
    
    if ( localMax > globalMax ) {
      globalMax = localMax;
    }
  }

  // Report max sum
  printf( "Maxiumum Sum: %d\n", globalMax );   

  return 0;
}
