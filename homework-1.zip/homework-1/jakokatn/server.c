#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Store board state in 5x5 array of booleans
bool state[5][5];

// Store x and y positions of previous move ( indicate no history with -1 )
int prevX = -1;
int prevY = -1;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Helper function to return a string representation of the board
void getBoardStatusString( char *statusString ) {
  int i = 0;
  for ( int j = 0; j < 5; j++ ) {
    for ( int k = 0; k < 5; k++ ) {
      if ( state[ j ][ k ] == true ) {
        statusString[ i ] = '*';
      } else {
        statusString[ i ] = '.';
      }
      i++;
    }
    statusString[ i ] = '\n';
    i++;
  }

  statusString[ i ] = '\0';
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// SIGINT handler
void sigintHandler( int sig ) {
  char statusString[31];
  getBoardStatusString( statusString );
  printf( "\n%s", statusString );
  running = 0;
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues\n" );
  
  // Register sigint handler
  struct sigaction act;
  act.sa_handler = sigintHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Check command line args
  if ( argc != 2 ) {
    printf( "usage: server <board-file>\n" );
    exit( 1 );
  }

  // Open file
  FILE * fp = fopen( argv[ 1 ], "r" );
  if ( fp == NULL ) {
    printf( "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }

  // Read file contents into memory
  int i = 0;
  int j = 0;
  char c;
  while ( (c = fgetc( fp )) != EOF ) {
    if ( c == '\n' ) {
      j = 0;
      i++;
    } else if ( c == '.' ) {
      state[ i ][ j ] = false;
      j++;
    } else if ( c == '*' ) {
      state[ i ][ j ] = true;
      j++;
    } else {
      printf( "Invalid input file: %s\n", argv[ 1 ] );
      exit( 1 );
    }
  }

  // Repeatedly read and process client messages.
  while ( running ) {
    // get message from queue
    // even though we expect a buffer size of 3 from the client, account for larger messages
    char buffer[ MESSAGE_LIMIT ];
    int len = mq_receive( serverQueue, buffer, sizeof(buffer), NULL ); 
    
    if ( len > 0 ) {
      // create buffer to send message back
      char returnBuffer[ MESSAGE_LIMIT ];

      // use first char to determine command
      if ( buffer[ 0 ] == 'a' ) {
        // move command
        int r = (int) buffer[ 1 ] - 1;
        int c = (int) buffer[ 2 ] - 1;

        // check numbers
        if ( r > 4 || r < 0 || c > 4 || c < 0 ) {
          mq_send( clientQueue, "error\n", strlen( "error\n" ), 0 );
        } else {    
          // flip lights
          state[ r ][ c ] = !state[ r ][ c ];
          if ( r - 1 >= 0 ) {
            state[ r - 1 ][ c ] = !state[ r - 1 ][ c ];
          }
          if ( r + 1 <= 4 ) {
            state[ r + 1 ][ c ] = !state[ r + 1 ][ c ];
          }
          if ( c - 1 >= 0 ) {
            state[ r ][ c - 1 ] = !state[ r ][ c - 1 ];
          }
          if ( c + 1 <= 4 ) {
            state[ r ][ c + 1 ] = !state[ r ][ c + 1 ];
          }
        
          // store position for undo command
          prevX = r;
          prevY = c;

          mq_send( clientQueue, "success\n\0", strlen( "success\n\0" ), 0 );
        }
      } else if ( buffer[ 0 ] == 'b' ) {
        // undo command (only if history exists)
        int r = prevX;
        int c = prevY;
        if ( r == -1 || c == -1 ) {
          mq_send( clientQueue, "error\n", strlen( "error\n" ), 0 );
        } else {
          // flip lights
          state[ r ][ c ] = !state[ r ][ c ];
          if ( r - 1 >= 0 ) {
            state[ r - 1 ][ c ] = !state[ r - 1 ][ c ];
          }
          if ( r + 1 <= 4 ) {
            state[ r + 1 ][ c ] = !state[ r + 1 ][ c ];
          }
          if ( c - 1 >= 0 ) {
            state[ r ][ c - 1 ] = !state[ r ][ c - 1 ];
          }
          if ( c + 1 <= 4 ) {
            state[ r ][ c + 1 ] = !state[ r ][ c + 1 ];
          }

          // clear position history
          prevX = -1;
          prevY = -1;

          mq_send( clientQueue, "success\n\0", strlen( "success\n\0" ), 0 );
        }
      } else if ( buffer[ 0 ] == 'c' ) {
        // report command
        getBoardStatusString( returnBuffer );
        mq_send( clientQueue, returnBuffer, strlen( returnBuffer ), 0 );
      } else {
        // error
        mq_send( clientQueue, "error\n", strlen( "error\n" ), 0 );
      }
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
