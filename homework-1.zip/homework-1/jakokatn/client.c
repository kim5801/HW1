#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

// Print out an error message and exit.
static void error() {
  printf( "error\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  
  // check cl arg count
  if ( argc >= 5 || argc <= 1 ) {
    error();
  }
  
  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
  if ( serverQueue == -1 || clientQueue == -1 )
    error();

  // Store args in three consecutive bytes
  char buffer[ 3 ];
  if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
    buffer[ 0 ] = 'a';

    // check number validity
    if ( strlen( argv[ 2 ] ) > 1 || strlen( argv[ 3 ] ) > 1 || !isdigit( argv[ 2 ][ 0 ] ) || !isdigit( argv[ 3 ][ 0 ] ) ) {
      error();
    }

    // parse row and column numbers
    int r = atoi( argv[ 2 ] );
    int c = atoi( argv[ 3 ] );

    // r and c are guaranteed greater than or equal to 0 already, check validity
    if ( r > 4 || c > 4 ) {
      error();
    }

    // these will store the actual parsed int value
    // faced bug setting buffer[n] to 0, fix by incrementing/decrementing later
    buffer[ 1 ] = (char) r + 1;
    buffer[ 2 ] = (char) c + 1;
  } else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    buffer[ 0 ] = 'b';
  } else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
    buffer[ 0 ] = 'c';
  } else {
    error();
  }

  // Send message to server
  mq_send( serverQueue, buffer, strlen( buffer ), 0 );

  // Get response
  char responseBuffer[ MESSAGE_LIMIT ];
  int len = mq_receive( clientQueue, responseBuffer, sizeof(responseBuffer), NULL );

  // No null terminator, print up to len
  for ( int i = 0; i < len; i++ )
     printf( "%c", responseBuffer[ i ] );
}
