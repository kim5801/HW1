#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

//light board- local to server
static bool lights[GRID_SIZE][GRID_SIZE];
//keeps track of row for undo
static int pvs_choice_row;
//keeps track of column for undo
static int pvs_choice_col;

static void report() {

  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      if(lights[i][j]) {
        fprintf(stdout, "%c", '*');
      }
      else {
        fprintf(stdout, "%c", '.');
      }
    }

    fprintf(stdout, "%c", '\n');
 
  } 
}

void terminateHandler(int sig) {
  fprintf(stdout, "\n");
  report();
  exit(0);
}

static void move(int r, int c) {
  //move command
  //row and col obtained
  lights[r][c] = !lights[r][c];
  //above
  if((r + 1) <= 4) {
    lights[r + 1][c] = !lights[r + 1][c];
  }
  //below
  if((r - 1) >= 0) {
    lights[r - 1][c] = !lights[r - 1][c];
  }
  //left
  if((c - 1) >= 0) {
    lights[r][c - 1] = !lights[r][c - 1];
  }
  //left
  if((c + 1) <= 4) {
    lights[r][c + 1] = !lights[r][c + 1];
  }     

  pvs_choice_row = r;
  pvs_choice_col = c;
  
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  if(argc != 2) {
    fail("usage: server <board-file>\n");
  }

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  FILE *inp = fopen(argv[1], "r");
  if(inp == NULL) {
    fprintf(stderr, "Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  char ch;

  int row = 0;
  int col = 0;
  bool undo_now = false;

  pvs_choice_row = 0;
  pvs_choice_col = 0;

  char msg[MESSAGE_LIMIT];

  while( (ch = fgetc(inp)) != EOF) {
    if(ch != '.' && ch != '*' && ch != '\n') {
      fprintf(stderr, "Invalid input file: %s\n", argv[1]);
      exit(1);
    }

    if(ch == '.') {
      lights[row][col++] = false;
    }
    else if(ch == '*') {
      lights[row][col++] = true;
    }

    if(col == 5) {
      row++;
      col = 0;
    }

  } //light board ready


  // Repeatedly read and process client messages.
  while ( running ) {

    if(argc != 2) {
      fail("usage: server <board-file>\n");
    }

    //handling Ctrl + C
    struct sigaction act;

    act.sa_handler = terminateHandler;
    sigemptyset( &( act.sa_mask ) );
    act.sa_flags = 0;
    sigaction( SIGINT, &act, 0 );


    char cmd[MESSAGE_LIMIT + 1];
    //trying to get a message and it will wait till it gets one
    int len = mq_receive(serverQueue, cmd, sizeof(cmd), NULL );

    //special case undo
    if(cmd[0] == 'u') {
      strcpy(cmd, "undo");
    }

    printf(cmd);

    if(len >= 0) {
      if(strcmp(cmd, "report") == 0) {
        //report
        char print[MESSAGE_LIMIT];
        int idx = 0;

        for(int i = 0; i < GRID_SIZE; i++) {
          for(int j = 0; j < GRID_SIZE; j++) {
            if(lights[i][j]) {
              print[idx++] = '*';
            }
            else {
              print[idx++] = '.';
            }
          }

          print[idx++] = '\n';
        } 

        mq_send(clientQueue, print, strlen(print), 0);
      } //end of report

      else if(strcmp(cmd, "undo") == 0) {
        //undo
        if(undo_now) {
          move(pvs_choice_row, pvs_choice_col);

          //send message to client
          strcpy(msg, "success");
          mq_send(clientQueue, msg, strlen(msg), 0);
        }

        else {
          strcpy(msg, "error");
          mq_send(clientQueue, msg, strlen(msg), 0);
        }

        undo_now = false;
      }

      else { //move
        // char *ptr;
        int r = 0;
        int c = 0;

        if(cmd[5] < '0' || cmd[5] > '4' || cmd[4] > '4' || cmd[4] < '0') {
          strcpy(msg, "error");
          mq_send(clientQueue, msg, strlen(msg), 0);
          continue;
        }   

        char strc[2];
        strc[0] = cmd[5];
        strc[1] = '\0';
        c = atoi(strc);

        char strr[2];
        strr[0] = cmd[4];
        strr[1] = '\0';
        r = atoi(strr);

        if(r < 0 || r > 4 || c < 0 || c > 4) {
          strcpy(msg, "error");
          mq_send(clientQueue, msg, strlen(msg), 0);
        }

        move(r, c);
        undo_now = true;

        //send message to client
        strcpy(msg, "success");
        mq_send(clientQueue, msg, strlen(msg), 0);
        
      } //move end

    } //length of msg > 0

    else {
      fail("Unable to receive message");
    }
    
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
