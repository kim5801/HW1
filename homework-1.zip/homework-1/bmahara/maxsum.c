#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  //making a pipe for IPC
  int pfd[2];
  if( pipe(pfd) != 0) {
    fail("Can't create pipe");
  }


  int my_share = vCount / workers;
  int excess_share = vCount % workers;
  // int idx_check_from = 0;

  for(int worker_id = 0; worker_id < workers; worker_id++) {
    
    int pid = fork();
    int max = INT_MIN;
    if(pid == -1) fail("Can't create child process");
    

    if(pid == 0) {
      //child process
      

      for(int a = 0; a < my_share; a++ ) {
        int subset_sum = 0;
        
        for(int b = (worker_id + (a * workers)); b < vCount; b ++ ) { // + a * my_share        
          subset_sum += vList[b];
          
          if(subset_sum > max) {
            max = subset_sum;
            
          }
        }
        
        
      }     

      if(excess_share != 0) {
        int excess_share_idx = vCount - excess_share;
        int excess_share_ss = 0;
        for(int d = excess_share_idx; d < vCount; d++) {
          excess_share_ss += vList[d];
          if(excess_share_ss > max) {
            max = excess_share_ss;
          }
        }
        excess_share--;
      } //end of calculating for an extra subset

      if(report) {
        pid_t child_pid = getpid();
        printf("I'm process %d. The maximum sum I found is %d.\n", child_pid, max);
      }

      close(pfd[0]);

      lockf(pfd[1], F_LOCK, 0);
      write(pfd[1], &max, sizeof(int));
      lockf(pfd[1], F_ULOCK, 0);

      close(pfd[1]);

      exit(EXIT_SUCCESS);

    } //end of child
    
    max = INT_MIN;

  } //end of multiple forks
  for(int i = 0; i < workers; i++) {
    wait(NULL);
  }
  int max_max = INT_MIN;
  int curr = 0;
  close(pfd[1]);

  while( read(pfd[0], &curr, sizeof(int)) > 0 ) {
    if(curr > max_max) {
      max_max = curr;
    }
  }

  close(pfd[0]);
  printf("Maximum Sum: %d\n", max_max);

  return 0;
}
