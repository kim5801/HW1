#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main(int argc, char *argv[]) {

    if(argc < 2 || argc > 4) {
        fail("error");
    }

    mqd_t server_talk = mq_open(SERVER_QUEUE, O_WRONLY);
    if(server_talk == -1) {
        fail("Can't open message queue");
    }

    // char cmd_final[MESSAGE_LIMIT + 1];
    if(argc == 2) {
        if(strcmp(argv[1], "report" ) == 0) {
            //sending message to server
            mq_send(server_talk, "report\0", strlen("report"), 0);
        }

        else if(strcmp(argv[1], "undo") == 0) {
            //sending message to server
            mq_send(server_talk, "undo\0", strlen("undo"), 0);
        }

        else {
            fail("error");
        }
    }

    else if(strcmp(argv[1], "move") == 0) {
        if(argc != 4) {
            fail("error");
        }
        char cmd_todo[MESSAGE_LIMIT + 1];
 
        cmd_todo[0] = 'm';
        cmd_todo[1] = 'o';
        cmd_todo[2] = 'v';
        cmd_todo[3] = 'e';
        cmd_todo[4] = *argv[2];
        cmd_todo[5] = *argv[3];
        cmd_todo[6] = '\0';

        //sending message to server
        mq_send(server_talk, cmd_todo, strlen(cmd_todo), 0);
        
    }
    else {
        fail("error");
    }

    //communication line from server to client
    mqd_t my_msgs = mq_open(CLIENT_QUEUE, O_RDONLY);

    //receiving status of operations from server
    char buffer[MESSAGE_LIMIT];
    int len = mq_receive(my_msgs, buffer, sizeof(buffer), NULL);

    if(len >= 0) {
        fprintf(stdout, "%s\n", buffer);
    }
    else {
        mq_close(server_talk);
        fail("unable to receiver msg in client from server");
    }

    //close queue to server
    mq_close(server_talk);
    mq_close(my_msgs);

    return 0;



    
}