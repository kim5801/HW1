#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * Breaks a line into its component words and adds null termination between them
 * fills in words array with pointers to word start
 * returns words found in line
 */
int parseClientCommand( char *line, char *words[] ) {
  int numWords = 0;
  if ( isalnum( line[ 0 ]) ) {
    words[ numWords++ ] = &( line[ 0 ] );
  }

  for ( int l = 1; line[ l ] != '\0'; l++ ) {
    if ( !isspace( line[ l ] ) && ( isspace( line[ l - 1 ] ) || line[ l - 1 ] == '\0' ) ) {
      words[ numWords++ ] = &( line[ l ] );
    } else if ( isspace( line [ l ] ) && !isspace( line[ l - 1 ] ) ) {
      line[ l ] = '\0'; 
    }
  }
  return numWords;
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

//Stored representation of board  
static char board[ GRID_SIZE ][ GRID_SIZE ];

//stored location of last move as r, c
int  lmove[2];  

/**
 *  Prints Board state to terminal
 */
static void printBoard() {
  for( int r = 0; r < GRID_SIZE; r++ ) {
    printf("\n");
    for( int c = 0; c < GRID_SIZE; c++ ) {
      printf( "%c", board[r][c] );
    }
  }
  printf("\n");
}


/**
 * Updates position at board( r, c ) and the surrounding cells to the opposite of their current values 
 */
static void makeMove( int r, int c) {
  //Loop through cells surrounding the move position and update the character of the cardinal cells
  //if the row or col is out of bounds skip that column and row combination
  for (int row = r - 1; row <= r + 1; row ++) {
    for (int col = c - 1; col <= c + 1; col++ ) {
      //check that we are in a valid row and col
      if ( row >= 0 && row < GRID_SIZE && col >= 0 && col < GRID_SIZE ) {
        //exclude noncardinal cells
        if( row == r || col == c ) {
          //perform swap operation
          if ( board[ row ][ col ] == '*' ) {
            board[ row ][ col ] = '.';
          } else {
            board[ row ][ col ] = '*';
          }
        }
      }
    }
  }
}
/**
 * catches signal from sigaction and turns off running flag to end loop and print board
 */
void closeHandler( int sig) {
  running = 0;
  printBoard();
}

int main( int argc, char *argv[] ) {
  //sig action for detecting program termination
  struct sigaction act;
  act.sa_handler = closeHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  //check for valid argument count and begin intial board state construction
  if (argc != 2) {
    fail( "usage: server <board-file>" );
  }
  FILE *fp = fopen( argv[ 1 ], "r" );
  //read through file if able to open or exit in error if file was bad
  if ( !fp ) {
    char errorMessage[ sizeof("Invalid input file: ") + sizeof(argv[1]) ];
    strcat(errorMessage, "Invalid input file : ");
    strcat(errorMessage, argv[1]);
    fail( errorMessage );
  } else {
    char ch;
    int row = 0;
    int col = 0;
    //Read through initial input, throw error if file contains bad chars or is too large
    while ( fscanf( fp, "%c", &ch ) == 1 ) {
      if ( ch != '\n' && ch != EOF ) {
        if ( ch != '*' && ch != '.' ) {
          char errorMessage[ sizeof("Invalid input file: ") + sizeof(argv[1]) ];
          strcat(errorMessage, "Invalid input file: ");
          strcat(errorMessage, argv[1]);
          fail( errorMessage );
        }
        board[ row ][ col ] = ch;
       
        col++;
        if ( col == GRID_SIZE ) {
          row++;
          col = 0;
          if ( row > GRID_SIZE ) {
            char errorMessage[ sizeof("Invalid input file: ") + sizeof(argv[1]) ];
            strcat(errorMessage, "Invalid input file: ");
            strcat(errorMessage, argv[1]);
            fail( errorMessage );
          }
        }
      }
    }
  }

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );
  
  //initialize lmove to fail state for undo
  lmove[0] = GRID_SIZE;
  lmove[1] = GRID_SIZE;

  // Repeatedly read and process client messages.
  while ( running ) {
    char buffer[ MESSAGE_LIMIT  + 1 ];
    char *words[ ( MESSAGE_LIMIT / 2 ) + 1 ];
    int len = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );
    if ( len > 0 ) {
      //add Null Terminator to buffer
      buffer[ len ] = '\0';
      //turn command into words    
      int count = parseClientCommand( buffer, words );
      if ( strcmp( words[0], "move" ) == 0 && count == 3 ) {
        //Run move command with given coordinates and update last move post to most recent move
        int row = atoi( words[1] );
        int col = atoi( words[2] );
        makeMove( row, col );
        lmove[0] = row;
        lmove[1] = col;
        mq_send( clientQueue, "success", 7, 0 );

      } else if ( strcmp( words[0], "undo" ) == 0 && count == 1 ) {
        //Run undo command by doing last move and reset lmove to fail state, if no last move exists (fail state)
        //send back fail message
        if ( lmove[0] == GRID_SIZE || lmove[1] == GRID_SIZE ) {
          mq_send( clientQueue, "error", 5, 0 );
        } else {
          makeMove( lmove[0], lmove[1] );
          lmove[0] = GRID_SIZE;
          lmove[1] = GRID_SIZE;
          mq_send( clientQueue, "success", 7, 0 );
        }

      } else if ( strcmp( words[0], "report" ) == 0 && count == 1 ) {
        //create string of board to retuen to client
        char boardState[(GRID_SIZE * GRID_SIZE) + (GRID_SIZE - 1)];
        int printPos = 0;
        //loop through board to generate single line representation of board
        for (int r = 0; r < GRID_SIZE; r++) {
          if ( r != 0 ) {
            boardState[printPos] = '\n';
            printPos++;
          }
          for (int c = 0; c < GRID_SIZE; c++) {
            boardState[printPos] = board[r][c];
            printPos++;
          }
        }
        mq_send( clientQueue, boardState, sizeof( boardState ), 0 );

      } else {
        //No valid command detected send back fail
        mq_send( clientQueue, "error", 5, 0 );
      }
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
