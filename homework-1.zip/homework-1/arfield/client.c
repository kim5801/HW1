#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * Checks if char array is made solely of digits
 */
static bool isNumber( char *num ) {
  for(int i = 0; num[i] != '\0'; i++ ) {
    if(!isdigit(num[i]))
      return false;
  }
  return true;
}

int main( int argc, char *argv[] ) {
  //check that we have the right amount of arguments for each command
  if ( argc < 2 || argc > 4 || ( strcmp( argv[1], "move" ) == 0 && argc != 4) ||
      ((strcmp( argv[1], "undo" ) == 0 || strcmp( argv[1], "report" ) == 0) && argc != 2)) {
    fail("error");
  }

  //open up message queues from server
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );

  //buffer for returned message
  char buffer[ MESSAGE_LIMIT  + 1 ];

  if ( strcmp( argv[1], "move" ) == 0 ) {
    //Call move command from server, takes 2 additional arguments for row and col of move
    //error if row and col args are out of range (< 0 or >= GRID_SIZE ) or not numeric
    if ( !isNumber(argv[2]) || !isNumber(argv[3]) || atoi(argv[2]) >= GRID_SIZE || atoi(argv[2]) < 0 || atoi(argv[3]) >= GRID_SIZE || atoi(argv[3]) < 0 ) {
      fail("error");
    }
    //compile sending string from word and numbers and send command message
    char sendStr[ 6 + sizeof(argv[2]) + sizeof(argv[3]) ];
    strcpy( sendStr, "move ");
    strcat(sendStr, argv[2]);
    strcat(sendStr, " ");
    strcat(sendStr, argv[3]);
    mq_send( serverQueue, sendStr, sizeof(sendStr) , 0 );
    
    int len = mq_receive( clientQueue, buffer, sizeof( buffer ), NULL );
    //loop over to print message, if len is less than zero error has occured
    if ( len >= 0 ) {
      for ( int i = 0; i < len; i++ )
        printf( "%c", buffer[ i ] );
      printf("\n");
    } else {
      fail( "Unable to receive message." );
    }

    //if message was error exit with code 1
    buffer[ len ] = '\0';
    if( strcmp(buffer, "error") == 0 )
      exit(1);   

  } else if ( strcmp( argv[1], "undo" ) == 0 ) {
    //Call undo from server and then process its message it returns
    mq_send( serverQueue, "undo", 4, 0 );

    int len = mq_receive( clientQueue, buffer, sizeof( buffer ), NULL );
    //loop through recieved message to print, if len is less than zero message was not recieved
    if ( len >= 0 ) {
      for ( int i = 0; i < len; i++ )
        printf( "%c", buffer[ i ] );
      printf("\n");
    } else {
      fail( "Unable to receive message." );
    }

    //if message was error exit with code 1
    buffer[ len ] = '\0';
    if( strcmp(buffer, "error") == 0 )
      exit(1);

  } else if ( strcmp( argv[1], "report" ) == 0 ) {
    //Call report from server and print the string that it returns
    mq_send( serverQueue, "report", 6, 0 );

    int len = mq_receive( clientQueue, buffer, sizeof( buffer ), NULL );
    //loop through recieved message to print, if len is less than zero message was not recieved
    if ( len >= 0 ) {
      for ( int i = 0; i < len; i++ )
        printf( "%c", buffer[ i ] );
      printf("\n");
    } else {
      fail( "Unable to receive message." );
    }

    //if message was error exit with code 1
    buffer[ len ] = '\0';
    if( strcmp(buffer, "error") == 0 )
      exit(1);   

  } else {
    //general catch statement any other command is errorneous behavior
    fail("error");
  }

}
