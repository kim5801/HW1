#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

//print error message and exit unsuccessfully
static void fail() {
  fprintf( stderr, "%s\n", "error" );
  exit( 1 );
}

//buffer for receiving messages
char buffer[MESSAGE_LIMIT];

int main( int argc, char *argv[] ) {

  if(argc > 4 || argc < 2) { //check number of args
    fail();
  }


  //message queue attributes
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  //open queues for sending and receiving
  mqd_t queue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  mqd_t receive = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );

  //check queue opened successfully
  if ( queue == -1 || receive == -1) {
    fail();
  }

  if( strcmp(argv[1], "undo") == 0) {

    mq_send( queue, argv[1], strlen( argv[1] ), 0 ); //send undo command to server

    int len = mq_receive( receive, buffer, sizeof( buffer ), NULL );
    buffer[len] = '\0';
    printf("%s\n", buffer); //receives and prints success/error message

  }
  else if( strcmp(argv[1], "report") == 0) {

    mq_send( queue, argv[1], strlen( argv[1] ), 0 ); //sends report command to server

    //print grid received from server
    for(int i = 0; i < GRID_SIZE; i++) {
      int len = mq_receive( receive, buffer, sizeof( buffer ), NULL );
      buffer[len] = '\0';
      printf("%s\n", buffer);
    }
    printf("\n");

  }
  else if( strcmp(argv[1], "move") == 0 && argc == 4) {

    //send move command with arguments to server
    mq_send( queue, argv[1], strlen( argv[1] ), 0 );
    mq_send( queue, argv[2], 1, 0 );
    mq_send( queue, argv[3], 1, 0 );

    char buffer[MESSAGE_LIMIT];
    int len = mq_receive( receive, buffer, sizeof( buffer ), NULL );
    buffer[len] = '\0';
    printf("%s\n", buffer); //receives and prints success/error message

  }
  else {
    fail(); //error if unrecognized command
  }

  mq_close(queue);
  mq_close(receive);

}
