#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

//keeps track of current grid state
char board[GRID_SIZE][GRID_SIZE];

//stores previous move
char undo[] = {'\0', '\0'};

//Toggles character at given board position
void toggle(int r, int c) {
  if(board[r][c] == '.') {
    board[r][c] = '*';
  }
  else {
    board[r][c] = '.';
  }
}

//prints board to console
void report(char board[GRID_SIZE][GRID_SIZE]) {
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int ii = 0; ii < GRID_SIZE; ii++) {
      printf("%c", board[i][ii]); //print character from board
    }
    printf("\n"); //print new line after 5 chars
  }
  printf("\n");
}

//handles signal interrupt
void signalFunc() {
  printf("\n");
  report(board);
  running = 0;
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Repeatedly read and process client messages.

  struct sigaction end;
  end.sa_handler = signalFunc;
  sigemptyset(  &end.sa_mask );
  end.sa_flags = 1;

  if(argc != 2) { //checks for correct number of args
    fail("usage: server <board-file>");
  }

  FILE *fp = fopen(argv[1], "r"); //open file for reading

  if(fp == NULL) { //check for valid file
    printf("Invalid input file: %s\n", argv[1]);
    exit(1);
  }

  for(int i = 0; i < GRID_SIZE; i++) {
    for(int ii = 0; ii < GRID_SIZE + 1; ii++) {
      char c = fgetc(fp); //read char from file

      if(c == '*' || c == '.' || c == '\n') {
        if(c != '\n') {
          board[i][ii] = c; // if char is not a new line char, the char is added to the board
        }
      }
      else {
        printf("Invalid input file: %s\n", argv[1]); //exits on unaccepted char
        exit(1);
      }

    }
  }

  sigaction(SIGINT, &end, 0); //waiting for interrupt signal

  while ( running ) {

    //read message from message queue
    char buffer[MESSAGE_LIMIT];
    int len = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );
    buffer[len] = '\0';


    if ( len > 0 ) { //makes sure a message was received
      if( strcmp(buffer, "undo") == 0) {

        if(undo[0] != '\0') { //if there is a saved move, perform move
          int r = undo[0];
          int c = undo[1];

          //toggles lights  of coordinate and near coordinates
          toggle(r,c);

          if(r - 1 >= 0) {
            toggle(r - 1, c);
          }
          if(r + 1 < GRID_SIZE) {
            toggle(r + 1, c);
          }
          if(c - 1 >= 0) {
            toggle(r, c - 1);
          }
          if(c + 1 < GRID_SIZE) {
            toggle(r, c + 1);
          }
          undo[0] = '\0'; //clear undo

          mq_send( clientQueue, "success", strlen( "success" ), 0 ); //send success message
        }
        else {
          mq_send( clientQueue, "error", strlen( "error" ), 0 ); //send error message
        }


      }
      else if( strcmp(buffer, "report") == 0) { //

        char send[MESSAGE_LIMIT];
        for(int i = 0; i < GRID_SIZE; i++) {
          for(int ii = 0; ii < GRID_SIZE; ii++) {
            send[ii] = board[i][ii]; //convert board to strings
          }
          send[GRID_SIZE] = '\0'; //add null terminator
          mq_send( clientQueue, send, sizeof(send), 0 ); //send strings to client to print
        }

      }
      else if( strcmp(buffer, "move") == 0) {

        len = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL ); //receive move argumment
        buffer[len] = '\0';
        if(!isdigit(buffer[0])) { //makes sure an integer was passed
          mq_send( clientQueue, "error", strlen( "error" ), 0 );
          continue;
        }

        int r = atoi(buffer); //convert string to int
        len = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );//receive seconnd move argumment
        buffer[len] = '\0';
        if(!isdigit(buffer[0])) {//makes sure an integer was passed
          mq_send( clientQueue, "error", strlen( "error" ), 0 );
          continue;
        }
        int c = atoi(buffer);

        if(r < GRID_SIZE && r >= 0 && c < GRID_SIZE && c >= 0) { //checks coordinate is in bounds

          //toggles coordinate and near by spaces
          toggle(r,c);

          if(r - 1 >= 0) {
            toggle(r - 1, c);
          }
          if(r + 1 < GRID_SIZE) {
            toggle(r + 1, c);
          }
          if(c - 1 >= 0) {
            toggle(r, c - 1);
          }
          if(c + 1 < GRID_SIZE) {
            toggle(r, c + 1);
          }

          mq_send( clientQueue, "success", strlen( "success" ), 0 ); //send success message

          //save performed move for undo function
          undo[0] = r;
          undo[1] = c;
        }
        else {
          mq_send( clientQueue, "error", strlen( "error" ), 0 );//send error message
        }

      }
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
