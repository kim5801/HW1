#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Signal handler to direct output after server termination
void signalHandler( int sig ) {
  running = 0;
}

// Parse string as int
int stringToInt( char string[] ) {
  // Iterate through string to take each digit and add it to value
  int value = 0, currDigit = 0, i = 0;
  while ( string[i] != '\0' ) {
    // Not a numerical digit (0-9)
    if ( string[i] < ASCII_LOW || string[i] > ASCII_UP ) {
        return -1;
    }

    currDigit = string[i] - ASCII_LOW;
    value = currDigit + ( value * 10 );

    i++;
  }

  return value;
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues for server" );

  // Set up signal receiver
  struct sigaction kill;
  kill.sa_handler = signalHandler;
  sigemptyset( &( kill.sa_mask ) );
  kill.sa_flags = 0;
  sigaction( SIGINT, &kill, 0 );

  // Error case: invalid usage.
  if ( argc != 2 ) {
    fail( "usage: server <board-file>" );
  }

  // Attempt to read input file.
  int fd = open( argv[ 1 ], O_RDONLY );

  // Error message for invalid file
  char errFile[ MESSAGE_LIMIT ] = "";

  // File not found, exit
  if ( fd == -1 ) {
    // Technique for avoiding segmentation fault found on stack overflow
    strcat( errFile, INVALID_FILE );
    strcat( errFile, argv[ 1 ] );
    // End of stack overflow code
    fail( errFile );
  }

  // Read file contents, store in buffer
  char board[ MESSAGE_LIMIT ];
  int len = read( fd, board, MESSAGE_LIMIT );

  for ( int i = 0; i < len; i++ ) {
    if ( board[ i ] != '*' && board[ i ] != '.' && board[ i ] != '\n' ) {
      // Invalid character
      // Technique for avoiding segmentation fault found on stack overflow
      strcat( errFile, INVALID_FILE );
      strcat( errFile, argv[ 1 ] );
      // End of stack overflow code
      fail( errFile );
    }
  }

  // 2D Array for manipulation ease
  char boardGrid[ GRID_SIZE ][ GRID_SIZE + 1 ];
  char origGrid[ GRID_SIZE ][ GRID_SIZE + 1 ];

  // Copy input board to 2D grid
  int j = 0, k = 0;
  for ( int i = 0; i < strlen( board ); i++ ) {
    if ( board[ i ] == '\n' ) {
      boardGrid[ j ][ k ] = '\n';
      j++;
      k = 0;
    }
    else {
      boardGrid[ j ][ k ] = board[ i ];
      k++;
    }
  }

  // Make copy of board for undo
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE + 1; j++ ) {
      origGrid[ i ][ j ] = boardGrid[ i ][ j ];
    }
  }

  // Input file is valid, continue to receiving client messages.
  // Repeatedly read and process client messages.
  char input[ MESSAGE_LIMIT ];
  int inLen, r, c; // For user moves
  while ( running ) {

    // Receive message from client
    inLen = mq_receive( serverQueue, input, sizeof( input ), NULL );
    input[ inLen ] = '\0'; // To end string at end of new input

    if ( strcmp( input, "move" ) == 0 ) {
      // Get first move number
      inLen = mq_receive( serverQueue, input, sizeof( input ), NULL );
      input[ inLen ] = '\0';

      // Parse first integer from string
      r = stringToInt( input );

      // Get second move number
      inLen = mq_receive( serverQueue, input, sizeof( input ), NULL );
      input[ inLen ] = '\0';

      // Parse second integer from string
      c = stringToInt( input );

      // Invalid integer move input
      if ( ( r == -1 || c == -1 ) || ( r < 0 || r >= GRID_SIZE ) || ( c < 0 || c >= GRID_SIZE ) ) {
        mq_send( clientQueue, ERROR, strlen( ERROR ), 0 );
      }
      else {
        // Save state of current grid in case of undo
        for ( int i = 0; i < GRID_SIZE; i++ ) {
          for ( int j = 0; j < GRID_SIZE + 1; j++ ) {
            origGrid[ i ][ j ] = boardGrid[ i ][ j ];
          }
        }

        // Carry out initial move
        if ( boardGrid[ r ][ c ] == '.' ) {
          boardGrid[ r ][ c ] = '*';
        }
        else {
          boardGrid[ r ][ c ] = '.';
        }

        // Now cascading moves
        // Up
        if ( ( ( r - 1 ) >= 0 ) && ( ( r - 1 ) < GRID_SIZE ) ) {
          if ( boardGrid[ r - 1 ][ c ] == '.' ) {
            boardGrid[ r - 1 ][ c ] = '*';
          }
          else {
            boardGrid[ r - 1 ][ c ] = '.';
          }
        }
        // Down
        if ( ( ( r + 1 ) >= 0 ) && ( ( r + 1 ) < GRID_SIZE ) ) {
          if ( boardGrid[ r + 1 ][ c ] == '.' ) {
            boardGrid[ r + 1 ][ c ] = '*';
          }
          else {
            boardGrid[ r + 1 ][ c ] = '.';
          }
        }
        // Right
        if ( ( ( c + 1 ) >= 0 ) && ( ( c + 1 ) < GRID_SIZE ) ) {
          if ( boardGrid[ r ][ c + 1 ] == '.' ) {
            boardGrid[ r ][ c + 1 ] = '*';
          }
          else {
            boardGrid[ r ][ c + 1 ] = '.';
          }
        }
        // Left
        if ( ( ( c - 1 ) >= 0 ) && ( ( c - 1 ) < GRID_SIZE ) ) {
          if ( boardGrid[ r ][ c - 1 ] == '.' ) {
            boardGrid[ r ][ c - 1 ] = '*';
          }
          else {
            boardGrid[ r ][ c - 1 ] = '.';
          }
        }
        // Done

        // Copy edited 2D grid back to input line
        for ( int i = 0; i < GRID_SIZE; i++ ) {
          for ( int j = 0; j < GRID_SIZE + 1; j++ ) {
            board[ j + ( i * ( GRID_SIZE + 1 ) ) ] = boardGrid[ i ][ j ];
          }
        }

        // Return success message
        mq_send( clientQueue, SUCCESS, strlen( SUCCESS ), 0 );
      }
    }
    else if ( strcmp( input, "undo") == 0 ) {
      // Check similarity to previous grid. If the same, can't undo
      int validUndo = 0;
      for ( int i = 0; i < GRID_SIZE; i++ ) {
        for ( int j = 0; j < GRID_SIZE + 1; j++ ) {
          if ( origGrid[ i ][ j ] != boardGrid[ i ][ j ] ) {
            // There is a difference, good to go
            validUndo = 1;
          }
        }
      }
      // Copy over old grid, or exit with error
      if ( validUndo ) {
        for ( int i = 0; i < GRID_SIZE; i++ ) {
          for ( int j = 0; j < GRID_SIZE + 1; j++ ) {
            boardGrid[ i ][ j ] = origGrid[ i ][ j ];
          }
        }
        // Copy edited 2D grid back to input line
        for ( int i = 0; i < GRID_SIZE; i++ ) {
          for ( int j = 0; j < GRID_SIZE + 1; j++ ) {
            board[ j + ( i * ( GRID_SIZE + 1 ) ) ] = boardGrid[ i ][ j ];
          }
        }

        // Return success message
        mq_send( clientQueue, SUCCESS, strlen( SUCCESS ), 0 );
      }
      // Error
      else {
        mq_send( clientQueue, ERROR, strlen( ERROR ), 0 );
      }
    }
    // Printf out current board report
    else if ( strcmp( input, "report" ) == 0 ) {
      // Send current board to client to be printed
      mq_send( clientQueue, board, strlen( board ), 0 );
    }
    // Command not recognized
    else {
      mq_send( clientQueue, ERROR, strlen( ERROR ), 0 );
    }
  }

  // Print final board
  printf( "\n%s", board );

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
