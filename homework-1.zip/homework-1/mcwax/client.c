#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 )
        fail( "Can't create the needed message queues for client" );

    // Check for invalid commands
    if ( strcmp(argv[ 1 ], "move") != 0 && strcmp(argv[ 1 ], "undo") != 0 && strcmp(argv[ 1 ], "report") != 0 ) {
        fail( ERROR );
    }

    // Send message(s) through queue
    for ( int i = 1; i < argc; i++ ) {
        if ( mq_send( serverQueue, argv[ i ], strlen( argv[ i ] ), 0 ) == -1 ) {
            fail( ERROR );
        }
    }

    // Receive confirmation message from server
    char message[ MESSAGE_LIMIT ];
    mq_receive( clientQueue, message, sizeof( message ), NULL );

    // Display received confirmation message
    printf( "%s\n", message );

    // Close queues on clients end
    mq_close( serverQueue );
    mq_close( clientQueue );

    // Commands transferred successfully
    return EXIT_SUCCESS;
}
