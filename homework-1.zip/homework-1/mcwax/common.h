// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/mcwax-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/mcwax-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5

// Error message for client
#define ERROR "error"

// Error message for invalid file
#define INVALID_FILE "Invalid input file: "

// Success message for client
#define SUCCESS "success"

// Upper boundary ASCII value
#define ASCII_UP 57

// Lower boundary ASCII value
#define ASCII_LOW 48
