#include "common.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <unistd.h>

// Print out an error message and exit
static void fail(char const *message) {
  fprintf(stderr, "%s\n", message);
  exit(1);
}


// Print out the usage message and exit
static void usage() {
  printf("usage: client move <row> <column>\n");
  printf("       client undo\n");
  printf("       client report\n");
  exit(1);
}

int main(int argc, char *argv[]) {
  // Check argument bounds
  if (argc != 2 && argc != 4) {
    usage();
  }

  // Prepare structure indicating maximum queue and message sizes
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Open both the server and client message queues
  mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY, 0600, &attr);
  mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY, 0600, &attr);
  if (serverQueue == -1 || clientQueue == -1) {
    fail("Can't open the needed message queues");
  }

  // Send the message to the user
  char buf[MESSAGE_LIMIT] = "";
  if (argc == 4) {
    sprintf(buf, "%s %s %s", argv[1], argv[2], argv[3]);
  } else {
    sprintf(buf, "%s", argv[1]);
  }
  mq_send(serverQueue, buf, strlen(buf), 0);

  // Get the reponse from the server and print it
  char resp[MESSAGE_LIMIT];
  int len;
  if ((len = mq_receive(clientQueue, resp, sizeof(resp), NULL)) < 0) {
    fail("Unable to receive message");
  }
  resp[len] = '\0';
  printf("%s", resp);

  // Close the queues
  close(serverQueue);
  close(clientQueue);
}
