#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

// Find the largest sum from a starting index from the vList array
int findLargestSum(int start) {
  int sum = 0, max = vList[start];

  // Repeat for the given length of input numbers
  for (int i = start; i < vCount; i++) {
    sum += vList[i];

    // Compare the sum to the max
    if (sum > max) {
      max = sum;
    }
  }

  // Return the max
  return max;
}

// Find the largest sum from a base up to the length using repeat
int findLargestSumRange(int base, int repeat) {
  // Initialize the largest value to the last one
  int largest = findLargestSum(base);

  int sum;
  for (int i = base; i < vCount; i += repeat) {
    // Determine if the given sum is larger than the value we already have
    sum = findLargestSum(i);

    if (sum > largest) {
      largest = sum;
    }
  }

  return largest;
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // Create a pipe for interprocess communciation
  int pfd[2];
  if (pipe(pfd) != 0) {
    fail("Cannot create pipe");
  }

  // Create a number of workers to find the largest sum from a given starting index
  for (int worker = 0; worker < workers; worker++) {
    int pid = fork();

    if (pid < 0) {
      // Fail if a process cannot be created
      fail("Cannot create worker process");
    } else if (pid == 0) {
      int max = findLargestSumRange(worker, workers);
      close(pfd[0]);

      // Lock the writing end of the pipe, send the max, unlock the pipe, and exit
      lockf(pfd[1], F_LOCK, 0);
      if (write(pfd[1], &max, sizeof(int)) < 0) {
        fail("Error writing to pipe");
      }
      lockf(pfd[1], F_ULOCK, 0);

      // Do reporting if that option is enabled
      if (report) {
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), max);
      }
      exit(0);
    }
  }
  close(pfd[1]);

  // Read all values in the pipe to find the maximum sum
  int val, max = vList[vCount - 1];
  while (read(pfd[0], &val, sizeof(int)) > 0) {
    if (val > max) {
      max = val;
    }
  }

  printf("Maximum Sum: %d\n", max);

  free(vList);

  return 0;
}
