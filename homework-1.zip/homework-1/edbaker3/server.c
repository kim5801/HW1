#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out the usage message and exit
static void usage() {
  printf("usage: server <board-file>\n");
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// A structure that represents the board
typedef struct board {
  bool current[GRID_SIZE][GRID_SIZE]; // The current state of the board
  bool previous[GRID_SIZE][GRID_SIZE]; // The previous state of the board (for undos)

  bool undo; // Whether or not the user can undo a move
} Board;

// Handle any user interrupts the program receives
void interruptHandler(int sig) {
  // Set running to false so the program can stop
  running = 0;
}

// Populate a board from a given file path
int populateBoard(char *path, Board *board) {
  // Open the file
  FILE *fp = fopen(path, "r");
  if (fp == NULL) {
    return -1;
  }

  char c;
  int i = 0;

  // Read line by line and populate the board
  while ((c = fgetc(fp)) != -1) {
    // Populate the board on a '.' or '*' and ignore '\n', return error on anything else
    switch (c) {
      case '.':
      case '*':
        *(*(board->current + i / GRID_SIZE) + i % GRID_SIZE) = c == '*';
        i++;
        break;

      case '\n':
        break;

      default:
        return -1;
    }
  }

  // Return status on the count representing a square of length GRID_SIZE
  fclose(fp);
  return (i == GRID_SIZE * GRID_SIZE) - 1;
}

// Print out the current state of the board
void printBoard(Board *b, char *str) {
  char c;

  // Add characters from each row and column
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      c = ('*' + (*(*(b->current + i) + j) - 1) * -4);
      strncat(str, &c, 1);
    }
    // Add a newline at the end of each row
    c = '\n';
    strncat(str, &c, 1);
  }
  c = '\0';
  strncat(str, &c, 1);
}

// Make a move on a board and populate a status message
void move(Board *b, char *pos, char *str) {
  // Get the x and y position from the user
  int row, col;
  if (sscanf(pos, "%*[a-z]%d %d", &row, &col) < 0) {
    strcpy(str, "error\n");
    return;
  }

  // Check if the positions are in bounds
  if (row < 0 || col < 0 || row >= GRID_SIZE || col >= GRID_SIZE) {
    strcpy(str, "error\n");
    return;
  }

  // Set the previous board to the current one before a move is made
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      b->previous[i][j] = b->current[i][j];
    }
  }

  // Invert the corrent spots on the board
  *(*(b->current + row) + col) = !*(*(b->current + row) + col);
  if (col > 0) *(*(b->current + row) + col - 1) = !*(*(b->current + row) + col - 1);
  if (col < GRID_SIZE - 1) *(*(b->current + row) + col + 1) = !*(*(b->current + row) + col + 1);
  if (row > 0) *(*(b->current + row - 1) + col) = !*(*(b->current + row - 1) + col);
  if (row < GRID_SIZE - 1) *(*(b->current + row + 1) + col) = !*(*(b->current + row + 1) + col);

  // Return success and update undo status
  strcpy(str, "success\n");
  b->undo = true;
}

// Undo the latest move
void undo(Board *b, char *str) {
  // Return error if the board cannot be undone
  if (!(b->undo)) {
    strcpy(str, "error\n");
    return;
  }
  b->undo = false;

  // Change every element from previous to current
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      b->current[i][j] = b->previous[i][j];
    }
  }
  strcpy(str, "success\n");
}

int main( int argc, char *argv[] ) {
  // Check the usage and get the required command arguments
  if (argc != 2) {
    usage();
  }

  char *path = argv[1];

  // Initalize a signal for receiving interrupts
  struct sigaction act;
  act.sa_handler = interruptHandler;
  sigemptyset(&act.sa_mask);
  act.sa_flags = 0;
  sigaction(SIGINT, &act, 0);

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Initialize and populate the board
  Board *b = (Board *) malloc(sizeof(Board));
  if (populateBoard(path, b) == -1) {
    free(b);

    char errstr[MESSAGE_LIMIT] = "Invalid input file: ";
    strncat(errstr, path, strlen(path));
    fail(errstr);
  }

  // Repeatedly read and process client messages.
  int len;
  char buf[MESSAGE_LIMIT];
  char str[MESSAGE_LIMIT];
  bool skip;
  while ( running ) {
    // Receive a message from the client
    skip = false;
    if ((len = mq_receive(serverQueue, buf, sizeof(buf), NULL)) < 0) {
      skip = true;
    }
    buf[len] = '\0';

    // Determine what message the user sent and respond to it appropriately
    str[0] = '\0';
    if (strncmp(buf, "report", strlen("report")) == 0 && !skip) {
      printBoard(b, str);
    } else if (strncmp(buf, "move", strlen("move")) == 0 && !skip) {
      move(b, buf, str);
    } else if (strncmp(buf, "undo", strlen("undo")) == 0 && !skip) {
      undo(b, str);
    } else {
      strcpy(str, "error\n");
    }

    // Send the message to the client
    if (mq_send(clientQueue, str, strlen(str) + 1, 0) < 0) {
      fail("Failed to send to client queue");
    }
  }

  // Print out and free the board when the program stops
  printf("\n");

  str[0] = '\0';
  printBoard(b, str);
  printf("%s", str);

  free(b);

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;

  //Test for populating board
  /*
     Board *b = (Board *) malloc(sizeof(Board));
     if (populateBoard("board-6.txt", b) == -1) {
     fail("Error here!");
     }
     for (int i = 0; i < 5; i++) {
     for (int j = 0; j < 5; j++) {
     printf("%d ", b->current[i][j]);
     }
     printf("\n");
     }
     free(b);
     */
}
