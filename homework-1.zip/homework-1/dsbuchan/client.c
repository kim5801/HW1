/**
 * @file client.c
 * @author Daniel Buchanan (dsbuchan)
 * Client that will communicate with server to play game of lights out
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** The third argument in command line*/
static int THIRD_ARG = 2;
/** The fourth argument in the command line*/
static int FOURTH_ARG = 3;
/** The number of arguments for move command*/
static int NUM_MOVE = 4;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
   // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't open the needed message queues" );
    // validate input here and send via message queue
    // combine relevant args into buffer
    // null terminated string with spaces between values
  // if move

  if(0 == strcmp("move" , argv[1]) && argc == NUM_MOVE){
    // invalid arguments for move
    if(strlen(argv[THIRD_ARG]) > 1 || strlen(argv[FOURTH_ARG]) > 1){
      fail("error");

    }
    // charcter not valid for the coordinates
    if(argv[THIRD_ARG][0] < '0' || argv[THIRD_ARG][0] > '9'){
      fail("error");
    }
    if(argv[FOURTH_ARG ][0] < '0' || argv[FOURTH_ARG ][0] > '9'){
      fail("error");
    }

    // making the string to send to the server
    char buffer[MESSAGE_LIMIT + 1];
    // make message for the buffer
    strncpy(buffer, "move ", sizeof("move "));
    strncat(buffer, " ", 1 * sizeof(char));
    strncat(buffer, argv[THIRD_ARG], 1 * sizeof(char));
    strncat(buffer, " ", 1 * sizeof(char));
    strncat(buffer, argv[FOURTH_ARG ], 1 * sizeof(char));
    strncat(buffer, "\0", 1 * sizeof(char));
    mq_send(serverQueue, buffer, MESSAGE_LIMIT, 0);

    // recieve if move was successful or an error
    int len = mq_receive(clientQueue, buffer, MESSAGE_LIMIT, NULL);
    if(len >= 0){
      if(0 == strncmp("error", buffer, sizeof("error"))){
        fail(buffer);
      } 
      printf("%s\n", buffer);
    } else {
      fprintf(stderr, "%d", errno);
      fail(" - errno value");
    }
    // if argument is undo
  } else if(0 == strcmp("undo" , argv[1])) {
    char buffer[MESSAGE_LIMIT + 1] = "undo ";
    // send argument to server
    mq_send(serverQueue, buffer, strlen(buffer), 0);
    char message[MESSAGE_LIMIT + 1];
    int len = mq_receive(clientQueue, message, sizeof(message), NULL);
    // decipher argument from server
    if(len >= 0){
      if(0 == strncmp("error", message, sizeof("error"))){
        fail(message);
      }
      printf("%s\n", message);
    } else{
      fprintf(stderr, "%d", errno);
      fail(" - errno value");
    }

  } else if(0 == strcmp("report" , argv[1])){
    char buffer[MESSAGE_LIMIT + 1] = "report ";
    // request the grid
    mq_send(serverQueue, buffer, strlen(buffer), 0);
    char message[MESSAGE_LIMIT + 1];
    int len = mq_receive(clientQueue, message, sizeof(message), NULL);
    // print out the grid
    if(len >= 0){
      printf("%s\n", message);
    } else {
      fprintf(stderr, "%d", errno);
      fail(" - errno value");
    }
    // on all other arguments, error
  } else {
    fail("error");
  }
  // close queues
  mq_close( clientQueue );
  mq_close( serverQueue );
}
    