/**
 * @file maxsum.c
 * @author Daniel Buchanan (dsbuchan)
 * Calculates the max sum of the integers in an input file using a user input number of
 * child processes.
 */

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
 * Will calculate the largest sum on the given interval
 * 
 * @param list a list of integers
 * @param workers the number of workers
 * @param the number of the given worker
 * @return int the largest sum
 */
int sumChild(int workers, int num)
{
  int maxSum = 0;
  
  // need to got through every start index so, increment start index by workers
  for(int j = num; j < vCount; j += workers){
    int sum = 0;
    for(int i = j; i < vCount; i++){
      sum += vList[i];
      if(sum > maxSum){
        maxSum = sum;
      }    
    }
  }
  return maxSum;
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

  // vCount = num values
  // vCap = capacity of list
  // vlist is the sequence of values

  // create child processes, and establish pipe to communicate results, each child process will have different start, and intervals

  // create pipe first
  int pfd[2];
  pipe(pfd);

  // the max sum of all processes
  int maxSum = 0;
  // only workers calculates, interval = num workers
  // send starting address of integer through pipe

  // determine number of workers to create
  if(workers == 1){
    pid_t worker0 = fork();
    if(worker0 == -1){
      fail("Cannot make child process");
    }
    int sum = 0;
    // one worker
    if(worker0 == 0){
      // closes reading end of pipe
      close(pfd[0]);
      // method will determine sum for each worker
      sum = sumChild(workers, 0);
      // write sum to pipe
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &sum, sizeof(int));
      lockf( pfd[1], F_ULOCK, 0 );
      exit(0);
      // parent process
    } else {
      // waits for child process
      wait(NULL);
      int reSum = 0;
      // reads sum from process
      read(pfd[0], &reSum, sizeof(int));
      if(reSum > maxSum){
        maxSum = reSum;
      }
      // if user entered report in command line, report the max of each process
      if(report){
        printf("I'm process %d. The maximum sum I found is %d.\n", worker0, reSum);
      }
    }
    // two workers
  } else if(workers == 2){
    pid_t worker0 = fork();
    pid_t worker1;
    // only the parent will create child processes
    if(worker0 != 0){
      worker1 = fork();
    }
    // if worker cannot be created
    if(worker0 == -1 || worker1 == -1){
      fail("Cannot make child process");
    }
    int sum = 0;
    // first worker
    if(worker0 == 0){
      // close reading end of pipe
      close(pfd[0]);
      sum = sumChild(workers, 0);
      // write sum to pipe
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &sum, sizeof(int));
      lockf( pfd[1], F_ULOCK, 0 );
      exit(0);
      // second worker
    }else if(worker1 == 0){
      close(pfd[0]);
      sum = sumChild(workers, 1);
      // write sum to pipe
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &sum, sizeof(int));
      lockf( pfd[1], F_ULOCK, 0 );
      exit(0);
      // parent
    }else {
      // wait for each worker
      for(int i = 0; i < 2; i ++){
        pid_t val = wait(NULL);
        int reSum = 0;
        read(pfd[0], &reSum, sizeof(int));
        if(report){
          printf("I'm process %d. The maximum sum I found is %d.\n", val, reSum);
        }
        if(reSum > maxSum){
          maxSum = reSum;
        }
      }
       
    }
    // three workers
  } else if(workers == 3){
    pid_t worker0 = fork();
    pid_t worker1;
    // only create child process if the parent process
    if(worker0 != 0){
      worker1 = fork();
    }
    pid_t worker2;
    if(worker0 != 0 && worker1 != 0){
      worker2 = fork();
    }
    // if any process fails to be created
    if(worker0 == -1 || worker1 == -1 || worker2 == -1){
      fail("Cannot make child process");
    }
    // sum for each process
    int sum = 0;
    if(worker0 == 0){
      close(pfd[0]);
      sum = sumChild(workers, 0);
      // write sum to pipe
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &sum, sizeof(int));
      lockf( pfd[1], F_ULOCK, 0 );
      exit(0);
    } else if(worker1 == 0){
      close(pfd[0]);
      sum = sumChild(workers, 1);
      // write sum to pipe
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &sum, sizeof(int));
      lockf( pfd[1], F_ULOCK, 0 );
      exit(0);
    } else if(worker2 == 0){
      close(pfd[0]);
      sum = sumChild(workers, 2);
      // write sum to pipe
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &sum, sizeof(int));
      lockf( pfd[1], F_ULOCK, 0 );
      exit(0);
    } else {
      // wait for each worker
      for(int i = 0; i < 3; i++){
        pid_t val = wait(NULL);
        int reSum = 0;
        read(pfd[0], &reSum, sizeof(int));
        if(report){
          printf("I'm process %d. The maximum sum I found is %d.\n", val, reSum);
        }
        if(reSum > maxSum){
          maxSum = reSum;
        }
      }
    }

// create four workers
  } else if(workers == 4){
    pid_t worker0 = fork();
    pid_t worker1;
    // only parent makes child processes
    if(worker0 != 0){
      worker1 = fork();
    }
    pid_t worker2;
    if(worker0 != 0 && worker1 != 0){
      worker2 = fork();
    }
    pid_t worker3;
    if(worker0 != 0 && worker1 != 0 && worker2 != 0){
      worker3 = fork();
    }

    // if any child processes failed to be created
    if(worker0 == -1 || worker1 == -1 || worker2 == -1 || worker3 == -1){
      fail("Cannot make child process");
    }
    int sum = 0;
    if(worker0 == 0){
      close(pfd[0]);
      sum = sumChild(workers, 0);
      // write sum to pipe and exit
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &sum, sizeof(int));
      lockf( pfd[1], F_ULOCK, 0 );
      exit(0);
    } else if(worker1 == 0){
      close(pfd[0]);
      sum = sumChild(workers, 1);
      // write sum to pipe and exit
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &sum, sizeof(int));
      lockf( pfd[1], F_ULOCK, 0 );
      exit(0);
    } else if(worker2 == 0){
      close(pfd[0]);
      sum = sumChild(workers, 2);
      // write sum to pipe and exit
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &sum, sizeof(int));
      lockf( pfd[1], F_ULOCK, 0 );
      exit(0);
    } else if(worker3 == 0) {
      close(pfd[0]);
      sum = sumChild(workers, 3);
      // write sum to pipe and exit
      lockf( pfd[1], F_LOCK, 0 );
      write(pfd[1], &sum, sizeof(int));
      lockf( pfd[1], F_ULOCK, 0 );
      exit(0);
    } else {
      // wait for each worker to calculate their sum
      for(int i = 0; i < 4; i++){
        pid_t val = wait(NULL);
        int reSum = 0;
        read(pfd[0], &reSum, sizeof(int));
        if(report){
          printf("I'm process %d. The maximum sum I found is %d.\n", val, reSum);
        }
        if(reSum > maxSum){
          maxSum = reSum;
        }
      }
    }
  }
  

// close reading end of the pipe and report the max sum
  close(pfd[0]);
  printf("Maximum Sum: %d\n", maxSum);

  return 0;
}


