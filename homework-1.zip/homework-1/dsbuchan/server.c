/**
 * @file server.c
 * @author Daniel Buchanan (dsbuchan)
 * Creates a server for a client to play a lights-out game using IPC.
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** Number of arguments for a board*/
static int ARGS_BOARD = 2;
/** Characters between row and colums*/
static int SPACE_MOVE = 2;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}


// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// how many arguments

// Handles signal from sigaction to kill the server
void signalHandler(int sig){
  running = 0;
}


int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // too many input arguments
  if(argc > ARGS_BOARD){
    fail("usage: server <board-file>");
  }
  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // the grid of the game
  char grid[MESSAGE_LIMIT];

  // grid for the previous play
  char prev[(GRID_SIZE + 1) * GRID_SIZE];
  // if there is an undo
  _Bool undo = false;

  // open file, and if cannot open the file is invalid
  FILE * fp = fopen(argv[1], "r");
  if(fp == NULL){
    fprintf(stderr, "Invalid input file: ");
    fail(argv[1]);
  }
  // read in the board and 
  // read in each character, and check if character is valid
  char inCh = fgetc(fp);
  int x = 0;
  while(inCh != EOF){
    // only valid characters in file
    if(inCh != '*' && inCh != '.' && inCh != '\n' ){
      fclose(fp);
      fprintf(stderr, "Invalid input file: ");
      fail(argv[1]);
    }
    grid[x] = inCh;
    x++;
    inCh = fgetc(fp);
  }
  fclose(fp);
  // Repeatedly read and process client messages.
  while ( running ) {


    // to end loop given user signal
    struct sigaction act;
    // sets value for running
    act.sa_handler = signalHandler;
    // when CTRL-C is pressed, print new line and kill
    sigaction(SIGINT, &act, 0);
    
    // bad command line argument "usage: server <board-file>\n"
    if(argc > ARGS_BOARD){
      fail("usage: server <board-file>\n");
    }
    // to read from the sender
    char buffer[MESSAGE_LIMIT];
    int len = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);
    // message received
    if(len >= 0){
      // assuming null terminated buffer
      //need to find where the first argument in the message ends
      int i = 0;
      char ch = buffer[i];
      char command[MESSAGE_LIMIT];
      while(ch != ' ' && ch != '\0'){
        command[i] = ch;
        i++;
        ch = buffer[i];
      }
      // ensuring null terminated string
      command[i] = '\0';
      if(0 == strcmp("move", command)){
        // switch coordinates to ints
        i += SPACE_MOVE;
        int row = buffer[i] - '0';
        i += SPACE_MOVE;
        int col = buffer[i] - '0';
        // not within bounds of grid, send error
        if(row > (GRID_SIZE - 1) || col > (GRID_SIZE - 1)){
          strncpy(command, "error", sizeof("error"));
          mq_send(clientQueue, command, MESSAGE_LIMIT, 0);
        } else {
          // save the previous grid
          undo = true;
          strncpy(prev, grid, (GRID_SIZE + 1) * GRID_SIZE);
          // at cell
          if(grid[(row * (GRID_SIZE + 1)) + col] == '.'){
            grid[(row * (GRID_SIZE + 1)) + col] = '*';
          } else {
            grid[(row * (GRID_SIZE + 1)) + col] = '.';
          }
        
          // above cell
          if(row > 0){
            if(grid[(row - 1) * (GRID_SIZE + 1) + col] == '.'){
              grid[(row - 1) * (GRID_SIZE + 1) + col] = '*';
            } else {
              grid[(row - 1) * (GRID_SIZE + 1) + col] = '.';
            }
          }
          // below cell
          if(row < GRID_SIZE - 1){
            if(grid[(row + 1) * (GRID_SIZE + 1) + col] == '.'){
              grid[(row + 1) * (GRID_SIZE + 1) + col] = '*';
            } else {
              grid[(row + 1) * (GRID_SIZE + 1) + col] = '.';
            }
          }
          // left of cell
          if(col > 0){
            if(grid[(row * (GRID_SIZE + 1)) + col - 1] == '.'){
              grid[(row * (GRID_SIZE + 1)) + col - 1] = '*';
            } else {
              grid[(row * (GRID_SIZE + 1)) + col - 1] = '.';
            }
          }
          // right of cell
          if(col < GRID_SIZE - 1){
            if(grid[(row) * (GRID_SIZE + 1) + col + 1] == '.'){
              grid[(row) * (GRID_SIZE + 1) + col + 1] = '*';
            } else {
              grid[(row) * (GRID_SIZE + 1) + col + 1] = '.';
            }
          }
          // move is successful
          strncpy(command, "success", sizeof("success"));
          mq_send(clientQueue, command, MESSAGE_LIMIT, 0);
        }
  
      } else if (0 == strcmp("undo", command)){
        // check undo
        if(undo){
          // set grid to the previous grid and send success to client
          strncpy(grid, prev, (GRID_SIZE + 1) * GRID_SIZE);
          strncpy(command, "success", sizeof("success"));
          mq_send(clientQueue, command, MESSAGE_LIMIT, 0);
        } else {
          // cannot undo move, send error
          strncpy(command, "error", sizeof("error"));
          mq_send(clientQueue, command, MESSAGE_LIMIT, 0);
        }
        undo = false;
        

      } else if (0 == strcmp("report", command)){
        // send the current grid
        mq_send(clientQueue, grid, MESSAGE_LIMIT, 0);
        // if none of the commands are working, error
      } else {
        strncpy(command, "error", sizeof("error"));
        mq_send(clientQueue, command, MESSAGE_LIMIT, 0);
      }
    } 

    
    // if recieved from sigint
    if(!running){
      printf("\n%s", grid);
    }
    
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
