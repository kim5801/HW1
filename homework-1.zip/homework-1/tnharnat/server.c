#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
// #define MIN(i, j) (((i) < (j)) ? (i) : (j))
// #define MAX(i, j) (((i) > (j)) ? (i) : (j))

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// flip light
char flipLight(char c) {
  if(c == '.')
    return '*';
  else
    return '.';
}

// flip all relevant lights / play the move
void playMove(lightBoard * board) {

  board->board[board->move[0]][board->move[1]] = flipLight(board->board[board->move[0]][board->move[1]]);
  if(board->move[0] > 0)
    board->board[board->move[0] - 1][board->move[1]] = flipLight(board->board[board->move[0] - 1][board->move[1]]);
  if(board->move[1] > 0)
    board->board[board->move[0]][board->move[1] - 1] = flipLight(board->board[board->move[0]][board->move[1] - 1]);
  if(board->move[0] < 4)
    board->board[board->move[0] + 1][board->move[1]] = flipLight(board->board[board->move[0] + 1][board->move[1]]);
  if(board->move[1] < 4)
    board->board[board->move[0]][board->move[1] + 1] = flipLight(board->board[board->move[0]][board->move[1] + 1]);

}


// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// ctrl-C handler
void sigHandler(int error) {
  running = 0;
}

/**
 * @brief main server function
 * 
 * @param argc number of params
 * @param argv board file
 * @return int exit status
 */
int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  lightBoard board;
  board.move[0] = -1;
  board.move[1] = -1;
  FILE * input = fopen(argv[1], "r");

  //board population
  for(int i = 0; i < 5; i++) {
    for(int j = 0; j < 5; j++) {
      board.board[i][j] = fgetc(input);
    }
    fgetc(input);
  }
  
  // Repeatedly read and process client messages
  while ( running ) {
    
    signal(SIGINT, sigHandler);
   
    char rec[MESSAGE_LIMIT];
    mq_receive(serverQueue, rec, MESSAGE_LIMIT, NULL);

    if(strcmp(rec, "move") == 0) {
      mq_receive(serverQueue, (char *)board.move, MESSAGE_LIMIT, NULL);
      playMove(&board);
      mq_send(clientQueue, "success\n", 9, 0);
    }

    if(strcmp(rec, "report") == 0){
      mq_send(clientQueue, (char *)&board, sizeof(board), 0);
    }

    if(strcmp(rec, "undo") == 0){
      if(board.move[0] == -1)
        mq_send(clientQueue, "error\n", 6, 0);
      else {
        playMove(&board);
        board.move[0] = -1;
        mq_send(clientQueue, "success\n", 9, 0);
      }
    }
    
  }
  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  printf("\n");
  printBoard(&board);

  return 0;
}
