/**
 * @file client.c
 * @author Teddy Harnatkiewicz
 * @brief client end of light board game, uses message queue to convey actions
 * @version 0.1
 * @date 2022-09-15
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <mqueue.h>


// Print out an error message and exit.
static void fail( char const *message ) {
  printf("%s\n", message );
  exit( 1 );
}


int main( int argc, char *argv[] ) {
  // Open the message queue for talking to the receiver.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);
  if ( serverQueue == -1  || clientQueue == -1)
    fail( "Can't open message queue" );

  // checks for invalid input
  if(argc != 2 && argc != 4)
    fail("error");

  if(strcmp(argv[1], "move") != 0 && strcmp(argv[1], "undo") != 0 && strcmp(argv[1], "report") != 0)
    fail("error");

  if(strcmp(argv[1], "move") == 0 && argc != 4)
    fail("error");

  if(strcmp(argv[1], "report") == 0 && argc != 2)
    fail("error");

  if(strcmp(argv[1], "undo") == 0 && argc != 2)
    fail("error");
    
  // move command
  if(strcmp(argv[1], "move") == 0) {
    int move[2];
    if(sscanf(argv[2], "%d", move) != 1 || sscanf(argv[3], "%d", move + 1) != 1)
      fail("error");
    if(move[0] < 0 || move[0] > 4 || move[1] < 0 || move[1] > 4)
      fail("error");
    mq_send(serverQueue, "move", 5, 0);
    mq_send(serverQueue, (char *) move, sizeof(move), 0);
    char rec[MESSAGE_LIMIT];
    mq_receive(clientQueue, rec, MESSAGE_LIMIT, NULL);
    printf("%s", rec);
  }

  // report command
  if(strcmp(argv[1], "report") == 0) {
    lightBoard board;
    mq_send(serverQueue, "report", 7, 0);
    mq_receive(clientQueue, (char *)&board, MESSAGE_LIMIT, NULL);
    printBoard(&board);
  }

  // undo command (fails if undo already sent after most recent move)
  if(strcmp(argv[1], "undo") == 0) {
    mq_send(serverQueue, "undo", 5, 0);
    char rec[MESSAGE_LIMIT];
    mq_receive(clientQueue, rec, MESSAGE_LIMIT, NULL);
    printf("%s", rec);
  }


  // We're done, close our copy of the queue (which would happen when we exit anyway).
  mq_close(serverQueue);
  mq_close(clientQueue);
}
