#include<stdlib.h>
#include<stdio.h>
// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/tnharnat-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/tnharnat-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5


typedef struct {
    char board[5][5];
    int move[2];
} lightBoard;

/**
 * @brief print a board struct
 * 
 * @param board board to print 
 */
void printBoard(lightBoard * board) {
  for(int i = 0; i < 5; i++) {
    for(int j = 0; j < 5; j++) {
      printf("%c", board->board[i][j]);
    }
    printf("\n");
  }
  printf("\n");
}
