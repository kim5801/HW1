/**
 * Server file receiveing data from a client, returning responses, and
 * manipulating the board state as requested.
 * @file server.c
 * @author Zach Taylor (zstaylor)
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

/**
 * Represents the state of a board. Contains array for holding current
 * board, and last board, and flag to determine if undo is currently possible
 */
struct boardState {
    char currentBoard[GRID_SIZE * GRID_SIZE];
    char lastBoard[GRID_SIZE * GRID_SIZE];
    int undoPossible;
}typedef BoardState;

/**
 * Outputs the contents of a board to the cli
 * @param board Board contents
 */
void report(BoardState* board) {

    //loop with a second counter to determine when to indent
    for(int i = 0, counter = 0; i < (GRID_SIZE * GRID_SIZE); i++, counter++) {

        if (counter == GRID_SIZE) {
            printf("\n");
            counter = 0;
        }

        printf("%c", board->currentBoard[i]);
    }

    printf("\n");
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;



/**
 * Handler registered with SIGINT signal.
 * @param sig Signal
 */
void quitHandler(int sig) {

    //set the running to 0 to exit program loop
    running = 0;
}

/**
 * Move will attempt to execute a move on the desired cell
 * @param row Row number (0 indexed)
 * @param col Column number (0 indexed)
 * @param board Board State
 * @return 0 if unsuccessful, 1 if successful
 */
int move(int row, int col, BoardState* board) {

    //ensure that the row and column given are valid
    if(row < 0 || row >= 5 || col < 0 || col >= 5) {
        return 0;
    }

    //set the lastboard to the current contents, enable an undo
    memcpy(board->lastBoard, board->currentBoard, sizeof(board->currentBoard));
    board->undoPossible = 1;

    //retrieve idx from row/col info
    int idx = row * GRID_SIZE + col;

    //process north cell, if possible
    if(idx - 5 >= 0) {

        if(board->currentBoard[idx-5] == '.') {
            board->currentBoard[idx-5] = '*';
        }
        else {
            board->currentBoard[idx-5] = '.';
        }
    }

    //south cell, if possible
    if(idx + 5 < 25) {

        if(board->currentBoard[idx+5] == '.') {
            board->currentBoard[idx+5] = '*';
        }
        else {
            board->currentBoard[idx+5] = '.';
        }
    }

    //west cell, if possible
    if(idx - 1 >= 0 && col - 1 >= 0) {

        if(board->currentBoard[idx-1] == '.') {
            board->currentBoard[idx-1] = '*';
        }
        else {
            board->currentBoard[idx-1] = '.';
        }
    }

    //east cell
    if(idx + 1 < 25 && col + 1 <= 4) {

        if(board->currentBoard[idx+1] == '.') {
            board->currentBoard[idx+1] = '*';
        }
        else {
            board->currentBoard[idx+1] = '.';
        }
    }

    //cell itself
    if(idx >= 0 && idx < 25) {

        if(board->currentBoard[idx] == '.') {
            board->currentBoard[idx] = '*';
        }
        else {
            board->currentBoard[idx] = '.';
        }
    }

    return 1;
}

/**
 * Undo will attempt to reset the board to the state of the prior move
 * if possible. Will return 1 if undo successful, 0 if undo unavailable
 * @param board Board State
 * @return 0 if unsuccessful, 1 if successful
 * */
int undo(BoardState* board) {

    //check if undo is possible
    if(board->undoPossible == 0) {
        return 0;
    }

    //roll back current board with last board contents
    memcpy(board->currentBoard, board->lastBoard, sizeof(board->lastBoard));
    board->undoPossible = 0;

    return 1;
}


int main( int argc, char *argv[] ) {

    //invalid args
    if( argc != 2) {
        fail("usage: server <board-file>");
    }

    //set up signal handler for terminate signal
    struct sigaction act;
    act.sa_handler = quitHandler;
    sigemptyset( &(act.sa_mask));
    act.sa_flags = 0;
    sigaction(SIGINT, &act, 0);


    //open the board file and assess the handle
    int boardHdl = open(argv[1], O_RDONLY, 0600);
    if(boardHdl == -1) {
        fprintf(stderr, "Invalid input file: %s\n", argv[1]);
        exit(1);
    }

    //create board state
    struct boardState* board = (struct boardState*) malloc(sizeof(struct boardState));
    board->undoPossible = 0;


    //create buffer for holding input from file
    char rawInput[50] = {};
    int bytesRead = read(boardHdl, rawInput, sizeof(char) * 50);

    //read input from file, checking to ensure it only contains */.
    //if other characters are found, exit unsuccessfully
    for(int i = 0, placed = 0; i < bytesRead; i++) {
        if(rawInput[i] == '.' || rawInput[i] == '*') {
            board->currentBoard[placed] = rawInput[i];
            placed += 1;
        }
        else {
            if(rawInput[i] != '\n') {
                fprintf(stderr, "Invalid input file: %s\n", argv[1]);
                exit(1);
            }
        }
    }

    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );


    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 3;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 )
        fail( "Can't create the needed message queues" );

    // Repeatedly read and process client messages.
   while ( running ) {

        //create buffer for messages from client
        char buff[1024] = {};
        mq_receive(serverQueue, buff, sizeof(buff), NULL );

        /*
        if(received >= 0) {
            printf("RECIEVED: %d bytes\n", received);
        }*/

        /*
         * Message format
         * byte 0: 0 - move
         *         1 - undo
         *         2 - report
         * byte 1: \0
         * byte 2: 0-4 (if of type move)
         * byte 3: \0
         * byte 4: 0-4 (if of type move)
         * byte 5: \0
         */
        //switch on command type as first byte
        if(buff[0] == 0) {
            //printf("MOVE %d %d\n", buff[2], buff[4]);
            //execute command on board
            int result = move(buff[2] - '0', buff[4] - '0', board);

            //create and send response based on result of move function
            char responsebuffer[1024]= {result};
            mq_send(clientQueue, responsebuffer, 1, 0);

        }
        else if (buff[0] == 1) {
            //execute undo on board
            int result = undo(board);

            //create and send response based on result of undo function
            char responsebuffer[1024] = {result};
            mq_send(clientQueue, responsebuffer, 1, 0);
        }
        else if (buff[0] == 2) {

            //send response with current board data to client
            mq_send(clientQueue, board->currentBoard, 25, 0);
        }
   }

    //output final board state on exit
    printf("\n");
    report(board);

    //free board
    free(board);

    // Close our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );

    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    return 0;
}
