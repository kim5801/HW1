/**
 * Client is responsible for communicating with the server and to receive and send data
 * to manipulate the servers board object.
 * @file client.c
 * @author Zach Taylor (zstaylor)
 */
#include "common.h"
#include <mqueue.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>


/**
 * Prints error message to cli
 * @param message Message to print
 */
static void fail( char const *message ) {
    printf( "%s\n", message );
    exit( 1 );
}

/**
 * Outputs the contents of a board to the cli
 * @param board Board contents
 */
void report(char board[]) {

    //loop with a second counter to determine when to indent
    for(int i = 0, counter = 0; i < (GRID_SIZE * GRID_SIZE); i++, counter++) {

        if (counter == GRID_SIZE) {
            printf("\n");
            counter = 0;
        }

        printf("%c", board[i]);
    }

    printf("\n");
}

int main(int argc, char* argv[]) {

    //check for invalid cli arguments
    if(argc < 2 || argc > 4) {
        fail("error");
    }

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 3;
    attr.mq_msgsize = MESSAGE_LIMIT;

    //open queues
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT , 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    if ( serverQueue == -1 || clientQueue == -1)
        fail( "Can't create the needed message queues" );


    //create buffer for holding message to server
    char buff[1024] = {};

    //deal with the command
    if(strcmp(argv[1], "move") == 0) {

        //ensure move has 4 arguments if it is called
        if(argc != 4) {
            fail("error");
        }

        //format message
        char* row = argv[2];
        char* col = argv[3];

        buff[0] = 0;
        buff[1] = '\0';
        buff[2] = *row;
        buff[3] = '\0';
        buff[4] = *col;
        buff[5] = '\0';

        //send message and check for failure
        int result = mq_send(serverQueue, buff, 6, 0);
        if(result != 0) {
            fail("Message send failure");
        }

        //create buffer for response and receive it
        char responseBuffer[1024] = {};
        int responseReceived = mq_receive(clientQueue, responseBuffer, sizeof(responseBuffer), NULL);

        if(responseReceived >= 0) {

            if((int)responseBuffer[0] == 0) {
                fail("error");
            }
            else {
                printf("success\n");
            }
        }
        else {
            fail("error");
        }

    }
    else if (strcmp(argv[1], "undo") == 0) {

        //format message
        buff[0] = 1;
        buff[1] = '\0';

        //send and check for bad send
        int result = mq_send(serverQueue, buff, 2, 0);
        if(result != 0) {
            fail("Message send failure");
        }

        //create buffer for response and receive it
        char responseBuffer[1024] = {};
        int responseReceived = mq_receive(clientQueue, responseBuffer, sizeof(responseBuffer), NULL);

        if(responseReceived >= 0) {

            if((int)responseBuffer[0] == 0) {
                fail("error");
            }
            else {
                printf("success\n");
            }
        }
        else {
            fail("error");
        }
    }
    else if (strcmp(argv[1], "report") == 0) {
        //format message
        buff[0] = 2;
        buff[1] = '\0';

        //send message and check for bad send
        int result = mq_send(serverQueue, buff, 2, 0);
        if(result != 0) {
            fail("Message send failure");
        }

        //create buffer for response and receive it
        char boardbuffer[1024] = {};
        int responseReceived = mq_receive(clientQueue, boardbuffer, sizeof(boardbuffer), NULL);

        //ensure response matches board parameters, output the board
        if(responseReceived == 25) {
            report(boardbuffer);
        }
        else {
            fail("error");
        }

    }
    else { //fail on any other command input
        fail("error");
    }

    //close and unlink from message queue
    mq_close( serverQueue );
    mq_close( clientQueue );

    return EXIT_SUCCESS;

}