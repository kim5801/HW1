/**
 * Computes the maximum sum possible with different ranges in an array
 * Uses child processes to do work and report back to the parent with the
 * results.
 * @file maxsum.c
 * @author Zachary Taylor (zstaylor)
 */
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}



int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

  //create array for holding worker procs
  pid_t childProcs[workers];

  //create return pipe for workers
  int pipefd[2];
  if(pipe(pipefd) != 0) {
      fail("Could not create pipe");
  }

  //determine number of iterations each worker will need to calculate
  int runsPerWorker = vCount / workers;
  if(vCount % workers != 0){ //add one to all workers if it doesnt divide equally
      runsPerWorker += 1;
  }

  // i + workers*J
  //5 workers
  //i j   f
  //o o = 0
  //0 1 = 5
  //0 2 = 10

  //1 0 = 1
  //1 1 = 6
  //1 2 = 11

  //2 0 = 2
  //2 1 = 7
  //2 2 = 12

  //3 0 = 3
  //3 1 = 8
  //3 2 = 13

  //4 0 = 4
  //4 1 = 9
  //4 2 = 14

  for(int i = 0; i < workers; i++ ) {

      pid_t pid = fork();
      childProcs[i] = pid;

      if(pid == 0) {
          //close reading end
          close(pipefd[0]);

          int maxSum = 0;

          //do work
          for(int j = 0; j < runsPerWorker; j++) {

              int sum = 0;

              //Ith worker Jth iteration of that worker
              for(int f = i + (workers*j); f < vCount; f++ ) {

                  //add next item to sum
                  sum += vList[f];

                  //update max if applicable
                  if(sum > maxSum) {
                      maxSum = sum;
                  }
              }
          }



          lockf(pipefd[1], F_LOCK, 0);

          //write to pipe
          write(pipefd[1], &maxSum, sizeof(int));

          lockf(pipefd[1], F_ULOCK, 0);

          //report if necessary
          if(report) {
              printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), maxSum);
          }

          //close writing end and exit
          close(pipefd[1]);
          exit(0);
      }


  }

  //parent closes writing end of pipe
  close(pipefd[1]);

  int receivedMaxSum = 0;

  for(int i = 0; i < workers; i++) {

      int response;

      //wait for it to finish
      wait(childProcs + i);

      read(pipefd[0], &response, sizeof(int));

      if(response > receivedMaxSum) {
          receivedMaxSum = response;
      }
  }

  //close reading end of pipe
  close(pipefd[0]);
  free(vList); //free input list
  printf("Maximum Sum: %d\n", receivedMaxSum);

  return 0;
}
