/**
 * Common definitions for both server and client
 * including agreed names of message queues, message size, and game board size constants
 * @file common.h
 * @author Zachary Taylor (zstaylor)
 */
// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/zstaylor-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/zstaylor-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5
