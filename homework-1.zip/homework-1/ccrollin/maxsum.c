/**
    @file maxsum.c
    @author Caleb Rollins (ccrollin)
    This program uses multiple child processes called workers to more quickly parse
    a list of positive and negative integers to figure out the maximum sum of values in any
    range throughout the list.
*/

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// This is a helper function provided that will print out an error message and exit.
static void fail( char const *message )
{
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// This is a helper function provided that will print out a usage message then exit.
static void usage()
{
    printf( "usage: maxsum <workers>\n" );
    printf( "       maxsum <workers> report\n" );
    exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList()
{
    // Set up initial list and capacity.
    vCap = 5;
    vList = ( int * ) malloc( vCap * sizeof( int ));

    // Keep reading as many values as we can.
    int v;
    while ( scanf( "%d", &v ) == 1 ) {

        // Grow the list if needed.
        if ( vCount >= vCap ) {
            vCap *= 2;
            vList = ( int * ) realloc( vList, vCap * sizeof( int ));
        }

        // Store the latest value in the next array slot.
        vList[vCount++] = v;
    }
}

// This function will iterate through the vList starting at the index passed with the goal of calculating the maximum sum in this segment
static int runSummationSegment( int startingSegmentIndex )
{
    int segmentMax = 0;
    int runningSum = 0;
    for ( int j = startingSegmentIndex; j < vCount; j++ ) {
        runningSum += *( vList + j );
        if ( runningSum > segmentMax ) {
            segmentMax = runningSum;
        }
    }
    return segmentMax;
}

// Create the workers and wait for all of them to return their local max sum to then find/report the global max
int main( int argc, char *argv[] )
{
    // Unless the user specifies that we should report child/worker local max sums then we do assume not
    bool report = false;

    // Variable to store the number of workers the user would like to assign
    int workers;

    // Parse command-line arguments.
    if ( argc < 2 || argc > 3 )
        usage();
    if ( sscanf( argv[1], "%d", &workers ) != 1 || workers < 1 )
        usage();

    // If there's a second argument, it better be the word, report
    if ( argc == 3 ) {
        if ( strcmp( argv[2], "report" ) != 0 )
            usage();
        report = true;
    }

    // Call helper method that will read the input file and add the contents into vList
    readList();

    // Setup our pipe file descriptor and if there is a problem respond appropriately
    int pipefd[2];
    if ( pipe( pipefd ) != 0 ) {
        fail( "There was a problem setting up the pipe for IPC." );
    }

    // Maintain record of the original root parent PID
    int pidParent;

    // Effective PID is a variable that records the order in which a child process was created
    int myEffectivePid;

    // Iterate repeatedly creating children/workers of the original parent process
    for ( int a = 0; a < workers; a++ ) {
        int forkReturn = fork();
        if ( forkReturn == -1 ) {
            fail( "There was a problem creating children/workers." );
        }
        // If the process is the new child/worker then set their effective PID and close the reading end of pipe
        // The child/worker does not need to be accidentally forked again so it breaks out of loop
        if ( forkReturn == 0 ) {
            myEffectivePid = a;
            close( pipefd[0] );
            break;
        }
            // Otherwise if the process is the original parent continue iterating while recording the pid of the parent
        else {
            pidParent = getpid();
        }
    }

    // After we have created all of our workers we need to ensure that they go do the work
    if ( getpid() != pidParent ) {
        // Store the highest sequence sum the child inspects
        int childSumMax = 0;
        // Repeatedly choose a new sequence starting point and calculate the sequence maximum
        for ( int b = 0; b < vCount; b++ ) {
            // Workers are split up across the list repeating every number of workers times where they start
            if ( b % workers == myEffectivePid ) {
                int segmentMaxSum = runSummationSegment( b );
                if ( segmentMaxSum > childSumMax ) {
                    childSumMax = segmentMaxSum;
                }
            }
        }
        // Make sure that this process alone is using the pipe to write to
        lockf( pipefd[1], F_LOCK, 0 );
        // Write to the parent the local child maximum sum found
        int written = write( pipefd[1], &childSumMax, sizeof( int ));
        lockf( pipefd[1], F_ULOCK, 0 );
        if ( written == -1 ) {
            fail( "There was a problem writing to the pipe." );
        }
        // Close the writing end of the pipe now that we are done with it
        close( pipefd[1] );
        // If the user wants to report the local child max then we can do that here
        if ( report ) {
            printf( "I'm process %d. The maximum sum I found is %d.\n", getpid(), childSumMax );
        }
        exit( EXIT_SUCCESS );
    }

        // Otherwise if we are the parent...
    else {
        // We do not need the writing side of the pipe, we just need to read wat the children/workers give us
        close( pipefd[1] );
        // Wait repeatedly for all workers to finish before doing anything
        for ( int a = 0; a < workers; a++ ) {
            wait( NULL );
        }

        // Store the local worker sums in an array, one sum for each worker
        int localSums[workers];
        // Continually read in the local workers sums
        for ( int b = 0; b < workers; b++ ) {
            int readIn = read( pipefd[0], &localSums[b], sizeof( int ));
            if ( readIn == -1 ) {
                fail( "There was a problem reading from the pipe." );
            }
        }
        // We no longer need to read from the pipe so close it
        close( pipefd[0] );

        // Now find the overall list max by comparing our values stored in localSums array
        int overallMax = 0;
        for ( int c = 0; c < workers; c++ ) {
            if ( localSums[c] > overallMax ) {
                overallMax = localSums[c];
            }
        }

        // Print global max sum now that it is found
        printf( "Maximum Sum: %d\n", overallMax );
    }
    return 0;
}
