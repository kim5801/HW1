/**
    @file server.c
    @author Caleb Rollins (ccrollin)
    This is the server side of the Lights Out board game that accepts all request from
    a valid client application. The main operations are to report the current state of the
    game board, to undo the last move, and to make a move at a particular cell.
*/

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message )
{
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Define a single struct to hold the state of the current game
// including the grid, the most recent move, and if an undo operation was the last operation
// Here we are typedef-ing the struct for ease of use later on
typedef struct {
    bool *boardStatus[GRID_SIZE];
    int mostRecentMoveR;
    int mostRecentMoveC;
    bool undoCompleted;
} GameState;

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// The state struct to be maintained exclusively in this server
static GameState state;

// This is a helper method that makes a new move on the game board using the row and column passed
// The makeMove function is also called when the user wants to undo the last move so a parameter exists to differentiate who is calling makeMove
static int makeMove( int row, int column, bool undoTriggered )
{
    // Ensure that the row and column sent by client are valid for the grid size
    if ( row >= 0 && row < GRID_SIZE && column >= 0 && column < GRID_SIZE ) {
        // If so just negate the current status of the cell at row and column
        state.boardStatus[row][column] = !( state.boardStatus[row][column] );
    }
    else {
        // Otherwise let the client know that they did not provide proper row and column
        return 1;
    }

    // Set the top cell above the cell at row and column while accounting for edge case
    if ( row != 0 ) {
        state.boardStatus[row - 1][column] = !( state.boardStatus[row - 1][column] );
    }
    // Set the bottom cell below the cell at row and column while accounting for edge case
    if ( row != GRID_SIZE - 1 ) {
        state.boardStatus[row + 1][column] = !( state.boardStatus[row + 1][column] );
    }
    // Set the cell to the left of the cell at row and column while accounting for edge case
    if ( column != 0 ) {
        state.boardStatus[row][column - 1] = !( state.boardStatus[row][column - 1] );
    }
    // Set the cell to the right of the cell at row and column while accounting for edge case
    if ( column != GRID_SIZE - 1 ) {
        state.boardStatus[row][column + 1] = !( state.boardStatus[row][column + 1] );
    }

    // Set the value of undoCompleted in the state struct whether an undo operation was calling makeMove
    state.undoCompleted = undoTriggered;

    // Store the most recent cell that makeMove worked on so that it can be potentially undone
    state.mostRecentMoveR = row;
    state.mostRecentMoveC = column;

    return 0;
}

// This is a helper method the delegates to makeMove to undo the last move on the game board
// A player can only undo the most recent play, so we also ensure that they cannot undo multiple times
static int undoMove()
{
    if ( state.undoCompleted ) {
        return 1;
    }
    else {
        makeMove( state.mostRecentMoveR, state.mostRecentMoveC, true );
        return 0;
    }
}

// This is a helper method that goes through our the game grid/board stored in the state struct
// and constructs a one dimensional string representation that includes newline characters to be sent across a message queue
static void reportState( char *boardRepresentation )
{
    int i = 0;
    for ( int r = 0; r < GRID_SIZE; r++ ) {
        for ( int c = 0; c < GRID_SIZE; c++ ) {
            if ( state.boardStatus[r][c] ) {
                *( boardRepresentation + i ) = '*';
            }
            else {
                *( boardRepresentation + i ) = '.';
            }
            i++;
        }
        *( boardRepresentation + i ) = '\n';
        i++;
    }
    *( boardRepresentation + ( GRID_SIZE * ( GRID_SIZE + 1 ))) = '\0';
}

// This is our exit/signal handler that simply sets the global running variable to false
// so that the while loop in main stops running. The code to print the visual grid is inside main.
static void exitHandlerFn( int signal )
{
    running = 0;
}

// This function reads from our file pointer that has an initial board to load in and sets up the state struct
static int initBoard( FILE *fp )
{
    int currentChar;
    for ( int r = 0; r < GRID_SIZE; r++ ) {
        for ( int c = 0; c < GRID_SIZE + 1; c++ ) {
            currentChar = fgetc( fp );
            if ( currentChar == '*' ) {
                state.boardStatus[r][c] = true;
            }
            else if ( currentChar == '.' ) {
                state.boardStatus[r][c] = false;
            }
            else if ( currentChar == '\n' ) {
                continue;
            }
            else {
                return 1;
            }
        }
    }
    return 0;
}

// This is the main entry point where the server will being running and listening for client command across a message queue
// once a command is completed it will send a status or contents back to the client for processing.
int main( int argc, char *argv[] )
{
    // Check that when we call server we are providing the initial board file to load from
    if ( argc < 2 || argc > 2 ) {
        fail( "usage: server <board-file>" );
    }

    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 ) {
        fail( "Can't create the needed message queues" );
    }

    // Setup struct that maintains the state of the current game
    // Specifically set up the grid/board array and set the variable to prohibit completing an undo from the start
    bool row0[GRID_SIZE];
    state.boardStatus[0] = row0;
    bool row1[GRID_SIZE];
    state.boardStatus[1] = row1;
    bool row2[GRID_SIZE];
    state.boardStatus[2] = row2;
    bool row3[GRID_SIZE];
    state.boardStatus[3] = row3;
    bool row4[GRID_SIZE];
    state.boardStatus[4] = row4;
    state.undoCompleted = true;

    // Open the board file and ensure that it is able to be read from
    FILE *fp = fopen( argv[1], "r" );
    if ( !fp ) {
        mq_close( clientQueue );
        mq_close( serverQueue );
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        exit( 1 );
    }

    // Initialize the board with the provided input file
    int statusRet = initBoard( fp );

    // If the initialization of the board was unsuccessful then respond appropriately
    if ( statusRet == 1 ) {
        fclose( fp );
        mq_close( clientQueue );
        mq_close( serverQueue );
        fprintf( stderr, "Invalid input file: %s\n", argv[1] );
        exit( 1 );
    }
    else {
        // Otherwise, continue executing later code but close the file pointer now that we have no use for it
        fclose( fp );
    }

    // Configure the sigaction struct with appropriate fields such as our exit handler
    // function, any special flags, and the signal we want to listen for (an interrupt signal in this case)
    struct sigaction signalAction;
    signalAction.sa_handler = exitHandlerFn;
    sigemptyset( &( signalAction.sa_mask ));
    signalAction.sa_flags = 0;
    sigaction( SIGINT, &signalAction, 0 );

    // Repeatedly read and process client messages.
    while ( running ) {
        // Initialize a buffer for reading messages from the client and being reading the message queue
        char readBuff[MESSAGE_LIMIT];
        int numRead = mq_receive( serverQueue, readBuff, sizeof( readBuff ), 0 );

        if ( numRead >= 0 ) {
            // If we are able to read any amount of information from the message queue then we need to further inspect the contents of the message
            int commandStatus;
            if ( *readBuff == 'm' ) {
                // If the first character of the message is 'm' then we want to make a move
                // Get the one character assured (from client) row and column to make the move at
                char r = *( readBuff + 1 );
                char c = *( readBuff + 2 );
                // Convert the ASCII version of the row and column to integer versions
                int row = r - '0';
                int col = c - '0';
                // Call makeMove on row and col and let it know this is not being called the context of an undo operation
                commandStatus = makeMove( row, col, false );
                // If we are successfully able to make a move then let the client know with a 's' character
                // Otherwise let the client know we ran into some type of issue making the move via the 'f' character
                char tempBuff[2];
                if ( commandStatus == 0 ) {
                    tempBuff[0] = 's';
                    tempBuff[1] = '\0';
                }
                else {
                    tempBuff[0] = 'f';
                    tempBuff[1] = '\0';
                }
                // Send either message 's' or 'f' to the client via mq_send
                mq_send( clientQueue, tempBuff, sizeof( tempBuff ), 0 );
            }
            else if ( *readBuff == 'u' ) {
                // If the first character of the message is a 'u' then we want to undo the previous move
                // Call undoMove and store the result of the command
                commandStatus = undoMove();
                // If we are successfully able to undo a move then let the client know with a 's' character
                // Otherwise let the client know we ran into some type of issue undoing the move via the 'f' character
                char tempBuff[2];
                if ( commandStatus == 0 ) {
                    tempBuff[0] = 's';
                    tempBuff[1] = '\0';
                }
                else {
                    tempBuff[0] = 'f';
                    tempBuff[1] = '\0';
                }
                // Send either message 's' or 'f' to the client via mq_send
                mq_send( clientQueue, tempBuff, sizeof( tempBuff ), 0 );
            }
                // At this point we know that since the client will only send report, undo, and move operations this has to be a report
            else {
                char boardRepresentation[GRID_SIZE * ( GRID_SIZE + 1 ) + 1];
                reportState( boardRepresentation );
                // Send the result of reportState via mq_send to the client for it to print out
                mq_send( clientQueue, boardRepresentation, sizeof( boardRepresentation ), 0 );
            }
        }
        else if ( errno != EINTR ) {
            // Otherwise we run into a problem reading from the serverQueue, so respond appropriately
            mq_close( clientQueue );
            mq_close( serverQueue );
            fail( "Can't read from the serverQueue" );
        }
    }

    // Now that we have exited the while loop and are about to terminate lets print out via the server the final game board
    putchar( '\n' );
    // This is to avoid the first line of text being offset from the "^C" that is printed automatically
    for ( int r = 0; r < GRID_SIZE; r++ ) {
        for ( int c = 0; c < GRID_SIZE; c++ ) {
            if ( state.boardStatus[r][c] ) {
                putchar( '*' );
            }
            else {
                putchar( '.' );
            }
        }
        putchar( '\n' );
    }

    // Close and unlink our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );
    return 0;
}
