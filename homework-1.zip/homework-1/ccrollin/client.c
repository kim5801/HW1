/** 
    @file client.c
    @author Caleb Rollins (ccrollin)
    This is the client that sends requests to the server and prints out the response of the
    server for the Light Board game. The user will run this program each time (multiple times)
    they want to send a command to the server.
*/

#include <stdio.h>
#include <stdlib.h>
#include <mqueue.h>
#include <string.h>
#include "common.h"

// This is the home of all code in this simpler program
// Here we read command line arguments that dictate how we send our request and then appropriately respond
int main( int argc, char *argv[] )
{
    // The client needs to have at least one command line argument to tell it what to do
    if ( argc < 2 ) {
        printf( "error\n" );
        exit( 1 );
    }

    // Here we just open the already existing message queues the server created and move on
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
    // In the case that there is an issue opening either message queue then respond appropriately
    if ( serverQueue == -1 || clientQueue == -1 ) {
        fprintf( stderr, "Can't create the needed message queues\n" );
        exit( 1 );
    }

    // All messages are encoded as single continuous null-terminated strings
    // At max our sending buffer should have a size of 4 for the largest command move which would send "mRC\0" across the message queue
    // where m is the literal 'm', R is the row number, and C is the column number. Notice there is a null terminator added as well
    char sendingBuff[4];
    // The receiving buffer as per the mq_receive manual pages must be at least as large as the maximum message size
    char receivingBuff[MESSAGE_LIMIT];

    // If the first command line argument is move then handle a move operation
    if ( strcmp( argv[1], "move" ) == 0 ) {
        // Ensure that there is a row and column command line argument specified
        if ( argc != 4 ) {
            printf( "error\n" );
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit( 1 );
        }
        // Ensure that the length of each row and column argument is 1 (this means numbers 0-9 are still possible, but the server will check that
        // the row and column ranges are valid for the designated board size)
        if ( strlen( argv[2] ) != 1 || strlen( argv[3] ) != 1 ) {
            printf( "error\n" );
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit( 1 );
        }

        // Send a request to the server to move with a 'm' character
        sendingBuff[0] = 'm';
        // Send the server the row and col numbers specified
        sendingBuff[1] = *argv[2];
        sendingBuff[2] = *argv[3];
        // Message is null terminated
        sendingBuff[3] = '\0';

        // Send the request via a message queue
        mq_send( serverQueue, sendingBuff, sizeof( sendingBuff ), 0 );

        // Get a response back on whether the operation was permitted or if there was an error
        int numRead = mq_receive( clientQueue, receivingBuff, sizeof( receivingBuff ), 0 );

        if ( numRead >= 0 && *( receivingBuff ) == 's' ) {
            // if we got a response, and it was a success print the word "success" to the console
            printf( "success\n" );
        }
        else if ( *( receivingBuff ) == 'f' ) {
            // if we got a response, and it was a failure print the word "error" and exit
            printf( "error\n" );
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit( 1 );
        }
        else {
            // otherwise we had trouble reading a response from the clientQueue, so exit properly
            fprintf( stderr, "Can't read from the clientQueue\n" );
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit( 1 );
        }
    }
    else if ( strcmp( argv[1], "undo" ) == 0 ) {
        // If the first command line argument is to undo the previous move
        // Check that the only command line argument is the undo
        if ( argc != 2 ) {
            printf( "error\n" );
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit( 1 );
        }
        // Send a request to the server to undo with a 'u' character (null-terminated)
        sendingBuff[0] = 'u';
        sendingBuff[1] = '\0';
        // Send the request via a message queue to the server
        mq_send( serverQueue, sendingBuff, 2, 0 );
        // Get a response back on whether the operation was permitted or if there was an error
        int numRead = mq_receive( clientQueue, receivingBuff, sizeof( receivingBuff ), 0 );
        if ( numRead >= 0 && *( receivingBuff ) == 's' ) {
            // if we got a response, and it was a success print the word "success" to the console
            printf( "success\n" );
        }
        else if ( *( receivingBuff ) == 'f' ) {
            // if we got a response, and it was a failure print the word "error" and exit
            printf( "error\n" );
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit( 1 );
        }
        else {
            // otherwise we had trouble reading a response from the clientQueue, so exit properly
            fprintf( stderr, "Can't read from the clientQueue\n" );
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit( 1 );
        }
    }
    else if ( strcmp( argv[1], "report" ) == 0 ) {
        // If the first command line argument is to report the current state of the board
        // Check that the only command line argument is the report
        if ( argc != 2 ) {
            printf( "error\n" );
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit( 1 );
        }
        // Send a request to the server to report with a 'r' character (null-terminated)
        sendingBuff[0] = 'r';
        sendingBuff[1] = '\0';
        // Send the request via a message queue to the server
        mq_send( serverQueue, sendingBuff, 2, 0 );
        // Get a response back on whether the operation was permitted or if there was an error
        int numRead = mq_receive( clientQueue, receivingBuff, sizeof( receivingBuff ), 0 );
        if ( numRead >= 0 ) {
            // if we got a response, print the received buffer with the game board to the console
            printf( "%s", receivingBuff );
        }
        else {
            // otherwise we had trouble reading a response from the clientQueue, so exit properly
            fprintf( stderr, "Can't read from the clientQueue\n" );
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit( 1 );
        }
    }
    else {
        // if we got a command that was not one of the valid commands then let the user know, and then quit
        printf( "error\n" );
        mq_close( serverQueue );
        mq_close( clientQueue );
        exit( 1 );
    }

    // On successful exit close open message queues
    mq_close( serverQueue );
    mq_close( clientQueue );
    return 0;
}
