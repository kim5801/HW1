#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
// got stuck when i could not figure out why the message queues would not even create. unfortunately all the code in server and client are completely untested
// and are at best partial implementations of what was asked in this assignment

// Print out an error message and exit.
static void error( char const *message ) {
  fprintf( stdout, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {

  // link to the message queues created by server
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
  if ( serverQueue == -1 || clientQueue == -1 ) {
    error( "Can't link to the needed message queues" );
  }

  // send request to server queue
  if (argc != 2) {
    if (argc == 4 && strcmp(argv[1], "move") == 0) {
      // do move(r, c) command
      int r = strtol(argv[2], (char **)NULL, 10);
      int c = strtol(argv[3], (char **)NULL, 10);
      if (r >= 0 && r <= 4 && c >= 0 && c <= 4) {
        // write command into (server) queue
        char send[9] = {'m','o','v','e',' ',r,' ',c,'\0'};
        int s = mq_send( serverQueue, send, strlen( send ), 0 );
        if (s < 0) {
          error("error: failed to send move request");
        }
      } else {
        error("error: move requires the rows and colums to be integers between 0 and 4");
      }
    } else {
      if (strcmp(argv[1], "undo") == 0 || strcmp(argv[1], "report") == 0) {
        // write command into (server) queue
        int s = mq_send( serverQueue, argv[1], strlen( argv[1] ), 0 );
        if (s < 0) {
          error("error: failed to send undor or report request");
        }
      } else {
        error("error: not a recognized command");
      }
    } 
  } else {
    error("error: wrong number of command arguments");
  }
  
  // read response from client queue
  // Try to get a message (this will wait until one arrives).
  char buffer[ MESSAGE_LIMIT ];
  int len = mq_receive( clientQueue, buffer, sizeof( buffer ), NULL );

  if ( len >= 0 ) {
    printf( "test message: \n" );
    if (len == 1) {
      if (buffer[0] == 's') {
        printf("success\n");
      } else if (buffer[0] == 'e') {
        error("e");
      }
    }
    // The message isn't null terminated (we don't send the null in this example)
    // We could add a null terminator; instead, we just print it a char at a time.
    for ( int i = 0; i < len; i++ ) {
      printf( "%c", buffer[ i ] );
    }
  } else {
    error( "error: Unable to receive message in clientQueue." );
  }
  
  mq_close(serverQueue);
  mq_close(clientQueue);
  
  exit(0);

}