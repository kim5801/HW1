#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
// got stuck when i could not figure out why the message queues would not even create. unfortunately all the code in server and client are completely untested
// and are at best partial implementations of what was asked in this assignment

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// same parsecommand as previous project cause it worked pretty well i think
int parseCommand( char *line, char *words[] )
{
  int wordIdx = 0;
  bool inspace = true;
  for (char *i = line; *i; i++) {
    if (isspace(*i)) {
       if (!inspace) {
         *i = '\0';
         inspace = true;
       }
    } else {
      if (inspace) {
        words[wordIdx] = i;
        wordIdx++;
        inspace = false;
      }
    }
  }
  return wordIdx;
}

// function called when SIGINT is caught
void saHandler(int sig) {
  running = 0;
}

int main( int argc, char *argv[] ) {
  // manage arguments
  if (argc != 2) {
    fail("usage: server <board-file>");
  }
  FILE *fp = fopen( argv[1], "r" );
  if ( fp == NULL ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[1] );
    exit( EXIT_FAILURE);
  }
  
  // populate an array of lights
  char lights[GRID_SIZE][GRID_SIZE];
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
        int ch = fgetc(fp);
        if (ch == EOF || (ch != '.' && ch != '*')) {
          fprintf( stderr, "Invalid input file: %s\n", argv[1] );
          exit( EXIT_FAILURE);
        }
        lights[i][j] = ch;
        if (j == 4) {
          ch = fgetc(fp);
          if (ch != '\n') {
            fprintf( stderr, "Invalid input file: %s\n", argv[1] );
            exit( EXIT_FAILURE);
          }
        }
    }
  }
  
  // keep for undo
  // whether the user can use undo
  bool canUndo = false;
  char oldLights[GRID_SIZE][GRID_SIZE];
  


  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Repeatedly read and process client messages.
  
  // Struct to use when catching the signal for an abrupt exit with ^C
  struct sigaction sa;
  // Fill in a structure to redirect the alarm signal.
  sa.sa_handler = saHandler;
  sigemptyset( &( sa.sa_mask ) );
  sa.sa_flags = 0;
  sigaction( SIGINT, &sa, 0 );
  
  
  while ( running ) {
    int i = 0;
    char* words[513];
    char buffer[ MESSAGE_LIMIT ];
    int len = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );
    if ( len >= 0 ) {
      i = parseCommand(buffer, words);
      if (i == 1) {
        if (strcmp(words[0], "undo") == 0 && canUndo) {
          canUndo = false;
          for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                lights[i][j] = oldLights[i][j];
            }
          }
          mq_send( clientQueue, "s", strlen( "s" ), 0 );
        } else if (strcmp(words[0], "report") == 0) {
          for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
              printf("%c", lights[i][j]);
              if (j == 4) {
                printf("\n");
              }
            }
          }
        } else {
          mq_send( clientQueue, "e", strlen( "e" ), 0 );
        }
      } else if (i == 3) {
        // MOVE: 
      } else {
        mq_send( clientQueue, "e", strlen( "e" ), 0 );
      }
    } else {
      mq_send( clientQueue, "e", strlen( "e" ), 0 );
    }
    // ...
    
  }
  
  // breaks out of running when catches exit
  printf("\n");
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      printf("%c", lights[i][j]);
      if (j == 4) {
        printf("\n");
      }
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
