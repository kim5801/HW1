#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // store the list in malloced vList
  readList();

  // You get to add the rest.
  // create pipe
  int pfd[2];
  if (pipe(pfd) != 0) {
    fail("can't create pipe");
  }
  
  // make "workers" number of child processes
  for (int i = 0; i < workers; i++) {
    pid_t child_pid = fork();
    if (child_pid < 0) {
        fail("fork");
    } else if (child_pid ==  0) {
        // what the child does, based on child number i
        
        // close reading end of pipe
        close(pfd[0]);
        
        int max = 0;
        // O(n) for every [workers] in vList, check all sums of indices from i + c[workers] to vcap, where c is some #
        for (int z = i; z < vCount; z += workers) {
          // check i + c[workers] (=z)
          // check max for z, z + 1, ... , z +...+ (vcap - 2), z +...+ (vcap - 1)
          int temp = 0;
          for (int j = z; j < vCount; j++) {
            temp = temp + vList[j];
            if (temp > max) {
              max = temp;
            }
          }
        }
        
        // if report is true, print a short report on what each child did
        if (report) {
          printf("I’m process %d. The maximum sum I found is %d.\n", i + 1, max);
        }
        
        // write to pipe after locking it, then unlock
        lockf( pfd[1], F_LOCK, 0 );
        // max>bytes??
        write(pfd[1], &max, sizeof(max));
        lockf( pfd[1], F_ULOCK, 0 );
        
        // child exits after finished
        exit(0);
    }
  }
  
  // close writing end of pipe
  close(pfd[1]);
  
  // have parent wait for every child
  int totalMax = 0;
  for (int i = 0; i < workers; i++) {
    wait(NULL);
    int tempMax = 0;
    read(pfd[0], &tempMax, sizeof(int));
    if (tempMax > totalMax) {
      totalMax = tempMax;
    }
  }
  
  printf("Maximum sum: %d\n", totalMax);
  // ...

  return 0;
}