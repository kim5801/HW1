#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

//find the highest sum in a list starting from the startIndex parameter
int highestContSumFrom(int startIndex) {
  int highestSum = INT_MIN;
  int totalSum = 0;
  for (int i = startIndex; i < vCount; i++) {
    totalSum += vList[i];
    if (totalSum > highestSum) {
      highestSum = totalSum; 
    } //else continue through the list (do not stop) cuz a future integer may be big and make a new highest sum
  }
  return highestSum;
}

void calculateMaxSum(int numWorkers, int pipeFd[2], bool report) {
  for (int i = 0; i < numWorkers; i++) {
    // Try to make a child process.
    int pid = fork();
    if ( pid == -1 )
      fail( "Can't create child process" );

    // Print out a report from that child.
    if ( pid == 0 ) {
      //close reading end
      close(pipeFd[0]);
      /* 
        the strategy used for dividing work is taking the current worker number, and adding the increment (the number of workers) 
        to it. This effectively makes it so that each worker only does every n process, offset by one for each worker.
      */
      int highestSum = INT_MIN;
      for (int j = i; j < vCount; j += numWorkers) {
        int currentSum = highestContSumFrom(j);
        if (currentSum > highestSum) {
          highestSum = currentSum;
        }
      }
      //write information to the pipe or to standard output if the report flag is true
      lockf(pipeFd[1], F_LOCK, 0);
      write(pipeFd[1], &highestSum, sizeof(highestSum));
      lockf(pipeFd[1], F_ULOCK, 0);

      if (report) {
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), highestSum);
      }

      //child is done
      exit(0);
    }
  }
  //after all writes are finished close writing end.
  close(pipeFd[1]);
  for (int i = 0; i < numWorkers; i++) {
    wait(NULL);
  }
}


int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // create pipe
  int pfd[ 2 ];
  if ( pipe( pfd ) != 0 )
    fail( "Can't create pipe" );

  //call function that most work occurs in
  calculateMaxSum(workers, pfd, report);

  //once the above finishes, figure out the largest int in the pipe
  int max = INT_MIN;
  int current;
  for (int i = 0; i < workers; i++) {
    if (read(pfd[0], &current, sizeof(current)) == -1) {
      fail("Could not read an int from the worker who submitted int number\n");
    }
    if (current > max) {
      max = current;
    }
  }
  close(pfd[0]);
  printf("Maximum Sum: %d\n", max);

  return 0;
}
