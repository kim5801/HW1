#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

//compilation command: gcc -D_POSIX_SOURCE -Wall -g -std=c99 -o server server.c -lrt

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//the basic success message to client if the command is successful
const char *SUC_MSG = "success";
//the basic error message to client if the command fails
const char *ERR_MSG = "error";

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

struct {
  char current[GRID_SIZE][GRID_SIZE + 2];
  char last[GRID_SIZE][GRID_SIZE + 2];
  bool lastDiff;
} boardState;

/// @brief Reads from the input file and initializes the boardState based on the file.
/// this can stop the program running if something with the file is invalid
/// @param filename the file to read from
void initializeBoardState(char *filename) {
  //try to open file
  FILE *fp = fopen(filename, "r");
  if (fp == NULL) {
    fprintf(stderr, "Invalid input file: %s\n", filename);
    exit(1);
  }
  
  //iterate thru file
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE + 2; j++) {
      //if we are past the newline, add a null terminator so that we can print 
      //as string, and then continue in the loop
      if (j == GRID_SIZE + 1) {
        boardState.current[i][j] = '\0';
        continue;
      }

      char currChar = fgetc(fp);
      //if currChar is not an allowed char, then close the file and exit
      if (currChar != '.' && currChar != '*' && currChar != '\n') {
        fclose(fp);
        fprintf(stderr, "Invalid input file: %s\n", filename);
        exit(1);
      }
      //otherwise add the char into the corresponding element in the 2D array
      boardState.current[i][j] = currChar;
    }
  }
  boardState.lastDiff = false;
  fclose(fp);
}

/// @brief handles what happens when the process aborts
/// @param sig the error code
void terminationHandler(int sig) {
  running = 0;
  printf("\n");
  for (int i = 0; i < GRID_SIZE; i++) {
    printf(boardState.current[i]);
  }
  exit(sig);
}

/// @brief copies one 2d char array representation of the board to another
/// @param to the 2d char array to copy to
/// @param from the 2d char array to copy from
void copyBoard(char to[GRID_SIZE][GRID_SIZE + 2], char from[GRID_SIZE][GRID_SIZE + 2]) {
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE + 2; j++) {
      to[i][j] = from[i][j];
    }
  }
}

/// @brief Converts a string to an int. Sets the success flag if it parsed successfully
/// @param str the string to parse
/// @param success the success of the conversion
/// @return the integer if the parsing was successful, otherwise -1
int strToInt(char *str, bool *success) {
  char *endPtr = NULL;
  int retVal = strtol(str, &endPtr, 10);
  //check that errno is not set, that the string is not empty, and that the whole string was parsed
  if (errno == 0 && (str != endPtr) && *endPtr == '\0') {
    *success = true;
    return retVal;
  } else {
    *success = false;
    return -1;
  }
}

/// @brief flips the light on or off depending on its state. If it is not one of 
/// two expected chars, nothing happens
/// @param light a char pointer to either '*' or '.'
void flipLight(char *light) {
  if (*light == '*') {
    *light = '.';
  } else if (*light == '.') {
    *light = '*';
  }
}

/// @brief checks if a coordinate is out of bounds for the grid
/// @param coord the coord to check
/// @return true if out of bounds, otherwise false
bool isOutOfBounds(int coord) {
  return coord < 0 || coord > GRID_SIZE - 1;
}

/// @brief Executes a move at the specified coordinates
/// @param x the x coord
/// @param y the y coord
/// @param responseBuf the response to the given command is stored in this parameter
/// @return a message representing success or failure
void moveCommand(char *x, char *y, char responseBuf[MESSAGE_LIMIT]) {
  //error check coords
  bool success;
  int xCoord = strToInt(x, &success);
  if (!success || isOutOfBounds(xCoord)) {
    strcpy(responseBuf, ERR_MSG);
    return;
  }
  int yCoord = strToInt(y, &success);
  if (!success || isOutOfBounds(xCoord)) {
    strcpy(responseBuf, ERR_MSG);
    return;
  }

  //save board for undo
  copyBoard(boardState.last, boardState.current);

  //flip lights if possible
  flipLight(&boardState.current[xCoord][yCoord]);
  if (!isOutOfBounds(xCoord + 1)) {
    flipLight(&boardState.current[xCoord + 1][yCoord]);
  }
  if (!isOutOfBounds(xCoord - 1)) {
    flipLight(&boardState.current[xCoord - 1][yCoord]);
  }
  if (!isOutOfBounds(yCoord + 1)) {
    flipLight(&boardState.current[xCoord][yCoord + 1]);
  }
  if (!isOutOfBounds(yCoord - 1)) {
    flipLight(&boardState.current[xCoord][yCoord - 1]);
  }
  boardState.lastDiff = true;
  strcpy(responseBuf, SUC_MSG);
}

/// @brief Sets the current board state to the last board state
/// @param responseBuf the response to the given command is stored in this parameter
/// @return a message representing success or failure
void undoCommand(char responseBuf[MESSAGE_LIMIT]) {
  if (!boardState.lastDiff) {
    strcpy(responseBuf, ERR_MSG);
    return;
  }
  copyBoard(boardState.current, boardState.last);
  boardState.lastDiff = false;
  strcpy(responseBuf, SUC_MSG);
}

/// @brief returns a string visualizing the board
/// @param responseBuf the response to the given command is stored in this parameter
/// @return a string visualizing the board
void reportCommand(char responseBuf[MESSAGE_LIMIT]) {
  for (int i = 0; i < GRID_SIZE; i++) {
    strcat(responseBuf, boardState.current[i]);
  }
}

/// @brief Parses the buffer and attempts to execute or gives errors
/// @param cmdBuf the text of the command
/// @param responseBuf the response to the given command is stored in this parameter
/// @return a string response to command
void parseCommand(char cmdBuf[MESSAGE_LIMIT], char responseBuf[MESSAGE_LIMIT]) {
  char *str = strtok(cmdBuf, " ");
  if (strcmp("move", str) == 0) {
    //parse and check the remaining arguments for move command
    char *xCoord = strtok(NULL, " ");
    if (xCoord == NULL) {
      strcpy(responseBuf, ERR_MSG);
      return;
    }
    char *yCoord = strtok(NULL, " ");
    if (yCoord == NULL) {
      strcpy(responseBuf, ERR_MSG);
      return;
    }
    //if there are more arguments throw an error
    if (strtok(NULL, " ") != NULL) {
      strcpy(responseBuf, ERR_MSG);
      return;
    }
    moveCommand(xCoord, yCoord, responseBuf);

  } else if (strcmp("undo", str) == 0) {
    //if there are more arguments throw an error
    if (strtok(NULL, " ") != NULL) {
      strcpy(responseBuf, ERR_MSG);
      return;
    }
    undoCommand(responseBuf);


  } else if (strcmp("report", str) == 0) {
    //if there are more arguments throw an error
    if (strtok(NULL, " ") != NULL) {
      strcpy(responseBuf, ERR_MSG);
      return;
    }
    reportCommand(responseBuf);
    
  } else {
    strcpy(responseBuf, ERR_MSG);
  }
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  //check arguments and initialize board state
  if (argc != 2) {
    fail("usage: server <board-file>");
  }
  initializeBoardState(argv[1]);

  //set up server termination
  struct sigaction act;
  act.sa_handler = terminationHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Repeatedly read and process client messages.
  while ( running ) {
    char cmdBuf[MESSAGE_LIMIT];
    char responseBuf[MESSAGE_LIMIT];
    memset(responseBuf, 0, sizeof(responseBuf)); //clear anything that may be in response buffer
    memset(cmdBuf, 0, sizeof(cmdBuf)); //clear anything that may be in cmd buffer

    int len = mq_receive(serverQueue, cmdBuf, sizeof(cmdBuf), NULL);

    if (len > 0) {
      parseCommand(cmdBuf, responseBuf);
      mq_send(clientQueue, responseBuf, strlen(responseBuf), 0);
    } else {
      mq_send(clientQueue, ERR_MSG, strlen(ERR_MSG), 0);
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
