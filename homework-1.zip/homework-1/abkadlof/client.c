#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <mqueue.h>
#include "common.h"
#include "string.h"

//compilation command: gcc -Wall -g -std=c99 -o client client.c -lrt

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main(int argc, char *argv[]) {
  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  //make sure there is a minimum number of args
  if (argc < 2) {
    printf("error\n");
    exit(1);
  }

  char sendBuffer[ MESSAGE_LIMIT ];
  for (int i = 1; i < argc; i++) {
    //concat a space before every argument except the first
    if (i != 1) {
      strcat(sendBuffer, " ");
    }
    strcat(sendBuffer, argv[i]);
  }

  // Send the message to the server
  mq_send( serverQueue, sendBuffer, strlen( sendBuffer ), 0 );

  // get a message back from server and print to output
  char receiveBuffer[ MESSAGE_LIMIT ];
  mq_receive(clientQueue, receiveBuffer, sizeof(receiveBuffer), NULL);
  printf(receiveBuffer);
  printf("\n");

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  if (strcmp(receiveBuffer, "error") == 0) {
    exit(1);
  }
  exit(0);
}
