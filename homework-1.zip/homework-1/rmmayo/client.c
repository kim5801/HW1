#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stdin, "%s\n", message );
  exit( 1 );
}

//Quick check to make sure the given string is a one digit num.
bool isNum(char* str) {
  if(strlen(str) > 1) {
    return false;
  }
  return str[0] >= 48 || str[0] <= 57;
}

int main(int argc, char *argv[]) {
  if(argc < 2) {//Make sure their is at least one arg to read from
    fail("error");
  }

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );
    
  char buffer[MESSAGE_LIMIT];//The message buffer


  strncpy(buffer, argv[1], strlen(argv[1]));//Copy the command to the buffer, without the null terminator
  buffer[strlen(argv[1])] = '\0';//Add the null terminator
  
  if(strcmp("move", argv[1]) == 0) {//Extra step if the command is "move"
    
    if(argc != 4 || strlen(argv[2]) != 1 || strlen(argv[3]) != 1) { fail("error\n"); } //Make sure there are exactly 4 args
    if(!isNum(argv[2]) || !isNum(argv[3])) { fail("error\n"); } //Make sure the last 2 args are one digit numbers
    int val1 = atoi(argv[2]); //Find their values
    int val2 = atoi(argv[3]);
    if(val1 > 4 || val1 < 0){ fail("error\n"); } //If they're greater than 5 or less than 0, they aren't valid.
    if(val2 > 4 || val2 < 0){ fail("error\n"); }

    //Since the "move" command string takes up so little space in the buffer, set the two small numbers at the very end of the buffer for the server to grab.
    buffer[MESSAGE_LIMIT - 2] = (char)atoi(argv[2]);
    buffer[MESSAGE_LIMIT - 1] = (char)atoi(argv[3]);
  }

  mq_send(serverQueue, buffer, sizeof(buffer), 0);//Send the buffer

  mq_receive(clientQueue, buffer, sizeof(buffer), NULL);//Recieve the server's response
  if(strcmp(buffer, "error") == 0) { fail("error\n"); }//If the server throws an error, exit unsuccessfully
  printf("%s\n\n", buffer); //Otherwise, print whatever the buffer sent, it could be the state of the board.
  
  //Close the connects to the queues
  mq_close(serverQueue);
  mq_close(clientQueue);
    return EXIT_SUCCESS;
}