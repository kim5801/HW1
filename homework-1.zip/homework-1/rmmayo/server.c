#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

char grid[GRID_SIZE + 2][GRID_SIZE + 2];//a 5 by 5 grid surrounded by padding characters
char prevGrid[GRID_SIZE + 2][GRID_SIZE + 2];//a grid to serve as the previous state of the main grid.

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * Print out the final state of the board when ^C is signalled.
 * 
 * @param sig 
 */
void alarmHandler(int sig) {
  putchar('\n');

  for(int i = 1; i < GRID_SIZE + 1; i++) {
    for(int j = 1; j < GRID_SIZE + 1; j++) {
      putchar(grid[i][j]);
    }
    putchar('\n');
  }
  exit(0);
}


// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main( int argc, char *argv[] ) {

  if(argc != 2) {
    fail("usage: server <board-file>\n");
  }
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Repeatedly read and process client messages.

  FILE* fp = fopen(argv[1], "r");//open the specified file.
  if(fp == NULL) {
    perror("Error: ");
  }

  //Fill the main grid with '.' characters for the sake of the boarder padding.
  for(int i = 0; i < GRID_SIZE+2; i++) {
    for(int j = 0; j < GRID_SIZE + 2; j++) {
      grid[i][j] = '.';
    }
  }

  //Read the contents of the file, making sure only to store '.' and '*'.
  char c = 0;
  for(int i = 1; i < 6; i++){
    for(int j = 1; j < 6; j++){
      c = fgetc(fp);
      if(!(c == '.' || c == '*' || c == '\n')) {fail("usage: server <board-file>\n");}
      grid[i][j] = c;
    }
    c = fgetc(fp);
  }

  
  fclose(fp);//Close the file
  
  bool undo = false;//Flag to mark if the undo command is available to use.

  char buffer[MESSAGE_LIMIT];//Buffer to send back and forth between client and server.
   while ( running ) {
    
    //signal handling starts
    struct sigaction act;
    act.sa_handler = alarmHandler;
    sigemptyset( &( act.sa_mask ) );
    act.sa_flags = 0;
    sigaction( SIGINT, &act, 0 );
    //Signal handling ends
    // ...
    ssize_t b = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);//Recieve a message from client

    if(strcmp(buffer, "move") == 0) {//If the command was move, perform the process.
      int row = buffer[MESSAGE_LIMIT - 2] + 1;
      int col = buffer[MESSAGE_LIMIT - 1] + 1;
      


      memmove(prevGrid, grid, sizeof(grid));
      undo = true;//undo is allowed
      
      if(grid[row][col] == '.') {
        grid[row][col] = '*';
      }

      else {
        grid[row][col] = '.';
      }

      if(grid[row-1][col] == '.') {
        grid[row-1][col] = '*';
      }
      else {
        grid[row-1][col] = '.';
      }

      if(grid[row+1][col] == '.') {
        grid[row+1][col] = '*';
      }
      else {
        grid[row+1][col] = '.';
      }
      
      if(grid[row][col-1] == '.') {
        grid[row][col-1] = '*';
      }
      else {
        grid[row][col-1] = '.';
      }

      if(grid[row][col+1] == '.') {
        grid[row][col+1] = '*';
      }
      else {
        grid[row][col+1] = '.';
      }
      
      //Tell the client that move was successful
      char response[] = "success";
      strcpy(buffer, response);
      mq_send(clientQueue, buffer, sizeof(buffer), 0);
      //Move operation ends
    }

    else if(b != -1 && strcmp(buffer, "report") == 0) {//Perform report command. Fill the buffer with the contents of the board, including newlines, to be printed by the client.
      
      int k = 0;
      for(int i = 1; i < GRID_SIZE + 1; i++) {
        for(int j = 1; j < GRID_SIZE + 1; j++) {
          buffer[k++] = grid[i][j];
        }
        buffer[k++] = '\n';
      }
      buffer[k] = '\0';


      
      mq_send(clientQueue, buffer, sizeof(buffer), 0);//Send the buffer
      //Report ends here.
    }

    else if(b != -1 && strcmp(buffer, "undo") == 0) {//Undo command starts here. If the undo flag is false, the client recieves an error, otherwise the operation is performed.
      if(!undo) {
      char response[] = "error";//Undo is not available, send the client an error
      strcpy(buffer, response);
      mq_send(clientQueue, buffer, sizeof(buffer), 0);
      }
      else{
        undo = false;
        memmove(grid, prevGrid, sizeof(grid));

        char response[] = "success";//Send the client a success message
        strcpy(buffer, response);
        mq_send(clientQueue, buffer, sizeof(buffer), 0);
      }
    }

    else{//The recieved command was invalid, send the client an error.
      char response[] = "error";
      strcpy(buffer, response);
      mq_send(clientQueue, buffer, sizeof(buffer), 0);
    }


   }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
