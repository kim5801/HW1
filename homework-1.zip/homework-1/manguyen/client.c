#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// static int running = 1;
char board[GRID_SIZE * GRID_SIZE + GRID_SIZE];

int main(int argc, char *argv[]) {
    // Open the message queue for talking to the receiver.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 ) {
        fail( "Can't create the needed message queues" );
    }
    
    char buffer[MESSAGE_LIMIT + 1];

    //check move
    if (argc == 4) {
        if (strcmp(argv[1], "move") == 0) { //check to make sure 2nd arg says "move"
            int r;
            int c;
            //scan in coordinates and check if properly scanned
            if (sscanf(argv[2], "%d", &r) != 1 || sscanf(argv[3], "%d", &c) != 1 ) {
                fail("error: coordinates need to be integers");
            }

            //then check if coordinates fall in between 0 &  4, inclusive
            if (r < 0 || r > 4 || c < 0 || c > 4) {
                fail("error: coordinates need to be in between 0 and 4");
            }

            //checked everything ready to make the move
            strcpy(buffer, argv[1]);
            strcat(buffer, argv[2]);
            strcat(buffer, argv[3]);
            //send the buffer
            mq_send(serverQueue, buffer, MESSAGE_LIMIT, 0);
        } else {
            fail("error: arg needs to be move");
        }
    } 
    
    //check undo/report
    else if (argc == 2) {
        if (strcmp(argv[1], "report") == 0) {
            strcpy(buffer, argv[1]);
            //send the buffer
            mq_send(serverQueue, buffer, MESSAGE_LIMIT, 0);

            mq_receive(clientQueue, board, MESSAGE_LIMIT, NULL);
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    putchar(board[i * GRID_SIZE + j]);
                }
                putchar('\n');
            }
        } else if (strcmp(argv[1], "undo") == 0) {
            char result[8];
            strcpy(buffer, argv[1]);
            //send the buffer
            mq_send(serverQueue, buffer, MESSAGE_LIMIT, 0);
            


            //receive the undo result
            mq_receive(clientQueue, result, MESSAGE_LIMIT, NULL);
            printf("%s\n", result);
        } else {
            fail("error: arg needs to be undo or report");
        }
    } else {
        fail("error: need 2 or 4 args\n");
    }

    mq_close( clientQueue );
    mq_close( serverQueue );

    exit(0);
}