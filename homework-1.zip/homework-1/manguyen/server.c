#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

//global
char board[GRID_SIZE * GRID_SIZE + GRID_SIZE];
char prev[GRID_SIZE * GRID_SIZE + GRID_SIZE];
static bool canUndo = false;

//helper method for moving current board to previous
void boardtoPrev() {
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            prev[i * GRID_SIZE + j] = board[i * GRID_SIZE + j];
        }
    }
}

//for handling move
void move(int r, int c) {
    //move current to previous before changing anything
    boardtoPrev();

    int idx = r * GRID_SIZE + c;
    
    board[idx] = (board[idx] == '.') ? '*' : '.';

    //check above
    if (idx - 5 >= 0) {
      board[idx - 5] = (board[idx - 5] == '.') ? '*' : '.';
    }
    //check below
    if (idx + 5 < 30) {
      board[idx + 5] = (board[idx + 5] == '.') ? '*' : '.';
    }
    //check left
    if (idx - 1 >= 0) {
      board[idx - 1] = (board[idx - 1] == '.') ? '*' : '.';
    }

    //check right
    if (idx + 1 < 30) {
      board[idx + 1] = (board[idx + 1] == '.') ? '*' : '.';
    }
}

const char* undoMove() {
  //if you can you can...
  if (!canUndo) {
    return "error";
  }

  //move prev board to current
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      board[i * GRID_SIZE + j] = prev[i * GRID_SIZE + j];
    }
  }

  return "success";
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

static void usage() {
  fprintf( stderr, "usage: server <board-file>\n");
  exit( 1 );
}

static void invalidFile( char const *filename ) {
  fprintf( stderr, "Invalid input file: %s\n", filename );
  exit( 1 );
}

void sigHandler(int sig) {
  
  //put newline, then print board, then set running to 0 
  //to exit the loop and close program appropriately
  putchar('\n');
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      putchar(board[i * GRID_SIZE + j]);
    }
    putchar('\n');
  }

  //need to exit the while loop
  running = 0;
}


int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 ) {
    fail( "Can't create the needed message queues" );
  }

  //need only 2 args
  if (argc != 2) {
    usage();
  }

  //open file and check if valid
  FILE *fp;
  if ( ( fp = fopen( argv[1], "r" ) ) == NULL ) {
    invalidFile(argv[1]);
  }

  char ch;
  // char end;
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE + 1; j++) {
      ch = fgetc(fp);

      //check if file has bad characters
      if (ch != '*' && ch != '.' && ch != '\n') {
        invalidFile(argv[1]);
      }

      //after ch goes through the gauntlet, it can now assign to array
      board[i * GRID_SIZE + j] = ch;
      prev[i * GRID_SIZE + j] = ch;
    }
  }
  

  struct sigaction act;

  // Fill in a structure to redirect the alarm signal.
  act.sa_handler = sigHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Repeatedly read and process client messages.
  while ( running ) {
    //receive the buffer
    char buffer[MESSAGE_LIMIT + 1];
    
    mq_receive(serverQueue, buffer, MESSAGE_LIMIT, NULL);
    
    //check if string contains move
    if (strstr(buffer, "move") != NULL) {
      move(buffer[4] - '0', buffer[5] - '0');
      canUndo = true;
    }

    else if (strstr(buffer, "undo") != NULL) {
      const char* result = undoMove();
      //send the result
      mq_send(clientQueue, result, MESSAGE_LIMIT, 0);
      canUndo = false;
    }

    else if (strstr(buffer, "report") != NULL) {
      mq_send(clientQueue, board, MESSAGE_LIMIT, 0);
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  fclose(fp);
  return 0;
}
