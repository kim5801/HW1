#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

extern int errno ;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
    // Open both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
    if ( serverQueue == -1 || clientQueue == -1 )
        fail( "Can't open the needed message queues" );

    //encrypts the argv into a string, null terminated
    char buffer[MESSAGE_LIMIT + 1];
    buffer[MESSAGE_LIMIT] = '\0';
    int count = 0;
    for(int i = 1; i < argc; i++){
        for(int j = 0; j < strlen(argv[i]); j++){
            if(count > MESSAGE_LIMIT){
                //do nothing
            }
            else{
                buffer[count] = argv[i][j];
                count++;
            }
        }
        buffer[count] = ' ';
        count++;
    }
    buffer[count] = '\0';
    //sends string to server
    mq_send(serverQueue, buffer, strlen(buffer), 0);
    //receive response
    char bufferReceiver[MESSAGE_LIMIT + 1];
    int len = mq_receive(clientQueue, bufferReceiver, sizeof(bufferReceiver), NULL);
    if(len >= 0){
        //gets the first word
        char temp[BUFFER_LIMIT];
        int scanResult = sscanf(bufferReceiver, "%s", temp);
        if(scanResult != 1){
            fail("Client msg receive too long fail.");
        }
        if(strcmp(temp, "success") == 0 && len == sizeof("success")){
            fprintf(stdout, "success\n");
        }
        else if(strcmp(temp, "error") == 0 && len == sizeof("error")){
            fprintf(stdout, "error\n");
        }
        else{
            int counter = 0;
            for(int i = 0; i < GRID_SIZE * GRID_SIZE; i++){
                fprintf(stdout, "%c", temp[i]);
                counter++;
                if(counter % 5 == 0){
                    fprintf(stdout, "\n");
                }
            }
        }
    }
    else{
//        fprintf(stdout, "WOLF WOLF PART 5 \n");
//        fprintf(stderr, "WOLF Value of errno: %d\n", errno);
//        int errnum = errno;
//        fprintf(stderr, "WOLF Error opening file: %s\n", strerror( errnum ));
        fail("Client msg receive fail.");
    }
    return 0;
}
