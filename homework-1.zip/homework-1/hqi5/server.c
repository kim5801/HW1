#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

//signal handler
void ctrlcHandler( int sig ) {
    running = 0;
}
int main( int argc, char *argv[] ) {

    //Fail with usage message: not 2 arguments
    if(argc != 2){
        fail("usage: server <board-file>");
    }

    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    //initializing the board

    //variables, board, file, temp get c, and count
    int board[GRID_SIZE][GRID_SIZE];
    FILE *boardFile;
    char c;
    int count = 0;

    //open file to read using fopen
    boardFile = fopen(argv[1], "r");
    if(boardFile == NULL){
        fail("usage: server <board-file>");
    }
    //reads the text file onto the board, fails with error if bad input
    while(1){
        c = fgetc(boardFile);
        if(c == '*' || c == '.'){
            board[count / GRID_SIZE][count % GRID_SIZE] = c;
            count++;
        }
        else if(c == '\n' && count % GRID_SIZE == 0){
            continue;
        }
        else if(c == EOF && count == GRID_SIZE * GRID_SIZE){
            break;
        }
        else{
            fprintf( stderr, "Invalid input file: %s\n", argv[1] );
            exit( 1 );
        }
    }

    //signal to catch
    struct sigaction act;

    // Fill in a structure to redirect the ctrlc signal.
    act.sa_handler = ctrlcHandler;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;
    sigaction(SIGINT, &act, 0 );

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 ){
        fail( "Can't create the needed message queues" );
    }

    // Huge buffer for receiving
    char buffer[MESSAGE_LIMIT];

    //undo variables
    char ableToUndo = 'n';
    int lastMoveRow = GRID_SIZE + 1;
    int lastMoveColumn = GRID_SIZE + 1;

    // Repeatedly read and process client messages.
    while ( running ) {
        int len = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);
        if(len >= 0){
            //null terminates the next byte
            buffer[len] = '\0';

            //gets the first word
            char temp[BUFFER_LIMIT];
            int scanResult = sscanf(buffer, "%s", temp);

            //checks command if too long
            if(scanResult != 1){
                mq_send(clientQueue, "error\n", strlen("error\n"), 0);
            }
            //testing stuff
//            fprintf(stdout, "temp: %s\n", temp);
//            fprintf(stdout, "len: %d\n", len);
//            fprintf(stdout, "ableToUndo: %c\n", ableToUndo);
//            fprintf(stdout, "lmr: %c\n", lastMoveRow);
//            fprintf(stdout, "lmc: %c\n", lastMoveColumn);

            //checks bad input
            if(strcmp(temp, "report") == 0 && len == sizeof("report")){
                //prints the board
                char result[GRID_SIZE * GRID_SIZE + 1];
                int num = 0;
                for(int i = 0; i < GRID_SIZE; i++){
                    for(int j = 0; j < GRID_SIZE; j++){
                        result[num] = board[i][j];
                        num++;
                        //fprintf(stdout, "%c", board[i][j]);
                    }
                    //fprintf(stdout, "\n");
                }
                result[GRID_SIZE * GRID_SIZE] = '\0';
                mq_send(clientQueue, result, strlen(result), 0);
            }
            else if(strcmp(temp, "move") == 0 && len == MOVE_MAX_LEN
                && buffer[MOVE_MAX_LEN] == '\0'){

                //assign row and col to variables
                char rowS= buffer[MOVE_ROW_INDEX];
                char columnS = buffer[MOVE_COL_INDEX];

                //checks row col for validity
                if(rowS >= '0' && rowS <= '4' && columnS >= '0' && columnS <= '4'){
                    //converts row and column into integers

                    int row = rowS - '0';
                    int column = columnS - '0';

                    //flips middle
                    if(board[row][column] == '*'){
                        board[row][column] = '.';
                    }
                    else{
                        board[row][column] = '*';
                    }

                    //flips top
                    if(row - 1 >= 0){
                        if(board[row - 1][column] == '*'){
                            board[row - 1][column] = '.';
                        }
                        else{
                            board[row - 1][column] = '*';
                        }
                    }
                    //flips left
                    if(column - 1 >= 0){
                        if(board[row][column - 1] == '*'){
                            board[row][column - 1] = '.';
                        }
                        else{
                            board[row][column - 1] = '*';
                        }
                    }
                    //flips bottom
                    if(row + 1 <= 4){
                        if(board[row + 1][column] == '*'){
                            board[row + 1][column] = '.';
                        }
                        else{
                            board[row + 1][column] = '*';
                        }
                    }
                    //flips right
                    if(column + 1 <= 4){
                        if(board[row][column + 1] == '*'){
                            board[row][column + 1] = '.';
                        }
                        else{
                            board[row][column + 1] = '*';
                        }
                    }
//                    for(int i = row - 1; i <= row + 1; i++){
//                        for(int j = column - 1; j <= column + 1; j++){
//                            if(i < 0 || i > GRID_SIZE || j < 0 || j > GRID_SIZE){
//                                //do nothing
//                            }
//                            else{
//                                if(board[i][j] == '*'){
//                                    board[i][j] = '.';
//                                }
//                                else{
//                                    board[i][j] = '*';
//                                }
//                            }
//                        }
//
//                    }
                    // enables undo after a move
                    if(ableToUndo == 'n'){
                        ableToUndo = 'y';
                    }
                    lastMoveRow = row;
                    lastMoveColumn = column;
                    mq_send(clientQueue, "success\n", strlen("success\n"), 0);
                }
                else{
                    mq_send(clientQueue, "error\n", strlen("error\n"), 0);
                }

            }
            //undo part
            else if(strcmp(temp, "undo") == 0 && len == sizeof("undo")){
                //checks conditions for undo
                if(ableToUndo == 'y'){
                    ableToUndo = 'n';
                    //does an undo by moving the row/col from last move

                    //flips middle
                    if(board[lastMoveRow][lastMoveColumn] == '*'){
                        board[lastMoveRow][lastMoveColumn] = '.';
                    }
                    else{
                        board[lastMoveRow][lastMoveColumn] = '*';
                    }

                    //flips top
                    if(lastMoveRow - 1 >= 0){
                        if(board[lastMoveRow - 1][lastMoveColumn] == '*'){
                            board[lastMoveRow - 1][lastMoveColumn] = '.';
                        }
                        else{
                            board[lastMoveRow - 1][lastMoveColumn] = '*';
                        }
                    }
                    //flips left
                    if(lastMoveColumn - 1 >= 0){
                        if(board[lastMoveRow][lastMoveColumn - 1] == '*'){
                            board[lastMoveRow][lastMoveColumn - 1] = '.';
                        }
                        else{
                            board[lastMoveRow][lastMoveColumn - 1] = '*';
                        }
                    }
                    //flips bottom
                    if(lastMoveRow + 1 <= 4){
                        if(board[lastMoveRow + 1][lastMoveColumn] == '*'){
                            board[lastMoveRow + 1][lastMoveColumn] = '.';
                        }
                        else{
                            board[lastMoveRow + 1][lastMoveColumn] = '*';
                        }
                    }
                    //flips right
                    if(lastMoveColumn + 1 <= 4){
                        if(board[lastMoveRow][lastMoveColumn + 1] == '*'){
                            board[lastMoveRow][lastMoveColumn + 1] = '.';
                        }
                        else{
                            board[lastMoveRow][lastMoveColumn + 1] = '*';
                        }
                    }
                    lastMoveRow = GRID_SIZE + 1;
                    lastMoveColumn = GRID_SIZE + 1;
                    mq_send(clientQueue, "success\n", strlen("success\n"), 0);
                }
                else{
                    mq_send(clientQueue, "error\n", strlen("error\n"), 0);
                }
            }
            else{
                mq_send(clientQueue, "error\n", strlen("error\n"), 0);
            }
        }
        else{
            if( !running ){
                break;
            }
            fail("Server msg receive fail.");
        }
    }
    fprintf(stdout, "\n");
    for(int i = 0; i < GRID_SIZE; i++){
        for(int j = 0; j < GRID_SIZE; j++){
            fprintf(stdout, "%c", board[i][j]);
        }
        fprintf(stdout, "\n");
    }

    // Close our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );

    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

  return 0;
}
