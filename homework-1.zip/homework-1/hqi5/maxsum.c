#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

    readList();

    // You get to add the rest.

    //max number
    int parentSum = 0;
    //pipe
    int pipe1[2];
    if(pipe(pipe1) == -1){
        fail("cannot create pipe");
    }

    //the length of the worker's work
    int arrayDivide = vCount / workers;
    //creates n workers and do work
    for(int j = 0; j < workers; j++){
        //creates child
        pid_t pid = fork();
        int totalSum = 0;
        if(pid == -1){
            fail("cannot create child");
        }

        //checks for child
        if(pid == 0){
            close(pipe1[0]);

            //last worker might have less work load, different code so it does
            //not segfault, splits work for workers and have them do the sums
            if(j == workers - 1){
                for(int k = j * arrayDivide; k < vCount; k++){
                    int index = k;
                    int localSum = 0;
                    while(index < vCount){
                        localSum += vList[index];
                        if(localSum > totalSum){
                            totalSum = localSum;
                        }
                        index++;
                    }
                }
            }
            //otherwise its normal work load
            else{
                for(int k = j * arrayDivide; k < (j + 1) * arrayDivide; k++){
                    int index = k;
                    int localSum = 0;
                    while(index < vCount){
                        localSum += vList[index];
                        if(localSum > totalSum){
                            totalSum = localSum;
                        }
                        index++;
                    }
                }
            }

            //sends stuff to parent
            lockf( pipe1, F_LOCK, 0 );
            if(write(pipe1[1], &totalSum, sizeof(totalSum)) != sizeof(totalSum)){
                fail("cant write");
            }
            lockf( pipe1, F_ULOCK, 0 );
            close(pipe1[1]);
            exit(0);
        }
    //waits for the n amount of workers to finish
    }
    pid_t child;
    while((child = wait(NULL)) != -1)
    {
        //read what worker sent
        int sumRead;
        if (read(pipe1[0], &sumRead, sizeof(sumRead)) != sizeof(sumRead))
        {
            fail("cant read");
        }
        //report processes
        if(report){
            printf("I'm process %d. The maximum sum I found is %d.\n", child, sumRead);
        }
        if(sumRead > parentSum){
            parentSum = sumRead;
        }
    }
    printf("Maximum Sum: %d.\n", parentSum);
//    for(int j = 0; j < workers; j++){
//        wait(NULL);
//        close(pipe1[1]);
//        int temp = 0;
//        if(read(pipe1[0], temp, sizeof(temp)) != sizeof(temp)){
//            fprintf(stderr, "%d meow %d \n", parentSum, temp);
//            fail("cant read");
//        }
//        if(temp > parentSum){
//            parentSum = temp;
//        }
//    }
//    close(pipe1[0]);
//    close(pipe1[1]);
  return 0;
}
