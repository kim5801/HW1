// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/hqi5-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/hqi5-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// small buffer definition
#define BUFFER_LIMIT 26

// max length of move command
#define MOVE_MAX_LEN 9

// max index of row
#define MOVE_ROW_INDEX 5

// max index of column
#define MOVE_COL_INDEX 7

// Height and width of the playing area.
#define GRID_SIZE 5
