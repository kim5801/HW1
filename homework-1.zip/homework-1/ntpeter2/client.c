/*
 * Sends various commands to the server to operate on
 * the current board state, can report the board, make
 * a move and undo the previous move operation
 * @author Nolan Peters (ntpeter2)
 * @file client.c
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// prints out an error message
static void printError() {
    fprintf(stderr, "error\n");
    exit(1);
}


/**
 * operates the client, allowing for several
 * commands to be sent to the server including
 * report, move and undo
 */
int main( int argc, char *argv[] ) {
    if (argc < 2 || argc > 4) {
        printError();
    }
    
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;
  
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY, 0600, &attr );
    
    char buffer[MESSAGE_LIMIT];
    for (int i = 0; i < MESSAGE_LIMIT; i++) {
            buffer[i] = '\0';
        }
    
    if (strcmp(argv[1], "report") == 0) {
        //report the state of the board (obtained from server)
        char reportVar[] = "report";
        
        
        mq_send(serverQueue, reportVar, strlen(reportVar), 0);
        mq_receive(clientQueue, buffer, sizeof buffer, 0);
        for (int i = 1; i < 26; i++) {
            printf("%c", buffer[i - 1]);
            if (i % GRID_SIZE == 0) {
                printf("\n");
            }
        }
    }
    
    else if (strcmp(argv[1], "move") == 0) {
        int row = argv[2][0] - '0';
        int column = argv[3][0] - '0';
        if ((row > 4 || row < 0) || (column > 4 || column < 0)) {
            printError();
        }
        char moveLoc[3];
        moveLoc[0] = 'M';
        moveLoc[1] = row + '0';
        moveLoc[2] = column + '0';
        mq_send(serverQueue, moveLoc, strlen(moveLoc), 0);
        mq_receive(clientQueue, buffer, sizeof buffer, 0);
        printf("%s\n", buffer);
    }
    
     else if (strcmp(argv[1], "undo") == 0) {
        char undo[1] = "U";
        mq_send(serverQueue, undo, strlen(undo), 0);
        mq_receive(clientQueue, buffer, sizeof buffer, 0);
        printf("%s\n", buffer);
    } else { printError(); }
    exit(0);
}