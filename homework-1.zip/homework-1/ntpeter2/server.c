/*
 * stores board state and allows for various operations as
 * given by the client
 * @author Nolan Peters (ntpeter2)
 * @file server.c
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>



// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/** 
 *prints out the current game board
 *@param gameBoard array
 */
static void printBoard(char gameBoard[GRID_SIZE][GRID_SIZE]) {
    for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
          printf("%c", gameBoard[i][j]);
      }
      printf("\n");
    }
}

/**
 * runs upon ctrl c, tells server to stop running
 * @param int dummy var
 */
static void sigHandler(int id) {
    running = 0;
}

/**
 * create a gameboard from the given input file fp
 * @param fp input file
 * @param gameBoard array to be filled
 * @param filename name of file fp points to
 */
static void createBoard(FILE *fp, char gameBoard[GRID_SIZE][GRID_SIZE], char *fileName) {
    for (int i = 0; i < GRID_SIZE; i++) {
      for (int j = 0; j < GRID_SIZE; j++) {
          char ch = fgetc(fp);
          gameBoard[i][j] = ch;
          if (gameBoard[i][j] != '*' && gameBoard[i][j] != '.') {
              fprintf(stderr, "Invalid input file: %s\n", fileName);
              exit( 1 );
          }
      }
      fgetc(fp); //newline char
    }
}

/** 
 * performs a move operation on the gameboard indicated by row/column
 * @param gameBoard board to be operated on
 * @param row row of move location
 * @param column column of move location
 */
static void move(char gameBoard[GRID_SIZE][GRID_SIZE], int row, int column) {
    if (gameBoard[row][column] == '.') {
        gameBoard[row][column] = '*';
    } else { gameBoard[row][column] = '.';
    }
    
    if (row - 1 >= 0) {
        if (gameBoard[row - 1][column] == '.') {
            gameBoard[row - 1][column] = '*';
        } else { gameBoard[row - 1][column] = '.';
        }
    }
    
    if (row + 1 < GRID_SIZE) {
        if (gameBoard[row + 1][column] == '.') {
            gameBoard[row + 1][column] = '*';
        } else { gameBoard[row + 1][column] = '.';
        }
    }
    
    if (column - 1 >= 0 ) {
        if (gameBoard[row][column - 1] == '.') {
            gameBoard[row][column - 1] = '*';
        } else { gameBoard[row][column - 1] = '.';
        }
    }
    
    if (column + 1 < GRID_SIZE ) {
        if (gameBoard[row][column + 1] == '.') {
            gameBoard[row][column + 1] = '*';
        } else { gameBoard[row][column + 1] = '.';
        }
    }
}


/**
 * stores a lights-out gameboard and computes various operations from the client side
 */
int main( int argc, char *argv[] ) {

    if (argc != 2) {
        fail("usage: server <board-file>");
    }
  
    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 )
      fail( "Can't create the needed message queues" );


 
    FILE *fp = fopen(argv[1], "r");
  
    if (fp == NULL) {
        fail( "Cannot locate file");
    }
  
    char gameBoard[GRID_SIZE][GRID_SIZE];
  
    createBoard(fp, gameBoard, argv[1]);
  
    struct sigaction act;
      act.sa_handler = sigHandler;
      sigemptyset( &( act.sa_mask ) );
      act.sa_flags = 0;
      
    sigaction( SIGINT, &act, 0 );
    
  
    int tempRow;
    int tempColumn;
  
    bool undoReady = false;
    // Repeatedly read and process client messages.
    while ( running ) {
 
        // Receiving buffer
        char buffer[MESSAGE_LIMIT];
    
        for (int i = 0; i < MESSAGE_LIMIT; i++) {
            buffer[i] = '\0';
        }
    
        // Wait to receive message from client
        mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );
    
        // Client sends report to indicate a report
        if (strcmp(buffer, "report") == 0) {
            char boardString[GRID_SIZE * GRID_SIZE];
            int idx = 0;
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    boardString[idx++] = gameBoard[i][j];
                }
            }
            //send string representation of board to client to report
            mq_send(clientQueue, boardString, strlen(boardString), 0);
        }
    
        // Client sends M to indicate a move, the next two chars in the buffer should be the number of the row and column
        if (buffer[0] == 'M') {
            int row = buffer[1] - '0';
            int column = buffer[2] - '0';
            move(gameBoard, row, column);
            tempRow = row;
            tempColumn = column;
            undoReady = true;
            char success[7] = "success";
            mq_send(clientQueue, success, strlen(success), 0);
        }
    
        // Client sends U to indicate an undo operation
        if (buffer[0] == 'U') {
            if (!undoReady) {
                char error[GRID_SIZE] = "error";
                mq_send(clientQueue, error, strlen(error), 0);
                continue;
            }
            move(gameBoard, tempRow, tempColumn);
            undoReady = false;
            char success[7] = "success";
            mq_send(clientQueue, success, strlen(success), 0);
        }
    }
    printf("\n");
    printBoard(gameBoard);
    // Close our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );

    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    fclose(fp);
  
    return 0;
}
