#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

/** the initial list capacity for ints */
#define INIT_LIST_CAP 5

/** the default number of workers */
#define DEFAULT_WORKER_NUM 4

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( EXIT_FAILURE );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = INIT_LIST_CAP;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
 * The function a process will run to find a maximum sum within its number of ranges
 * 
 * @param numProcesses the number of processes among which work is delegated
 * @param processId an identification number for the process in the range 0 to numProcesses - 1
 * @return int the maximum sum found by the process
 */
int computeProcessMax(int numProcesses, int processId) {
  //note that the spacing between ranges for which a process computes
  //a sum should be equal to the number of processes
  int maxSum = 0;
  for (int i = processId; i < vCount; i += numProcesses) {
    int currSum = 0;
    //compute sums that start at index i
    for (int j = i; j < vCount; j++) {
      currSum += vList[j];
      if (currSum > maxSum) {
        maxSum = currSum;
      }
    }
  }
  return maxSum;

}

/**
 * Starts the maxsum program, which reads a list of integers and reports the
 * maximum sum from a range of consecutive integers
 * 
 * @param argc the number of command line arguments provided
 * @param argv the command line arguments
 * @return the exit status of the program
 */
int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = DEFAULT_WORKER_NUM;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

  //create a pipe
  int pfd[2];
  if (pipe(pfd) != 0) {
    //pipe can't be created, exit unsuccessfully
    fail("can't create pipe");
  }

  //set an initial value for maxSum
  int maxSum = vList[0];
  
  //create processes
  for (int i = 0; i < workers; i++) {
    pid_t newProcess = fork();
    if (newProcess == 0) {
      //close the reading end of the pipe
      close(pfd[0]);

      //get a maximum for this process
      int procMax = computeProcessMax(workers, i);

      //lock the pipe, write the procMax to the pipe, and unlock the pipe
      lockf(pfd[1], F_LOCK, 0);
      write(pfd[1], &procMax, sizeof(procMax));
      lockf(pfd[1], F_ULOCK, 0);
      if (report) {
        int id = getpid();
        printf("I'm process %d. The maximum sum I found is %d.\n", id, procMax);
      }
      exit(EXIT_SUCCESS);
    }
  }
  //close the writing end of the pipe in the parent
  close(pfd[1]);

  //wait for processes to finish
  for (int i = 0; i < workers; i++) {
    wait(NULL);
    int current;
    //read from the pipe
    read(pfd[0], &current, sizeof(current));
    if (current > maxSum) {
      maxSum = current;
    }
  }
  printf("Maximum Sum: %d\n", maxSum);

  free(vList);

  return EXIT_SUCCESS;
}
