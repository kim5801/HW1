/**
 * @file server.c
 * @author Adam McIntosh
 * @author Dr. Sturgill
 * @brief A file for functionality relating to a server that interacts with a client and stores board information,
 * making changes to the board when necessary
 * 
 */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

//print out an error message and exit
static void fail( char const *message );

typedef struct {

  /** the game baord as a 2d array of chars */
  char boardArr[GRID_SIZE][GRID_SIZE];

  /** last move is just the location of the last move, with a bucket for each coordinate */
  int lastMove[2];
} Board;

/**
 * Retrieves a string representation of a board
 * 
 * @param board the board for which a string representation is desired
 * @return char* the string representation of the board
 */
char* getBoardString(Board* board) {
  //room for GRID_SIZE rows of GRID_SIZE length, each with a newline. One null terminator at the end
  char* boardString = (char*) malloc(GRID_SIZE * GRID_SIZE + GRID_SIZE + 1);
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      boardString[i * (GRID_SIZE + 1) + j] = board->boardArr[i][j];
    }
    boardString[i * (GRID_SIZE + 1) + GRID_SIZE] = '\n';
  }
  boardString[GRID_SIZE * GRID_SIZE + GRID_SIZE] = '\0';
  return boardString;
}

/**
 * Changes the status of a light at a coordinate
 * 
 * @param board the board whose light will be toggled
 * @param row the row number of the light
 * @param col the col numher of the light
 */
void toggleTile(Board* board, int row, int col) {
  //if a tile is off of the board, we will do nothing
  if (row < 0 || row > GRID_SIZE - 1) {
    return;
  }
  if (col < 0 || col > GRID_SIZE - 1) {
    return;
  }
  if (board->boardArr[row][col] == '*') {
    board->boardArr[row][col] = '.';
  }
  else {
    board->boardArr[row][col] = '*';
  }
}

/**
 * Makes a move, switching all adjacent lights, on a board
 * 
 * @param board the board on which the move is made
 * @param row the row coordinate of the move
 * @param col the col coordinate of the move
 */
void makeMove(Board* board, int row, int col) {
  //toggle at this coordinate
  toggleTile(board, row, col);
  //toggle the tile above this one
  toggleTile(board, row - 1, col);
  //toggle the tile below this one
  toggleTile(board, row + 1, col);
  //toggle the tile to the right of this one
  toggleTile(board, row, col + 1);
  //toggle the tile to the left of this one
  toggleTile(board, row, col - 1);
}

/**
 * Takes an input message and breaks it up into individual words based on spaces. 
 * The message is null terminated.
 * SOURCE INFO: this code is based on code I wrote for parseCommand() in the first homework
 * 
 * @param line the input command 
 * @param words an array of pointers to the words that are read in 
 * @return int the number of words read in 
 */
int parseInput(char* message, char* words[]) {
    int index = 0;
    int wordCount = 0;
    //traverse until we hit the end of the message
    while(message[index] != '\0') {
        while (isspace(message[index])) {
            index++;

            //we may have just pushed ourself to the very end of the line
            if (message[index] == '\0') {
                return wordCount;
            }
        }
        int wordLen = 0;
        while(!isspace(message[index + wordLen]) && message[index + wordLen] != '\0') {
            wordLen++;
        }
        char* word = (char*)malloc(wordLen + 1);
        for (int i = 0; i < wordLen; i++) {
            word[i] = message[index + i];
        }
        word[wordLen] = '\0'; 
        index += wordLen;
        words[wordCount] = word;
        wordCount++;
    }
    return wordCount;
}

/**
 * Parses a board file, storing its contents in a Board struct
 * 
 * @param filename the name of the input file
 * @param board a pointer to the struct to be filled in
 */
void parseInputFile(char* filename, Board* board) {
  FILE* boardFile = fopen(filename, "r");
  if (boardFile == NULL) {
    char beginning[] = "Invalid input file: ";
    char* failMessage = strcat(beginning, filename);
    fail(failMessage);
  }
  char buffer[(GRID_SIZE + 1) * GRID_SIZE + 1];
  int bytesRead = fread(buffer, 1, ((GRID_SIZE + 1) * GRID_SIZE + 1), boardFile);
  if (bytesRead < (GRID_SIZE + 1) * GRID_SIZE) {
    char beginning[] = "Invalid input file: ";
    char* failMessage = strcat(beginning, filename);
    fail(failMessage);
  }
  //generate each row of our board
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      if (buffer[i * (GRID_SIZE + 1) + j] != '*' && buffer[i * (GRID_SIZE + 1) + j] != '.') {
        char beginning[] = "Invalid input file: ";
        char* failMessage = strcat(beginning, filename);
        fail(failMessage);
      }
      board->boardArr[i][j] = buffer[i * (GRID_SIZE + 1) + j];
    }
    //make sure there is a newline at every GRID_SIZE + 1th character
    if (buffer[i * (GRID_SIZE + 1) + GRID_SIZE] != '\n') {
      char beginning[] = "Invalid input file: ";
      char* failMessage = strcat(beginning, filename);
      fail(failMessage);
    }
  }
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

Board* ourBoard;

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

static void sigintHandler(int sig) {
  running = 0;
}

int main( int argc, char *argv[] ) {

  //SOURCE INFO: these 5 lines are based on Dr. Sturgill's processes slides
  struct sigaction act;
  act.sa_handler = &sigintHandler;
  sigemptyset(&(act.sa_mask));
  act.sa_flags = 0;
  sigaction(SIGINT, &act, NULL);

  if (argc != 2) {
    fail("usage: server <board-file>");
  }
  Board* ourBoard = (Board*) malloc(sizeof(Board));

  parseInputFile(argv[1], ourBoard);
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Repeatedly read and process client messages.
  while ( running ) {
    char messageFromClient[MESSAGE_LIMIT + 1];
    //we will never have more tham MESSAGE_LIMIT words
    char* words[MESSAGE_LIMIT];

    //receive a message from the client
    int len = mq_receive(serverQueue, messageFromClient, sizeof(messageFromClient), NULL);
    if (len == -1) {
      if (!running) {
        //if we have received SIGINT, it doesn't matter that we didn't receive anything
        break;
      }
      fail("Could not receive message from client.");
    }

    //null terminate the message we received
    messageFromClient[len] = '\0';
    int wordNum = parseInput(messageFromClient, words); 

    //we received a move command
    if (strcmp(words[0], "move") == 0) {
      //there should be 3 arguments after ./client
      if (wordNum != 3) {
        mq_send(clientQueue, "failure", strlen("failure"), 0);
      }
      int row = -1;
      int col = -1;
      int ret = sscanf(words[1], "%d", &row);
      int ret2 = sscanf(words[2], "%d", &col);
      int retSend = 0;
      if (ret == 0 || ret2 == 0) {
        retSend = mq_send(clientQueue, "error\n", strlen("error\n"), 0);
        if (retSend == -1) {
          fail("Could not send message to client.");
        }
      }
      if (row < 0 || row > 4 || col < 0 || col > 4) {
        retSend = mq_send(clientQueue, "error\n", strlen("error\n"), 0);
        if (retSend == -1) {
          fail("Could not send message to client.");
        }
      }
      else {
        makeMove(ourBoard, row, col);
        ourBoard->lastMove[0] = row;
        ourBoard->lastMove[1] = col;
        mq_send(clientQueue, "success\n", strlen("success\n"), 0);
        if (retSend == -1) {
          fail("Could not send message to client.");
        }
      }
    }
    //we received an undo command
    else if (strcmp(words[0], "undo") == 0) {
        int retSend = 0;
      if (wordNum != 1) {
        retSend = mq_send(clientQueue, "error\n", strlen("error\n"), 0);
        if (retSend == -1) {
          fail("Could not send message to client.");
        }
      }
      if (ourBoard->lastMove[0] == -1) {
        //there is not a move to undo
        retSend = mq_send(clientQueue, "error\n", sizeof("error\n"), 0);
        if (retSend == -1) {
          fail("Could not send message to client.");
        }
      }
      else {
        makeMove(ourBoard, ourBoard->lastMove[0], ourBoard->lastMove[1]);
        ourBoard->lastMove[0] = -1;
        ourBoard->lastMove[1] = -1;
        retSend = mq_send(clientQueue, "success\n", sizeof("success\n"), 0);
        if (retSend == -1) {
          fail("Could not send message to client.");
        }
      }
    } 
    //we received a report command
    else if (strcmp(words[0], "report") == 0) {
      int retSend = 0;
      if (wordNum != 1) {
        retSend = mq_send(clientQueue, "error\n", strlen("error\n"), 0);
        if (retSend == -1) {
          fail("Could not send message to client.");
        }
      }
      char* messageToClient = getBoardString(ourBoard);
      retSend = mq_send(clientQueue, messageToClient, strlen(messageToClient), 0);
      if (retSend == -1) {
        fail("Could not send message to client.");
      }
    }
    else {
      int retSend = 0;
      retSend = mq_send(clientQueue, "error\n", sizeof("error\n"), 0);
      if (retSend == -1) {
        fail("Could not send message to client.");
      }
    }
    for (int i = 0; i < wordNum; i++) {
        free(words[i]);
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  if (running == 0) {
    //print a report and free resources
    printf("\n");
    char* boardString = getBoardString(ourBoard);
    printf("%s", boardString);
    free(boardString);
  }

  return EXIT_SUCCESS;
}
