/**
 * @file client.c
 * @author Adam McIntosh
 * @brief A file for functionality relating to a client that interacts with a server and tells the server
 * what changes to make to the board based on user input
 * 
 */

#include "common.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** the number of arguments expected for the move command */
#define EXPECTED_ARGS_MOVE 4

/** the number of arguments expected for the report command */
#define EXPECTED_ARGS_REPORT 2

/** the number of arguments expected for the undo command */
#define EXPECTED_ARGS_UNDO 2

/**
 * Runs the client program
 * 
 * @param argc the number of command-line arguments given to the client
 * @param argv the command-line arguments given to the client
 * @return int the exit status of the program
 */
int main(int argc, char *argv[]) {
    if (argc == 1) {
        printf("error\n");
        exit(EXIT_FAILURE);
    }

    //error checking
    if (strcmp(argv[1], "move") == 0) {
        //there should be 3 arguments after ./client
        if (argc != EXPECTED_ARGS_MOVE) {
            printf("error\n");
            exit(EXIT_FAILURE);
        }
    }
    //we received an undo command
    else if (strcmp(argv[1], "undo") == 0) {
        if (argc != EXPECTED_ARGS_UNDO) {
            printf("error\n");
            exit(EXIT_FAILURE);
        }
    }
    //we received a report command
    else if (strcmp(argv[1], "report") == 0) {
        if (argc != EXPECTED_ARGS_REPORT) {
            printf("error\n");
            exit(EXIT_FAILURE);
        }
    }

    //we will smush the argv arguments together into one string to send to the server
    char messageToServer[MESSAGE_LIMIT + 1];
    int messageIndex = 0;
    for (int i = 1; i < argc; i++) {
        for (int j = 0; argv[i][j]; j++) {
            messageToServer[messageIndex++] = argv[i][j];
        }
        if (i != argc - 1) {
            messageToServer[messageIndex++] = ' ';
        }
    }
    messageToServer[messageIndex] = '\0';

    //open the server message queue and send a message
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY);
    if (serverQueue == -1) {
        printf("Could not create message queue.\n");
    }
    int retSend = mq_send(serverQueue, messageToServer, strlen(messageToServer), 0);
    if (retSend == -1) {
        printf("Could not receive message from server.\n");
        exit(EXIT_FAILURE);
    }

    //open the client message queue to receive a message from the server
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY);
    if (clientQueue == -1) {
        printf("Could not create message queue.\n");
    }
    char messageFromServer[MESSAGE_LIMIT + 1];
    int len = mq_receive(clientQueue, messageFromServer, sizeof(messageFromServer), NULL);
    if (len == -1) {
        printf("Could not receive message from server.\n");
        exit(EXIT_FAILURE);
    }
    messageFromServer[len] = '\0';
    printf("%s", messageFromServer);

    //close the message queue connections
    mq_close(serverQueue);
    mq_close(clientQueue);
}