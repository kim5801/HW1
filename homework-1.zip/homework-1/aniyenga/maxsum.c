#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

int global;

int inc;
// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.
  //creating pipe
  int pfd[2];
  //Creating pipe and making sure that it does not fail
  if(pipe(pfd) != 0){
    fail("Can't create pipe");
  }
  
  //making sum
  int sum = 0;
  pid_t pid;
  //int arr[workers];
  pid_t wpid;
  int status = 0;
  
  //printf("workers: %d", workers);
  //int count = 0;
  int max = 0; 
  for(int i = 0; i < workers; i++)	{
  	pid = fork();
  	if(pid == 0)	{
  		max = 0;
  		for(int j = inc; j < workers; j++) {
  			sum = vList[j];
  			for(int d = j + 1; d < vCount; d++) {
  				sum += vList[d];
  			}
  			if(max < sum) {
  				max = sum;
  			}
  		}
  		
// 			for(int d = i + 1; d < vCount; d++) {
// 				sum += vList[d];
// 			}
// 			if(max < sum) {
//   				max = sum;
//   			}
		
		//max = sum;
  		lockf(pfd[1], F_LOCK, 0);
  		close(pfd[0]);
  		write(pfd[1], &sum, sizeof(sum));
  		close(pfd[1]);
  		lockf(pfd[1], F_ULOCK, 0);
  		if(report) {
  			printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), sum);
  		}
  		  		//if command line arg wants to report values
  		//sum = max;
  		
  		// lockf( pfd[0], F_LOCK, 0 );
//   		close(pfd[0]);
//   		write(pfd[1], &sum, sizeof(sum));
//   		//printf("pipe %d", pfd[1]);
//   		lockf( pfd[0], F_ULOCK, 0 );
//   		
  		
  		//arr[i] = sum;
  		//count++;
  		// so that there are only a certain amount of children
  		//wait(NULL);
  		break;	
  	} else {
  		close(pfd[1]);
//   		for(int c = 0; c < workers; c++){
//   			wait(NULL);
//   		}
  		int y;
  		read(pfd[0], &y, sizeof(int));
  		close(pfd[0]);
  		//arr[i] = y;
  		global++;
  		inc++;	
  	}
  	
  	
  	
  }
  close(pfd[1]);
  close(pfd[0]);
  while(wait(NULL) > 0);
  while ((wpid = wait(&status)) > 0);
  
  if(max != 0 && (global == workers || global == (workers - 1))) {
  	printf("Maximum Sum: %d\n", max);
  }
  //printf("global %d", global);
  //int status;
  
//   int max = arr[0];
//   for(int i = 0; i < workers; i++) {
//   	if(max < arr[i]) {
//   		max = arr[i];
//   	}
//   }
	
  

  return 0;
}
