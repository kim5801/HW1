#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

struct Board {
  bool boardState[GRID_SIZE][GRID_SIZE];
  int lastMove[2];
};

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

bool makeMove( struct Board * board, unsigned char move );
void sendBoard( struct Board * board, mqd_t clientQueue );
void openBoard( struct Board * board, char * filename );
void sighandler(int signo);

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );
    
  struct sigaction act;
  act.sa_handler = &sighandler;
  sigemptyset( &act.sa_mask );
  act.sa_flags = 0;
  if( sigaction( SIGINT, &act, 0) == -1 ) {
    fail( "Couldn't set up sigaction" );
  }
    
  //Create and setup a board from a file
  struct Board board;
  //Make sure there is no previous move
  board.lastMove[0] = -1;
  board.lastMove[1] = -1;
  if( argc != 2 ) {
    printf( "usage: server <board-file>\n" );
    fail( "Bad syntax" );
  }
  openBoard( &board, argv[1] );
  
  char move[MESSAGE_LIMIT];

  // Repeatedly read and process client messages.
  while ( running ) {

    //Read a move from the clients()
    mq_receive( serverQueue, move, MESSAGE_LIMIT, NULL );
    //If its a report, send the boardstate
    if( move[0] & 0x01 ) {
      sendBoard( &board, clientQueue );
    }
    //If its not a report, make that move
    else if( makeMove( &board, move[0] ) ) {
      mq_send( clientQueue, "success", 8, 1 );
    }
    else {
      //Move could not be made
      mq_send( clientQueue, "error", 6, 1 );
    }
    
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );
  
  //Print the final state of the board
  printf( "\n" );
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      printf( "%c", board.boardState[i][j] ? '*' : '.' );
    }
    printf( "\n" );
  }

  return 0;
}

bool makeMove( struct Board * board, unsigned char move ) {
  //Seperate out components of a byte move
  //First (most significant) 3 bits are the row
  int row = (move & 0xE0) >> 5;
  //Next 3 bits are the column
  int col = (move & 0x1C) >> 2;
  //Next bit is the undo flag
  bool undo = move & 0x02;
  //Last bit is the report flag
  bool report = move & 0x01;
  //Don't need to move if we are just reporting
  if( report ) {
    return true;
  }
  //Undo by setting the current move to the last move, because making a move and undoing it is symmetric
  if( undo ) {
    //Error (return false) if there is not a previous move
    if( board->lastMove[0] == -1 ) {
      return false;
    }
    row = board->lastMove[0];
    col = board->lastMove[1];
    //Set previous move to empty
    board->lastMove[0] = -1;
    board->lastMove[1] = -1;
  }
  //Make the move if in bounds
  if(row >= 0 && row <= GRID_SIZE - 1 && col >= 0 && col <= GRID_SIZE - 1 ) {
    board->boardState[row][col] = !board->boardState[row][col];
    
    //Make sure we can act on the grid space in each direction
    if( row > 0 ) {
      board->boardState[row - 1][col] = !board->boardState[row - 1][col];
    }
    
    if( row < GRID_SIZE - 1 ) {
      board->boardState[row + 1][col] = !board->boardState[row + 1][col];
    }
    
    if( col > 0 ) {
      board->boardState[row][col - 1] = !board->boardState[row][col - 1];
    }
    
    if( col < GRID_SIZE - 1 ) {
      board->boardState[row][col + 1] = !board->boardState[row][col + 1];
    }
    
    //If its not an undo, set the last move to this move
    if( !undo ) {
      board->lastMove[0] = row;
      board->lastMove[1] = col;
    }
    //No errors!
    return true;
  }
  //Out of bounds!
  else return false;
}

void sendBoard( struct Board * board, mqd_t clientQueue ) {
  //Create string with space for newlines
  char boardString[GRID_SIZE * (GRID_SIZE + 1)];
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      //Set next char in string to * or . for true or false
      boardString[i * (GRID_SIZE + 1) + j] = board->boardState[i][j] ? '*' : '.';
    }
    //Add a newline after GRID_SIZE characters
    boardString[i * (GRID_SIZE + 1) + GRID_SIZE] = '\n';
  }
  //Last character as a nuller terminator
  boardString[GRID_SIZE * (GRID_SIZE + 1) - 1] = '\0';
  //Send the board string over the client queue
  mq_send( clientQueue, boardString, GRID_SIZE * GRID_SIZE + GRID_SIZE + 1, 1 );
}

void openBoard(struct Board * board, char * filename ) {
  //Open the given filename
  FILE * fp;
  fp = fopen( filename, "r" );
  //Couldn't find the file?
  if( !fp ) {
    printf( "Invalid input file: %s\n", filename );
    fail( "Invalid filename" );
  }
  int i = 0;
  char c;
  //Read in 25 * or .
  while( i < 25 ) {
    c = fgetc(fp);
    if( feof( fp ) ) {
      //Reached end of file without 25 * or .    invalid file format
      printf( "Invalid input file: %s\n", filename );
      fail( "Invalid file" );
    }
    if( c == '*' ) {
      i++;
      board->boardState[i/5][i%5] = true;
    }
    else if( c == '.' ) {
      i++;
      board->boardState[i/5][i%5] = false;
    }
    else if( c != '\n' ) {
      //Found a character that wasn't a * . or newline
      printf( "Invalid input file: %s\n", filename );
      fail( "Invalid file" );
    }
  }
  //Close the file, it's not needed.
  close( fp );
}

void sighandler(int signo) {
  //Stop running
  running = 0;
}
