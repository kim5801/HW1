#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  if( strcmp( argv[1], "move" ) == 0 ) {
    //Send entered move as 1 byte (8 bits)
    char move = ( ( atoi( argv[2] ) & 0x07 ) << 5 ) | ( ( atoi( argv[3] ) & 0x07 ) << 2 );
    mq_send( serverQueue, &move, 1, 1 );
  }
  
  if( strcmp( argv[1], "report" ) == 0 ) {
    //Send request to report board state
    char move = 0x01;
    mq_send( serverQueue, &move, 1, 1 );
  }
  
  if( strcmp( argv[1], "undo" ) == 0 ) {
    //Send undo request
    char move = 0x02;
    mq_send( serverQueue, &move, 1, 1 );
  }
  
  char response[MESSAGE_LIMIT];
  mq_receive( clientQueue, response, MESSAGE_LIMIT, NULL );
  printf( "%s\n", response );
}
