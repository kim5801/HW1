#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main(int argc, char *argv[]) {
    // Open the message queue for talking to the receiver.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
    if(serverQueue == -1) {
        fail("Can't open server queue");
    }

    char buffer[MESSAGE_LIMIT + 1];
    for(int i = 0; i < argc; i++) {
      fgets(buffer, MESSAGE_LIMIT + 1, argv[i]);
    }
    mq_send( serverQueue, buffer, strlen(buffer), 0);

    mq_close(serverQueue);
}