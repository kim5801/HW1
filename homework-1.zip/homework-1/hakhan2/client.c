#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <mqueue.h>
#include "common.h"

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[]) {
  // ensure argc is 2 or 4 
  if ( argc != 2 && argc != 4 ) {
    fail( "Invalid arguments" );
  }
  
  // Open the message queue for talking to the server
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  if ( serverQueue == -1 )
    fail( "Can't open server message queue" );
  
  // Open the client queue for receiving messages from the server
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
  if ( clientQueue == -1 )
    fail( "Can't open client message queue" );

  // Handle logic for report, undo, and move
  // handle the report case
  if( strcmp("report", argv[1]) == 0 ) {
    // send report to the server
    if ( mq_send( serverQueue, argv[1], strlen( argv[1] ) + 1, 0 ) == -1 )
      fail( "Can't send message" );
  }
  // handle the undo case
  else if( strcmp("undo", argv[1]) == 0 ) {
    // send undo to the server
    if ( mq_send( serverQueue, argv[1], strlen( argv[1] ) + 1, 0 ) == -1 )
      fail( "Can't send message" );
  }
  // handle the move case
  else if( argc == 4 && strcmp("move", argv[1] ) == 0 ) {
    // send move to the server
    if ( mq_send( serverQueue, argv[1], strlen( argv[1] ) + 1, 0 ) == -1 )
      fail( "Can't send message" );
    // send row to the server
    if ( mq_send( serverQueue, argv[2], strlen( argv[2] ) + 1, 0 ) == -1 )
      fail( "Can't send message" );
    // send col to the server
    if ( mq_send( serverQueue, argv[3], strlen( argv[3] ) + 1, 0 ) == -1 )
      fail( "Can't send message" );
  }
  // if the user did not enter a valid command
  else {
    fail( "Invalid command" );
  }

  // Read response from the server
  char serverResponse[ MESSAGE_LIMIT ];
  if ( mq_receive( clientQueue, serverResponse, MESSAGE_LIMIT, NULL ) == -1 )
    fail( "Can't receive message" );

  // terminate with failure if server response has the word invalid or error
  if( strstr(serverResponse, "error") != NULL || strstr(serverResponse, "Invalid") != NULL ) {
    fail("error");
  }
  else {
    // print server response
    printf("%s", serverResponse);
  }


  // We're done, close our copy of the queue (which would happen when we exit anyway).
  mq_close( serverQueue );

  return EXIT_SUCCESS;
}