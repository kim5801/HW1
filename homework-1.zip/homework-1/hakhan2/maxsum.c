/**
 * @file maxsum.c
 * @author Harris Khan (hakhan2)
 * This program takes in user input of numbers and determines the maximum sum from any consecutive row of numbers
 * 
 */
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>
#include <fcntl.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

// function to determine the max value of sums from a certain index to the end of the list
/**
 * Function to find the max sum inbetween a start index and end index
 * @param startIndex the index to begin sum from
 * @param end index before your ending index
 * @return returns the maximum value from that section ofthe 
 */
int maxSumFromIndex(int startIndex, int end) {
  // variables to hold the max and the current sum, both beginning at 0
  int max = INT_MIN;
  int sum = 0;

  // iterate through every start index
  for( int j = startIndex; j < end; j++ ) {
    // reset the sum 
    sum = 0; 

    // iterate through the list of values starting at the given index
    for (int i = j; i < vCount; i++) {
      
      // add the current value to the sum
      sum += vList[i];
      
      // if the sum is greater than the max, set the max to the sum
      if (sum > max) {
        max = sum;
      }

    }
  }

  // return the maximum value
  return max;
}


int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // STEP 1: determine the distribution of the work

  // this is an integer array with the index a worker will start at
  int *start = (int *) malloc( (workers + 1) * sizeof( int ) );

  // divide the work evenly among the workers
  int work = vCount / workers;

  // set the beginning index to 0
  start[0] = 0; 

  // add the beginning index of each worker to the start array
  for ( int i = 1; i < workers + 1; i++ ) {
    start[ i ] = i == workers + 1 ? i * work : i * work + vCount % workers;
  }

  // STEP 2: create the workers and assign the work

  // this is an array of worker process ID's
  int pids[workers];

  // create a singular communication pipe for all workers
  int pipes[2];
  if ( pipe( pipes ) < 0 )
    fail("pipe failed"); 

  // create the pipes and workers
  for ( int i = 0; i < workers; i++ ) {

    // fork the worker
    pids[ i ] = fork();
    if ( pids[ i ] < 0 )
      fail( "fork failed" );

    // if we are the worker, break out of the loop after doing the work
    if ( pids[ i ] == 0 ) {
      // close the read end of the pipe
      close( pipes[ 0 ] );

      // write to the pipe 
      int maxValCalced = maxSumFromIndex(start[ i ], start[ i + 1 ]); 

      // pause writing to the pipe until after this process can write to the pipe 
      lockf( pipes[1], F_LOCK, 0 ); 

      // write the max value to the pipe
      if(write( pipes[ 1 ], &maxValCalced, sizeof( int ) ) == -1) {
        // fail("The write to the pipe did not work");
      };

      // unlock the pipe
      lockf( pipes[1], F_ULOCK, 0 );

      // report if it needs to report
      if( report ) {
        printf("I'm process %d. The maximum sum I found is %d\n", getpid(), maxValCalced);
      }
      
      exit( EXIT_SUCCESS );
    }
  }

  if( pids[0] != 0 ) {
    // save the max and current Val
    int currentVal;
    int max = INT_MIN;

    // wait for all the processes to finish 
    for( int i = 0; i < workers; i++ ) {
      read( pipes[0], &currentVal, sizeof( int ));
      waitpid( pids[i], NULL, 0);

      // change the max val if currentVal is bigger
      if( currentVal > max ) {
        max = currentVal;
      }
    }

    // print that all process have finished 
    printf("Maximum Sum: %d\n", max);
  }

  return EXIT_SUCCESS;
}