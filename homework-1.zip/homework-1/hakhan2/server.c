#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Struct to hold the state of the board
typedef struct {
  char currentBoardState[ GRID_SIZE ][ GRID_SIZE ];
  char previousBoardState[ GRID_SIZE ][ GRID_SIZE ];
  bool undo;
} Board; 

// Print the current board
void printCurrentBoard( Board *board ) {
  // Print a new line right before the board for formatting purposes
  printf("\n");
  
  for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
          printf( "%c", board->currentBoardState[ i ][ j ] );
      }
      // Print a new line after each row
      printf("\n");
  }

  // a final new line
  printf("\n");
}

// Print the previous board
void printPreviousBoard( Board *board ) {
  for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
          printf( "%c", board->previousBoardState[ i ][ j ] );
      }
      // Print a new line after each row
      printf("\n");
  }
}

// Function to read in board from file
void readBoard( Board *board, char *fileName ) {
  // Open the file
  FILE *openBoard;
  
  // create a string that can be concatenated 
  char buffer[MESSAGE_LIMIT] = "Invalid input file: ";

  // attempt to open the file and check for errors
  if ( ( openBoard = fopen( fileName, "r" ) ) == NULL ) {
    strcat( buffer, fileName);
    fail( buffer );
  }

  // Iterate over every row
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    // Iterate over the column in a row
    for( int j = 0; j < GRID_SIZE; j++ ) {
          
      // Read in the character from the file
      char c = fgetc( openBoard );
      // Check if the character is a valid character
      if ( c != '*' && c != '.' ) {
          fail( "Invalid board state file" );
      }

      // Set the current state 
      board->currentBoardState[ i ][ j ] = c;
    }

    // Read in the new line character
    if( fscanf( openBoard, "%*c" ) == 1 ) {
      fail( "Invalid board state file" );
    }
  }

  // Make undo false
  board->undo = false; 

  // Close the file
  fclose( openBoard );
}

// Invert position function 
void invertPosition( Board *board, int row, int column ) {
  // Check if the position is valid
  if ( row < 0 || row >= GRID_SIZE || column < 0 || column >= GRID_SIZE ) {
    return;
  }

  // Invert the position
  if ( board->currentBoardState[ row ][ column ] == '*' ) {
    board->currentBoardState[ row ][ column ] = '.';
  } else {
    board->currentBoardState[ row ][ column ] = '*';
  }
}

// Function to change the state of the board
bool changeState( Board *gameBoard, int row, int col ) {

  // Ensure row and column are within 
  if( row < 0 || row > 4 || col < 0 || col > 4 )
    return false;

  // copy the current state to previous state
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      gameBoard->previousBoardState[ i ][ j ] = gameBoard->currentBoardState[ i ][ j ];
    }
  }

  // Set the change the undo to true
  gameBoard->undo = true; 
  
  // Change all surrounding states 
  invertPosition( gameBoard,  row, col );
  invertPosition( gameBoard,  row - 1, col );
  invertPosition( gameBoard,  row + 1, col );
  invertPosition( gameBoard,  row, col - 1 );
  invertPosition( gameBoard,  row, col + 1 );

  return true;
}

// Create an undo function
bool undo( Board *gameBoard ) {
  
  // Check if the undo is true
  if ( gameBoard->undo ) {
    // Copy the previous state to the current state
    for ( int i = 0; i < GRID_SIZE; i++ ) {
      for ( int j = 0; j < GRID_SIZE; j++ ) {
        gameBoard->currentBoardState[ i ][ j ] = gameBoard->previousBoardState[ i ][ j ];
      }
    }
  }
  else {
    return false;
  }

  // Set the undo to false
  gameBoard->undo = false;

  // return true if everything went according to plan
  return true;
}

// Function to turn board into printable string with new line characters
void boardToString( Board *board, char *string ) {
  // current string character 
  int stringChar = 0;

  // Iterate over every row
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    // Iterate over the column in a row
    for( int j = 0; j < GRID_SIZE; j++ ) {
      // Add the character to the string
      string[ stringChar++ ] = board->currentBoardState[ i ][ j ];
      if( j == GRID_SIZE - 1 ) {
        string[ stringChar++ ] = '\n';
      }
    }
  }

  // Final new line for printing in client
  string[ stringChar++ ] = '\n';
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Function to handle the signal interrupt from CTRL+C
void terminationHandle() {
  // make running 0 to terminate while loop
  running = 0;
}

// This is the main program 
int main( int argc, char *argv[] ) {
  // ensure only 2 parameters are passed
  if( argc != 2 ) {
    fail( "usage: server <board-file>" );
  }

  // Signal to keep track of termination
  signal( SIGINT, terminationHandle );

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Create an instance of the board
  Board *myBoard = (Board *) malloc( sizeof( Board ) );

  // Load in the state of the board
  readBoard( myBoard, argv[1] );

  char message[MESSAGE_LIMIT];

  // Repeatedly read and process client messages.
  while ( running ) {
    // Read a message from the client
    mq_receive( serverQueue, message, MESSAGE_LIMIT, NULL );
    
    // The buffer to respond with
    char response[MESSAGE_LIMIT] = {'\0'};

    // Send back the report
    if( strcmp("report", message) == 0 ) {
      // use previously written board to string function
      boardToString( myBoard, response );
    }
    // handle undo
    else if( strcmp("undo", message) == 0 ) {
      if( undo( myBoard ) ) {
        strcpy(response, "success\n");
      } else {
        strcpy(response, "success\n");
      }
    }
    // handle move
    else if( strcmp("move", message) == 0 ) {
      // Read the row and column
      int row, col;
      mq_receive( serverQueue, message, MESSAGE_LIMIT, NULL );
      sscanf( message, "%d", &row );
      mq_receive( serverQueue, message, MESSAGE_LIMIT, NULL );
      sscanf( message, "%d", &col );

      // Change the state of the board
      if( changeState( myBoard, row, col ) ) {
        strcpy(response, "success\n");
      } else {
        strcpy(response, "Invalid row or column\n");
      }
    }

    // send a response back to the client
    if ( mq_send( clientQueue, response, strlen( response ) + 1, 0 ) == -1 )
      fail( "Can't send message to client\n" );

    // Clear the message 
    memset( message, '0', MESSAGE_LIMIT );
  }

  // Print out the last state of the board
  printCurrentBoard( myBoard );

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // free the board that was created
  free( myBoard );

  return EXIT_SUCCESS;
}
