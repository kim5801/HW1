/**
 * @file client.c
 * @author Ethan Gilbert
 * @brief This program is the client
 * @version 0.1
 * @date 2022-09-15
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <mqueue.h>
#include "common.h"

static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}


int main( int argc, char *argv[] ) {
    // If there is an invalid number of command arguments
    if ( argc < 2 || argc > 4 ) {
        fail( "usage: server <board-file>" );
    }
    //Initialize integer to determine which command is being called
    int command;
    
    // If move command is called
    if ( strcmp( argv[ 1 ] , "move" ) == 0 ) {
        if(argv[2] == NULL || argv[3] == NULL) {
            fail( "error" );
        }

        if(atoi(argv[2]) < 0 || atoi(argv[2]) > 4 || atoi(argv[3]) < 0 || atoi(argv[3]) > 4) {
            fail( "error" );
        }
        
        //Set command to 1
        command = 1;
    }

    //If undo command is called
    else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
        //Check too many arguments
        if ( argc != 2 ) {
            fail( "error" );
        }
        //Set command to 2
        command = 2;
    }

    //If report command is called
    else if ( strcmp( argv[ 1 ], "report" ) == 0) {
        //Check too many arguments
        if ( argc != 2 ) {
            fail( "error" );
        }
        //Set command to 3
        command = 3; 

    //Else fail, invalid argument
    } else {
        fail( "usage: server <board-file>" );
    }
    
    // Open message queue 
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
    if ( serverQueue == -1 || clientQueue == -1 ) {
        fail( "Can't create message queues" );
    }

    // Create message parameter to send to server
    char message[ MESSAGE_LIMIT ]; 

    // If move is called, send command = 1 to server, send input parameters as well
    if ( command == 1 ) {
        message[0] = 1;
        message[1] = atoi(argv[ 2 ] );
        message[2] = atoi(argv[ 3 ] );
        mq_send( serverQueue, message, strlen( message ), 0 );
    // If undo is called, send command = 2 to server
    } else if ( command == 2 ) {
        message[ 0 ] = 2;
        mq_send( serverQueue, message, strlen( message ), 0 );
    // If report is called, send command = 3 to server 
    } else if ( command == 3 ) {
        message[ 0 ] = 3;
        mq_send( serverQueue, message, strlen( message ), 0 ); 
    }

   // Buffer for reading a message from the sender, this must be at least as large as the
  // size bound on the queue.
  char buffer[ MESSAGE_LIMIT ];
  
  // Try to get a message (this will wait until one arrives).
  int len = mq_receive( clientQueue, buffer, sizeof( buffer ), NULL );
    if(command == 1) {
        printf("success\n");
    }
    if(command == 2) {
        printf("success\n");
    }
    
    if(command == 3) {
            
        if ( len >= 0 ) {

                for ( int i = 0; i < len - 1; i++ ) {
                    printf( "%c", buffer[ i ] );
                }
        } 
        printf( "\n");
    }
    return EXIT_SUCCESS; 
}
