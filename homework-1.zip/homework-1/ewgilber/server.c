/**
 * @file server.c
 * @author ewgilber
 * @brief 
 * @version 0.1
 * @date 2022-09-15
 * 
 * @copyright Copyright (c) 2022
 * 
 */
 
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  //Open file
  int fd;
    if((fd = open(argv[1], O_RDONLY)) < 0) {
      printf("Invalid input file: %s", argv[1]);
      fail("");
    }

  // Repeatedly read and process client messages.
  while ( running ) {
  
    //Creating message to receive from client
    char message[ MESSAGE_LIMIT ]; 
    mq_receive( serverQueue, message, sizeof(message), NULL );
    //Saving what command has been called to message
    int command = message[ 0 ];
  
    char buffer[MESSAGE_LIMIT];
    int len = read(fd, &buffer, sizeof(buffer));

    char undone[MESSAGE_LIMIT];

    if(command == 1) {
        for(int i = 0; i < len; i++) {
          undone[i] = buffer[i];
        }

        int index = 0;
        char temp[GRID_SIZE][GRID_SIZE];
        for(int i = 0; i < GRID_SIZE; i++) {
          for(int j = 0; j < GRID_SIZE; j++) {
            temp[i][j] = buffer[index];
            index++;
          }
          index++;
        }
        index = 0;
        int row = (int) message[1];
        int col = (int) message[2];
        
        //Left Side
        if(col == 0) {
          //Special Case 0 0
          if(row == 0) {
            if(temp[0][0] == '.') {
              temp[0][0] = '*';
            } else {
              temp[0][0] = '.';
            }
            if(temp[0][1] == '.') {
              temp[0][1] = '*';
            } else {
              temp[0][1] = '.';
            }
            if(temp[1][0] == '.') {
              temp[1][0] = '*';
            } else {
              temp[1][0] = '.';
            }
          }
          //Special Case 4 0
          else if(row == 4) {
            if(temp[4][0] == '.') {
              temp[4][0] = '*';
            } else {
              temp[4][0] = '.';
            }
            if(temp[4][1] == '.') {
              temp[4][1] = '*';
            } else {
              temp[4][1] = '.';
            }
            if(temp[3][0] == '.') {
              temp[3][0] = '*';
            } else {
              temp[3][0] = '.';
            }
          } else {
            //Special Case 1,2,3 0
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row+1][col] == '.') {
              temp[row+1][col] = '*';
            } else {
              temp[row+1][col] = '.';
            }
            if(temp[row-1][col] == '.') {
              temp[row-1][col] = '*';
            } else {
              temp[row-1][col] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
          }
        }
          //Right side
          else if(col == 4) {
          //Special Case 0 4
          if(row == 0) {
            if(temp[0][4] == '.') {
              temp[0][4] = '*';
            } else {
              temp[0][4] = '.';
            }
            if(temp[0][3] == '.') {
              temp[0][3] = '*';
            } else {
              temp[0][3] = '.';
            }
            if(temp[4][1] == '.') {
              temp[4][1] = '*';
            } else {
              temp[4][1] = '.';
            }
          }
          //Special Case 4 4
          else if(row == 4) {
            if(temp[4][4] == '.') {
              temp[4][4] = '*';
            } else {
              temp[4][4] = '.';
            }
            if(temp[4][3] == '.') {
              temp[4][3] = '*';
            } else {
              temp[4][3] = '.';
            }
            if(temp[3][4] == '.') {
              temp[3][4] = '*';
            } else {
              temp[3][4] = '.';
            }
          } else {
            //Special Case 1,2,3 4
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row+1][col] == '.') {
              temp[row+1][col] = '*';
            } else {
              temp[row+1][col] = '.';
            }
            if(temp[row-1][col] == '.') {
              temp[row-1][col] = '*';
            } else {
              temp[row-1][col] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
          }
        }
        //Top
        else if(row == 0 && (col != 0 || col != 4)) {
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row+1][col] == '.') {
              temp[row+1][col] = '*';
            } else {
              temp[row+1][col] = '.';
            }
            if(temp[row][col-1] == '.') {
              temp[row][col-1] = '*';
            } else {
              temp[row][col-1] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
        }

        //Bottom
        else if(row == 4 && (col != 0 || col != 4)) {
            if(temp[row][col] == '.') {
              temp[row][col] = '*';
            } else {
              temp[row][col] = '.';
            }
            if(temp[row-1][col] == '.') {
              temp[row-1][col] = '*';
            } else {
              temp[row-1][col] = '.';
            }
            if(temp[row][col-1] == '.') {
              temp[row][col-1] = '*';
            } else {
              temp[row][col-1] = '.';
            }
            if(temp[row][col+1] == '.') {
              temp[row][col+1] = '*';
            } else {
              temp[row][col+1] = '.';
            }
        }
        else {
          if(temp[row][col] == '.') {
          temp[row][col] = '*';
          } else {
            temp[row][col] = '.';
          }
          if(temp[row-1][col] == '.') {
            temp[row-1][col] = '*';
          } else {
            temp[row-1][col] = '.';
          }
          if(temp[row+1][col] == '.') {
            temp[row+1][col] = '*';
          } else {
            temp[row+1][col] = '.';
          }
          if(temp[row][col-1] == '.') {
            temp[row][col-1] = '*';
          } else {
            temp[row][col-1] = '.';
          }
          if(temp[row][col+1] == '.') {
            temp[row][col+1] = '*';
          } else {
            temp[row][col+1] = '.';
          }
        }
    
        for(int i = 0; i < GRID_SIZE; i++) {
          for(int j = 0; j < GRID_SIZE; j++) {
            buffer[index] = temp[i][j];
            index++;
          }
          buffer[index] = '\n';
          index++;
        }
        mq_send( clientQueue, buffer, strlen( buffer ), 0 );
    }
    if(command == 2) {
      mq_send( clientQueue, undone, strlen( undone ), 0 );
    }
    if(command == 3) {
      mq_send( clientQueue, buffer, strlen( buffer ), 0 );
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
