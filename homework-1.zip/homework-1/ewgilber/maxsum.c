#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

/**
 * This program takes a list of numbers and determines the maximum continguous non empty
 * sequence of numbers. This task will be split up by a specified number of workers. 
 *
 * @author Ethan Gilbert 
 */

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // Create tracker array of workers pids and what index they start at
  int pidList[workers][2];
  // Creating pipe
  int buffer[2];
  if(pipe(buffer) != 0) {
    fail("Could not create pipe");
  }

  //Creating first child
  pid_t pid;
  pid = fork();
  if(pid < 0) {
    fail("Count not create new child");
  }

  //First child created successfully, save to pid array
  if( pid == 0) {
    pidList[0][0] = getpid();
    pidList[0][1] = 0;
  }
 
  //Parent creating other workers if input specifies
  for(int i = 1; i < workers; i++) {
    if(pid > 0) {
      if((pid = fork()) == 0) {
        pidList[i][0] = getpid();
        pidList[i][1] = i;
      }
    }
  }

  //If they are a worker
  if(pid == 0) {
    //Closing reading end of pipe
    close(buffer[0]);
    
    //Initializing sum, localSum and starting index
    int sum = 0;
    int localSum = 0;
    int start;
    
    //Setting start index of each worker
    for(int i = 0; i < workers; i++) {
      if(pidList[i][0] == getpid()) {
        start = pidList[i][1];
      }
    }

      //For lopp to increment start index depending on number of workers
        for(int i = 0; i < vCount; i = i + workers) {
          //For loop to go through each possible starting index, adding to a local sum to compare to total sum
            for (int j = start + i; j < vCount; j++) {
                 localSum += vList[j];  
                 // If local is larger than max sum, it becomes max sum
                 if(localSum > sum) {
                  sum = localSum;
                 }           
            } 
            //Restting local sum
            localSum = 0;
        }
      //If user asks for a report, provide report
      if( report == true) {
        printf( "I'm process %d. The maximum sum I found is %d.\n", getpid(), sum );
      }

        // Lock the pipe
        lockf( *buffer, F_LOCK, 0);
        //Write to pipe
        write( buffer[ 1 ], &sum, sizeof( sum ) );
        // Unlock the pipe 
        lockf( *buffer, F_ULOCK, 0);

  }

  //If they are the parent
  if( pid > 0) {
    //Closing the writing end of the pipe
    close(buffer[1]);

    //Initializing the values read in through the pipe and maximum sum
    int readInValue;
    int sum = 0;

    //Waiting for children processes to finish
    for(int i = 0; i < workers; i++) {
      wait(NULL);
    }

    //Check each of the worker's read in values by reading them
    for(int i = 0; i < workers; i++) {
      read(buffer[0], &readInValue, sizeof(readInValue));
      //If the worker's sum is larger than the sum of previous workers, save as maximum sum;
      if(readInValue > sum) {
        sum = readInValue;
      }
    }
    //Printing maximum sum
    printf("Maximum Sum: %d\n", sum ); 
  }


  return EXIT_SUCCESS;
}
