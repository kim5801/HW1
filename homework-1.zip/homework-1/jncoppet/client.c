#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 7;
    attr.mq_msgsize = MESSAGE_LIMIT;
    // Opens all the messages queues
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    char sendBuffer[7];
    char receiveBuffer[1025];
    
    if(argc == 4) { // Checks number of commands
		    strcpy(sendBuffer, "move");
	      if(*argv[2] - 48 < 0 || *argv[2] - 48 > 4 || *argv[3] - 48 < 0 || *argv[3] - 48 > 4) {
				    fail("Error: Invalid indices"); // Fails if move has invalid indices
				}
	      sendBuffer[4] = *argv[2];
	      sendBuffer[5] = *argv[3];
	     	if(atoi(argv[2]) < 0 || atoi(argv[2]) > 5 || atoi(argv[3]) < 0 || atoi(argv[3]) > 5) {
				    fail("Error: Invalid index"); // Fails if move has invalid indices
		    }
		} else if (argc == 2) {
		    if(strcmp(argv[1], "report") == 0) {
				    strcpy(sendBuffer, "report");
				} else if(strcmp(argv[1], "undo") == 0) {
				    strcpy(sendBuffer, "undo");
				} else {
				    fail("Error: Invalid command"); // Fails if bad command is entered
				}
		} else {
		    fail("Error: Invalid run parameters");
		}
	  char cmd[4]; // Temporary string to hold first four characters for move
    cmd[0] = sendBuffer[0];
    cmd[1] = sendBuffer[1];
    cmd[2] = sendBuffer[2];
    cmd[3] = sendBuffer[3];
    cmd[4] = '\0';
    if(strcmp("report", sendBuffer) != 0 && strcmp("move", cmd) != 0 && strcmp("undo", sendBuffer) != 0) {
		    fail("Error: Invalid command"); // Fails if command is not valid
		}
	  int len = mq_send(serverQueue, sendBuffer, strlen(sendBuffer), 0); // Sends command to the queue
	  if(len == -1) {
		    perror("Error: ");
		}
	  int receiveLen = mq_receive(clientQueue, receiveBuffer, sizeof(receiveBuffer), NULL); // Receives back message from server
	  if(receiveLen == -1) {
		    perror("Error: ");
		}
	  if(strcmp("report", sendBuffer) == 0) { // If command was report, it prints the receiveBuffer which is the board
		    for(int i = 0; i < (GRID_SIZE * GRID_SIZE); i++) {
				     if(i % GRID_SIZE == 0 && i > 0) {
						      printf("\n");
						 }
	 			     printf("%c", receiveBuffer[i]);
				}
				printf("\n");
		} else if(strcmp("undo", sendBuffer) == 0) { // Prints buffer from server which is success or error
		    printf("%s\n", receiveBuffer);
		} else if(strcmp("move", cmd) == 0) { // Prints buffer from server which is success or error
		    printf("%s\n", receiveBuffer);
		}
}