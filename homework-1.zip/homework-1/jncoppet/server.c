#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out two error messages and exit. Used only for invalid inputs
static void failInput( char const *message1, char const *message2 ) {
  fprintf( stderr, "%s %s\n", message1, message2 );
  exit( 1 );
}

// Flips from . or #
static char flip(char element) {
    if(element == '*') {
		    return '.';
		} else if(element == '.') {
		    return '*';
		} else {
		    fail("Invalid board");
		}
	  return 'x';
}
// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Routine when an interrupt is caught
void alarmHandler(int sig) {
    running = 0;
}

int main( int argc, char *argv[] ) {
  struct sigaction act;
  act.sa_handler = alarmHandler;
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  if(argc != 2) {
	    fail("usage: server <board-file>");
	}

  char board[GRID_SIZE][GRID_SIZE]; // Current board
  char prevBoard[GRID_SIZE][GRID_SIZE]; // Previous board used by undo
  char boardToSend[GRID_SIZE*GRID_SIZE]; // Board as one continuous string
  char current;
  int row = 0;
  int col = 0;
  FILE *fp = fopen(argv[1], "r");
  if( !fp ) {
	    failInput("Invalid input file: ", argv[1]); // Error if file can not open
	}
  for(int i = 0; i < GRID_SIZE; i++) {
	    for(int k = 0; k < GRID_SIZE + 1; k++) {
			    current = fgetc(fp);
			    if(k != GRID_SIZE) {
					    if(current != '*' && current != '.') {
							    failInput("Invalid input file: ", argv[1]); // Error if board is not correct
							}
					}																						    																												
		      if(current == '*' || current == '.') {
					    board[i][k] = current;
				      prevBoard[i][k] = current;
					}
			}
	}
	
  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 7;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  bool canUndo = false;
  bool undo = false;
  // Repeatedly read and process client messages.
  while ( running ) { 
      sigaction(SIGINT, &act, 0); // Check for interrupt in case of CTRL + C
      char buffer[1025];
      memset(buffer, 0, sizeof(buffer)); // Reset buffer in case calls have been made already 
      int len = mq_receive( serverQueue, buffer, sizeof(buffer), NULL); // Receives buffer from the queue
      if(len == -1) {
          if(SIGINT != 2) {
					    perror("Error: ");
					}        
			}
 		  char cmd[4]; // Variable to used to check for move 
      cmd[0] = buffer[0];
      cmd[1] = buffer[1];
      cmd[2] = buffer[2];
      cmd[3] = buffer[3];
      cmd[4] = '\0';
      if(strcmp(buffer, "report") == 0) { // If buffer is report, it copies board or prevBoard to boardToSend
          int ind = 0;
					for(int i = 0; i < GRID_SIZE; i++) {
 				      for(int k = 0; k < GRID_SIZE; k++) {
			            if(undo) {
							        boardToSend[ind] = prevBoard[i][k];
							    } else {
							        boardToSend[ind] = board[i][k];
							    }  
                  ind++;
			        }
          }
          undo = false; // Undo is now not possible if it was before
			    int sendLen = mq_send( clientQueue, boardToSend, strlen(boardToSend), 0); // Sends boardToSend
			    if(sendLen == -1) {
					    perror("Error: ");
					}
			} else if(strcmp(buffer, "undo") == 0) { // Checks if buffer is undo
		      if(canUndo) {
		          undo = true; // Sets undo to true
					    char success[8] = "success";
			        int sendLen = mq_send( clientQueue, success, strlen(success), 0); // Send back success to client
			        if(sendLen == -1) {
					        perror("Error: ");
				    	}
 							for(int i = 0; i < GRID_SIZE; i++) { // Copies previous board to board. Both are now equal
							    for(int k = 0; k < GRID_SIZE; k++) {
									    board[i][k] = prevBoard[i][k];
									} 
		          }
		          canUndo = false;
					} else {
					    char error[6] = "error";
							int sendLen = mq_send( clientQueue, error, strlen(error), 0); // Sends error if undo is not legal
			        if(sendLen == -1) {
					        perror("Error: ");
				    	}		 										    
					}
		      
			} else if(strcmp(cmd, "move") == 0) { // Checks if buffer is now move
			    canUndo = true;
			    row = buffer[4] - 48;
			    col = buffer[5] - 48;
			    for(int i = 0; i < GRID_SIZE; i++) { // Firstly updates prevBoard to board before making changes to board
					    for(int k = 0; k < GRID_SIZE; k++) {
							    prevBoard[i][k] = board[i][k];
							}
					}
		 		  if(row - 1 < 0) { // Deals with all cases when row == 0 i.e. left top row
					    if(col - 1 < 0) {
							    board[row][col] = flip(board[row][col]);
                  board[row][col + 1] = flip(board[row][col + 1]);
           				board[row + 1][col] = flip(board[row + 1][col]);
							} else if(col + 1 > 4) {
							    board[row][col - 1] = flip(board[row][col - 1]);
 				          board[row][col] = flip(board[row][col]);
	 		            board[row + 1][col] = flip(board[row + 1][col]);
							} else {
							    board[row][col - 1] = flip(board[row][col - 1]);
 				          board[row][col] = flip(board[row][col]);
			            board[row][col + 1] = flip(board[row][col + 1]);
			            board[row + 1][col] = flip(board[row + 1][col]);
							} 
				  } else if(row + 1 > 4) { // Deals with all cases when row == 4 i.e. bottom row
					    if(col - 1 < 0) {
							    board[row][col] = flip(board[row][col]);
                  board[row][col + 1] = flip(board[row][col + 1]);
           				board[row - 1][col] = flip(board[row - 1][col]);
							} else if(col + 1 > 4) {
							    board[row][col - 1] = flip(board[row][col - 1]);
 				          board[row][col] = flip(board[row][col]);
	 		            board[row - 1][col] = flip(board[row - 1][col]);
							} else {
							    board[row][col - 1] = flip(board[row][col - 1]);
 				          board[row][col] = flip(board[row][col]);
			            board[row][col + 1] = flip(board[row][col + 1]);
			            board[row - 1][col] = flip(board[row - 1][col]);
							} 
					} else if(col - 1 < 0) { // Deals with all cases if col == 0 i.e. left column
					    board[row - 1][col] = flip(board[row - 1][col]);
 				      board[row][col] = flip(board[row][col]);
			        board[row][col + 1] = flip(board[row][col + 1]);
			        board[row + 1][col] = flip(board[row + 1][col]);
					} else if(col + 1 > 4) { // Deals with all cases if col == 4 i.e. right column
					    board[row][col - 1] = flip(board[row][col - 1]);
 				      board[row][col] = flip(board[row][col]);
			        board[row + 1][col] = flip(board[row + 1][col]);
			        board[row - 1][col] = flip(board[row - 1][col]);
					} else { // Deals with all remaining middle cases for col and row
					    board[row][col - 1] = flip(board[row][col - 1]);
 				      board[row][col] = flip(board[row][col]);
			        board[row][col + 1] = flip(board[row][col + 1]);
			        board[row - 1][col] = flip(board[row - 1][col]);
			        board[row + 1][col] = flip(board[row + 1][col]);
					}
			    char success[8] = "success";
          int sendLen = mq_send( clientQueue, success, strlen(success), 0); // Sends back success after board is changed
			    if(sendLen == -1) {
              perror("Error: ");
		    	}
			}
  }
  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );
  
  // Prints the final state of the board after server recognizes CTRL + C
  printf("\n");
  for(int i = 0; i < GRID_SIZE; i++) {
      for(int k = 0; k < GRID_SIZE; k++) {
		      printf("%c", board[i][k]);
			}
 		  printf("\n");
  }
  return 0;
}
