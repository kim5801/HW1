/**
 * @file maxsum.c
 * @author Rose Xiao
 * @brief It will be able to use
multiple processes and multiple CPU cores to solve a computationally expensive problem more quickly. Your job is to find a contiguous non-empty subsequence within the sequence that has the largest sum.
 * @date 2022-09-02
 */

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

#define MIN_ARGS 2
#define MAX_ARGS 3
#define MIN_WORKERS 1

 //compile with the following line
 // gcc -Wall -std=c99 -D_XOPEN_SOURCE=500 -g maxsum.c -o maxsum

  // Print out an error message and exit.
static void fail( char const* message )
{
	fprintf( stderr, "%s\n", message );
	exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage()
{
	printf( "usage: maxsum <workers>\n" );
	printf( "       maxsum <workers> report\n" );
	exit( EXIT_FAILURE );
}

// Input sequence of values.
int* vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList()
{
	// Set up initial list and capacity.
	vCap = 5;
	vList = ( int* )malloc( vCap * sizeof( int ) );

	// Keep reading as many values as we can.
	int v;
	while ( scanf( "%d", &v ) == 1 ) {
		// Grow the list if needed.
		if ( vCount >= vCap ) {
			vCap *= 2;
			vList = ( int* )realloc( vList, vCap * sizeof( int ) );
		}

		// Store the latest value in the next array slot.
		vList [ vCount++ ] = v;
	}
}

int main( int argc, char* argv [ ] )
{
	bool report = false;
	int workers = 0;

	// Parse command-line arguments.
	if ( argc < MIN_ARGS || argc > MAX_ARGS )
		usage();

	if ( sscanf( argv [ 1 ], "%d", &workers ) != 1 ||
		workers < MIN_WORKERS )
		usage();

	// If there's a second argument, it better be the word, report
	if ( argc == MAX_ARGS ) {
		if ( strcmp( argv [ 2 ], "report" ) != 0 )
			usage();
		report = true;
	}

	readList();

	//opens a pipe to read and write from
	int pipes [ 2 ];

	//create a directional pipe between the child an dthe parent
	if ( pipe( pipes ) == -1 ) {
		fail( "Not able to fork a child." );
	}

	//the maximum sum out of all the workers
	int maxSumPar = 0;
	int tempSum = 0;

	//creates all the children at once
	for ( int k = 0;k < workers;k++ ) {
		pid_t child = fork();
		if ( child == 0 ) {
			//close the read end of the pipe
			close( pipes [ 0 ] );
			//the sum computed by the worker
			int maxSum = 0;
			//increment by the number of workers
			for ( int i = k; i < vCount; ( i += workers ) ) {
				int sum = 0;
				for ( int j = i; j < vCount; j++ ) {
					sum += *( vList + j );
					if ( sum > maxSum ) {
						maxSum = sum;
					}
				}

			}

			if ( report ) {
				printf( "I'm process %d. the maximum sum I found is %d.\n", getpid(), maxSum );
			}

			//worker locks the pipe to avoid collision with two workers writing to the pipe at the same time
			lockf( pipes [ 1 ], F_LOCK, 0 );
			//write to the pipe
			int val = write( pipes [ 1 ], &maxSum, sizeof( maxSum ) );
			if ( val == -1 ) {
				fail( "Worker unable to write to pipe" );
			}
			//unlocks the pipe to let the others use the pipe
			lockf( pipes [ 1 ], F_ULOCK, 0 );
			//close the writing end of the pipe
			close( pipes [ 1 ] );
			exit( EXIT_SUCCESS );
		}
	}

	//parent closes their writing end of the pipe
	close( pipes [ 1 ] );
	//wait for all the children to terminate
	for ( int i = 0; i < workers;i++ ) {
		wait( NULL );
	}
	//read in the writes and check if the worker sum is the maximum
	for ( int i = 0; i < workers;i++ ) {
		int val = read( pipes [ 0 ], &tempSum, sizeof( int ) );
		if ( val == -1 ) {
			perror( "pipe" );
		}
		if ( tempSum > maxSumPar ) {
			maxSumPar = tempSum;
		}
	}

	//close the reading end of the pipe
	close( pipes [ 0 ] );
	printf( "Maximum Sum: %d\n", maxSumPar );
	return EXIT_SUCCESS;
}
