/**
 * @file client.c
 * @author Rose Xiao
 * @brief For this problem, you’re going to use Inter-Process Communication (IPC) to create a pair of
programs, client.c and server.c that work together. I’ve already written part of the server for you. The client works with the server to implement a multi-player version of the lights-out game from
the 1990s.
 * @date 2022-09-03
 */

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

#include "common.h"
#include <mqueue.h> //to have access to message queue methods
#include <string.h>

//the minimun and maximun number of command-line arguments
#define MIN_ARGS 2
#define MAX_ARGS 4
// Print out an error message and exit.
static void fail( char const* message )
{
	printf( "%s\n", message );
	exit( EXIT_FAILURE );
}

int main( int argc, char* argv [ ] )
{
	// Prepare structure indicating maximum queue and message sizes.
	struct mq_attr attr;
	attr.mq_flags = 0;
	attr.mq_maxmsg = 1;
	attr.mq_msgsize = MESSAGE_LIMIT;


	//  Make both the server and client message queues.
	// NOTE: since we are on the client file,, the oflags used is to read only for client and write only for server (the reverse in the server.c)
	mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
	mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
	if ( serverQueue == -1 || clientQueue == -1 ) {
		fail( "Can't create the needed message queues" );
	}

	//if the incorrect number of arguments are passed
	if ( argc != MIN_ARGS && argc != MAX_ARGS ) {
		fail( "Invalid arguments passed" );

	}
	//the message to be sent to the server queue
	char sendMsg [ MESSAGE_LIMIT ];
	bool notReport = true;
	char receiveMsg [ MESSAGE_LIMIT + 1 ];

	//if the cmd received was to move
	if ( strcmp( "move", argv [ 1 ] ) == 0 ) {
		int row, col;

		//read in the two int values that will be used
		int rowScan = sscanf( argv [ 2 ], "%d", &row );
		int colScan = sscanf( argv [ 3 ], "%d", &col );

		//if not an integer
		if ( rowScan != 1 || colScan != 1 ) {
			fail( "error" );
		}

		//if the integers read in are out of bounds for the board
		if ( row < FIRST_ROW || row > LAST_ROW || col < FIRSt_COL || col > LAST_COL ) {
			fail( "error" );
		}

		//creates a string in the form of 'moverc'
		strcpy( sendMsg, argv [ 1 ] );
		strcat( sendMsg, argv [ 2 ] );
		strcat( sendMsg, argv [ 3 ] );

		//sends the command to the server queue
		if ( mq_send( serverQueue, sendMsg, strlen( sendMsg ) + 1, 0 ) == -1 ) {
			perror( "Client: Error sending the message." );
			exit( EXIT_FAILURE );
		}
	}
	//the client requests to undo 
	else if ( strcmp( "undo", argv [ 1 ] ) == 0 ) {
		char sendMsg [ MESSAGE_LIMIT ];
		strcpy( sendMsg, argv [ 1 ] );
		if ( mq_send( serverQueue, sendMsg, strlen( sendMsg ) + 1, 0 ) == -1 ) {
			perror( "Client: Error sending the message." );
			exit( EXIT_FAILURE );
		}
	}
	//the client requests to report the board state
	else if ( strcmp( "report", argv [ 1 ] ) == 0 ) {
		char sendMsg [ MESSAGE_LIMIT ];
		strcpy( sendMsg, argv [ 1 ] );
		if ( mq_send( serverQueue, sendMsg, strlen( sendMsg ) + 1, 0 ) == -1 ) {
			perror( "Client: Error sending the message." );
			exit( EXIT_FAILURE );
		}

		//read in the strings send by the server to which each string is a row of the board
		char board [ GRID_SIZE ][ GRID_SIZE ];
		for ( int i = 0; i < GRID_SIZE; i++ ) {
			//recieve response from server
			char receiveMsg [ MESSAGE_LIMIT + 1 ];
			if ( mq_receive( clientQueue, receiveMsg, sizeof( receiveMsg ), NULL ) == -1 ) {
				perror( "Client: Error receiving the message." );
				exit( EXIT_FAILURE );
			}

			for ( int j = 0; j < GRID_SIZE; j++ ) {
				board [ i ][ j ] = receiveMsg [ j ];
			}
		}

		//print out the final board sate
		for ( int i = 0; i < GRID_SIZE;i++ ) {
			for ( int j = 0; j < GRID_SIZE; j++ ) {
				printf( "%c", board [ i ][ j ] );
			}
			printf( "\n" );
		}
		notReport = false;
	}
	//if the user did not input a valid cmd
	else {
		fail( "error" );
	}

	//if the client did not ask to report anything,, receive the response from the server
	if ( notReport ) {
		if ( mq_receive( clientQueue, receiveMsg, sizeof( receiveMsg ), NULL ) == -1 ) {
			perror( "Client: Error receiving the message." );
			exit( EXIT_FAILURE );
		}
		printf( "%s\n", receiveMsg );
	}

	return EXIT_SUCCESS;
}