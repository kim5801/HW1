/**
 * @file server.c
 * @author Rose Xiao
 * @brief For this problem, you’re going to use Inter-Process Communication (IPC) to create a pair of
programs, client.c and server.c that work together. I’ve already written part of the server for you. The server works with the client to implement a multi-player version of the lights-out game from
the 1990s.
 * @date 2022-09-13
 */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

#include <mqueue.h> //to have access to message queue methods
#include <signal.h>
#include <errno.h>
#include <string.h>

//the required number of command-line arguments
#define NUM_ARGS 2
//The bit mask used to flip the characters
#define MASK 4

//the line to compile the server
// gcc -D_POSIX_SOURCE -Wall -g -std=c99 -o server server.c -lrt

// Print out an error message and exit.
static void fail( char const* message )
{
	fprintf( stderr, "%s\n", message );
	exit( EXIT_FAILURE );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

//if the command line arguments are invalid
static void usage()
{
	fprintf( stderr, "usage: server <board-file>\n" );
	// printf( "       maxsum <workers> report\n" );
	exit( EXIT_FAILURE );
}

static char board [ GRID_SIZE ][ GRID_SIZE ];
//keeps track of the previous board state
static char prevBoard [ GRID_SIZE ][ GRID_SIZE ];

//the signal handler for SIGINT where the user kills the server with ctrl-C.
//the server catches the signal,, prints out a new line,, then the state of the playing board
void printHandler( int sig )
{
	printf( "\n" );
	for ( int i = 0; i < GRID_SIZE;i++ ) {
		for ( int j = 0; j < GRID_SIZE; j++ ) {
			printf( "%c", board [ i ][ j ] );
		}
		printf( "\n" );
	}
	exit( EXIT_FAILURE );
}

int main( int argc, char* argv [ ] )
{
	// Remove both queues, in case, last time, this program terminated
	// abnormally with some queued messages still queued.
	mq_unlink( SERVER_QUEUE );
	mq_unlink( CLIENT_QUEUE );

	// Prepare structure indicating maximum queue and message sizes.
	struct mq_attr attr;
	attr.mq_flags = 0;
	attr.mq_maxmsg = 1;
	attr.mq_msgsize = MESSAGE_LIMIT;

	// Make both the server and client message queues.
	mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
	mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
	if ( serverQueue == -1 || clientQueue == -1 ) {
		fail( "Can't create the needed message queues" );
	}

	// If given too many arguements or missing a board file name
	if ( argc != NUM_ARGS  ) {
		usage();
	}

	//opening the board file
	FILE* fp = fopen( argv [ 1 ], "r" );
	if ( fp == NULL ) { //checks if file exists
		fprintf( stderr, "Invalid input file: %s\n", argv [ 1 ] );
		exit( EXIT_FAILURE );
	}

	char str [ GRID_SIZE + 2 ]; //7 to account for that extra space after each row and/or to account for the \n 
	int row = 0;

	//reading in the board line by line
	while ( fgets( str, sizeof( str ), fp ) ) {
		//error checking to see the row only has 5 chars
		if ( strlen( str ) != ( GRID_SIZE + 1 ) ) { //check with 6 since strlen doesn't account for \n
			fprintf( stderr, "Invalid input file: %s\n", argv [ 1 ] );
			exit( EXIT_FAILURE );
		}
		for ( int j = 0; j < strlen( str ) - 1; j++ ) { //check only the first 5 chars
			//error checking to see that the right chars are used
			if ( str [ j ] != '*' && str [ j ] != '.' ) {
				fprintf( stderr, "Invalid input file: %s\n", argv [ 1 ] );
				exit( EXIT_FAILURE );
			}
			else {
				if ( str [ j ] == '*' ) {
					board [ row ][ j ] = '*';
				}
				else {
					board [ row ][ j ] = '.';
				}
			}
		}
		row++;
	}

	//error checking to there are only 5 rows
	if ( row != GRID_SIZE ) {
		fprintf( stderr, "Invalid input file: %s\n", argv [ 1 ] );
		exit( EXIT_FAILURE );
	}

	//boolean to track if the client called the 'undo' cmd
	bool undo = false;
	// Repeatedly read and process client messages.
	while ( running ) {
		//the struct to catch the Ctrl^c cmd (when user wants to terminate server)
		struct sigaction act;
		//calls the signal handler
		act.sa_handler = printHandler;
		sigaction( SIGINT, &act, 0 );

		//msg received must be longer than the maximun length for message in queue
		char receive [ MESSAGE_LIMIT + 1 ];
		//initially set the message that will be sent to the client as failed
		char string [ ] = "error";

		//get the command from the client
		if ( mq_receive( serverQueue, receive, sizeof( receive ), NULL ) == -1 ) {
			fail( "Server: mq_receive failed" );
		}
		// printf( "SERVER: %s\n", receive );
		//to not send a message if the report was requested
		bool send = true;
		//see if the request sent was 'move'
		if ( receive [ 0 ] == 'm' ) {
			//copy the previous state
			for ( int i = 0; i < GRID_SIZE;i++ ) {
				for ( int j = 0; j < GRID_SIZE; j++ ) {
					prevBoard [ i ][ j ] = board [ i ][ j ];
				}

			}

			//since I have the cmd in 'moverc' string form,, I need to change the 'r' and 'c' values from string to integers
			int row, col;

			row = ( int )receive [ 4 ] - '0';
			col = ( int )receive [ 5 ] - '0';

			//decimal value of the open bracket
			//this is the mask used to toggle between '*' and '.'
			int mask = MASK;

			//check where the move requested is located at the corner
			if ( ( row == FIRST_ROW || row == LAST_ROW ) && ( col == FIRSt_COL || col == LAST_COL ) ) {
				if ( row == FIRST_ROW && col == FIRSt_COL ) {
					//upper left
					board [ row + 1 ][ col ] = ( board [ row + 1 ][ col ] ) ^ mask;
					board [ row ][ col + 1 ] = ( board [ row ][ col + 1 ] ) ^ mask;
				}
				else if ( row == FIRST_ROW && col == LAST_COL ) {
					//upper right
					board [ row + 1 ][ col ] = ( board [ row + 1 ][ col ] ) ^ mask;
					board [ row ][ col - 1 ] = ( board [ row ][ col - 1 ] ) ^ mask;
				}
				else if ( row == LAST_ROW && col == FIRSt_COL ) {
					//lower left
					board [ row - 1 ][ col ] = ( board [ row - 1 ][ col ] ) ^ mask;
					board [ row ][ col + 1 ] = ( board [ row ][ col + 1 ] ) ^ mask;
				}
				else {
					//lower right
					board [ row - 1 ][ col ] = ( board [ row - 1 ][ col ] ) ^ mask;
					board [ row ][ col - 1 ] = ( board [ row ][ col - 1 ] ) ^ mask;
				}

			}
			//check where the move requested is located at the sides
			else if ( row == FIRST_ROW || row == LAST_ROW || col == FIRSt_COL || col == LAST_COL ) {
				if ( row == 0 ) {
					//top row
					board [ row + 1 ][ col ] = ( board [ row + 1 ][ col ] ) ^ mask;
					board [ row ][ col + 1 ] = ( board [ row ][ col + 1 ] ) ^ mask;
					board [ row ][ col - 1 ] = ( board [ row ][ col - 1 ] ) ^ mask;

				}
				else if ( row == LAST_ROW ) {
					//bottom row
					board [ row - 1 ][ col ] = ( board [ row - 1 ][ col ] ) ^ mask;
					board [ row ][ col - 1 ] = ( board [ row ][ col - 1 ] ) ^ mask;
					board [ row ][ col + 1 ] = ( board [ row ][ col + 1 ] ) ^ mask;
				}
				else if ( col == FIRSt_COL ) {
					//left col
					board [ row - 1 ][ col ] = ( board [ row - 1 ][ col ] ) ^ mask;
					board [ row + 1 ][ col ] = ( board [ row + 1 ][ col ] ) ^ mask;
					board [ row ][ col + 1 ] = ( board [ row ][ col + 1 ] ) ^ mask;
				}
				else {
					//right col
					board [ row - 1 ][ col ] = ( board [ row - 1 ][ col ] ) ^ mask;
					board [ row + 1 ][ col ] = ( board [ row + 1 ][ col ] ) ^ mask;
					board [ row ][ col - 1 ] = ( board [ row ][ col - 1 ] ) ^ mask;
				}
			}
			//the move requested is inner
			else {
				board [ row - 1 ][ col ] = ( board [ row - 1 ][ col ] ) ^ mask;
				board [ row + 1 ][ col ] = ( board [ row + 1 ][ col ] ) ^ mask;
				board [ row ][ col - 1 ] = ( board [ row ][ col - 1 ] ) ^ mask;
				board [ row ][ col + 1 ] = ( board [ row ][ col + 1 ] ) ^ mask;

			}
			board [ row ][ col ] = ( board [ row ][ col ] ) ^ mask;
			undo = true;
			strcpy( string, "success" );
		}
		//if the client requested to undo the previous move operation
		else if ( strcmp( "undo", receive ) == 0 ) {

			//check if a move request was made
			if ( undo ) {
				//copy the previous state
				for ( int i = 0; i < GRID_SIZE;i++ ) {
					for ( int j = 0; j < GRID_SIZE; j++ ) {
						board [ i ][ j ] = prevBoard [ i ][ j ];
					}
				}
				strcpy( string, "success" );
				undo = false;
			}
		}
		//if the user requested to report the board
		else if ( strcmp( "report", receive ) == 0 ) {
			//mq_send() the board where each row is a string
			for ( int i = 0; i < GRID_SIZE;i++ ) {
				if ( mq_send( clientQueue, board [ i ], strlen( board [ i ] ) + 1, 0 ) == -1 ) {
					perror( "Server: Error sending the message." );
					exit( EXIT_FAILURE );
				}
			}
			send = false;
		}

		//see if the report cmd was called
		if ( send ) {
			//sent the message back to client stating whether the action was successful or not
			if ( mq_send( clientQueue, string, strlen( string ) + 1, 0 ) == -1 ) {
				perror( "Server: Error sending the message." );
				exit( EXIT_FAILURE );
			}
		}
	}

	// Close our two message queues (and delete them).
	mq_close( clientQueue );
	mq_close( serverQueue );

	//unlink the two message queues
	mq_unlink( SERVER_QUEUE );
	mq_unlink( CLIENT_QUEUE );

	return EXIT_SUCCESS;
}

