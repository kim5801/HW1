//Rose Xiao
//header file for the server and client

// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/rxiao3-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/rxiao3-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5

//the macros for the first and last rows and columns
#define FIRST_ROW 0
#define FIRSt_COL 0
#define LAST_ROW 4
#define LAST_COL 4