#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

typedef struct GameBoardStruct Gameboard;

struct GameBoardStruct {
  // String containing board state
  char state[31];
  // Previous move row and columns
  int prevRow;
  int prevCol;
  // True if an undo operation has not been done for the given move
  // False otherwise
  bool undoAllowed;
};

// Toggles a given row or col of the game board
// Handles error checking if row or col is invalid
// 0 1 2 3 4 5
// 6 7 8 9 10 11
// 12 13 14 15 16 17
// 18 19 20 21 22 23
// 24 25 26 27 28 29
static void toggle(Gameboard *board, int row, int col) {
  if (row > 0 && row < 5 && col > 0 && col < 5) {
    int rowStartingIndex = 6 * row;
    int stateIndex = rowStartingIndex + col;

    if (board->state[stateIndex] == '*') {
      board->state[stateIndex] = '.';
    }
    else {
      board->state[stateIndex] = '*';
    }
  }
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main( int argc, char *argv[] ) {
  // Check args
  if (argc != 2) {
    fail("usage: server <board-file>\n");
  }

  // Open input file
  FILE *inputFile = fopen(argv[1], "r");
  if (inputFile == NULL) {
    fail("Invalid input file: filename\n");
  }

  // Create and intialize gameboard
  Gameboard *board = (Gameboard *) malloc(sizeof(Gameboard));
  board->state[0] = '\n';
  board->prevRow = 0;
  board->prevCol = 0;
  board->undoAllowed = false;
  
  // Populate struct with file contents
  char charRead = fgetc(inputFile);
  int boardStrIndex = 0;
  while (charRead != EOF) {
    if (charRead != '*' && charRead != '.' && charRead != '\n') {
      fail("Invalid input file: filename\n");
    }
    else {
      board->state[boardStrIndex] = charRead;
    }
    boardStrIndex++;
    charRead = fgetc(inputFile);
  }
  // Add null terminator
  board->state[30] = '\0';

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 3;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Repeatedly read and process client messages.
  while ( running ) {
    // Read command from client
    char buffer[MESSAGE_LIMIT];
    int len = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);
    if (len == -1) {
      fail("Problem with mq_receive: initial command\n");
    }
    
    // Move command
    if (strcmp(buffer, "move") == 0) {
      char rowString[2];
      char colString[2];

      len = mq_receive(serverQueue, rowString, sizeof(buffer), NULL);
      if (len == -1) {
        perror("");
        fail("Problem with mq_receive: move rows\n");
      }

      len = mq_receive(serverQueue, colString, sizeof(buffer), NULL);
      if (len == -1) {
        fail("Problem with mq_receive: move cols\n");
      }

      // Set to 5 to make sure that they are reset correctly by sscanf
      int row = 5;
      int col = 5;

      sscanf(rowString, "%d", &row);
      sscanf(colString, "%d", &col);


      if (row > 0 && row < 5 && col > 0 && col < 5) {
        board->prevRow = row;
        board->prevCol = col;

        // If row or col is out of bounds, toggle doesn't do anything
        toggle(board, row, col);
        toggle(board, row - 1, col);
        toggle(board, row + 1, col);
        toggle(board, row, col - 1);
        toggle(board, row, col + 1);
        board->undoAllowed = 1;

        int bytes =  mq_send(clientQueue, "success", sizeof(buffer), 0);
        if (bytes == -1) {
          fail("Could not write to message queue\n");
        }
      }
      else {
        int bytes = mq_send(clientQueue, "error", sizeof(buffer), 0);
        if (bytes == -1) {
          fail("Could not write to message queue\n");
        }
      }
    }
    // Undo command
    else if (strcmp(buffer, "undo") == 0) {
      if (board->undoAllowed) {
        int row = board->prevRow;
        int col = board->prevCol;

        toggle(board, row, col);
        toggle(board, row - 1, col);
        toggle(board, row + 1, col);
        toggle(board, row, col - 1);
        toggle(board, row, col + 1);
        board->undoAllowed = 0;

        
        int bytes = mq_send(clientQueue, "success", sizeof("success"), 0);
        if (bytes == -1) {
          fail("Could not write to message queue\n");
        }
      }
      else {
        int bytes = mq_send(clientQueue, "error", sizeof("error"), 0);
        if (bytes == -1) {
          fail("Could not write to message queue\n");
        }
      }
    }
    // Report command
    else if (strcmp(buffer, "report") == 0) {
      int bytes = mq_send(clientQueue, board->state, sizeof(board->state), 0);
      if (bytes == -1) {
        fail("Could not write to message queue\n");
      }
    }
    // Unkown command
    else {
      int bytes = mq_send(clientQueue, "error", sizeof("error"), 0);
      if (bytes == -1) {
        fail("Could not write to message queue\n");
      }
    }
  }
  

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
