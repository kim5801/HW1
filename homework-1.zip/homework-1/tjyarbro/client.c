#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail(char const *message) {
    fprintf(stderr, "%s\n", message);
    exit(1);
}

int main(int argc, char *argv[]) {

    // make sure a command-line argument was given and it is "move", "undo", or "report"
    if(argc >= 2) {
        // argv[1] is the first command
        if(strcmp("move", argv[1]) != 0 && strcmp("undo", argv[1]) != 0 && strcmp("report", argv[1]) != 0) {
            printf("error\n");
            exit(1);
        } else {
            // do nothing, the command was valid
        }
    } else {
        printf("error\n");
        exit(1);
    }

    // at this point, "move", "undo", or "report" was received
    // make sure further arguments for move are ok
    if(strcmp("move", argv[1]) == 0) {
        // the command is move
        if(argc != 4) {
            // should be exactly 4 arguments, "client", "move", "r", "c"
            printf("error\n");
            exit(1);
        }

        // check argv[2]; r
        if(strlen(argv[2]) > 1) {
            printf("error\n");
            exit(1);
        } else if(argv[2][0] >= 53 || argv[2][0] <= 47) {
            // if the character is not 0-4 it is invalid
            printf("error\n");
            exit(1);
        }

        // check argv[3]; c
        if(strlen(argv[3]) > 1) {
            printf("error\n");
            exit(1);
        } else if(argv[3][0] >= 53 || argv[3][0] <= 47) {
            // if the character is not 0-4 it is invalid
            printf("error\n");
            exit(1);
        }

    }

    // at this point all command-line arguments have been validated
    // however, the server will have the ultimate decision on whether undo is valid at this point in time

    // open the serverQueue
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY);
    // see if there was an error opening the serverQueue
    if(serverQueue == -1) {
        fail("Can't open server queue");
    }

    // send command with null terminator
    mq_send(serverQueue, argv[1], strlen(argv[1]) + 1, 0);

    // if the command is move, also send argv[2] and argv[3] with their null terminators
    if(strcmp("move", argv[1]) == 0) {
        mq_send(serverQueue, argv[2], strlen(argv[2]) + 1, 0);
        mq_send(serverQueue, argv[3], strlen(argv[3]) + 1, 0);
    }

    // open the clientQueue
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY);

    // see if there was an error opening the clientQueue
    if(clientQueue == -1) {
        fail("Can't open client queue");
    }

    // buffer to receive message
    char buffer[MESSAGE_LIMIT];

    mq_receive(clientQueue, buffer, sizeof(buffer), NULL);

    // print message received from server (server will include a new line)
    printf("%s", buffer);

    // exit with success if buffer is not error\n and close queues
    if(strcmp("error\n", buffer) != 0) {
        mq_close(serverQueue);
        mq_close(clientQueue);
        exit(0);
    } else {
        mq_close(serverQueue);
        mq_close(clientQueue);
        exit(1);
    }

}