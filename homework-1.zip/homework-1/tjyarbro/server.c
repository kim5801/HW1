#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// define a struct to hold board state
typedef struct {

  // 2D array of characters
  // the first array corresponds to the row
  // the second array corresponds to the column plus a null terminator (so each row can be used as a string)
  char boardLayout[5][6];

  // hold the last move
  int lastR;
  int lastC;

  // flag to see if the current boardState accepts an undo operation
  // initially false because no move has been made to undo
  int undoOK;

} boardState;

// Print out an error message and exit.
static void fail(char const *message) {
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// usage message and exit with error
static void usage() {
  printf("usage: server <board-file>\n");
  // exit with error
  exit(1);
}

// invalid file message and exit with error
static void badFile(char const* message) {
  printf("Invalid input file: %s\n", message);
  exit(1);
}

// define a swap method
void swap(char* swapChar) {

  if(*swapChar == '.') {
    *swapChar = '*';
  } else {
    *swapChar = '.';
  }

}

// define a move method
void move(int r, int c, boardState* board) {

  // define new variables in the + pattern for moves
  // NOTE: if up, down, left, or right is out of the range of the board, their position is not swapped
  int up = r + 1;
  int down = r - 1;
  int left = c - 1;
  int right = c + 1;

  // make initial swap
  swap(&(board->boardLayout[r][c]));

  // make sure up index is valid then swap
  if(up >= 0 && up <= 4) {
    swap(&(board->boardLayout[up][c]));
  }

  // make sure down index is valid then swap
  if(down >= 0 && down <= 4) {
    swap(&(board->boardLayout[down][c]));
  }

  // make sure left index is valid then swap
  if(left >= 0 && left <= 4) {
    swap(&(board->boardLayout[r][left]));
  }

  // make sure right index is valid then swap
  if(right >= 0 && right <= 4) {
    swap(&(board->boardLayout[r][right]));
  }

}

// define a board toString method
void boardToString(char* boardString, boardState* board) {
  // clear junk in boardString
  for(int i = 0; i < 31; i++) {
    boardString[i] = '\0';
  }

  // add board.boardLayout strings to boardString
  // NOTE: strcat null terminates the string, so boardString is null terminated after this
  for(int i = 0; i < 5; i++) {
    strcat(boardString, board->boardLayout[i]);
    strcat(boardString, "\n");
  }
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// define a signal handler for when the sigint signal is received
void sigHandler(int sig) {
  // stop running
  // i.e. set running to 0
  running = 0;
}

int main(int argc, char *argv[]) {

  // Create a sigaction struct
  struct sigaction sigAct;

  // Fill in a structure to redirect the sigint signal.
  sigAct.sa_handler = sigHandler;
  sigemptyset(&(sigAct.sa_mask));
  sigAct.sa_flags = 0;
  sigaction(SIGINT, &sigAct, 0);

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink(SERVER_QUEUE);
  mq_unlink(CLIENT_QUEUE);

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open(SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
  mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);

  if(serverQueue == -1 || clientQueue == -1) {
    fail("Can't create the needed message queues");
  }

  // check for valid command line arguments
  // should be 2 arguments, process name and the original board state
  if(argc != 2) {
    // print usage message and exit with error
    usage();
  }

  // read in original board state
  // second argument to argv should hold the name of the file location (index 1)
  int initBoardFD = open(argv[1], O_RDWR);

  // error occured if initBoardFD == -1
  if(initBoardFD == -1) {
    badFile(argv[1]);
  }

  // buffer to read input file
  char buffer[1024];

  // read input
  read(initBoardFD, buffer, 1024);

  // count through file
  int countFile;

  // flag for invalid characters; initially is set to false
  int invalidChars = 0;

  // if the file has the right amount of characters, countFile should == 30 when the loop is over
  // countFile == 30 because there are 30 characters up until the null terminator (0 - 29), but countFile is incremented again at the end of the for-loop before the coniditonal evaluates to false
  for(countFile = 0; buffer[countFile] != '\0'; countFile++) {
    // if the character is not a valid character update invalidChars to true
    if(buffer[countFile] != '.' && buffer[countFile] != '*' && buffer[countFile] != '\n') {
      invalidChars = 1;
    }
  }

  // file is invalid if countFile != 30 or invalidChars == 1
  if(countFile != 30 || invalidChars == 1) {
    badFile(argv[1]);
  }

  // char array to hold board values
  char boardChars[25];

  // used to look through the buffer
  int countBuffer = 0;

  // used to count through the chars added to boardChars
  int countBoardChars = 0;

  while(buffer[countBuffer] != '\0') {
    // add to boardChars if the character is not '\n' and update countBoardChars
    if(buffer[countBuffer] != '\n') {
      boardChars[countBoardChars] = buffer[countBuffer];
      countBoardChars++;
    }
    // move to next char in buffer
    countBuffer++;
  }

  // testing for board.boardLayout
  // printf("%s\n", buffer);
  // for(int i = 0; i < 25; i++) {
  //   printf("%c", boardChars[i]);
  //   if(i == 4 || i % 5 == 4) {
  //     printf("\n");
  //   }
  // }
  // printf("\n");

  // create new board
  boardState board;

  // initialize board from file
  for(int i = 0; i < 25; i++) {
    board.boardLayout[i / 5][i % 5] = boardChars[i];
  }

  // null terminate board values
  for(int i = 0; i < 5; i++) {
    board.boardLayout[i][5] = '\0';
  }

  // initialize undoOK to false because no move has been made yet
  board.undoOK = 0;

  // testing for board.boardLayout
  // for(int i = 0; i < 5; i++) {
  //   for(int j = 0; j < 5; j++) {
  //     printf("%c", board.boardLayout[i][j]);
  //   }
  //   printf("\n");
  // }
  // printf("\n");

  // Repeatedly read and process client messages.
  while(running) {

    // buffer to receive message
    char buffer[MESSAGE_LIMIT];

    int receiveReturn = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);

    // holds the command
    char command[MESSAGE_LIMIT];

    strcpy(command, buffer);

    // holds the string verison of r if command was move
    char rString[MESSAGE_LIMIT];

    // holds the string verison of c if command was move
    char cString[MESSAGE_LIMIT];

    // holds r if the command was move
    int r = -1;

    // holds c if the command was move
    int c = -1;

    // if the command is message, read two more messages, rString and cString respectively and store them in r and c
    if(strcmp("move", command) == 0) {
      mq_receive(serverQueue, rString, sizeof(rString), NULL);
      // know at this point that rString will be 0-4, use atoi to convert to int
      r = atoi(rString);
      mq_receive(serverQueue, cString, sizeof(cString), NULL);
      c = atoi(cString);
    }

    // execute the command
    // if "report"
    if(strcmp("report", command) == 0) {
      // 6 characters per board line (including new line) and one additional space for the null terminator
      char boardString[31];

      boardToString(boardString, &board);

      mq_send(clientQueue, boardString, strlen(boardString) + 1, 0);

    }

    // if "move"
    if(strcmp("move", command) == 0) {
      // call move with r and c
      move(r, c, &board);

      // update lastR and lastC
      board.lastR = r;
      board.lastC = c;

      // update undoOK to true
      board.undoOK = 1;

      // NOTE: if move was not okay, the client handled it

      // move was successful, send to client
      char* succ = "success\n";

      mq_send(clientQueue, succ, strlen(succ) + 1, 0);

    }

    // if "undo"
    if(strcmp("undo", command) == 0) {
      // see if undo is valid
      if(board.undoOK == 1) {

        // undo will be completed by calling move on with lastR and lastC
        move(board.lastR, board.lastC, &board);

        // update undoOK to 0 (false)
        board.undoOK = 0;
        
        // move was successful, send to client
        char* succ = "success\n";

        mq_send(clientQueue, succ, strlen(succ) + 1, 0);

      } else {
        // move was unsuccessful, send to client
        char* err = "error\n";

        mq_send(clientQueue, err, strlen(err) + 1, 0);
      }

    }

    // if anything else; i.e. -1 (mq_receive() was interrupted by the SIGINT signal)
    // do nothing!
    // running will be set to 0 and the while loop will not execute again, then the server will print the final state of the board and exit
    if(receiveReturn == -1) {
      // do nothing!
      // printf("\nreceiveReturn = -1");
    }
    
  }

  // Close our two message queues (and delete them).
  mq_close(clientQueue);
  mq_close(serverQueue);

  mq_unlink(SERVER_QUEUE);
  mq_unlink(CLIENT_QUEUE);

  // print final state of the board with initial \n
  printf("\n");
  char finalBoard[31];
  boardToString(finalBoard, &board);
  printf("%s", finalBoard);

  return 0;

}
