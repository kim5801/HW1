#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail(char const *message) {
    fprintf(stderr, "%s\n", message);
    exit(1);
}

// Print out a usage message, then exit.
static void usage() {
    printf("usage: maxsum <workers>\n");
    printf("       maxsum <workers> report\n");
    exit(1);
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
    // Set up initial list and capacity.
    vCap = 5;
    vList = (int *) malloc(vCap * sizeof(int));

    // Keep reading as many values as we can.
    int v;
    while (scanf("%d", &v) == 1) {
        // Grow the list if needed.
        if (vCount >= vCap) {
        vCap *= 2;
        vList = (int *) realloc(vList, vCap * sizeof(int));
        }

        // Store the latest value in the next array slot.
        vList[vCount++] = v;
    }
}

int main(int argc, char *argv[]) {
    bool report = false;
    int workers = 4;

    // Parse command-line arguments.
    if (argc < 2 || argc > 3)
        usage();

    if (sscanf(argv[1], "%d", &workers) != 1 ||
        workers < 1)
        usage();

    // If there's a second argument, it better be the word, report
    if (argc == 3) {
        if (strcmp(argv[2], "report") != 0)
        usage();
        report = true;
    }

    readList();

    // You get to add the rest.

    // create the pipe
    int pfd[2];

    if(pipe(pfd) != 0) {
        fail("Can't create pipe");
    }

    // create an array of pids for the children
    pid_t workerPids[workers];

    // initialize to null
    for(int i = 0; i < workers; i++) {
        workerPids[i] = '\0';
    }

    // will create at least 1 child
    pid_t pid = fork();

    // add child's pid to list
    if(pid != 0) {
        workerPids[0] = pid;
    } else {
        workerPids[0] = getpid();
    }

    // create additional children if needed
    // if you want only 1 child this loop should run 0 times,
    // if you want 2 children this loop should run 1 time, ...
    for(int i = 1; i < workers && pid != 0; i++) {
        // add child's pid to list
        pid = fork();
        workerPids[i] = pid;

        // update child's workerPids
        if (pid == 0) {
            workerPids[i] = getpid();
        }
    }

    // close reading end of the pipe for the children
    if(pid == 0) {
        close(pfd[0]);
    }

    // close parent reading end of the pipe
    if(pid != 0) {
        close(pfd[1]);
    }

    // work with children
    for(int i = 0; i < workers; i++) {

        // work with the child whose pid is workerPids[i]
        if(workerPids[i] == getpid()) {

            // index where the child starts counting
            int startIndex = i;

            // start with an initial max
            int childMaxSum = vList[i];

            // store the current sum
            int sum = 0;

            // make sure the number of workers does not excede the number of ints in the input
            // i.e. do not try to access vList[vCount]
            if(i < vCount) {

                // find the childMaxSum starting at startIndex and incrementing by the number of workers
                // i.e. worker 0 starts at index 0, then index 8, then index
                for(int j = startIndex; j < vCount; j = j + workers) {

                    // reset sum to 0
                    int sum = 0;

                    // start k at startIndex
                    // each increment will be a different sum
                    // i.e. the first loop sum will equal vCount[k]
                    // then the second loop sum will equal vCount[k] + vCount[k + 1]
                    for(int k = j; k < vCount; k++) {

                        // add next number to sum
                        sum = sum + vList[k];

                        // see if childMaxSum needs to be changed
                        if(sum > childMaxSum) {
                            // update childMaxSum
                            childMaxSum = sum;
                        }

                    }

                }

            } else {
                // this is here only to remove a compiler warning that is annoying
                sum = sum;
            }

            
            // loop to make sure all children actually did some work (use vCount instead of workers)
            for(int i = 0; i < vCount; i++) {
                if(workerPids[i] == getpid()) {
                    // check to see if this is a report
                    if(report) {
                        // if so, print required message
                        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), childMaxSum);
                    }
                    // write address of childMaxSum to the pipe
                    // first lock the pipe
                    lockf(pfd[1], F_LOCK, 0);
                    // write the starting address of the int to the pipe
                    write(pfd[1], &childMaxSum, sizeof(int));
                    // unlock the pipe
                    lockf(pfd[1], F_ULOCK, 0);
                }

            }
                
        }

    }

    // close writing ends of the pipe for the children and terminate them
    if(pid == 0) {
        close(pfd[1]);
        exit(0);
    }

    // all children should be closed here
    // if parent, wait for all children to terminate
    for(int i = 0; i < workers; i++) {
        wait(NULL);
    }

    // hold tempMaxSum (initialize to INT_MIN, the absolute minimum the max could be)
    int tempMaxSum = INT_MIN;

    // hold the real maxSum (initialize to INT_MIN, the absolute minimum the max could be)
    int maxSum = INT_MIN;
    
    // read all pointers passed into the pipe
    while(read(pfd[0], &tempMaxSum, sizeof(int))) {
        // update maxSum if needed
        if(tempMaxSum > maxSum) {
            maxSum = tempMaxSum;
        }
    }    

    // print the overall max sum
    printf("Maximum Sum: %d\n", maxSum);

    return 0;

}
