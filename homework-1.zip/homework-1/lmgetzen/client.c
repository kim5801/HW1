#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>


// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

int main(int argc, char *argv[])
{
    // Structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    if (serverQueue == -1 || clientQueue == -1) {
        fail("Can't create the needed message queues");
    }

    //message array for client
    char messageArr[MESSAGE_LIMIT];

    //Check to see if command is report for client
    if (strcmp(argv[1], "report") == 0) {
        //Send message to server
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0);

        // server sends back the board state and print out the board
        int len = mq_receive(clientQueue, messageArr, sizeof(messageArr), NULL);
        if (len >= 0) {
            //keep 30 for the new line characters and print board
            for (int i = 0; i < 30; i++) {
                printf("%c", messageArr[i]);
            }
        }
    }
    else if (strcmp(argv[1], "undo") == 0)
    {
        //send over undo command to server
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0);

        int len = mq_receive (clientQueue, messageArr, sizeof(messageArr), NULL);
        //print success for undo if successful
        if (len >= 0) {
            for (int i = 0; i < len; i++) {
                printf("%c", messageArr[i]);
            }
        }
        printf("\n");
    }
   else if (strcmp(argv[1], "move") == 0) {
        //send over move command to server
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0);
        //Send over the move coordinates
        mq_send(serverQueue, argv[2], strlen(argv[2]), 0);
        mq_send(serverQueue, argv[3], strlen(argv[3]), 0);

        //print out success after move works
        int len = mq_receive (clientQueue, messageArr, sizeof(messageArr), NULL);
        if (len >= 0) {
            for (int i = 0; i < len; i++) {
                printf("%c", messageArr[i]);
            }
        }
        printf("\n");

    }
    else {
        fail("error\n");
    }

    // close the queues
    mq_close(clientQueue);
    mq_close(serverQueue);
}