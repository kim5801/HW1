#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>



// Print out an error message and exit.
static void fail(char const *message) {
    fprintf(stderr, "%s\n", message);
    exit(1);
}

static void switchFunc(char c) {
    if (c == '.') {
        c = '*';
    }
    else if (c == '*') {
        c = '.';
    }
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;
char board[GRID_SIZE][GRID_SIZE]; // stores the 5x5 board
char ch;
bool undo = false;
bool firstMove = false;


// Signal handler for whatever SIGINT is
void ctrlCExit(int sig_num) {
    signal(sig_num, SIG_IGN);
    printf("\n");
    exit(0);
}


int main(int argc, char *argv[])
{
    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
    if (serverQueue == -1 || clientQueue == -1)
        fail("Can't create the needed message queues");

    // if invalid command lines and/or file cannot be read as it doesn't exist
    if (argc != 2) {
        fail("usage: server <board-file>");
    }
    //open input file for reading  
    FILE *input = fopen(argv[1], "r");
    
    //if input file is invalid
    if (input == NULL) {
        fprintf(stderr, "%s %s\n", "Invalid input file:", argv[1]);
        exit(1);
    }

    //establish each position in board with a either an asterisk or .
    for (int i = 0; i <= GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            ch = fgetc(input);
            if (ch == '.' || ch == '*' || ch == '\n')
                board[i][j] = ch;
            else {
                fprintf(stderr, "%s %s\n", "Invalid input file:", argv[1]);
                exit(1);
            }
        }
    }


    //save old board for undo
    char oldBoard[GRID_SIZE][GRID_SIZE];
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            oldBoard[i][j] = board[i][j];
        }
    }
    

    //handle exiting with CTRL+C
    signal(SIGINT, ctrlCExit);

    // Repeatedly read and process client messages.
    while (running)
    {
        char messageArr[MESSAGE_LIMIT]; 
        char portBoard[25];
        int inc = 0;
        //get message from 
        mq_receive(serverQueue, messageArr, sizeof(messageArr), NULL);

        printf("Got message: ");
       
        if (strcmp("report", messageArr) == 0) {    

            //put board into single array buffer so that it can be sent
            for (int i = 0; i <= GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    char ch = board[i][j];
                    portBoard[inc] = ch;
                    inc++;
                }
            }
            //send single array board
            mq_send(clientQueue, portBoard, strlen(portBoard), 0);
        }

        //if command is move
        else if (strcmp(messageArr, "move") == 0) {
            char move[MESSAGE_LIMIT];
            //get row from command
            mq_receive(serverQueue, move, sizeof(move), NULL); 
            int row = atoi(move); 
            //get col from command
            mq_receive(serverQueue, move, sizeof(move), NULL);
            int col = atoi(move);

            //switch each position
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    if (board[row][col] == '.') {
                        switchFunc(board[row - 1][col]);
                        switchFunc(board[row + 1][col]);
                        switchFunc(board[row][col + 1]);
                        switchFunc(board[row][col - 1]);
                    }
                    else if (board[row][col] == '*') {
                        switchFunc(board[row - 1][col]);
                        switchFunc(board[row + 1][col]);
                        switchFunc(board[row][col + 1]);
                        switchFunc(board[row][col - 1]);
                    }
                }    
            }  
            //get success message
            char* suc = "success";
            mq_send(clientQueue, suc, strlen(suc), 0);
        }
        //if command is undo
        else if (strcmp(messageArr, "undo") == 0) {
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    board[i][j] = oldBoard[i][j];
                }
            }

        }   
    }

    // Close our two message queues (and delete them).
    mq_close(clientQueue);
    mq_close(serverQueue);

    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    return 0;
}