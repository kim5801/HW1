/**
 * @file client.c
 * @author Cameron Himes
 * @brief Sends commands based on commandline arguments to a server on the same host to play a game.
 */

#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <mqueue.h>

// Print 'error' to indicate an error occurred, then close the queues.
void error(mqd_t serverQueue, mqd_t clientQueue) {
    printf("error\n");
    mq_close(serverQueue);
    mq_close(clientQueue);
    exit(1);
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Read in then print a message coming from the server
void printServerResponseAndExit(mqd_t serverQueue, mqd_t clientQueue) {
    char buffer[MESSAGE_LIMIT];
    mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
    printf("%s\n", buffer);

    // Close the message queues and exit
    mq_close(serverQueue);
    mq_close(clientQueue);
    exit(0);
}

int main( int argc, char *argv[] ) {
    // Open the message queues for reading and writing
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY);

    if (serverQueue == -1 || clientQueue == -1)
        fail( "Can't create the needed message queues" );

   // Check if the input is valid
   if (argc == 2) {
    // Undo command
    if (strcmp("undo", argv[1]) == 0) {
        char * cmd = "undo";
        // Send an undo request to the server
        mq_send(serverQueue, cmd, strlen(cmd), 0);

        printServerResponseAndExit(serverQueue, clientQueue);
    } 
    // Report command
    else if (strcmp("report", argv[1]) == 0) 
    {
        // Send a report request to the server
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0);

        // Read in the game board and print out its contents
        struct Game game;
        mq_receive(clientQueue, (char *) &game, MESSAGE_LIMIT, NULL);

        for (int i = 0; i < NUM_ROW_AND_COL; i++) {
            printf("%c", game.board[i][0]);
            printf("%c", game.board[i][1]);
            printf("%c", game.board[i][2]);
            printf("%c", game.board[i][3]);
            printf("%c\n", game.board[i][4]);
        }
        printf("\n");

        // Close the message queues and exit
        mq_close(serverQueue);
        mq_close(clientQueue);
        exit(0);
    } else {
        error(serverQueue, clientQueue);
    }
   } else if (argc == 4) {
        if (strcmp("move", argv[1]) != 0) {
            error(serverQueue, clientQueue);
        }
        int row;
        int col;
        // Attempt to parse the input into rows and columns, which have to be between 0 and 4 (inclusive)
        if (sscanf(argv[2], "%d", &row) != 1 || row < 0 || row > NUM_ROW_AND_COL - 1) {
            error(serverQueue, clientQueue);
        }

        if (sscanf(argv[3], "%d", &col) != 1 || col < 0 || col > NUM_ROW_AND_COL - 1) {
            error(serverQueue, clientQueue);
        }

        // Send a request to the server - concatenate the arguments into the form row|col
        char * moveRequestString = strcat(argv[2], argv[3]);
        mq_send(serverQueue, moveRequestString, strlen(moveRequestString), 0);

        // Get and print the servers response
        printServerResponseAndExit(serverQueue, clientQueue);
   } else {
    error(serverQueue, clientQueue);
   }
}
