/**
 * @file server.c
 * @author Cameron Himes
 * @brief Receives and handles client requests on the same host via a message queue then executes
 * those commands to play a game.
 */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <signal.h>

// The string sent to the client on success
#define SUCCESS_STRING "success"

// The string sent to the client on error
#define ERROR_STRING "error"

struct Game game;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Read the game board in from the given file and store the information in the game struct
void readGameBoard(char * fileName) {
  FILE *boardFptr = fopen(fileName, "r");

  if (boardFptr == NULL) {
    fprintf(stderr, "Invalid input file: %s\n\n", fileName);
    exit(1);
  }

  // Read in the file contents
  char c;
  int charsRead = 0;
  int linesRead = 0;
  while ((c = fgetc(boardFptr)) != EOF && linesRead < 5) {
    if (c == '*' || c == '.') {
      game.board[linesRead][charsRead - (linesRead * 5)] = c;
      charsRead++;
    } else if (c == '\n') {
      if (charsRead % 5 != 0) {
        // There should be 5 characters read per line
        fprintf(stderr, "Invalid input file: %s\n\n", fileName);
        exit(1);
      }
      linesRead++;
    } else if (c != 1) {
        fprintf(stderr, "Invalid input file: %s\n\n", fileName);
        exit(1);
    }
  }

  // If there are any more characters, the file format is invalid
  if (c != EOF) {
    fprintf(stderr, "Invalid input file: %s\n\n", fileName);
    exit(1);
  }
}

// Play a move on the board
void playMove(char * move, struct Game * game) {
  int row = move[0] - '0';
  int col = move[1] - '0';

  // Play the move by editing values in the game board
  game->board[row][col] = game->board[row][col] == '.'? '*': '.';

  if (row != 0) {
    game->board[row - 1][col] = game->board[row - 1][col] == '.'? '*': '.';
  }

  if (row != NUM_ROW_AND_COL - 1) {
    game->board[row + 1][col] = game->board[row + 1][col] == '.'? '*': '.';
  }

  if (col != 0) {
    game->board[row][col - 1] = game->board[row][col - 1] == '.'? '*': '.';
  }

  if (col != NUM_ROW_AND_COL - 1) {
    game->board[row][col + 1] = game->board[row][col + 1] == '.'? '*': '.';
  }

  // Update the Game struct's lastmove field
  game->lastMove = move;
}

void shutdownHandler() {
  // Print the board's state and exit
  printf("\n");
  for (int i = 0; i < 5; i++) {
    printf("%c", game.board[i][0]);
    printf("%c", game.board[i][1]);
    printf("%c", game.board[i][2]);
    printf("%c", game.board[i][3]);
    printf("%c\n", game.board[i][4]);
  }

  exit(0);
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main( int argc, char *argv[] ) {
  // Attempt to read in the game board
  if (argc != 2) {
    fail("usage: server <board-file>");
    exit(1);
  }

  game.lastMove = NULL;
  readGameBoard(argv[1]);

  // Tell the OS what to do when the user shuts down the server with Ctrl+C
  // Code adapted from course slides - 03-Processes
  struct sigaction act;

  act.sa_handler = shutdownHandler;
  sigemptyset(&(act.sa_mask));
  act.sa_flags = 0;
  sigaction(SIGINT, &act, 0);

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Repeatedly read and process client messages.
  // NOTE - Some of this code is inspired by/taken from the 'mqReceiver.c' program
  // on the course Moodle page. Credit to Dr. Sturgill.
  while ( running ) {
    // Buffer for reading in client messages
    char buffer[ MESSAGE_LIMIT ];

    // Try to get a message
    // Temporarily store the value of the game struct's last move
    // This relates to a bug where mq_receive somehow replaces
    // the value of game.lastMove with the contents of the buffer.
    // I do not know how to fix this...
    char lastMove[3];
    if (game.lastMove != NULL) {
      lastMove[0] = game.lastMove[0];
      lastMove[1] = game.lastMove[1];
      lastMove[2] = '\0';
    }
    int len = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);
    buffer[len] = '\0';

    // Copy the original value back to replace the buggy buffer value
    if (game.lastMove != NULL) {
      game.lastMove = lastMove;
    }

    if (len < 0) {
      fail("No message received from client.");
    }

    // Check which message was received and act accordingly
    if (strcmp("report", buffer) == 0) {
      mq_send(clientQueue, (const char *) &game, sizeof(game), 0);
    } else if (strcmp("undo", buffer) == 0) {
        if (game.lastMove == NULL) {
          mq_send(clientQueue, ERROR_STRING, strlen(ERROR_STRING), 0);
        } else {
          playMove(game.lastMove, &game);
          mq_send(clientQueue, SUCCESS_STRING, strlen(SUCCESS_STRING), 0);
          game.lastMove = NULL;
        }
    } else {
      playMove(buffer, &game);
      mq_send(clientQueue, SUCCESS_STRING, strlen(SUCCESS_STRING), 0);
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
