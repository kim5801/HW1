// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/cshimes-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/cshimes-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5

// The number of rows and columns in the game board
#define NUM_ROW_AND_COL 5

// Represents the game 
struct Game {
    char board[NUM_ROW_AND_COL][NUM_ROW_AND_COL];
    char * lastMove;
};
