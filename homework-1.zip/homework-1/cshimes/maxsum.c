/**
 * @file maxsum.c
 * @author Cameron Himes
 * @brief Computes the maximum contiguous sum given a list of integers.
 * 
 */

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

// Find the max subset given a list of indices to start at
void findMaxSubset(int *indices, int indicesListSize, int writeFd, bool report) {
  // Search at all of the starting indices for the greatest sum
  int maxSum = 0;
  for (int i = 0; i < indicesListSize; i++) {
    int localSum = 0;
    int currentIndex = indices[i];

    while (currentIndex < vCount) {
      localSum += vList[currentIndex];

      if (localSum > maxSum) {
        maxSum = localSum;
      }
      currentIndex++;
    }
  }

  // If the report flag is true, print your max sum
  if (report) {
    printf("I'm process %ld. The maximum sum I found is %d.\n", (long) getpid(), maxSum);
  }

  // Write your max sum to the pipe to be picked up by the parent.
  // Also lock the pipe before you write and unlock it after
  lockf( writeFd, F_LOCK, 0 );
  write(writeFd, &maxSum, sizeof(int));
  lockf( writeFd, F_ULOCK, 0 );
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.
  // Make a pipe for IPC
  int pfd[2];
  if (pipe( pfd ) != 0) {
    fail("The pipe could not be created.");
  }

  // Create the children
  for (int i = 0; i < workers; i++) {
    // Make a child process
    pid_t pid = fork();
    if ( pid == -1 )
      fail( "Child process could not be created." );

    if (pid == 0) {
      // Children will not use the reading end of the pipe - it can be closed 
      close(pfd[0]);

      // Child x of n --> search subsets of values starting at indices x, x + n, x + 2n, etc.
      // At worst, there will be 1 worker who will have to search all indices
      int indicesToSearch[vCount];
      int size = 0;
      for (int j = i; j < vCount; j += workers, size++) {
        indicesToSearch[size] = j;
      }

      findMaxSubset(indicesToSearch, size, pfd[1], report);

      // Close the remaining end of the pipe and exit
      close(pfd[1]);
      exit(0);
    }
  }

  // The parent isn't going to use the writing end of the pipe so it can be closed
  close(pfd[1]);

  // Wait for the children to exit
  int maxSum = INT_MIN;
  int childSum = 1;
  for (int i = 0; i < workers; i++) {
    wait( NULL );
    read(pfd[0], &childSum, sizeof(int));
    if (childSum > maxSum) {
      maxSum = childSum;
    }
  }

  // Report the max sum and exit
  printf("Maximum Sum: %d\n", maxSum);
  return 0;
}
