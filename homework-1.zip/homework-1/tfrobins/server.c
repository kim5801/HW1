#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
//function declarations
void loadBoard(char *file, int rows, int cols, char load[rows][cols]);
void printBoard(int rows, int cols, char load[rows][cols]);
void flip(int row, int col, char load[5][5]);
void sendBoard(char *rtn, int rows, int cols, char load[rows][cols]);

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

//When the user hits ctrl-c
void handler(int sig){
  //make room for the board
  printf("\n");
  running = 0;
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );
  
  //Ensure the correct number of arguments
  if(argc != 2){
    printf("usage: server <board-file>\n");
    return EXIT_FAILURE;
  }
  //Load in the game board from the txt file
  char board[GRID_SIZE][GRID_SIZE];
  loadBoard(argv[1], GRID_SIZE, GRID_SIZE, board);
  //variables for last move
  int lastrow;
  int lastcol;

  // Repeatedly read and process client messages.
  while ( running ) {
    //For signal interrupt
    signal(SIGINT, handler);
    //Read in the client command from the queue
    char buffer[MESSAGE_LIMIT];
    mq_receive(serverQueue, buffer, sizeof(buffer)+1, NULL);
    //Proccess the command from the queue
    bool undoallow = false;
    //Undo command
    if(strcmp(buffer, "undo") == 0){
      if(!undoallow){
        //send result
        mq_send(clientQueue, "error", sizeof("error")+1, 0);
        continue;
      }
      else{
        flip(lastrow, lastcol, board);
        undoallow = false;
        mq_send(clientQueue, "success", sizeof("success")+1, 0);
        continue;
      }
    }
    //report command
    if(strcmp(buffer, "report") == 0){
      //allocate message space
      char *msg = (char *) malloc(sizeof(char) * 31);
      //prepare msg with the board 
      sendBoard(msg, GRID_SIZE, GRID_SIZE, board);
      //send the board in the client queue
      mq_send(clientQueue, msg, sizeof(msg)+1, 0);
      //free up memory
      free(msg);
      continue;
    }
    if(strncmp(buffer, "move", 4) == 0){
      undoallow = true;
      //convert to an int
      lastrow = atoi(buffer[5]);
      lastcol = atoi(buffer[7]);
      //add move to board
      flip(lastrow, lastcol, board);
      //send success message
      mq_send(clientQueue, "success", sizeof("success"), 0);
      continue;
    }
    //if it was an invalid command
    mq_send(clientQueue, "error", sizeof("error"), 0);
  }
  //Print board after exiting loop
  printBoard(GRID_SIZE, GRID_SIZE, board);

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}

//Load in the board from the text file to the server
void loadBoard(char *file, int rows, int cols, char load[rows][cols]){
  //junk variable for the newlines
  char junk;
  int input = open(file, O_RDONLY|O_CREAT);
  for(int i=0; i<rows; i++){
    for(int j=0; j<cols; j++){
      read(input, &load[i][j], sizeof(char));
      if(load[i][j] != '.' && load[i][j] != '*'){
        printf("Invalid input file: %s\n", file);
        exit(1);
      }
    }
    read(input, &junk, sizeof(char));
  }
}

//Print out the board when requested
void printBoard(int rows, int cols, char load[rows][cols]){
  for(int i=0; i<rows; i++){
    for(int j=0; j<cols; j++){
      printf("%c", load[i][j]);
    }
    printf("\n");
  }
}

//send the board to the client
void sendBoard(char *rtn, int rows, int cols, char load[rows][cols]){
  //send into the buffer
  int index = 0;
  for(int i=0; i<rows; i++){
    for(int j=0; j<cols; j++){
      rtn[index++] = load[i][j];
    }
    rtn[index++] = '\n';
  }
  //terminate the string
  rtn[index] = '\0';
}

//Switch the position along with the others
void flip(int row, int col, char load[GRID_SIZE][GRID_SIZE]){
  //do the row first
  for(int i=col-1; i<=col+1; i++){
    if(i < 0 || i > 4){
      //edge case
      continue;
    } else if(load[row][i] == '*'){
      load[row][i] = '.';
    } else{
      load[row][i] = '*';
    }
  }
  //do the column
  for(int i=row-1; i<=row+1; i++){
    if(i < 0 || i > 4){
      //edge case
      continue;
    } else if(load[i][col] == '*'){
      load[i][col] = '.';
    } else{
      load[i][col] = '*';
    }
  }
  //flip the center again
  if(load[row][col] == '*'){
    load[row][col] = '.';
  } else{
    load[row][col] = '*';
  }
}
