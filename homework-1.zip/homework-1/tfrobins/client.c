#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

//main user input prompts
int main(int argc, char **argv)
{
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    if(argc < 2){
        printf("error\n");
        return EXIT_FAILURE;
    }
    else if(argc == 2)
    //send a one arg command
    mq_send(serverQueue, argv[1], sizeof(argv[1])+1, 0);
    //for a multi arg command
    else if(argc == 4){
        //create buffer
        char message[MESSAGE_LIMIT];
        int cursor = 0;
        //input into buffer
        for(int i=1; i<argc; i++){
            strncpy(message+cursor, argv[i], strlen(argv[i]));
            cursor += strlen(argv[i])-1;
            //add a space
            cursor++;
            strncpy(message+cursor, " ", sizeof(char));
            //move up
            cursor++;
        }
        mq_send(serverQueue, message, sizeof(message)+1, 0);
    }
    else{
        printf("error\n");
        return EXIT_FAILURE;
    }
    char answer[MESSAGE_LIMIT];
    mq_receive(clientQueue, answer, sizeof(answer)+1, NULL);
    printf("%s\n", answer);
    mq_close(serverQueue);
    mq_close(clientQueue);
    return 0;
}