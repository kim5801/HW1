/*
 * This program communicates with server.c using message keys. 
 * Client gets user commands and sends them to server to be completed
 * and then prints out the server's response.
 * @author Sophia Laciano
 * @file client.c
 */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/* A buffer for messages */
char buffer[ MESSAGE_LIMIT ];
/* An array for responses */
char response[ MESSAGE_LIMIT ];
/* An array for the string report to be printed */
char responseReport[MESSAGE_LIMIT];

/**
 * Print out an error message and exit.
 * @param message the error message to be printed.
 */
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

/** 
 * Main method of the program. Receives command line arguments in order to send
 * the correct commands to the server and adjust the game board.
 * @param argc the number of comand line arguments.
 * @param argv[] the command line arguments input from the user.
 * @return successful exit status when the program is successfully completed.
 */
int main( int argc, char *argv[] ) {

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY, &attr );
    if ( serverQueue == -1 || clientQueue == -1 ) {
        fail( "Can't create the needed message queues" );
    }

    // Move command.
    if ( strcmp( argv[ 1 ], "move" ) == 0 ) {
        // If there aren't enough command line arguments for move, fail.
        if ( argc != 4 ) {
            printf( "error\n" );
            exit( 1 );
        }
        // If the row and column input are longer then 1 character, fail.
        if ( strlen( argv[ 2 ] ) > 1 || strlen( argv[ 3 ] ) > 1 ) {
            printf( "error\n" );
            exit( 1 );
        }
        // If the row input isn't a valid row number, fail.
        if ( atoi( argv[ 2 ] ) < 0 || atoi( argv[ 2 ] ) > 4 ) {
            printf( "error\n" );
            exit( 1 );
        }
        // If the column input isn't a valid column number, fail.
        if ( atoi( argv[ 3 ] ) < 0 || atoi( argv[ 3 ] ) > 4 ) {
            printf( "error\n" );
            exit( 1 );
        }
        // Buffer message for move comand.
        char buffermove[ MESSAGE_LIMIT ];
        buffermove[0] = 'm';
        buffermove[ 1 ] = argv[ 2 ][ 0 ];        
        buffermove[ 2 ] = argv[ 3 ][ 0 ];

        // Send the message to the receiver.
        mq_send( serverQueue, buffermove, strlen( buffermove ), 0 );
        // Try to get a message for the result.
        int len = mq_receive( clientQueue, response, sizeof( response ), NULL );
        if ( len >= 0 ) {
            // Print success if command was successful.
            if ( response[ 0 ] == 's' ) {
                printf("success\n");
            }
            // Print error if command was unsuccessful.
            if ( response[ 0 ] == 'f' ) {
                printf("error\n");
                exit( 1 );
            }
        }
        else {
            fail( "Unable to receive message." );
        }
    }
    // Undo command
    else if ( strcmp( argv[ 1 ], "undo" ) == 0 ) {
        // If the amount of command line arguments is incorrect, fail.
        if ( argc != 2 ) {
            printf( "error\n" );
            exit( 1 );
        }
        // Buffer message for the undo command.
        char bufferUndo[ MESSAGE_LIMIT ];
        bufferUndo[ 0 ] = 'u';
        // Send the message to the receiver.
        mq_send( serverQueue, bufferUndo, strlen( bufferUndo ), 0 );
        // Try to get a message for the result.
        int len = mq_receive( clientQueue, response, sizeof( response ), NULL );
        if ( len >= 0 ) {
            // Print success if command was successful.
            if ( response[ 0 ] == 's' ) {
                printf("success\n");
            }
            // Print error if command was unsuccessful.
            else if ( response[ 0 ] == 'f' ) {
                printf("error\n");
                exit( 1 );
            }
            else {
                fail( "Unable to receive message." );
            }
        }
    }
    // Report command
    else if ( strcmp( argv[ 1 ], "report" ) == 0 ) {
        // If the amount of command line arguments is incorrect, fail.
        if ( argc != 2 ) {
            printf( "error\n" );
            exit( 1 );
        }
        // Buffer message for report command. 
        char bufferReport[ MESSAGE_LIMIT ];
        bufferReport[ 0 ] = 'r';
        // Send the message to the receiver.
        mq_send( serverQueue, bufferReport, strlen( bufferReport ), 0 );
        // Try to get a message for the result.
        int len = mq_receive( clientQueue, responseReport, sizeof( responseReport ), NULL );
        if ( len >= 0 ) {
            // Print out the report.
            printf( "%s", responseReport );
        }
    }
    // Invalid command, fail.
    else {
        printf( "error\n" );
        exit( 1 );
    }
    
    // Close our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );

   // mq_unlink( SERVER_QUEUE );
   // mq_unlink( CLIENT_QUEUE );

    return 0;
}