/*
 * This program communicates with client.c using message keys. 
 * Server receives commands and completes them before sending a response
 * to client to be printed out.
 * @author Sophia Laciano
 * @file server.c
 */
 
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/* Stores the board game */
char board[ 5 ][ 5 ];
/* Stores a copy of the board game before its most recent command */
char undoBoard[ 5 ][ 5 ];
/* An array for responses */
char response[ MESSAGE_LIMIT ];
/* An array for the string report to be printed */
char responseReport[ MESSAGE_LIMIT ];
/** Stores the most recent command */
//char command;
/* Is true if one move has been made on the board */
bool moveMade;
// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;
/* 1 if a move was performed, 0 if an undo just occurred */
int lastCommand;

/*
 * Print out an error message and exit.
 * @param message the error message to be printed.
 */
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

/*
 * Function called when the action goes off.
 */
void actionHandler( int sig ) {
    running = 0;
}

/** 
 * Main method of the program. Receives command line arguments in order to open
 * the correct board file. Receives messages from client.c in order to change or 
 * display the board.
 * @param argc the number of comand line arguments.
 * @param argv[] the command line arguments input from the user.
 * @return successful exit status when the program is successfully completed.
 */
int main( int argc, char *argv[] ) {
    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;                  // No special flags.
    attr.mq_maxmsg = 1;                 // 1 messages of buffer capacity.
    attr.mq_msgsize = MESSAGE_LIMIT;    // Maximum size of each message.

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 ) {
        fail( "Can't create the needed message queues" );
    }
    // Fail if there aren't the right amount of command line arguments.
    if ( argc != 2 ) {
        fail("usage: server <board-file>\n");
    }

    // Open the input file for reading.
    int fd = open( argv[ 1 ], O_RDONLY );
    // Print usage message & exit unsuccessfully if file didn't open.
    if ( fd < 0 ) {
        fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
        exit( 1 );
    }
    
    // Fill in a structure to redirect the alarm signal.
    struct sigaction act;
    act.sa_handler = actionHandler;
    sigemptyset( &( act.sa_mask ) );
    act.sa_flags = 0;
    sigaction( SIGINT, &act, 0 );
    
    // Fill in board based off file given.  
    int ind = 0;
    int ro = 0;
    int co = 0;
    // Read up to 6 bytes from the file.
    char buffer[ 6 ];
    int leng = read( fd, buffer, sizeof( buffer ) );
    while ( leng > 0 ) {
        for ( int k = 0; k < leng; k++ ) {
            if ( ( buffer[ ind ] == '*' || buffer[ ind ] == '.' ) && co != 5 ) {
                board[ ro ][ co ] = buffer[ ind ];
            }
            else if ( buffer[ ind ] == '\n' && co == 5 ) {
                co = -1;
                ro++;
            }
            // Else the characters are invalid, fail.
            else {
                fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
                exit( 1 );
            }
            ind++;
            co++; 
        }
        // Attempt to read 6 more bytes from the file.
        leng = read( fd, buffer, sizeof( buffer ) );
        ind = 0;
        co = 0;
    }
    
    // A move hasn't been made on the board yet so set this value to false;
    moveMade = false;
    
    // Repeatedly read and process client messages.
    while ( running ) {
        // Buffer for reading a message from the sender, this must be at least as large as the
        // size bound on the queue.
        char message[ MESSAGE_LIMIT ];
  
        // Try to get a message (this will wait until one arrives).
        int len = mq_receive( serverQueue, message, sizeof( message ), NULL );
        
        // If we caught the signal, print the following before killing the program.
        if ( running == 0 ) {
            printf( "\n" );
            for ( int i = 0; i < 5; i++ ) {
                for ( int j = 0; j < 5; j++ ) {
                    printf( "%c", board[ i ][ j ] );
                }
                printf( "\n" );
            }
        }

        if ( len >= 0 ) {
            // If the message is a move command, then we have made a move on the board.
            if ( message[ 0 ] == 'm' ) {
                moveMade = true;
            }
        }
        
        // Move command
        if ( message[ 0 ] == 'm' ) {
            int r = ( int )message[ 1 ] - 48;
            int c = ( int )message[ 2 ] - 48;
            lastCommand = 1;
            
            // Before making a move, update the undoBoard to match most recent board.
            for( int i = 0; i < 5; i++ ) {
                for( int j = 0; j < 5; j++ ) {
                    undoBoard[ i ][ j ] = board[ i ][ j ];
                }
            }
            // Change top first.
            if ( r - 1 >= 0 ) {
                if ( board[ r - 1 ][ c ] == '*' ) {
                    board[ r - 1 ][ c ] = '.';
                }
                else {
                    board[ r - 1 ][ c ] = '*';
                }
            }
            // Change bottom.
            if ( r + 1 <= 4 ) {
                if ( board[ r + 1 ][ c ] == '*' ) {
                    board[ r + 1 ][ c ] = '.';
                }
                else {
                    board[ r + 1 ][ c ] = '*';
                }
            }
            // Change left.
            if ( c - 1 >= 0 ) {
                if ( board[ r ][ c - 1 ] == '*' ) {
                    board[ r ][ c - 1 ] = '.';
                }
                else {
                    board[ r ][ c - 1 ] = '*';
                }
            }
            //Change right.
            if ( c + 1 <= 4 ) {
                if ( board[ r ][ c + 1 ] == '*' ) {
                    board[ r ][ c + 1 ] = '.';
                }
                else {
                    board[ r ][ c + 1 ] = '*';
                }
            }
            // Change center.
            if ( board[ r ][ c ] == '*' ) {
                board[ r ][ c ] = '.';
            }
            else {
                board[ r ][ c ] = '*';
            }
            
            // Send the message to the receiver.
            response[ 0 ] = 's';
            mq_send( clientQueue, response, strlen( response ), 0 );
            
        }
        // Undo command
        if ( message[ 0 ] == 'u' ) {
            // If we haven't made a move yet, or we just performed 'undo', send error.
            if ( moveMade == false || lastCommand == 0 ) {
                response[ 0 ] = 'f';
                mq_send( clientQueue, response, strlen( response ), 0 );
            }
            else {
                // Make board match the undoBoard (the board before most recent command).
                for( int i = 0; i < 5; i++ ) {
                    for( int j = 0; j < 5; j++ ) {
                        board[ i ][ j ] = undoBoard[ i ][ j ];
                    }
                }
                // Set lastCommand to 0 since we just performed an undo.
                lastCommand = 0;
                // Send the message to the receiver.
                response[ 0 ] = 's';
                mq_send( clientQueue, response, strlen( response ), 0 );
            }            
        }        
        // Report comand
        int s = 0;
        int t = 0;
        // Create String to send to receiver in order to print report.
        if ( message[ 0 ] == 'r' ) {
            for ( int j = 0; j < 31; j++ ) {
                if ( j == 30 ) {
                    responseReport[ j ] = '\0';
                }
                else if ( t == 5 ) {
                    responseReport[ j ] = '\n';
                    t = 0;
                    s++;
                }
                else {
                    responseReport[ j ] = board[ s ][ t ];
                    t++;
                }
            }
            lastCommand = 1;
            // Send the message to the receiver.
            mq_send( clientQueue, responseReport, strlen( responseReport ), 0 );
        }
    }

    // Close our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );

    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    return 0;
}
