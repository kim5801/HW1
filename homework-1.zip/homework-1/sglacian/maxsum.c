/*
 * This program finds the max sum from a given file of values.
 * The program utilizes children processes to find multiple max values.
 * @author Sophia Laciano
 * @file maxsum.c
 */

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

/*
 * Print out an error message and exit.
 * @param message the error message to be printed.
 */
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

/*
 * Print out a usage message, then exit.
 */
static void usage() {
    printf( "usage: maxsum <workers>\n" );
    printf( "       maxsum <workers> report\n" );
    exit( 1 );
}

/*
 * Calculate the sum of values.
 * @param indexStart the index location to start summations at.
 * @param numWorkers the number of workers to use.
 * @param valCount the number of values on the list.
 * @param valList the input sequence of values.
 */
int calculateSum( int indexStart, int numWorkers, int valCount, int *valList ) {
    int maxSum = 0;
    int currentSum = 0;
    int nextIndex = indexStart;
    while ( nextIndex < valCount ) {
        for ( int j = nextIndex; j < valCount; j++ ) {
            currentSum += valList[j];
            if ( currentSum > maxSum ) {
                maxSum = currentSum;
            }
        }
        nextIndex += numWorkers;
        currentSum = 0;
    }
    return maxSum;
}


/* Input sequence of values. */
int *vList;

/* Number of values on the list.*/
int vCount = 0;

/* Capacity of the list of values. */
int vCap = 0;

/*
 * Read the list of values.
 */
void readList() {
    // Set up initial list and capacity.
    vCap = 5;
    vList = (int *) malloc( vCap * sizeof( int ) );

    // Keep reading as many values as we can.
    int v;
    while ( scanf( "%d", &v ) == 1 ) {
        // Grow the list if needed.
        if ( vCount >= vCap ) {
            vCap *= 2;
            vList = ( int * ) realloc( vList, vCap * sizeof( int ) );
        }

        // Store the latest value in the next array slot.
        vList[ vCount++ ] = v;
    }
}

/** 
 * Main method of the program. Receives command line arguments in order to create
 * a specific number of workers to find a maximum sum. 
 * display the board.
 * @param argc the number of comand line arguments.
 * @param argv[] the command line arguments input from the user.
 * @return successful exit status when the program is successfully completed.
 */
int main( int argc, char *argv[] ) {
    bool report = false;
    int workers = 4;

    // Parse command-line arguments.
    if ( argc < 2 || argc > 3 ) {
        usage();
    }

    if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
        workers < 1 ) {
        usage();
    }

    // If there's a second argument, it better be the word, report
    if ( argc == 3 ) {
        if ( strcmp( argv[ 2 ], "report" ) != 0 ) {
            usage();
        }
        report = true;
    }

    readList();
    
    // Make a pipe for talking with the child.
    int pfd[ 2 ];
    if ( pipe( pfd ) != 0 ) {
        fail( "Can't create pipe" );
    }
    int maxSum = 0;
    int parentMaxSum = 0;
    // Iterate for every worker to perform its operation.
    for( int i = 0; i < workers; i++ ) {
        // make the child process
        pid_t id = fork();
        if ( id  < 0 ) {
            fail( "Not able to fork a child" );
        }
        // If I'm the child:
        if ( id == 0 ) {
            // I'm the child, I don't need the reading end of the pipe.
            close( pfd[ 0 ] );
            // child id
            long childId = (long)getpid();
            // Write the maxSum for this index into the pipe.
            maxSum = calculateSum( i, workers, vCount, vList);
            if ( report == true ) {
                printf( "I'm process %ld. ", childId );
                printf( "The maximum sum I found is %d.\n", maxSum );
            }
            lockf( pfd[ 1 ], F_LOCK, 0 );
            int len = write( pfd[ 1 ], &maxSum, sizeof( maxSum ) );
            if ( len < 0 ) {
                fail( "Error writing to pipe" );
            }
            lockf( pfd[ 1 ], F_ULOCK, 0 );
            // Child is done.  Exiting will close pfd[ 1 ].
            exit( 0 );
        } else {
            // I'm the parent.
            // Read bytes from the pipe. 
            int localMax = 0;
            int len = read( pfd[ 0 ], &localMax, sizeof( maxSum ) );
            if ( len < 0 ) {
                fail( "Error reading from pipe" );
            }
            
            if ( localMax > parentMaxSum ) {
                parentMaxSum = localMax;
            }
        }
    }
    close( pfd[ 1 ] );
    for (int i = 0; i < workers; i++) {
        wait(NULL);
    }
    printf("Maximum Sum: %d\n", parentMaxSum);

  return 0;
}
