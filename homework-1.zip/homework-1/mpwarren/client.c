#include <mqueue.h>
#include "common.h"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

//determines if the given character in move is a valid board position
bool isValidPos(char c){
    return c >= 48 && c <= 52;
}

mqd_t serverQueue;
mqd_t clientQueue;

//closes queues and exits program
static void fail(char * message){
    fprintf(stderr, "%s\n", message);
    mq_close(serverQueue);
    mq_close(clientQueue);
    exit(1);
}

int main(int argc, char *argv[]){

    //open the message queues
    serverQueue = mq_open(SERVER_QUEUE, O_WRONLY);
    clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY);
    char result[MESSAGE_LIMIT];

    //if move is given with the correct # of args
    if(argc == 4 && strcmp(argv[1], "move") == 0){
        //convert r and c to ints
        if(strlen(argv[2]) != 1 || strlen(argv[3]) != 1){
            fail("error");
        }
        //create message to send in the format: m##
        char buffer[MESSAGE_LIMIT + 1] = "m";
        char r = argv[2][0];
        char c = argv[3][0];
        //make sure numbers are valid
        if(isValidPos(r) && isValidPos(c)){
            buffer[1] = r;
            buffer[2] = c;
            buffer[3] = '\0';
            //send message
            mq_send(serverQueue, buffer, strlen(buffer), 0);
            printf("%s\n", "success");

        }
        else{
            fail("error");
        }

    }
    //undo was sent
    else if(argc == 2 && strcmp(argv[1], "undo") == 0){
        //send a u to server
        char buffer[MESSAGE_LIMIT + 1] = "u";
        mq_send(serverQueue, buffer, strlen(buffer), 0);
        //get result of operation
        mq_receive(clientQueue, result, MESSAGE_LIMIT, NULL);
        printf("%s\n", result);
    }
    //report was sent
    else if( argc == 2 && strcmp(argv[1], "report") == 0){
        //send r to server
        char buffer[MESSAGE_LIMIT + 1] = "r";
        mq_send(serverQueue, buffer, strlen(buffer), 0);
        //get result of operation
        mq_receive(clientQueue, result, MESSAGE_LIMIT, 0);
        //print linear version of board
        int count = 0;
        for(int i = 0; i < 5; i++){
            for(int j = 0; j < 5; j++){
                printf("%c", result[count]);
                count++;
            }
            printf("%c", '\n');
        }
    }
    else{
        fail("error");
    }

    mq_close(serverQueue);
    mq_close(clientQueue);
    exit(0);
}