#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

//global game board struct
typedef struct _board {
  char gameBoard[GRID_SIZE][GRID_SIZE];
  int prevMove[2];
  bool canUndo;
} board;

board bo;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  fflush(stderr);
  exit( 1 );
}

//fails when an invalid file is given
static void invalidFile(char *fileName){
    fprintf(stderr, "%s", "Invalid input file: ");
    fail(fileName);
}

//prints out the game board to standard output
void printBoard(){
  for(int i = 0; i < GRID_SIZE; i++){
    for(int j = 0; j < GRID_SIZE; j++){
      printf("%c", bo.gameBoard[i][j]);
    }
    printf("%s", "\n");
  }
}

//Updates the game board at the given space
void updateSpace(int r, int c){
  //only update space if its in the board
  if((r >= 0 && r <= 4) && (c >= 0 && c <= 4)){
    bo.gameBoard[r][c] = bo.gameBoard[r][c] == '.' ? '*' : '.';
  }
}

//method that preforms a move at the given space
void updateBoard(int r, int c){
  //calculate indexes of surrounding spaces
  int left[2] = {r, c - 1};
  int right[2] = {r, c + 1};
  int top[2] = {r - 1, c};
  int bottom[2] = {r + 1, c};

  //change the middle and surrounding spaces
  updateSpace(r,c);
  updateSpace(left[0],left[1]);
  updateSpace(right[0],right[1]);
  updateSpace(top[0],top[1]);
  updateSpace(bottom[0],bottom[1]);

}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

//signal handler
void signalHandler(int num){
  running = 0;
}

int main( int argc, char *argv[] ) {

  if(argc != 2){
    fail("usage: server <board-file>");
  }

  //read and create board
  FILE *boardFile = fopen(argv[1], "r");
  if(!boardFile){
    invalidFile(argv[1]);
  }
  bo.canUndo = false;

  //set up exit signal
  struct sigaction act;
  act.sa_handler = signalHandler;
  sigaction(SIGINT, &act, 0);

  //read input file and create game board
  char c;
  for(int i = 0; i < GRID_SIZE; i++){
    for(int j = 0; j < GRID_SIZE; j++){
      //read first 5 chars on a line
      c = fgetc(boardFile);
      //make sure they are . or *
      if(c != '.' && c != '*'){
        invalidFile(argv[1]);
      }
      //put in game board
      bo.gameBoard[i][j] = c;
    }
    //get the newline character, we should be at the end of the line now
    c = fgetc(boardFile);
    if(c != '\n'){
      invalidFile(argv[1]);
    }
  }
  //make sure we are at EOF
  c = fgetc(boardFile);
  if(c != EOF){
    invalidFile(argv[1]);
  }

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  //recieve first message
  char message[MESSAGE_LIMIT];
  mq_receive(serverQueue, message, MESSAGE_LIMIT, NULL);
  // Repeatedly read and process client messages.
  while ( running ) {

    //move command was sent
    if(message[0] == 'm'){
      //convert ascii value to int
      int r = message[1] - 48;
      int c = message[2] - 48;
      //update game board at that space
      updateBoard(r, c);
      bo.prevMove[0] = r;
      bo.prevMove[1] = c;
      //undo is valid after a move
      bo.canUndo = true;
    }
    //undo command was sent
    else if(message[0] == 'u'){
      //make sure we can undo
      if(bo.canUndo){
        //update board at previous spot
        updateBoard(bo.prevMove[0], bo.prevMove[1]);
        //can't undo again until player moves again
        bo.canUndo = false;
        mq_send(clientQueue, "success", sizeof("success"), 0);

      }
      else{
        mq_send(clientQueue, "error", sizeof("error"), 0);
      }
    }
    else if(message[0] == 'r'){
      //create a linear repersentation of the board to send over the message queue
      char linearBoard[26];
      int count = 0;
      for(int i = 0; i < 5; i++){
        for(int j = 0; j < 5; j++){
          linearBoard[count] = bo.gameBoard[i][j];
          count++;
        }
      }
      //send board as a string to the client
      linearBoard[25] = '\0';
      mq_send(clientQueue, linearBoard, 26, 0);
    }
    //only m, r, and u should be sent through the client. This should never get run
    else{
      fail("Unknown Error");
    }

    //wait for the next client command
    mq_receive(serverQueue, message, MESSAGE_LIMIT, NULL);

  }
  //print board on exit
  printf("%s", "\n");
  printBoard();

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
