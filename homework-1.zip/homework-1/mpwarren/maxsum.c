#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

//determines if the process running is a child
static bool isChild(int size, int *workersArr){
  for(int i = 0; i < size; i++){
    //look at if any of the pid's in the array are children (0)
    if (workersArr[i] == 0){
      return true;
    }
  }
  return false;
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;
  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.

  // make a pipe
  int pfd[2];
  if(pipe(pfd) != 0){
    fail("Can't create pipe");
  }

  //Each child will start at a different point, this counter will be incremented as more children are made
  int startingPoint = 0;
  //array to hold worker pids
  int workersArr[workers];
  //set all workers to 1 so 
  for(int i = 0 ; i < workers; i++){
    workersArr[i] = 1;
  }
  
  //create the first fork and put in array
  int pid = fork();
  if(pid < 0){
    fail("Failed to create worker");
  }
  workersArr[0] = pid;

  //loop as many times as children are needed
  for(int i = 1; i < workers; i++){
    //if this is not a child process, create a new child and put in array
    if(!isChild(workers, workersArr)){
      pid = fork();
      if(pid < 0){
        fail("Failed to create worker");
      }
      workersArr[i] = pid;
      //increment starting point so the next fork will get this incremented value
      startingPoint++;
    }
  }

  //code for child processes
  if(isChild(workers, workersArr)){
    //close reading end for children
    close(pfd[0]);

    //variable to hold the highest sum this child finds - set it to the first value it reads
    int highest = vList[startingPoint];
    //loop through the starting values for this child
    for(int i = startingPoint; i < vCount; i += workers){
      int sum = vList[i];
      //calculate sum from starting point to end of array
      for(int j = i + 1; j < vCount; j++){
        sum += vList[j];
        if(sum > highest){
          highest = sum;
        }
      }
    }
    //print out report if specified by user
    if(report){
      printf("I’m process %d. The maximum sum I found is %d.\n", getpid(), highest);
    }
    //send highest number through pipe for parent to read
    lockf(pfd[1], F_LOCK, 0 );
    write(pfd[1], &highest, 4);
    lockf(pfd[1], F_ULOCK, 0 );
    close(pfd[1]);
    exit( EXIT_SUCCESS );
  }
  //parent
  else{
    //close writing end
    close(pfd[1]);
    //wait for all children to exit
    for(int i = 0; i < workers; i++){
      wait(NULL);
    }
    //read highest values from worker and find the largest
    int readFromWorker;
    int totalHighest = INT_MIN;
    for(int i = 0; i < workers; i++){
      read(pfd[0], &readFromWorker, 4);
      if(readFromWorker > totalHighest){
        totalHighest = readFromWorker;
      }
    }
    //close reading end
    close(pfd[0]);
    //print max sum
    printf("Maximum Sum: %d\n", totalHighest);
  }

  return 0;
}


