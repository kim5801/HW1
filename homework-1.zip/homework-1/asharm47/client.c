#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <mqueue.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

/**
 * This program is the client and receives and sends
 * to make the game work properly
 * @author Arnav Sharma
 * @file client.c
 *
 */

/**
 * main method sends and recieves the args in commandline.
 * @return exit
 */
int main(int argc, char *argv[])
{
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;
    mqd_t myQueue2 = mq_open(SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    mqd_t myQueue = mq_open(CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
    char message[MESSAGE_LIMIT + 1];

    if (argc == 2 && strcmp(argv[1], "undo") == 0) {
        mq_send(myQueue2, argv[1], 1024, NULL);
        mq_receive(myQueue, message, sizeof(message), NULL);
    } else if (argc == 2 && strcmp(argv[1], "report") == 0) {
        mq_send(myQueue2, argv[1], 1024, NULL);
        mq_receive(myQueue, message, sizeof(message), NULL);
    } else if (argc == 4 && strcmp(argv[1], "move") == 0) {
        mq_send(myQueue2, argv[1], 1024, NULL);
        mq_send(myQueue2, argv[2], 1024, NULL);
        mq_send(myQueue2, argv[3], 1024, NULL);
        mq_receive(myQueue, message, sizeof(message), NULL);
    }

    mq_close(myQueue);
    mq_close(myQueue2);
    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    return 0;
}