#include <ctype.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/**
 * This program checks for the greatest sum and uses a pipe
 * @author Arnav Sharma
 * @file maxsum.c
 *
 */

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

// Print out a usage message, then exit.
static void usage()
{
    printf("usage: maxsum <workers>\n");
    printf("       maxsum <workers> report\n");
    exit(1);
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList()
{
    // Set up initial list and capacity.
    vCap = 5;
    vList = (int *)malloc(vCap * sizeof(int));

    // Keep reading as many values as we can.
    int v;
    while (scanf("%d", &v) == 1) {
        // Grow the list if needed.
        if (vCount >= vCap) {
            vCap *= 2;
            vList = (int *)realloc(vList, vCap * sizeof(int));
        }

        // Store the latest value in the next array slot.
        vList[vCount++] = v;
    }
}

/**
 * main method goes into file and compares the values and returns the sums
 * @return exit
 */
int main(int argc, char *argv[])
{
    bool report = false;
    int workers = 4;

    // Parse command-line arguments.
    if (argc < 2 || argc > 3)
        usage();

    if (sscanf(argv[1], "%d", &workers) != 1 || workers < 1)
        usage();

    // If there's a second argument, it better be the word, report
    if (argc == 3) {
        if (strcmp(argv[2], "report") != 0)
            usage();
        report = true;
    }

    readList();

    // You get to add the rest.

    // ...
    // make pipe
    int pipefd[2];

    // check is pipe is not zero and make error cases
    if (pipe(pipefd) != 0)
        fail("Cannot create a pipe");

    // go through with worker and fork each time
    for (int i = 0; i < workers; i++) {
        pid_t proc = fork();
        int oldSum = 0;
        int newSum = 0;

        // error cases
        if (proc < 0) {
            fail("No children were made");
        }

        // if worked go through and get greatest amount
        if (proc == 0) {
            for (int j = i; j < vCount; j = j + workers) {
                // make 0 every time to reset
                oldSum = 0;
                for (int l = j; l < vCount; l++) {

                    // adds them
                    oldSum = oldSum + vList[l];
                    if (newSum < oldSum) {
                        newSum = oldSum;
                    }
                }
            }
            if (report == true) {
                printf("I’m process %d. The maximum sum I found is "
                       "%d.\n",
                       getpid(), newSum);
            }
            lockf(pipefd[1], F_LOCK, 0);
            write(pipefd[1], &newSum, sizeof(int));

            lockf(pipefd[1], F_ULOCK, 0);
            close(pipefd[1]);
            exit(0);
            // child is given a range from i 0 to through whole thing, finds
            // contiguous sum if report flag is given it prints id with sum
            // writes sum to pipe
        }
    }

    // close(pipefd[1]);
    int b;
    int max = 0;
    for (int i = 0; i < workers; i++) {
        wait(NULL);
        // get greatest
        read(pipefd[0], &b, sizeof(int));
        if (max < b) {
            max = b;
        }
    }
    // print out the result
    printf("Maximum Sum: %d\n", max);
    return 0;
}
