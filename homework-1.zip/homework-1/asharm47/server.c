#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <mqueue.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

/**
 * This program is the server that makes the board, works
 * with undo, report functions, and receives and sends
 * to make the game work properly
 * @author Arnav Sharma
 * @file server.c
 *
 */

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

/**
 * main method uses an input file to copy the board in a 2d array and change it
 * @return exit
 */
int main(int argc, char *argv[])
{
    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
    if (serverQueue == -1 || clientQueue == -1)
        fail("Can't create the needed message queues");

    // Repeatedly read and process client messages.
    while (running) {
        char temp = '';
        char grid[5][5];
        // ...
        char buffer[MESSAGE_LIMIT + 1];
        mqd_t myQueue = mq_open(SERVER_QUEUE, O_WRONLY);
        if (myQueue == -1)
            fail("Can't open message queue");
        char opener[MESSAGE_LIMIT] =
            mq_recieve(clientQueue, buffer, sizeof(buffer), NULL);
        FILE *point = fopen(opener, r);
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                fscanf(pointer, "%c", temp);
                grid[i][j] = temp;
            }
        }
        mq_send(serverQueue, grid, sizeof(grid), NULL);
    }

    // Close our two message queues (and delete them).
    mq_close(clientQueue);
    mq_close(serverQueue);

    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    return 0;
}
