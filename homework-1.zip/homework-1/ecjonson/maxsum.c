/**
 * @file maxsum.c
 * @author Evan Jonson (ecjonson)
 * @author CSC 246
 * This is an exercise on divvying work among processes to perform expensive
 * tasks faster. Uses worker processes to find the maximum contiguous subset
 * in the provided integer list.
 */

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

/**
 * Print out an error message and exit.
 * @param message The failure message.
 */
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

/**
 * Print out a usage message, then exit.
 */
static void usage() {
    printf( "usage: maxsum <workers>\n" );
    printf( "       maxsum <workers> report\n" );
    exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

/**
 * Read the list of values.
 */
void readList() {
    // Set up initial list and capacity.
    vCap = 5;
    vList = (int *) malloc( vCap * sizeof( int ) );

    // Keep reading as many values as we can.
    int v;
    while ( scanf( "%d", &v ) == 1 ) {
        // Grow the list if needed.
        if ( vCount >= vCap ) {
            vCap *= 2;
            vList = (int *) realloc( vList, vCap * sizeof( int ) );
        }

        // Store the latest value in the next array slot.
        vList[ vCount++ ] = v;
    }
}

/**
 * Calculates the maximum sum from the provided start to finish.
 * @param s The starting index of the range.
 * @return The maximum sum in the provided range.
 */
static int maxSumStartingAt( int s ) {

    // tracks the current max sum in this range
    int temp = 0, max = INT_MIN;

    // check all ranges from the starting point
    for ( int f = s; f < vCount; ++f ) {

        // sum the range
        temp += vList[ f ];

        // new maximum found
        if ( temp > max )
            max = temp;
    }

    return max;
}

/**
 * Program starting point. Uses the specified number of worker processes to
 * divvy up an expensive calculation.
 * @param argc The number of command line arguments.
 * @param argv The command line arguments.
 * @return The exit status.
 */
int main( int argc, char *argv[] ) {
    bool report = false;
    int workers = 4;

    // Parse command-line arguments.
    if ( argc < 2 || argc > 3 )
        usage();

    if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
             workers < 1 )
        usage();

    // If there's a second argument, it better be the word, report
    if ( argc == 3 ) {
        if ( strcmp( argv[ 2 ], "report" ) != 0 )
            usage();
        report = true;
    }

    readList();

    // create the pipe
    int pfd[ 2 ];
    
    if ( pipe( pfd ) != 0 )
        fail( "Can't create pipe" );

    // create the workers
    for ( int i = 0; i < workers; ++i ) {

        // create a child
        pid_t pid = fork();

        if ( pid == -1 )
            fail( "Can't create child process" );

        // I'm the child
        if ( pid == 0 ) {

            // if there's no work to do, exit
            if ( i >= vCount )
                _exit( 0 );

            // close the reading end of the pipe
            close( pfd[ 0 ] );

            // tracks the current max sum in this range
            int temp, max = INT_MIN;

            // divvy the work
            for ( int j = i; j < vCount; j += workers ) {
                
                // get the max sum starting at j
                temp = maxSumStartingAt( j );

                // new max found
                if ( temp > max )
                    max = temp;
            }

            // lock the pipe
            lockf( pfd[ 1 ], F_LOCK, 0 );

            // write the max to the pipe in binary
            write( pfd[ 1 ], &max, sizeof( max ) );

            // unlock the pipe
            lockf( pfd[ 1 ], F_ULOCK, 0 );

            // report
            if ( report )
                printf( "I'm process %ld. The maximum sum I found is %d.\n", (long)getpid(), max );

            // terminate the child
            _exit( 0 );
        }
    }

    // close the writing end of the pipe
    close( pfd[ 1 ] );

    // tracks the current max sum in this range
    int temp, max = INT_MIN;

    // read from the pipe to get the max sum
    for ( int i = 0; i < workers; ++i ) {

        // wait for a child to terminate
        wait( NULL );

        // read from the pipe
        read( pfd[ 0 ], &temp, sizeof( temp ) );

        // update max
        if ( temp > max )
            max = temp;
    }

    // final report
    printf( "Maximum Sum: %d\n", max );

    // close the pipe
    close( pfd[ 0 ] );

    // free allocated memory
    free( vList );

    return 0;
}
