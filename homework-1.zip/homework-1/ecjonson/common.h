/**
 * @file common.h
 * @author Evan Jonson (ecjonson)
 * @author CSC 246
 * This is the common header file for my server/client lights out game.
 */

// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/ecjonson-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/ecjonson-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5
