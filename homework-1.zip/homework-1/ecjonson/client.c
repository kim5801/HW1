/**
 * @file client.c
 * @author Evan Jonson (ecjonson)
 * This is an exercise on IPC (inter process commumication). This is the client end.
 * Used to exicute a single command at a time, by sending a comman request to the server.
 * The server then responds to the client with an error, success message, or report.
 */

#include "common.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <mqueue.h>

// ASCII to decimal conversion difference
#define ASCII_DIFF 48

/**
 * Prints an error message, closes the message queues,
 * and exits unsuccessfully.
 * @param clientQueue The client queue to close.
 * @param serverQueue The server queue to close.
 */
static void error( mqd_t clientQueue, mqd_t serverQueue ) {
    // Close our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );

    printf( "error\n" );
    exit( EXIT_FAILURE );
}

/**
 * Prints the given message to standard error and exits
 * unsuccessfully.
 * @param msg The error message.
 */
static void fail( char const *msg ) {
    fprintf( stderr, "%s\n", msg );
    exit( EXIT_FAILURE );
}

/**
 * Program stating point. Exicutes a single command at a time, by sending a comman request to the server.
 * The server then responds to the client with an error, success message, or report.
 * @param argc The number of command line arguments.
 * @param argv The command line arguments.
 * @return The exit status.
 */
int main( int argc, char *argv[] ) {
    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY, &attr );
    if ( serverQueue == -1 || clientQueue == -1 )
        fail( "Can't create the needed message queues" );

    // check base number of arguments
    if ( argc < 2 )
        error( clientQueue, serverQueue );

    // messsage buffers
    char buffer[ MESSAGE_LIMIT ], response[ MESSAGE_LIMIT ];

    // move command
    if ( strcmp( "move", argv[ 1 ] ) == 0 ) {

        // check number of arguments, and if they are digits
        if ( argc != 4 || strlen( argv[ 2 ] ) != 1 || strlen( argv[ 3 ] ) != 1 || !isdigit( argv[ 2 ][ 0 ] ) || !isdigit( argv[ 3 ][ 0 ] ) )
            error( clientQueue, serverQueue );

        // convert to decimal
        int i = argv[ 2 ][ 0 ] - ASCII_DIFF, j = argv[ 3 ][ 0 ] - ASCII_DIFF;

        // check digit size
        if ( i >= GRID_SIZE || j >= GRID_SIZE )
            error( clientQueue, serverQueue );

        // make the command buffer
        sprintf( buffer, "move %d %d", i, j );
    }

    // undo command
    else if ( strcmp( "undo", argv[ 1 ] ) == 0 ) {

        // check number of arguments
        if ( argc != 2 )
            error( clientQueue, serverQueue );

        // make the command buffer
        sprintf( buffer, "undo" );
    }

    // report command
    else if ( strcmp( "report", argv[ 1 ] ) == 0 ) {

        // check number of arguments
        if ( argc != 2 )
            error( clientQueue, serverQueue );

        // make the command buffer
        sprintf( buffer, "report" );
    }

    // invalid command
    else
        error( clientQueue, serverQueue );

    // send the command
    if ( mq_send( serverQueue, buffer, strlen( buffer ), 0 ) == -1 )
        fail( "failed to send a message" );

    // receive a response
    if ( mq_receive( clientQueue, response, sizeof( response ), NULL ) == -1 )
        fail( "failed to receive a response" );

    // print the response
    printf( "%s\n", response );

    // Close our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );

    // exit 1 on error, 0 otherwise
    return strcmp( "error", response ) == 0;
}
