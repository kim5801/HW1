#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/**
 * @brief exits due to a failure in the code
 * 
 */
static void fail() {
    printf("error\n");
    exit(1);
}

/**
 * @brief this class takes instructions about board moves and 
 * sends communication to the server
 * 
 * @param argc number of arguments 
 * @param argv user entered parameters
 * @return int 0 if successful
 */
int main(int argc, char *argv[]) {
    //checks user input parameters valid
    //opens the two queues for reading
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);
    if ( serverQueue == -1 || clientQueue == -1 ) {
        printf("error opening queues");
        fail();
    }
    if(strcmp(argv[1], "move") == 0) {
        if(argc != 4) {
            mq_close( serverQueue );
            mq_close( clientQueue );
            fail();
        }
        int num1 = 0;
        int num2 = 0;
        if(sscanf(argv[2], "%d", &num1) == 0 || sscanf(argv[3], "%d", &num2) == 0) {
            mq_close( serverQueue );
            mq_close( clientQueue );
            fail();
        }
        //bounds check if the move is valid
        if((num1 < 0 || num1 > 4) || (num2 < 0 || num2 > 4)) {
            mq_close( serverQueue );
            mq_close( clientQueue );
            fail();
        }
        //sends the move to server for processing
        char buffer[2];
        buffer[0] = *argv[2];
        buffer[1] = *argv[3];
        //concatenate the two int into string
        mq_send( serverQueue, buffer, 2, 0 );
        char buffer2[MESSAGE_LIMIT];
        mq_receive( clientQueue, buffer2, sizeof(buffer2), NULL );
        if(buffer2[0] == '0') {
            printf("success\n");
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit(0);
        } else {
            mq_close( serverQueue );
            mq_close( clientQueue );
            fail();
        }
    } else if(strcmp(argv[1], "undo") == 0) {
        if(argc != 2) {
            mq_close( serverQueue );
            mq_close( clientQueue );
            fail();
        }
        //sends to the server to undo last
        mq_send( serverQueue, argv[1], 4, 0 );
        char buffer2[MESSAGE_LIMIT];
        mq_receive(clientQueue, buffer2, sizeof(buffer2), NULL);
        if(buffer2[0] == '0') {
            printf("success\n");
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit(0);
        } else {
            mq_close( serverQueue );
            mq_close( clientQueue );
            fail();
        }
    } else if(strcmp(argv[1], "report") == 0) {
        if(argc != 2) {
            mq_close( serverQueue );
            mq_close( clientQueue );
            fail();
        }
        //sends a report request and listens for response(an array of the board)
        mq_send( serverQueue, argv[1], 6, 0 );
        char buffer2[MESSAGE_LIMIT];
        int e = mq_receive(clientQueue, buffer2, MESSAGE_LIMIT, NULL);
        if(e < 0) {
            printf("error son \n");
            perror("the error si:\n");
            mq_close( serverQueue );
            mq_close( clientQueue );
            exit(0);
        }
        //Prints the board
        int k = 0;
        for(int i = 0; i < GRID_SIZE; i++) {
            for(int j = 0; j < GRID_SIZE; j++) {
                printf("%c", buffer2[k]);
                k++;
            }
            printf("\n");
        }
        printf("success\n");
        mq_close( serverQueue );
        mq_close( clientQueue );
        exit(0);
    } else {
        mq_close( serverQueue );
        mq_close( clientQueue );
        fail();
    }
    mq_close( serverQueue );
    mq_close( clientQueue );
    exit(0);
}