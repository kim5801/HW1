#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

/**
 * @brief Writes the second 2d array's content into the first 2d array
 * 
 * @param oldGrid the 2d array being written over
 * @param newGrid the 2d array copied
 */
static void saveGrid(char oldGrid[5][5], char newGrid[5][5]) {
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      oldGrid[i][j] = newGrid[i][j];
    }
  }
}

/**
 * @brief Sets signal for if interrupt happens
 * 
 * @param j the interrupt signal changes
 */
static void cntc(int j) {
  running = 0;
}

/**
 * @brief This class acts as a server to store the current and previous game board as well
 * as processing "undo", "move", "report" commands from the client
 * The class prints out the current board upon interrupt(exit)
 * 
 * @param argc number of user given arguments
 * @param argv user given arguments
 * @return int 0 if successful
 */
int main( int argc, char *argv[] ) {
  //checks only input file
  if ( argc < 2 || argc > 3 )
    fail("usage: server <board-file>");
  //opens the input file
  FILE *fp = fopen(argv[1], "r");
  if (!fp) {
    printf("Invalid input file: %s\n", argv[1]);
    exit(1);
  }
  //keeps track if there has been an undo
  int hasUndo = 1;
  //keeps track of previous board
  char oldArr[GRID_SIZE][GRID_SIZE];
  //2d array representing the board
  char arr[GRID_SIZE][GRID_SIZE];
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      char cha = fgetc(fp);
      if(!(cha == '.' || cha == '*')) {
        printf("Invalid input file: %s\n", argv[1]);
        exit(1);
      }
      arr[i][j] = cha;
    }
    char cha = fgetc(fp);
    if((cha != '\n')) {
        printf("Invalid input file: %s\n", argv[1]);
        exit(1);
      }
  }
  char cha = fgetc(fp);
  if(cha != EOF) {
    printf("Invalid input file: %s\n", argv[1]);
    exit(1);
  }
  //at this point the board is is known to be valid
  
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  //sets up signal
  struct sigaction act;
  act.sa_handler = cntc;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );
  // Repeatedly read and process client messages.
  while ( running ) {
    char buffer[MESSAGE_LIMIT];
    int len = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );
    //this class assumes that all messages received falls under "undo", "move", "report"
    //and that there are no incorrect messages
    if(len == 2) {
      hasUndo = 0;
      saveGrid(oldArr, arr);
      buffer[2] = '\0';
      int num1 = buffer[0] - '0';
      int num2 = buffer[1] - '0';
      //changes the grid to new grid
      if(arr[num1][num2] == '*') {
        arr[num1][num2] = '.';
      } else {
        arr[num1][num2] = '*';
      }
      if(num1 - 1 >= 0) {
        if(arr[num1 - 1][num2] == '*') {
          arr[num1 - 1][num2] = '.';
        } else {
          arr[num1 - 1][num2] = '*';
        }
      }
      if(num1 + 1 < GRID_SIZE) {
        if(arr[num1 + 1][num2] == '*') {
          arr[num1 + 1][num2] = '.';
        } else {
          arr[num1 + 1][num2] = '*';
        }
      }
      if(num2 - 1 >= 0) {
        if(arr[num1][num2 - 1] == '*') {
          arr[num1][num2 - 1] = '.';
        } else {
          arr[num1][num2 - 1] = '*';
        }
      }
      if(num2 + 1 < GRID_SIZE) {
        if(arr[num1][num2 + 1] == '*') {
          arr[num1][num2 + 1] = '.';
        } else {
          arr[num1][num2 + 1] = '*';
        }
      }
  
      //returns 1 for successful server process
      mq_send( clientQueue, "0", 1, 0 );
    } else if(len == 4) {
      //This is the undo command
      if(hasUndo == 1) {
        mq_send( clientQueue, "1", 1, 0 );
        continue;
      } else {
        //writes Old grid into new grid
        saveGrid(arr, oldArr);
        hasUndo = 1;
        mq_send(clientQueue, "0", 1, 0);
      }
    } else {
      //This is the report command
      char buffer[26];
      buffer[25] = '\0';
      int k = 0;
      //puts the 2d array into an array and sends it to client
      for(int i = 0; i < GRID_SIZE; i++) {
        for(int j = 0; j < GRID_SIZE; j++) {
          buffer[k] = arr[i][j];
          k++;
        }
      }
      mq_send(clientQueue, buffer, 30, 0);
    }
  }
  //prints current board upon exit
  printf("\n");
  for(int i = 0; i < GRID_SIZE; i++) {
    for(int j = 0; j < GRID_SIZE; j++) {
      printf("%c", arr[i][j]);
    }
    printf("\n");
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
