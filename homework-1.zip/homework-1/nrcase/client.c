#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

int main(int argc, char *argv[])
{
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY); //creates the queue to send to server 

    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 10;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make client message queues.
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    if (serverQueue == -1 || clientQueue == -1) {  
        fail("Can't create the needed message queues");
    }
    //checking the first argument
    if (strcmp(argv[1], "move") == 0) {
        //start of all the error checking
        if (argc != 4) {
            fail("error");
        }
        if (!isdigit(argv[2][0])) {
            fail("error");
        }
        if (!isdigit(argv[3][0]))
        {
            fail("error");
        }
        if (atoi(argv[2]) < 0 || atoi(argv[2]) > 4)
        {
            fail("error");
        }
        if (atoi(argv[3]) < 0 || atoi(argv[3]) > 4)
        {
            fail("error");
        }
        //send the move, then the two coordinates to the server
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0);
        mq_send(serverQueue, argv[2], strlen(argv[2]), 0);
        mq_send(serverQueue, argv[3], strlen(argv[3]), 0);
        char end[MESSAGE_LIMIT];
        mq_receive(clientQueue, end, sizeof(end), NULL ); //recieve the message given by server and print it
        printf("%s\n", end);
    } else if (strcmp(argv[1], "undo") == 0) {
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0); //prints out the value given by the server
        char end[MESSAGE_LIMIT];
        mq_receive(clientQueue, end, sizeof(end), NULL);
        printf("%s\n", end);
    } else if (strcmp(argv[1], "report") == 0) {
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0); // sending command
        for (int i = 0; i < GRID_SIZE; i++) //sending line by line
        {
            char buffer[MESSAGE_LIMIT];
            memset(buffer, 0, MESSAGE_LIMIT); //zeroing out the memory to prevent no leftover
            mq_receive(clientQueue, buffer, sizeof(buffer), NULL); 
            printf("%s", buffer);
            putchar('\n');
            memset(buffer, 0, MESSAGE_LIMIT); // zeroing out the memory to prevent no leftover
        }
    } else 
    {
        printf("error\n"); //if does fit any of the above commands, error out and return;
        return EXIT_FAILURE;
    }
    mq_close(clientQueue); //close and unline all of the message queues
    mq_close(serverQueue);
    mq_unlink(clientQueue);
    mq_unlink(serverQueue);

    return EXIT_SUCCESS;
};