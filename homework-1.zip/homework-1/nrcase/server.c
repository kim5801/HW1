#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/**
 * @brief the state of the board
 */
char board[GRID_SIZE][GRID_SIZE];
/**
 * @brief the previous state board for undo
 */
char previous[GRID_SIZE][GRID_SIZE];
/**
 * @brief variable for undo
 */
bool canUndo = false;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * @brief This is the function that 
 * handles the sigaction when control c is sent to the server
 */
void exitHandle() {
  putchar('\n');
  for (int i = 0; i < GRID_SIZE; i++) //prints out line by line
  {
    char copy[MESSAGE_LIMIT];
    memset(copy, 0, MESSAGE_LIMIT); //clears the memory
    for (int j = 0; j < GRID_SIZE; j++)
    {
      copy[j] = board[i][j]; //copies each line into a 1D array
    }
    printf("%s", copy); //prints the line 
    putchar('\n');
    memset(copy, 0, MESSAGE_LIMIT);
  }
  exit(EXIT_SUCCESS); //exits 
};


// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

/**
 * @brief Method that creates the board from the input file
 * 
 * @param board the board to fill
 * @param filename the filename to get from
 */
static void initalBoard(char board[GRID_SIZE][GRID_SIZE], char *filename) {
  FILE* input = fopen(filename, "r");

  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      int c = fgetc(input);
      if (c != '.' && c != '*' && c != '\n' && c != ' ') //if the char is not something we have in input files
      {
        printf("Invalid input file: %s\n", filename); //error
        exit(EXIT_FAILURE);
      }
        if (c == '\n' || c < 32) //if it is a new line or space, skip it and go back a iteration of the loop
        {
          j--;
          continue;
        }
        board[i][j] = c; //set char to be in the array
    }
  }
}

/**
 * @brief Takes in two coordinates and then checks 
 * that location and switches the symbol there
 * 
 * @param x the x coordinate
 * @param y the y coordinate
 */
static void switchToOther(int x, int y) {
  if (board[x][y] == '*') {
    board[x][y] = '.';
  }
  else if (board[x][y] == '.') {
    board[x][y] = '*';
  }
}

/**
 * @brief Checks to see if the up, down, middle, right and center
 * are valid spaces in the board and turns them on if they are.
 * 
 * @param x the x coordinate
 * @param y the y coordinate
 */
static void turnOn(int x, int y) { //0-4 are valid values
  if ((x >= 0 && x < 5) && (y >= 0 && y < 5)) { //middle
    switchToOther(x, y);
  } 
  if (x + 1 <= 4) { //checking right
    switchToOther(x + 1, y);
  } 
  if (x - 1 >= 0) { //checking left
    switchToOther(x - 1, y);
  } 
  if (y + 1 <= 4) { //checking up
    switchToOther(x, y+1);
  } 
  if (y - 1 >= 0) { //checking down 
    switchToOther(x, y-1);
  }
}

/**
 * @brief Saves the current board to 
 * the global variable of the previous board, used for undo
 */
static void savePrevious() {
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      previous[i][j] = board[i][j];
    }
  }
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  //checks for right arguments
  if (argc > 2) {
    fail("usage: server <board-file>");
  }

//creates the board
  initalBoard(board, argv[1]);

  //handling the control c
  struct sigaction act;
  act.sa_handler = exitHandle;
  sigemptyset(&(act.sa_mask));
  act.sa_flags = 0;
  sigaction(SIGINT, &act, 0); //creates the handling the control c

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 10;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Repeatedly read and process client messages.
  while ( running ) {

    char buffer[MESSAGE_LIMIT];

    //gets data from the server
    int len = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);
    buffer[len] = '\0';

      if (strcmp(buffer, "report") == 0) { //gets it line by line and then sends to client
        for (int i = 0; i < GRID_SIZE; i++) {
          char copy[MESSAGE_LIMIT];
          memset(copy, 0, MESSAGE_LIMIT);
          for (int j = 0; j < GRID_SIZE; j++) {
            copy[j] = board[i][j]; //copys line by line and then sends it to the client
          }
          mq_send(clientQueue, copy, strlen(buffer), 0);
        }
      } else if (strcmp(buffer, "undo") == 0) {
        if (!canUndo) { //checks to make sure that undo is possible and sends message if can't 
          char error[MESSAGE_LIMIT] = "error";
          mq_send(clientQueue, error, sizeof(error), 0);
          continue;
        }
        canUndo = false; //make sure can't do double undo

        for (int i = 0; i < GRID_SIZE; i++) {
          for (int j = 0; j < GRID_SIZE; j++) { //just replace the board with board that was saved previously
            board[i][j] = previous[i][j];
          }
        }

        char done[MESSAGE_LIMIT] = "success";
        mq_send(clientQueue, done, sizeof(done), 0); //send success message
      }
      else if (strcmp(buffer, "move") == 0) {
        char first[MESSAGE_LIMIT];
        char second[MESSAGE_LIMIT];
        memset(first, 0, MESSAGE_LIMIT);
        memset(second, 0, MESSAGE_LIMIT);
        mq_receive(serverQueue, first, sizeof(first), NULL);
        mq_receive(serverQueue, second, sizeof(second), NULL); //getting the other arguments

        int x = atoi(first); //gets the integer values from the string of the arguments given by the client
        int y = atoi(second);

        savePrevious(); //save the previous board before turning on the new lights
        turnOn(x, y); //turns on the new lighst
        canUndo = true;
        char end[MESSAGE_LIMIT] = "success"; //sending the success message
        mq_send(clientQueue, end, sizeof(end), 0 );
      }
}
// Close our two message queues (and delete them).
mq_close(clientQueue);
mq_close(serverQueue);

mq_unlink(SERVER_QUEUE);
mq_unlink(CLIENT_QUEUE);

return 0;
}
