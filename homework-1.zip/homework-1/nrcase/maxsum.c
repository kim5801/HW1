#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>
#include <unistd.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Print out a usage message, then exit.
static void usage()
{
  printf("usage: maxsum <workers>\n");
  printf("       maxsum <workers> report\n");
  exit(1);
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList()
{
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *)malloc(vCap * sizeof(int));

  // Keep reading as many values as we can.
  int v;
  while (scanf("%d", &v) == 1)
  {
    // Grow the list if needed.
    if (vCount >= vCap)
    {
      vCap *= 2;
      vList = (int *)realloc(vList, vCap * sizeof(int));
    }

    // Store the latest value in the next array slot.
    vList[vCount++] = v;
  }
}

/**
 * @brief This is what the workers call to start at their unique spot
 * in the list and then keep going based on the pattern
 * set by the number of workers
 * 
 * @param start where for the worker to start
 * @param workers the nunber of workers
 * @return int the max of sequential numbers
 */
static int checkIndexes(int start, int workers)
{
  //gets the first max
  int endMax = vList[start];
  int max = 0;
  for (int i = start; i < vCount; i = (i + workers)) //loops starting at which number worker it is, and increases by the number of workers
  {
    
    for (int j = i; j < vCount; j++) //starting at the individual start points in the pattern
    {
      max += vList[j]; //adds sequentially
      if (max > endMax) //checking for max
      {
        endMax = max;
      }
    }
    max = 0;
  }
  return endMax;
}

int main(int argc, char *argv[])
{
  //loop variable
  bool report = false;
  //number of starting workers
  int workers = 4;

  // Parse command-line arguments.
  if (argc < 2 || argc > 3)
    usage();

  if (sscanf(argv[1], "%d", &workers) != 1 ||
      workers < 1)
    usage();

  // If there's a second argument, it better be the word, report
  if (argc == 3)
  {
    if (strcmp(argv[2], "report") != 0)
      usage();
    report = true;
  }

  //reads the list in
  readList();

  // You get to add the rest.

  //checks not out of bounds
  if (workers > vCount) {
    fail("More workers than values");
  }

  //creates pipe
  int pfd[2];
  if (pipe(pfd) != 0)
    fail("Can't create pipe");

  //loop to make workers
  for (int i = 0; i < workers; i++)
  {
    int workerMax = 0;
    int pid = fork();
    if (pid == 0)
    {
      //close reading end
      close(pfd[0]);
      //get maxes
      workerMax = checkIndexes(i, workers);
      //lock for writeing
      lockf(pfd[1], F_LOCK, 0);
      //write
      write(pfd[1], &workerMax, sizeof(workerMax));
      if (report) {
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid() , workerMax );
      }
      //unlock
      lockf(pfd[1], F_ULOCK, 0);
      //exit child
      exit(EXIT_SUCCESS);
    }
  }
  for (int i = 0; i < workers; i++) { //waits for all children to exit
    wait(NULL);
  }

  //creates array to hold all the maxes of all the workers
  int array[workers];

  close(pfd[1]); //closes the end you don't need

  //reads in from the pipe of all the workers
  for (int i = 0; i < workers; i++) {
    read(pfd[0], &(array[i]), sizeof(int));
  }
  
  //looks for the total max from all the workers
  int totalMax = array[0];
  for (int i = 0; i < workers; i++) {
    if (totalMax < array[i]) {
      totalMax = array[i];
    }
  }
  //prints out the max sum
  printf("Maximum Sum: %d\n", totalMax);

  free(vList);
  return 0;
}
