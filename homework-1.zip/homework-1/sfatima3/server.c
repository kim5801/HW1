#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

char *grid [GRID_SIZE][GRID_SIZE + 1];

void cancelS(int sig) {
  sendGrid(grid, 1);
  exit(0);
}

static void changeLight(char grid[GRID_SIZE][GRID_SIZE + 1], int r, int c) {
  if ((r >= 0 && r <= 4) && (c >= 0 && c <= 4)) {
    if (grid[r][c] == '*') {
      grid[r][c] = '.';
    }
    else if (grid[r][c] == '.') {
      grid[r][c] = '*';
    }
  }
}

static void sendGrid(grid[GRID_SIZE][GRID_SIZE + 1], int isExit) {
  char *string[31];
  int count = 0;

  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 6; j++) {
      string[count] = grid[i][j];
      count++;
    }
  }

  string[count] = '\0';

  if (isExit == 0) {
    mq_send(clientQueue, string, strlen(string), 0);
  }
  else if (isExit == 1) {
    printf("%s", string);
  }
}

/*
 * Sets up the game board any takes input from the client class
 * for the lights out game.
 * @param argc number of command line arguments
 * @param argv char array of the command line arguments
 * @return success value
 */
int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  //error message for invalid input files
  char *inputFileError = "Invalid input file: ";
  inputFileError = strcat(inputFileError, argv[1]);
  
  //error message for invalid boards
  char *boardError = "usage: server <board-file>";
   
  if (argc != 2) {
    fail(boardError);
  }

  FILE *fp = fopen(argv[1], "r");
  if( !fp ) {
    fail(inputFileError);
  }
  
  //char *grid = [GRID_SIZE][GRID_SIZE + 1];
  char currentChar;
  
  for (int i = 0; i < 5; i++) {
    for (int j = 0; j < 6; j++) {
      currentChar = fgetc(fp);
      if (currentChar == '\n' && j != 5) {
        fail(inputFileError);
      }
      else if (currentChar != '*' || currentChar != '.') {
        fail(inputFileError);
      }
      grid[i][j] = currentChar;
    }
  }
  
  struct sigaction cancel;
  cancel.sa_handler = cancelS;
  int turn = 0;
  int numOfUndo = 0;
  char *success = "success";
  char *error = "error";
  int r = 0;
  int c = 0;

  // Repeatedly read and process client messages.
  while ( running ) {
    sigaction( SIGINT, &cancel, 0 );
    turn++;
    char *request[MESSAGE_LIMIT];
    mq_receive( serverQueue, request, sizeof( request ), NULL );
    if (strncmp("move", request, 4) == 0) {
      if (!isDigit(request[5]) || !isDigit(request[7])) {
        mq_send(clientQueue, error, strlen(error), 0);
        continue;
      }

      r = request[5] - '0';
      c = request[7] - '0';

	  if (!(r >= 0 && r <= 4) || !(c >= 0 && c <= 4)) {
	    mq_send(clientQueue, error, strlen(error), 0);
	    continue;
	  }

	  //reset number of undos made
	  numOfUndo = 0;

      //change light for r, c
      changeLight(grid, r, c);
      //change light for r++, c
      changeLight(grid, r++, c);
      //change light for r--, c
      changeLight(grid, r--, c);
      //change light for r, c++
      changeLight(grid, r, c++);
      //change light for r, c--
      changeLight(grid, r, c--);

      mq_send(clientQueue, success, strlen(success), 0);
    }
    else if (strcmp("undo", request) == 0) {
      if (turn < 2 || numOfUndo > 1) {
        mq_send(clientQueue, error, strlen(error), 0);
        continue;
      }

      numOfUndo++;

      //change light for r, c
      changeLight(grid, r, c);
      //change light for r++, c
      changeLight(grid, r++, c);
      //change light for r--, c
      changeLight(grid, r--, c);
      //change light for r, c++
      changeLight(grid, r, c++);
      //change light for r, c--
      changeLight(grid, r, c--);

      mq_send(clientQueue, success, strlen(success), 0);
    }
    else if (strcmp("report", request) == 0) {
      //print grid that isn't being printed in server
      sendGrid(grid, 0);
    }
    else {
      mq_send(clientQueue, error, strlen(error), 0);
    }
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
