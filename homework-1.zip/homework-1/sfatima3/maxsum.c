#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

//Find a contiguous non-empty subsequence within the sequence that has 
//the largest sum
int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  //create pipe
  int pfd[ 2 ];
  if ( pipe( pfd ) != 0 )
    fail( "Can't create pipe" );

  int numChildren = atoi(argv[ 1 ]);
  int lastIndex = vCount - 1;
  int startIndex = 0;
  int maxValue = vList[0];
  int reportChildValue = 0;

  //makes a child process as many times as the number of children requested
  for (int i = 0; i < numChildren; i++) {
    pid_t pid = fork();
    if (pid == 0) {
    
      int startForChild = startIndex;
      int endForChild = startIndex;
      int childMaxValue = 0;
      int finalChildMaxValue = vList[0];
//       printf("number: %d\n", numChildren);
//       printf("startForChild: %d\n", startForChild);
//       printf("endForChild: %d\n", endForChild);
 
      //Each child gets work that is evenly divided for each child
      while (startForChild <= lastIndex) {
//       printf("startForChild: %d\n", startForChild);
//       printf("endForChild: %d\n", endForChild);
//       printf("***");
        for (int j = startForChild; j <= endForChild; j++) {
          childMaxValue += vList[j];
        }
        //if new child max found is larger than the largest max value 
        //the child has found, then make the new largest child max
        //equal to the new one it just found
        if (finalChildMaxValue < childMaxValue) {
          finalChildMaxValue = childMaxValue;
        }
        childMaxValue = 0;
        //if end of array is reached, reset and go to the next assigned 
        //index
        if (endForChild == lastIndex) {
          startForChild += numChildren;
          endForChild = startForChild;
        }
        else {
          endForChild++;
        }
       }

      //if report in command-line, print out info about child 
      if (report) {
        printf("I’m process %d. The maximum sum I found is %d.\n", (int) getpid(), finalChildMaxValue);
      }

      //lock file, then write to file, and unlock file
      lockf( pfd[1], F_LOCK, 0 );
 
      write(pfd[1], &finalChildMaxValue, sizeof(finalChildMaxValue));

      lockf( pfd[1], F_ULOCK, 0 );
      
      _exit(0);
    }

    startIndex++;
     
    //reads in the max value from the child and checks if it is larger
    //than the existing value
    read(pfd[0], &reportChildValue, sizeof(reportChildValue));
    if (maxValue < reportChildValue) {
      maxValue = reportChildValue;
    }
  }
  while(wait( NULL ) > 0) {
    //wait
  }

  //prints out the max sum
  printf("Maximum Sum: %d\n", maxValue);

  return 0;
}
