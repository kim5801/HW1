/** 
* @file server.c
* @author Annie Lowman aklowman
*
* Server file takes care of creating the message queues in order to handle
* communication between different programs. This program keeps track of the 
* state of the game board, and performs different commands sent to it 
* from different client programs.
*/
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** Dimension of the game board*/
#define DIM 5
/** Number of expected command line arguments*/
#define NUM_ARGS 2

/** Global variable to represent the game board*/
static char gameBoard[ DIM ][ DIM ];
/** Global variable to keep track of the most recent row changed in case of undo command */
static int row;
/** Global variable to keep track of the most recent row changed in case of undo command */
static int col;

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}
/** 
* Function takes the values currently stored in gameBoard and
* row and column and inverts all * to . and all . to * 
* for all indexes directly next to the targested index
*/
static void updateGameBoard() 
{
    if (gameBoard[ row ][ col ] == '.' ) {
        gameBoard[row][col] = '*';
    } else {
        gameBoard[row][col] = '.';
    }
    
    int oneBack = row - 1;
    if (oneBack >= 0) {
        if (gameBoard[ oneBack ][ col ] == '.' ) {
            gameBoard[oneBack][col] = '*';
        } else {
            gameBoard[oneBack][col] = '.';
        }
    }
    int oneFor = row + 1;
    if (oneFor < DIM) {
        if (gameBoard[ oneFor ][ col ] == '.' ) {
            gameBoard[oneFor][col] = '*';
        } else {
            gameBoard[oneFor][col] = '.';
        }
    }
    int oneUp = col - 1;
    if (oneUp >= 0) {
        if (gameBoard[ row ][ oneUp ] == '.' ) {
            gameBoard[row][oneUp] = '*';
        } else {
            gameBoard[row][oneUp] = '.';
        }
    }
    int oneDown = col + 1;
    if (oneDown < DIM) {
        if (gameBoard[ row ][ oneDown ] == '.' ) {
            gameBoard[row][oneDown] = '*';
        } else {
            gameBoard[row][oneDown] = '.';
        }
    }
}
/** Prints out the game board */
static void printBoard() {
    printf("\n");
    for ( int i = 0; i < DIM; i++ ) {
        for( int j = 0; j < DIM; j++ ) {
            printf("%c", gameBoard[i][j]);
        }
        printf("\n");
    }
}

/**
* Citing source of lecture 3 for this code
* Tells the signal handler what to do with the signal
*/
static void killHandler( int sig ) {
    running = 0;
}


/** 
* Server programs opens up the message queues to be used to communicate between programs.
* Program reads in game board from given file, and then waits for signals from the client
* programs. Program executes given commands, and either sends a success signal back
* to the program, or an error signal if the command couldn't be executed. Program only
* exits upon ^C terminal command, in which the final game board will be printed.
*
* 
* @param argc Number of command line arguments provided
* @param argv command line arguments
* @retrun program exit status
*/
int main( int argc, char *argv[] ) {
    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

    if (argc != NUM_ARGS) {
        fail("Invalid number of arguments");
    }
    
    // open up the given file
    FILE *fp = fopen( argv[ 1 ] , "r");
    if ( fp == NULL ) {
        fprintf( stderr, "Invalid input file: " );
        fail(argv[1]);
    }
    
    // process file and add chars to the game board
    char ch;
    for ( int i = 0; i < DIM; i++ ) {
        for (int j = 0; j < DIM + 1; j++) {
            ch = fgetc( fp );
            if ( ch == EOF )  {
                if (i != DIM - 1 && j != DIM) {
                     fprintf( stderr, "Invalid input file: " );
                     fail(argv[1]);
                }
            }
            else if ( j == DIM && ch >= ' ' ) {
                 fprintf( stderr, "Invalid input file: " );
                 fail(argv[1]);
            }
            else if (ch < ' ' && j != DIM ) {
                 fprintf( stderr, "Invalid input file: " );
                 fail(argv[1]);
            }
            else if (ch != '.' && ch != '*' && ch >= ' ') {
                 fprintf( stderr, "Invalid input file: " );
                 fail(argv[1]);
            }
            if ( j != DIM ) {
                gameBoard[i][j] = ch;
            }
        }
    }

    if (ch != EOF) {
        ch = fgetc( fp );
        if (ch != EOF ) {
            fail("Invalid input file");
        }
    }
    
    fclose ( fp ); 
    
    // Citing source of lecture 3
    // create signal handler
    struct sigaction act;
    act.sa_handler = killHandler;
    sigemptyset( &( act.sa_mask ) );
    act.sa_flags = 0;
    sigaction( SIGINT, &act, 0 );
    
    // variable to keep track of whether undo command is allowed
    bool undo = false;
    
  // Repeatedly read and process client messages.
  while ( running ) {
    // read in message
    char buffer[ MESSAGE_LIMIT + 1 ];
    int len = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );
    // breaks out of loop if ^C has been signaled
    if (running == 0 ) {
        break;
    }
    
    buffer[ len ] = '\0';
    // handle report command
    if ( strcmp( "report", buffer ) == 0 ) {
        for ( int i = 0; i < DIM; i++ ) {
            char temp[ DIM + 1 ];
            for ( int j = 0; j < DIM; j++ ) {
                temp[j] = gameBoard[i][j];
            }
            temp[DIM] = '\0';
            mq_send( clientQueue, temp, strlen( temp ), 0 );
        }
    } // handle undo command
    else if ( strcmp( "undo", buffer ) == 0 ) {
        if ( undo == false ) {
            char *unsuccessful = "unsuccessful";
            mq_send( clientQueue, unsuccessful, strlen( unsuccessful ), 0 );
            
        }
        else {
            updateGameBoard();
            char *success = "success";
            mq_send( clientQueue, success, strlen( success ), 0 );
            undo = false;
        }
    } // handle move command
    else if ( strcmp( "move", buffer ) == 0 ) {
        
        int rowLen = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL ); 
        buffer[rowLen] = '\0';
        sscanf(buffer, "%d", &row ); 
        int colLen = mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );
        buffer[colLen] = '\0';
        sscanf(buffer, "%d", &col ); 
        updateGameBoard();
        
        char *success = "success";
        mq_send( clientQueue, success, strlen( success ), 0 );
        
        undo = true;
    }
  }
  
  // print out the final game board
  printBoard();
  
  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
