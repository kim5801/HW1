/** 
* @file client.c
* @author Annie Lowman aklowman
* 
* Program opens message queues in order to send and recive messages from the server program.
* Program takes in command line arguemtns, ensures that they are correct, and then relays the
* messages to the server program. The server program performs it's tasks, and then sends back 
* the end result of the action, either successful or unsuccessful.
*/
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** Minumum number of command line arguments*/
#define ARGS_MIN 2
/** Maximum number of command line arguments*/
#define ARGS_MAX 4
/** Number of rows in the game board*/
#define NUM_ROW 5
/** Upper bound of the index for the game board*/
#define UPPER_BOUND 4


/** 
* The client part of the program opens up the message queues, 
* does error checking on the command line arguments, and then passes
* them to the server if they are valid. 
* 
* @param argc Number of command line arguments provided
* @param argv command line arguments
* @retrun program exit status
*/
int main (int argc, char *argv[] ) 
{

    // check number of arguments user supplied
    if ( argc != ARGS_MIN && argc != ARGS_MAX ) {
        printf("error\n");
        exit( EXIT_FAILURE );
    }
    
    // open up message queues
    mqd_t sendToServer = mq_open( SERVER_QUEUE, O_WRONLY );
    mqd_t recieveFromServer = mq_open( CLIENT_QUEUE, O_RDONLY );
    
    if (sendToServer == -1 || recieveFromServer == -1 ) {
        fprintf( stderr, "Unable to open message queue");
        exit( 1 );
    }
    
    // handle functionality for undo
    if ( strcmp( "undo", argv[ 1 ] ) == 0 ) {
        if (argc != ARGS_MIN ) {
            printf("usage: server <board-file>");
            mq_close(sendToServer);
            mq_close(recieveFromServer);
            exit( EXIT_FAILURE );
        }
        // Citing sources for use of mq_send and mq_recive from the examples provided in class
        mq_send( sendToServer, argv[ 1 ], strlen( argv[ 1 ] ), 0 );
        char buffer[ MESSAGE_LIMIT ];
        int len = mq_receive( recieveFromServer, buffer, sizeof( buffer ), NULL );
        buffer[ len ] = '\0';
        
        if (strcmp("unsuccessful", buffer) == 0 ) {
             printf("Illegal action\n");
             mq_close(sendToServer);
             mq_close(recieveFromServer);
             exit( EXIT_FAILURE );
        }
        else if (strcmp("success", buffer) == 0 ) {
            printf("%s\n", buffer);
        }
        
    } // handle functionality for report
    else if ( strcmp( "report", argv[ 1 ] ) == 0 ) {
        if ( argc != ARGS_MIN ) {
             printf("Invalid number of arguments\n");
             mq_close(sendToServer);
             mq_close(recieveFromServer);
             exit( EXIT_FAILURE );
        }
        mq_send( sendToServer, argv[ 1 ], strlen( argv[ 1 ]), 0 );
        for ( int i = 0; i < NUM_ROW; i++ ) {
            char buffer[ MESSAGE_LIMIT ];
            int len = mq_receive( recieveFromServer, buffer, sizeof( buffer ), NULL );
            buffer[ len ] = '\0';
            printf("%s\n", buffer);
        }
    } // handle functionality for move
    else if ( strcmp("move", argv[ 1 ] ) == 0 ) {
        if ( argc != ARGS_MAX ) {
             printf("Invalid number of arguments\n");
             mq_close(sendToServer);
             mq_close(recieveFromServer);
             exit( EXIT_FAILURE );
        }
        int row;
        int result = sscanf( argv[ 2 ], "%d", &row );
        if (result != 1) {
            printf("Invalid arguments\n");
             mq_close(sendToServer);
             mq_close(recieveFromServer);
             exit( EXIT_FAILURE );
        }
        int col;
        result = sscanf( argv[ 2 ], "%d", &col );
        if (result != 1) {
            printf("Invalid arguments\n");
            mq_close(sendToServer);
            mq_close(recieveFromServer);
            exit( EXIT_FAILURE );
        }
        // checking if numbers provided are within the correct bounds
        if (row < 0 || row > UPPER_BOUND ) {
            printf("Invalid arguments\n");
            mq_close(sendToServer);
            mq_close(recieveFromServer);
            exit( EXIT_FAILURE );
        }
        
        if (col < 0 || col > UPPER_BOUND ) {
            printf("Invalid arguments\n");
            mq_close(sendToServer);
            mq_close(recieveFromServer);
            exit( EXIT_FAILURE );
        }
        
        // sending actual signal
        mq_send( sendToServer, argv[ 1 ], strlen( argv[ 1 ] ), 0); 
        mq_send( sendToServer, argv[ 2 ], strlen( argv[ 2 ] ), 0);
        mq_send( sendToServer, argv[ 3 ], strlen( argv[ 3 ] ), 0);
        
        
        char buffer[ MESSAGE_LIMIT ];
        int len = mq_receive( recieveFromServer, buffer, sizeof( buffer ), NULL );
        buffer[ len ] = '\0';
        
        if (strcmp("unsuccessful", buffer) == 0 ) {
             printf("Illegal action\n");
             mq_close(sendToServer);
             mq_close(recieveFromServer);
             exit( EXIT_FAILURE );
        }
        else if (strcmp("success", buffer) == 0 ) {
            printf("%s\n", buffer);
        }
        
    } // user did not supply a recognized command, therefor invalud
    else {
        printf("Invalid arguments provided\n");
        mq_close(sendToServer);
        mq_close(recieveFromServer);
        exit( EXIT_FAILURE );
    }
    
    mq_close(sendToServer);
    mq_close(recieveFromServer);
    exit( EXIT_SUCCESS );
}