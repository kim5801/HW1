/**
  @file client.c
  @author Lane Nickson (ldnickso)
  Homework 1 Problem 4
*/

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <time.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

int main(int argc, char *argv[])
{
  // Open the client message queue.
  mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY);
  mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY);
  if (serverQueue == -1 || clientQueue == -1)
    fail("The server is not currently running.");

  // Buffer for reading a message from the sender, this must be at least as large as the
  // size bound on the queue.
  char buffer[ MESSAGE_LIMIT ];
  

  // Initial error handling - wrong number of args
  if (argc < 2 || argc > 4)
  {
    fail("error");
  }

  // Initial error handling - invalid command prefix
  if (strcmp(argv[1], MOVE) != 0 &&
      strcmp(argv[1], UNDO) != 0 &&
      strcmp(argv[1], REPORT) != 0)
  {
    fail("error");
  }
  //Handle undo command
  if (strcmp(argv[1], UNDO) == 0 && argc == 2) {
    strcpy(buffer, UNDO);
    mq_send(serverQueue, buffer, strlen( UNDO ) + 1, 0);
  }
  //Handle report command
  else if (strcmp(argv[1], REPORT) == 0 && argc == 2) {
    strcpy(buffer, REPORT);
    mq_send(serverQueue, buffer, strlen( REPORT ) + 1, 0);
  }
  //Handle move command
  else if (strcmp(argv[1], MOVE) == 0 && argc == 4) {
  //Integer Check
    for(int i = 2; i <= 3; i++) {
      int number;
      int isNum = sscanf(argv[i], "%d", &number);
      if (isNum == 0 || number >= GRID_SIZE) {
        fail("error");
      }
    }

    //Create a string such as "MOVE 2 2" to be sent to the server. Number input is guaranteed to be valid, so 
    //the server doesn't have to worry about error checking
    strcpy(buffer, MOVE);
    strcat(buffer, " ");
    strcat(buffer, argv[2]);
    strcat(buffer, " ");
    strcat(buffer, argv[3]);
    mq_send(serverQueue, buffer, strlen( buffer ) + 1, 0);
  }
  else {
    fail("error");
  }

  //Wait for server response
  char message[ MESSAGE_LIMIT ];
  int len = mq_receive(clientQueue, message, sizeof(message), NULL);

   if ( len >= 0 ) {
    //Print server response
    printf( "%s\n", message);
  } else
    fail( "Unable to receive message." );


  // Close the queue
  // mq_close(clientQueue);
  return 0;
}
