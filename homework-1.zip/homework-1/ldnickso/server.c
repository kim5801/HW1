/**
  @file server.c
  @author Lane Nickson (ldnickso)
  @author Dr. Sturgill
  Homework 1 Problem 4
*/

//C standard libs and syscalls
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

//Star and Period symbols
#define STAR '*'
#define PERIOD '.'

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

//Handler to make sure board is printed out before server is killed
static void killHandler(int sig) {
  running = 0;
}

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Toggles the state of the cell and surrounding cells
static void makeMove(int xPos, int yPos, char (*board)[GRID_SIZE])
{
  //Update left, right, and center
  for (int i = xPos - 1; i <= xPos + 1; i++)
  {
    if (i >= 0 && i < GRID_SIZE)
    {
      if (board[i][yPos] == STAR)
      {
        board[i][yPos] = PERIOD;
      }
      else
      {
        board[i][yPos] = STAR;
      }
    }
  }
  //Update top and down
  for (int i = yPos - 1; i <= yPos + 1; i+=2) {
    if (i >= 0 && i < GRID_SIZE) {
      if (board[xPos][i] == STAR)
      {
        board[xPos][i] = PERIOD;
      }
      else
      {
        board[xPos][i] = STAR;
      }
    }
  }
}

// Convert the board array into a string to be sent to the client
static char *reportBoard(char (*board)[GRID_SIZE])
{
  // This malloc will be freed once the report is sent into the message queue.
  char *boardString = (char *)malloc((GRID_SIZE + 1) * (GRID_SIZE));
  int currentBoardX = 0;
  int currentBoardY = 0;
  //For each board tile, add its status and place newlines when needed
  for (int i = 0; i < (GRID_SIZE + 1) * (GRID_SIZE); i++)
  {
    boardString[i] = board[currentBoardX++][currentBoardY];
    if (currentBoardX == GRID_SIZE)
    {
      if (currentBoardY != GRID_SIZE - 1)
      {
        boardString[++i] = '\n';
      }
      else
      {
        // End the string with a null terminator
        boardString[++i] = '\0';
      }
      currentBoardX = 0;
      currentBoardY++;
    }
  }
  return boardString;
}

int main(int argc, char *argv[])
{

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink(SERVER_QUEUE);
  mq_unlink(CLIENT_QUEUE);

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open(SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
  mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
  if (serverQueue == -1 || clientQueue == -1)
  {
    fail("Can't create the needed message queues");
  }

  // Create the board array
  char board[GRID_SIZE][GRID_SIZE];

  // Read the input file
  int fd = open(argv[1], O_RDONLY);
  if (argc == 2 && fd != -1)
  {
    char boardBuf[(GRID_SIZE + 1) * (GRID_SIZE)];
    int count = read(fd, &boardBuf, sizeof(boardBuf));
    if (count != sizeof(boardBuf) || count == -1)
    {
      fail("usage: server <board-file>");
    }
    else
    {
      // Check to make sure all input is correct and transfer thre data to the baord[][] array
      int currentBoardX = 0;
      int currentBoardY = 0;
      for (int i = 0; i < sizeof(boardBuf); i++)
      {

        if (currentBoardX != GRID_SIZE)
        {
          // printf("%c", boardBuf[i]);
          if (boardBuf[i] != PERIOD && boardBuf[i] != STAR)
          {
            printf("Invalid input file: %s\n", argv[1]);
            exit(EXIT_FAILURE);
          }
          else
          {
            board[currentBoardX][currentBoardY] = boardBuf[i];
            currentBoardX++;
          }
        }
        else
        {
          // printf("%c", boardBuf[i]);
          if (boardBuf[i] != '\n')
          {
            printf("Invalid input file: %s\n", argv[1]);
            exit(EXIT_FAILURE);
          }
          else
          {
            currentBoardX = 0;
            currentBoardY++;
          }
        }
      }
    }
  }
  else
  {
    fail("usage: server <board-file>");
  }

  //Create the kill signal handler
  struct sigaction act;

  act.sa_handler = killHandler;
  sigemptyset( &(act.sa_mask));
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0);

  // Vars for the undo function
  bool canUndo = false;
  int prevX;
  int prevY;
  // Repeatedly read and process client messages.
  while (running)
  {
    // Create sund buffer and wait for a command from the client
    char buffer[MESSAGE_LIMIT];
    mq_receive(serverQueue, buffer, sizeof(buffer), NULL);

    // Make and send report to client with "report" command
    if (strcmp(REPORT, buffer) == 0)
    {
      char *boardString = reportBoard(board);

      // Debug
      // printf("%s", boardString);

      mq_send(clientQueue, boardString, (GRID_SIZE + 1) * (GRID_SIZE), 0);
      free(boardString);
    }
    // Make a move on the board
    else if (strncmp(MOVE, buffer, 4) == 0)
    {
      int x;
      int y;
      sscanf(buffer, "%*s%d %d", &y, &x);
      //printf("%d %d\n", x, y);
      makeMove(x, y, board);
      prevX = x;
      prevY = y;
      canUndo = true;
      mq_send(clientQueue, "success", sizeof("success"), 0);
    }
    // Undo a previous move on the board (if possible)
    else if (strcmp(UNDO, buffer) == 0)
    {
      if (canUndo)
      {
        // Revert to old board by making the same move again
        makeMove(prevX, prevY, board);
        mq_send(clientQueue, "success", sizeof("success"), 0);
        canUndo = false;
      }
      else
      {
        mq_send(clientQueue, "error", sizeof("error"), 0);
      }
    }
  }

  //Print the board
  char *boardString = reportBoard(board);
  printf("\n%s\n", boardString);
  free(boardString);

  // Close our two message queues (and delete them).
  mq_close(clientQueue);
  mq_close(serverQueue);

  mq_unlink(SERVER_QUEUE);
  mq_unlink(CLIENT_QUEUE);

  return 0;
}
