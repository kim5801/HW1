#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//evaluates if the string is made up only of digits
bool isNumber( char *input ) {  
  int i = 0;
  while( input[ i ] ) {
    if( input[ i ] < '0' || input[ i ] > '9' ) {
      return false;
    }
    i++;
  }
  return true;
}

int main( int argc, char *argv[] ) {
  if( argc <= 1 ) {
    fail( "error" );
  }

  //move r c, undo, report
  char *cmd = argv[ 1 ];
  char receiveMsg[ MESSAGE_LIMIT ];

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY, 0600, &attr );
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  if( strcmp( cmd, "move" ) == 0 ) { //move r c
    if( argc != 4 ) {
      fail( "error" );
    }

    //check if valid row and column inputs    
    if( !isNumber( argv[ 2 ]) || !isNumber( argv[ 3 ] ) ) {      
      fail( "error" );
    }
    
    int r = atoi( argv[ 2 ] );    
    int c =  atoi( argv[ 3 ] );    
    if( r < 0 || r > 4 || c < 0 || c > 4 ) {
      fail( "error" );
    }
    
    //     The client will send the server a message indicating the requested move, and
    // the server should send the client a response indicating success or failure of the request. Before
    // terminating, the client will print out “success” if the command succeeded, or “error” if it failed.

    sprintf( cmd, "%s %s %s", cmd, argv[ 2 ], argv[ 3 ] );
    
    int len = mq_send( serverQueue, cmd, strlen( cmd ), 0 );   
    if( len < 0 ) {
      fail( "Can't send msg in client\n");
    }

    len = mq_receive( clientQueue, receiveMsg, sizeof( receiveMsg ), NULL );
    if( len < 0 ) {
      fail( "Can't receive msg in client\n" );
    }
    printf( "%s\n", receiveMsg );

  } else if( strcmp( cmd, "undo" ) == 0 ) {
      //     This command requests the sever to undo the most recent move. The server is expected to keep
      // a one-move undo history, so this command is invalid if no move has been made yet, or if the most
      // recent move has already been undone. The server will send back a response indicating the success
      // of the command, and the client will print out either “success” or “error”, like it does with the
      // move command.
    mq_send( serverQueue, cmd, strlen( cmd ), 0 );
    mq_receive( clientQueue, receiveMsg, sizeof( receiveMsg ), NULL );
    printf("%s\n", receiveMsg );

  } else if( strcmp( cmd, "report" ) == 0) {
    //     When the user enters this command, the client will request a report of the current state of the
    // board. It will print it out as a 5 × 5 square of ’.’ and ’*’ characters, just like the contents of a
    // board input file. The client doesn’t need to print out “success” and “error” for this command;
    // the printout of the board will show that the command was successful.
    mq_send( serverQueue, cmd, strlen( cmd ), 0 );
    for( int i = 0; i < GRID_SIZE; i++ ) {
      mq_receive( clientQueue, receiveMsg, sizeof( receiveMsg ), NULL );
      printf("%s\n", receiveMsg );
    }
    printf( "\n" );
  } else {
    fail( "error" );
  }
  mq_close( clientQueue );
  mq_close( serverQueue );

  return 0;
}
