#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();
  
  int localSum = 0;  //keeps track of sum for current partition
  int maxSum = 0; //total sum for whole list
  
  int pfd[ 2 ];
  pid_t id[ workers ]; //create shared pipe
  if( pipe( pfd ) != 0 ) {
    fail( "Can't create pipe" );
  }
  //split up counting for each worker
  for( int i = 0; i < workers; i++ ) { 
    
    id[ i ] = fork(); //create a new worker/child
    if( id[ i ] < 0 ) {
      fail( "Not able to fork a child" );
    }

    if( id[ i ] == 0 ) { //child
      close( pfd[ 0 ] ); //close reading end of pipe

      int topSum = 0;
      int partCount = vCount / workers; //number of partitions for each worker
      int partNum = 1; //keeps track of current partition number
      
      int j = i;
      while( j < vCount ) {
        localSum += vList[ j ];
        if( localSum > topSum ) {
          topSum = localSum;
        }

        //once the end of the array is reached and the worker still has more partitions to count,
        //start at the next partition and count up again
        if( j == vCount - 1 && partCount != 0 ) {
          partCount--;
          j = i + workers * partNum;
          localSum = 0; //reset sum for new partition
          partNum++;
          continue;
        } else {
          j++;
        }
        
      }
      if( report ) {
        printf( "I'm process %d. The maximum sum I found is %d.\n", getpid(), topSum );
      }      

      //send the top sum to the parent
      lockf( pfd[ 1 ], F_LOCK, 0 );
      int len = write( pfd[ 1 ], &topSum, sizeof( int ) );
      lockf( pfd[ 1 ], F_ULOCK, 0 );
      if( len < 0 ) {
        fail( "Error writing to pipe" );
      }
      

      exit( 0 );

    }
   
 
  }
  close( pfd[ 1 ] ); //now that the workers are done, we can close the writing end
	
	

  for( int i = 0; i < workers; i++ ) { //collect all of the workers at once
   //find total sum from all of the workers by reading the pipe    
    int childTopSum = 0;
    //read current child's top sum
    int len = read( pfd[ 0 ], &childTopSum, sizeof( int ) );
    if( len < 0 ) {
      fail( "Error reading from the pipe" );
    }

    if( childTopSum > maxSum ) {
      maxSum = childTopSum;
    } 
    wait( NULL );
  }

  printf( "Maximum Sum: %d\n", maxSum );


  return 0;
}
