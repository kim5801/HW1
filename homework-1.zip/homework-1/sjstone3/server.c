#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
  Takes in the buffer message and seperates it into each command
  For "move" there are 3 inputs, which is why the returned array is size 3
  @param buffer the string being proccessed
  @param cmd the given buffer but split into an array for each input
*/
void processBuffer( char *buffer, char cmd[ 3 ][ MESSAGE_LIMIT ] ) {
  char ch;
  int wordCount = 0; //number of inputs
  int i = 0; //current letter count in current word
  int letterCount = 0;  
  
  while( ( ch = buffer[ i ] ) ) {    
    if( ch == ' ') {
      wordCount++;
      letterCount = 0;
    } else {
      cmd[ wordCount ][ letterCount ] = ch;
      letterCount++;    
    }    
    i++;
  }  
}

/**
  Switches the lights on/off at the given coordinate, left, right, above and below
  @param r rows
  @param c columns
  @param board the board being modified
*/
void move( int r, int c, char board[ GRID_SIZE ][ GRID_SIZE ] ) {
 
  char change = ( board[ r ][ c ] == '*' ? '.' : '*' ); //given coord
  board[ r ][ c ] = change;

  if( r + 1 < GRID_SIZE && r + 1 >= 0 ) { //top of coords
    change = ( board[ r + 1 ][ c ] == '*' ? '.' : '*' );
    board[ r + 1 ][ c ] = change;
  }

  if( r - 1 < GRID_SIZE && r - 1 >= 0 ) { //bottom of coords
    change = ( board[ r - 1][ c ] == '*' ? '.' : '*' );
    board[ r - 1 ][ c ] = change;
  }

  if( c + 1 < GRID_SIZE && c + 1 >= 0 ) { //right of coords
    change = ( board[ r ][ c + 1 ] == '*' ? '.' : '*' );
    board[ r ][ c + 1 ] = change;
  }

  if( c - 1 < GRID_SIZE && c - 1 >= 0 ) { //left of coords
    change = ( board[ r ][ c - 1 ] == '*' ? '.' : '*' );
    board[ r ][ c - 1 ] = change;
  }
}

/**
  Sends out the given game board to the client
*/
void reportBoard( char board[ GRID_SIZE ][ GRID_SIZE ], mqd_t clientQueue ) {
  for( int i = 0; i < GRID_SIZE; i++ ) {
    mq_send( clientQueue, board[ i ], GRID_SIZE, 0 );
  }  
}

/**
  Clears the passed in string and replaces all the chars with null terminators
  This helps when recieving messages from the client so messages from the last sent
  aren't still on it
  @param buffer the buffer being cleared
*/
void clearBuffer( char buffer[ MESSAGE_LIMIT ] ) {
  for( int i = 0; i < MESSAGE_LIMIT; i++ ) {
    buffer[ i ] = '\0';
  }
}

/**
  Takes in a file and stores each of the characters into the gameboard array
  Detects if there's any errors in the file format
  @param file the file being read
  @param filename the name of the input file
  @param board the board where the * and . chars are stored for the game
*/
void readBoard( FILE *file, char *filename, char board[ GRID_SIZE ][ GRID_SIZE ] ) {
  char currCh = '0';
  int rows = 0;
  int columns = 0;

  //read in board from file
  while( currCh != EOF ) { 
    currCh = fgetc( file );    
    if( currCh == '*' || currCh == '.' ) {
      
      board[ rows ][ columns ] = currCh;
      columns++;      
    } else if( currCh == '\n' ) { 
      //too many or too few columns     
      if( columns != GRID_SIZE ) {
        fprintf( stderr, "columns Invalid input file: %s\n", filename );
        exit( 1 );
      }
      rows++;
      columns = 0;
    } else if( currCh == EOF ) {
      continue;
    } else { //invalid character
      fprintf( stderr, "Invalid input file: %s\n", filename );
      exit( 1 );
    }
  }
  //too many or too few rows
  if( rows != GRID_SIZE ) {
    fprintf( stderr, "%d", rows );      
    fprintf( stderr, "rows Invalid input file: %s\n", filename );
    exit( 1 );
  }
  
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

void sigintHandler( int sig ) {
  running = 0;
}

int main( int argc, char *argv[] ) {
  //handles SIGINT so ending gameboard can be printed
  struct sigaction act;
  act.sa_handler = sigintHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;  

  if( argc != 2 ) {
    fail( "usage: server <board-file>" );
  }
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues\n" );

  char board [ GRID_SIZE ][ GRID_SIZE ];  
  char oldBoard [ GRID_SIZE ][ GRID_SIZE ];

  
  //read the file and put it into the board file
  FILE *file = fopen( argv[ 1 ], "r" );
  if( file == 0 ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
  }
  
  readBoard( file, argv[ 1 ], board );

  int lastUndo = false; //true if the client used the "undo" cmd on last turn
  int numMoves = 0; //counts number of moves, used to check for error in undo if no moves have been made

  //copy current board state into the old board to maintain history
  memcpy( oldBoard, board, sizeof( char ) * GRID_SIZE * GRID_SIZE );  
  char buffer[ MESSAGE_LIMIT ]; //buffer for receiving commands  
  char cmd[ 3 ][ MESSAGE_LIMIT ]; //stores max of 3 commands
  
  char error[] = "error"; //used for sending msgs to client
  char success[] = "success";

  // Repeatedly read and process client messages.  
  while ( running ) {
    sigaction( SIGINT, &act, 0 );
    clearBuffer( buffer ); //get rid of any garbage
    clearBuffer( cmd[ 0 ] );
    mq_receive( serverQueue, buffer, sizeof( buffer ), NULL );

    processBuffer( buffer, cmd );
    char *command = cmd[ 0 ];
    
    ///***MOVE***///
    if( strcmp( "move", command ) == 0 ) { 
      int row = atoi( cmd[ 1 ] );
      int column = atoi( cmd[ 2 ] );

      //store current board as the last step before move operation
      memcpy( oldBoard, board, sizeof( char ) * GRID_SIZE * GRID_SIZE );
      move( row, column, board );
      mq_send( clientQueue, success, strlen( success ), 0 );
      //do the move command on current gameboard, update old gameboard
      numMoves++;
      lastUndo = false;

    ///***UNDO***///
    } else if( strcmp( "undo", command ) == 0 ) {
      if( lastUndo || numMoves == 0) {
        mq_send( clientQueue, error, strlen( error ), 0 );        
      } else {
        //load in last gameboard
        //send success
        lastUndo = true;
        memcpy( board, oldBoard, sizeof( char ) * GRID_SIZE * GRID_SIZE );
        mq_send( clientQueue, success, strlen( success ), 0 );       
      }
    ///***REPORT***///
    } else if( strcmp( "report", command ) == 0 ) {      
      reportBoard( board, clientQueue );      
    }
  }

  //print the board state after exit
  printf( "\n" );
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      printf("%c", board[ i ][ j ] );
    }
    printf( "\n" );
  }

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
