#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Maximum value discovered.
int maxGlobal;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
* Finds the maximum sum from a sequence of integers passed through to the function.
* @param array the array of numbers to sort through and find our maximum sequence sum
* @return the value of the maximum sequence
*/
int findMax( int startIndex, int numProcesses ) {
  //Set retVal to the first element in the array just in case all values are less than 0.
  int retVal = vList[ startIndex ];
  int tempVal;
  //We're going to do a simple sequence iterator where we start at the first index...go up till the end... and then increase the starting index.
  for( int i = startIndex; i < vCount; ( i += numProcesses ) ) {
    //Holds our comparison value
    tempVal = 0;
    for( int j = i; j < vCount; j++ ) {
      //printf("%d\n", j);
      tempVal += vList[ j ];
      //Check to see if tempVal is greater than the return value
      if( tempVal > retVal ) {
        retVal = tempVal;
      }
    }
  }
  //Return the maximum value discovered.
  return retVal;
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  //Create our pipe for the children to communicate back with the parent.
  int pPipe[ 2 ];
  if ( pipe( pPipe ) != 0 )
    fail( "Can't create pipe" );

  //We will start by creating all the children (through a for loop)
  for( int i = 0; i < workers; i++ ) {
    int pid = fork();
    if ( pid == -1 )
      fail( "Can't create child process" );

    // Print out a report from that child.
    if ( pid == 0 ) {

      //PIPE PROCESS
      //Close receiving end of the pipe
      close( pPipe[ 0 ] );

      //Lock the pipe
      lockf( pPipe[ 1 ], F_LOCK, 0 );

      //Find your sum
      int maxSumFound = findMax( i, workers );
      
      //Write to the writing end of the pipe
      write( pPipe[ 1 ], &maxSumFound, sizeof( maxSumFound ) );

      //Unlock the pipe
      lockf( pPipe[ 1 ], F_ULOCK, 0 );

      //Now that we copied we can go ahead and close
      close( pPipe[ 1 ] );

      if( report ) {
        //Print out pid and maximum found
        printf( "I'm process %d. The maximum sum I found is %d.\n", getpid(), maxSumFound );
      }

      exit( EXIT_SUCCESS );

    } else {
      //Parent is back here..let's read the value after closing the pipes writing side.
      int readValue;
      read( pPipe[ 0 ], &readValue, sizeof( readValue ) );

      //We copied to a value, we can now close the pipe
      

      //Adds the first max found to the list in order to account for negative values
      if( i == 0 ) {
        maxGlobal = readValue;
      } 
      //Otherwise we just do a standard check.
      else {
        //Standard check if maxSumFound is greater than our global sum
        if( readValue > maxGlobal ) {
          maxGlobal = readValue;
        }
      }
    }
  }
  
  close( pPipe[ 1 ] );
  close( pPipe[ 0 ] );

  //Wait for all children to finish
  while(wait(0) > 0);

  //Print our sum
  printf( "Maximum Sum: %d\n", maxGlobal );

  free(vList);

  return EXIT_SUCCESS;

}
