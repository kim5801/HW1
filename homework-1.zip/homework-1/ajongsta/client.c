#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

int main( int argc, char *argv[] ) {
  
  if(argc > 4 || argc < 2 ) {
    printf( "%s\n", "error" );
    exit( 1 );
  }

  if( ( ( strcmp( argv[ 1 ], "report" ) != 0 ) && ( strcmp( argv[ 1 ], "undo" ) != 0 ) ) && ( strcmp( argv[ 1 ], "move" ) != 0 ) ) {
    printf( "%s\n", "error" );
    exit( 1 );
  }

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );

  char buffer[ MESSAGE_LIMIT ];
  
  // Keeps track of where we are in our buffer
  int tracker = 0;

  //New array to pass through the queue
  for( int i = 1; i < argc; i++ ) {
    for( int j = 0; ( argv[ i ][ j ] != '\0' ); j++ ) {
      buffer[ tracker ] = argv[ i ][ j ]; 
      tracker++;
    }
    buffer[ tracker ] = ' ';
    tracker++;
  }
  buffer[tracker] = '\0';

  // Pass through argv to the server
  mq_send( serverQueue, buffer, strlen( buffer ), 0 );

  // Buffer to handle our input from the queue
  char charBuffer[ MESSAGE_LIMIT ];
    
  // Wait until we get a message
  int len = mq_receive( clientQueue, charBuffer, sizeof( charBuffer ), NULL );
  if( len >= 0 ) {
    //If we're reporting let's go ahead and iterate through our new array and print the board.
    if( strcmp( argv[ 1 ], "report" ) == 0 ) {
        for( int i = 0; i < 25; i++ ) {
            if( ( i % 5 == 0 ) && ( i != 0 ) ) {
                printf("\n");
            }
            printf( "%c", charBuffer[ i ]);
        }
        // Print a new line at the end
        printf("%c", '\n');
        exit( 0 );

    } 
    // Prints out our success message
    else if( strcmp( charBuffer, "success" ) == 0 ) {
        printf( "success\n" );
        exit( 0 );
    } 
    // Otherwise, we failed
    else {
        printf( "error\n" );
        exit( 0 );
    }
  }
  

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  exit( 1 );

}