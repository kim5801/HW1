#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Building board for storage
char board[ GRID_SIZE ][ GRID_SIZE ];

// Previous action stored
int lastAction[ 2 ] = { 6, 6 };

char * failed = "failure";

char * successed = "success";

/**
* Flips the tile selected and all surrounding tiles.
* @param x the x coordinate on the board
* @param y the y coordinate on the board
*/
void flipTiles( int x, int y ) {
  // Doing middle first, edge cases as else
  if( x != 4 && x != 0 ) {
    // Flips the value depending on what it already was (X)
    if( board[ y ][ x ] == '*' ) {
      board[ y ][ x ] = '.';
    } else {
      board[ y ][ x ] = '*';
    }

    // Flips the value depending on what it already was (X+1)
    if( board[ y ][ x + 1 ] == '*' ) {
      board[ y ][ x + 1 ] = '.';
    } else {
      board[ y ][ x + 1 ] = '*';
    }

    // Flips the value depending on what it already was (X-1)
    if( board[ y ][ x - 1 ] == '*' ) {
      board[ y ][ x - 1 ] = '.';
    } else {
      board[ y ][ x - 1 ] = '*';
    }
        
  } else {
    // If X is 0
    if( x == 0 ) {
      // Flips the value depending on what it already was (X)
      if( board[ y ][ x ] == '*' ) {
        board[ y ][ x ] = '.';
      } else {
        board[ y ][ x ] = '*';
      }

      // Flips the value depending on what it already was (X + 1)
      if( board[ y ][ x + 1 ] == '*' ) {
        board[ y ][ x + 1 ] = '.';
      } else {
        board[ y ][ x + 1 ] = '*';
      }
    } 
    // If X is 4
    else {
      // Flips the value depending on what it already was (X)
      if( board[ y ][ x ] == '*' ) {
        board[ y ][ x ] = '.';
      } else {
        board[ y ][ x ] = '*';
      }

      // Flips the value depending on what it already was (X - 1)
      if( board[ y ][ x - 1 ] == '*' ) {
        board[ y ][ x - 1 ] = '.';
      } else {
        board[ y ][ x - 1 ] = '*';
      }
    }
  }
  
  // Rinse and repeat for Y

  // Doing middle first, edge cases as else
  if( y != 4 && y != 0 ) {

    // Flips the value depending on what it already was (Y-1)
    if( board[ y - 1 ][ x ] == '*' ) {
      board[ y - 1 ][ x ] = '.';
    } else {
      board[ y - 1 ][ x ] = '*';
    }

    // Flips the value depending on what it already was (Y+1)
    if( board[ y + 1 ][ x ] == '*' ) {
      board[ y + 1 ][ x ] = '.';
    } else {
      board[ y + 1 ][ x ] = '*';
    }
        
  } else {
    // If Y is 0
    if( y == 0 ) {

      // Flips the value depending on what it already was (Y + 1)
      if( board[ y + 1 ][ x ] == '*' ) {
        board[ y + 1 ][ x ] = '.';
      } else {
        board[ y + 1 ][ x ] = '*';
      }
    } 
    // If Y is 4
    else {

      // Flips the value depending on what it already was (Y - 1)
      if( board[ y - 1 ][ x ] == '*' ) {
        board[ y - 1 ][ x ] = '.';
      } else {
        board[ y - 1 ][ x ] = '*';
      }
    }
  }
}

/**
* @param c the string being converted to an int
* @return c as an integer value
*/
int stringToInt( char c[] ) {
    int retVal = 0;
    for( int i = 0; c[i] != '\0'; i++ ) {
        if(c[i] > '9' || c[i] < '0') {
            return -1;
        }
        retVal = ( retVal * 10 ) + c[i] - '0';
    }
    return retVal;
}

/**
* Prints the board to standard output
*/
void printBoard() {
  // If we want to view the current board we can iterate and print everything
  for( int i = 0; i < 5; i++ ) {
    for( int j = 0; j < 5; j++ ) {
      printf( "%c", board[ j ][ i ] );
    }
    printf( "\n" );
  }
}

/**
* Handles our alarm -- reactive
* @param sig the SIGINT
*/
void exitProgramHandler( int sigInt ) {
  // Print a newline and then the board
  printf("\n");
  printBoard();
  exit( EXIT_SUCCESS );
}

int main( int argc, char *argv[] ) {
  // Create our sig action struct and set the alarm handler
  // GOT THIS CODE FROM EXAMPLE MAKE SURE TO CITE IT LATER
  struct sigaction act;
  act.sa_handler = exitProgramHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );
  
  // Error checking to see how many arguments we have
  if( argc != 2 ) {
    // Print error message
    fprintf( stderr, "usage: server <board-file>\n" );
    exit( 1 );
  }

  // Load in a file passed through as an argument given that we have an argument for it
  FILE *fp = fopen( argv[ 1 ], "r" );

  // Null check for bad open
  if( fp == NULL ) {
    // ERROR BAD FILE
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    exit( 1 );
  }

  // Big loop to fill out our board completely based on the file
  for( int i = 0; i < 5; i++ ) {
    char c = fgetc( fp );
    for( int j = 0; j < 5; j++ ) {
      // Let's get the value from the file to add to our array board
      if( c != '\n' ) {
        board[ j ][ i ] = c;
      }
      if( c != '*' && c != '.') {
        fprintf( stderr, "%s %s\n", "Invalid input file:", argv[ 1 ] );
        exit( 1 );
      }
      c = fgetc( fp );
    }
  }
  
  // Don't forget to close the file
  fclose( fp );

  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  // Our action item
  char * action;

  // Stores inputted x value
  int x;

  // Stores inputted y value
  int y;

  // Repeatedly read and process client messages.
  while ( running ) {
    
    // Buffer to handle our input from the queue
    char charBuffer[ MESSAGE_LIMIT ];

    // Tracks how many times we've iterated through the list
    int passNum = 0;
    
    // Wait until we get a message
    int len = mq_receive( serverQueue, charBuffer, sizeof( charBuffer ), NULL );
    // This will run once we get the message
    if( len >= 0 ) {
      // Okay so now we parse what we got in the buffer. We're expecting a certain format so we can go ahead and just get the action
      for( int i = 0; i < len; i++ ) {
        if( charBuffer[ i ] == ' ' ) {
          charBuffer[ i ] = '\0';
        }
      }
      action = &charBuffer[ 0 ];
      
    }

    // If we want to perform a new action
    if( strcmp( action, "move" ) == 0 ) {
      //Okay so we know we need an X and a Y...so we're going to go ahead and expect additional parameters
      for( int i = 1; i < len; i++ ) {
        if( ( charBuffer[ i ] == '\0' && i != ( len - 1 ) ) && ( passNum == 0 ) ) {
          x = stringToInt( &charBuffer[ i + 1 ] );
          passNum++;
        } else if( ( charBuffer[ i ] == '\0' && i != ( len - 1 ) ) && ( passNum == 1 ) ) {
          y = stringToInt( &charBuffer[ i + 1 ] );
          passNum++;
        }
      } 

      if( ( x > 4 || x < 0 ) || ( y > 4 ) || ( y < 0 ) ) {
        mq_send( clientQueue, failed, strlen( failed ), 0 );
      } else {
        // And now we execute the necessary functions
        flipTiles( x, y );
        lastAction[ 0 ] = x;
        lastAction[ 1 ] = y;
        // Send success through to the queue
        mq_send( clientQueue, successed, strlen( successed ), 0 );
      } 
    }

    // If we want to undo our last action
    else if( strcmp( action, "undo" ) == 0 ) {
      // Check to see if an Undo action is valid
      if( lastAction[ 0 ] == 6 ) {
        mq_send( clientQueue, failed, strlen( failed ), 0 );
      } else {
        flipTiles( lastAction[ 0 ], lastAction[ 1 ] );
        lastAction[ 0 ] = 6;
        lastAction[ 1 ] = 6;
        // Send succes through to the queue
        mq_send( clientQueue, successed, strlen( successed ), 0 );
      }
      
    }

    // Print if we have a print action call
    else if( strcmp( action, "report" ) == 0 ) {
      char sendBoardThru[25];
      int track = 0;
      for( int i = 0; i < 5; i++ ) {
        for( int j = 0; j < 5; j++ ) {
          sendBoardThru[track] = board[ j ][ i ];
          track++;
        }
      }
      mq_send( clientQueue, sendBoardThru, sizeof( sendBoardThru ), 0 );
    }

    else {
      // Send failure through to the queue
      char * failed = "failure";
      mq_send( clientQueue, failed, strlen( failed ), 0 );
    }  
  }  

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
