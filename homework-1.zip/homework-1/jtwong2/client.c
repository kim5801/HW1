#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include "common.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

// Function to easily print an error message and exit unsuccessfully
void error() {
    fprintf(stderr, "error\n");
    exit(1);
}

int main(int argc, char *argv[]) {
    // Attempt to open the queues that should have been created by the server. Print error message and exit if they were not able to be opened
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY);
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY);
    if (serverQueue == -1 || clientQueue == -1) {
        fprintf(stderr, "Failed to create queues\n");
        exit(1);
    }

    // Validate number of arguments
    if (argc < 2 || argc > 4) {
        error();
    }

    // Parse the command
    if (strcmp("move", argv[1]) == 0) {
        // Validate arguments for the move command
        if (argc != 4) {
            error();
        }

        // Make sure the arguments are integers between 0 and 4, inclusive
        if (argv[2][0] < '0' || argv[2][0] > '4' || argv[2][1] != '\0' || argv[3][0] < '0' || argv[3][0] > '4' || argv[3][1] != '\0') {
            error();
        }

        // Ask the server to make the move
        // Message format: <first letter of command><row><col>\n
        char message[4] = { argv[1][0], argv[2][0] - '0', argv[3][0] - '0', '\0' };
        mq_send(serverQueue, message, sizeof(message), 0);

        // Get the reply from the server and print it out, exiting with the correct status
        char replyMessage[MESSAGE_LIMIT];
        int status = mq_receive(clientQueue, replyMessage, sizeof(replyMessage), NULL);

        if (status == -1) {
            fprintf(stderr, "An error occured when receiving message from server\n");
            exit(1);
        }

        // The server always sends the messages in a printable way, so we can just print out the message as a string
        printf("%s\n", replyMessage);
        if (strcmp(replyMessage, "success") == 0) { // Determine whether the client should exit successfully or unsuccessfully
            exit(0);
        } else {
            exit(1);
        }

    } else if (strcmp("report", argv[1]) == 0) { // Handles the report command
        // Validate arguments for the report command
        if (argc != 2) {
            error();
        }

        // Message format: <first letter of command>\n
        char message[2] = { argv[1][0], '\n' };
        mq_send(serverQueue, message, strlen(message), 0);

        // Get the reply from the server and print it out, exiting with the correct status if failure
        char replyMessage[MESSAGE_LIMIT];
        int status = mq_receive(clientQueue, replyMessage, sizeof(replyMessage), NULL);

        if (status == -1) {
            fprintf(stderr, "An error occured when receiving message from server\n");
        }

        // No need to print out any success/error message; just print out the board
        printf("%s", replyMessage);
    } else if (strcmp("undo", argv[1]) == 0) {
        // Validate arguments for the undo command
        if (argc != 2) {
            error();
        }

        // Ask the server to undo the move
        // Message format: <first letter of command>\n
        char message[2] = { argv[1][0], '\n' };
        mq_send(serverQueue, message, strlen(message), 0);

        // Get the reply from the server and print it out, exiting with the correct status if failure
        char replyMessage[MESSAGE_LIMIT];
        int status = mq_receive(clientQueue, replyMessage, sizeof(replyMessage), NULL);

        if (status == -1) {
            fprintf(stderr, "An error occured when receiving message from server\n");
        }

        // Print the success/error message received by the client
        printf("%s\n", replyMessage);
        if (strcmp(replyMessage, "success") == 0) {
            exit(0);
        } else {
            exit(1);
        }
    } else {
        error(); // Must not have been a valid command, so error
    }

    return 0;
}