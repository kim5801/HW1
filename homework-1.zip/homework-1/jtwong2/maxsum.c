#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int calculateMax(int start, int numWorkers) {
  int max = vList[start]; // Start max at the first element. If we set it to 0, all the numbers processed may be negative

  // Each worker only processes a subset of starting indices. Specifically, every n indices, where n is the number of workers
  for (int i = start; i < vCount; i += numWorkers) { // i are the indices that this worker sums starting at
    int sum = 0; // Sum resets after each inner loop
    for (int j = i; j < vCount; j++) { // Inner loop sums the values to the end of the list to find max
      if (sum + vList[j] > max) { // If the new value would make the sum bigger than the old largest sum, then it should now be the max sum
        max = sum + vList[j];
      }
      sum += vList[j]; // Either way, add the new value to the running sum
    }
  }
  return max;
}

int main( int argc, char *argv[] ) {
  // By default, report is false and there are 4 workers (although this last case shouldn't happen)
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Read in the list of values to process
  readList();

  // Create the pipe, exiting if unsuccessful
  int pipefd[2];
  int status = pipe(pipefd);
  if (status == -1) {
    fail("Failed to create pipe");
  }

  // If the user asked for more workers than there are integers in the list, only create as
  // many workers as there are numbers to process, for max performance
  if (workers > vCount) {
    workers = vCount;
  }

  // Create the workers. The value in the for loop tells each worker which indices to process
  for (int i = 0; i < workers; i++) {
    if (fork() == 0) { // If this is the child process
      int max = calculateMax(i, workers);

      // Lock and send the max over the pipe
      lockf( pipefd[1], F_LOCK, 0 );
      write(pipefd[1], &max, 4);
      lockf( pipefd[1], F_ULOCK, 0 );

      // If the user wants to report the sum found by each process, print it
      if (report) {
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), max);
      }
      
      // Free memory associated with the integer list and exit. This frees the child's version of the list
      free(vList);
      exit(0);

    } // If it's the parent process, let it go to the next iteration of the for loop
  }
  // Wait for each worker to finish executing. When a worker finishes executing, read its calculated max and store it
  int values[workers];
  int numValuesRead = 0;
  for (int i = 0; i < workers; i++) {
    wait(NULL);
    read(pipefd[0], &values[numValuesRead++], 4);
  }

  // Calculate the max
  int max = values[0];
  for (int i = 1; i < workers; i++) { // Start at 1 because we already used the first value as our default max
    if (values[i] > max) {
      max = values[i];
    }
  }

  // Report the max as the parent process
  printf("Maximum Sum: %d\n", max);

  // Free the parent's list of values
  free(vList);
  
  return 0;
}
