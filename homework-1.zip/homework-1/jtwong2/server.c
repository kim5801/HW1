#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
#define NUM_CHARS_IN_BOARD 25

// Define a struct for a move to make passing coordinates easier
typedef struct {
    int row;

    int col;
} Move;

// Define a struct for a game so we can use external methods to do operations on the board
typedef struct {
    char board[5][5];

    Move *lastMove;

    bool undoOK;
} Game;

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Reads the file and creates a game struct with the contents of the file
static Game *createGame(char *filename) {
    // Create the game struct and open the file
    Game *g = (Game*)malloc(sizeof(Game));
    FILE *gameFile = fopen(filename, "r");
    if (!gameFile) {
        fprintf(stderr, "Invalid input file: %s\n", filename);
        exit(1);
    }

    // Initialize the state of the game. We can't undo a move immediately after
    // starting the game
    g->undoOK = false;
    g->lastMove = NULL;

    // Fill in the game board, reading from the file
    int row = 0;
    int col = 0;
    char currentChar = 0;
    int numGameChars = 0;
    while (fscanf(gameFile, "%c", &currentChar) == 1) {
        // Check for invalid input characters in the file
        if (currentChar != '\n' && currentChar != '.' && currentChar != '*') {
            fprintf(stderr, "Invalid input file: %s\n", filename);
            exit(1);
        }

        // Newline means to start filling in the next row
        if (currentChar == '\n') {
            // If we hit a newline before fully filling in the column, we know the file is invalid
            if (col != 5) {
                fprintf(stderr, "Invalid input file: %s\n", filename);
                exit(1);
            } else {
                // Else, start filling in the next row
                row++;
                col = 0;
                continue;
            }
        }

        // Check for too many characters in the board
        if (numGameChars > NUM_CHARS_IN_BOARD) {
            fprintf(stderr, "Invalid input file: %s\n", filename);
            exit(1);
        }

        // Fill in the board square with the character in the file
        g->board[row][col] = currentChar;
        numGameChars++;
        col++;
    }

    // Close file since we're done reading from it
    fclose(gameFile);

    return g;
}

// Prints the board. Useful for debugging too, in addition to printing after termination
static void printGame(Game *g) {
    // Prints one cell at a time, starting from 0,0 (top left)
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            printf("%c", g->board[i][j]);
        }

        printf("\n");
    }
}

// This method assumes that the move is valid
static int makeMove(Game *g, Move *m, bool removeLastMove) {

    // Flip the light at the move's coordinates
    if (g->board[m->row][m->col] == '.') {
        g->board[m->row][m->col] = '*';
    } else { // Must be set to '*' currently
        g->board[m->row][m->col] = '.';
    }


    // Flip the light above the move's coordinates
    if (m->row + 1 <= 4) { // If there's another cell on the board above the move's coordinate
        if (g->board[m->row + 1][m->col] == '.') {
            g->board[m->row + 1][m->col] = '*';
        } else { // Must be set to '*' currently
            g->board[m->row + 1][m->col] = '.';
        }
    }

    // Flip the light below the move's coordinates
    if (m->row - 1 >= 0) { // If there's another cell on the board below the move's coordinate
        if (g->board[m->row - 1][m->col] == '.') {
            g->board[m->row - 1][m->col] = '*';
        } else { // Must be set to '*' currently
            g->board[m->row - 1][m->col] = '.';
        }
    }

    // Flip the light to the right of the move's coordinates
    if (m->col + 1 <= 4) { // If there's another cell on the board to the right of the move's coordinate
        if (g->board[m->row][m->col + 1] == '.') {
            g->board[m->row][m->col + 1] = '*';
        } else { // Must be set to '*' currently
            g->board[m->row][m->col + 1] = '.';
        }
    }

    // Flip the light to the left of the move's coordinates
    if (m->col - 1 >= 0) { // If there's another cell on the board to the left of the move's coordinate
        if (g->board[m->row][m->col - 1] == '.') {
            g->board[m->row][m->col - 1] = '*';
        } else { // Must be set to '*' currently
            g->board[m->row][m->col - 1] = '.';
        }
    }

    // Set the game's last move
    if (g->lastMove && removeLastMove) {
        free(g->lastMove);
    }
    g->lastMove = m;
    g->undoOK = true;

    // Return success or failure (0 or 1, respectively)
    return 0;
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Function to handle the Ctrl+C signal when the process receives the signal
void terminationHandler(int signal) {
    // Setting to 0 will terminate the while loop
    running = 0;
}

// Core of our program
int main( int argc, char *argv[] ) {
    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 10;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
    mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
    if ( serverQueue == -1 || clientQueue == -1 )
        fail( "Can't create the needed message queues" );

    // Set up signal handler
    struct sigaction act;
    act.sa_handler = terminationHandler;
    sigemptyset( &( act.sa_mask ) );
    act.sa_flags = 0;
    sigaction( SIGINT, &act, 0 );

    // Create the game struct
    if (argc != 2) {
        fprintf(stderr, "usage: server <board-file>\n");
        exit(1);
    }
    Game *game = createGame(argv[1]);

    // Repeatedly read and process client messages.
    char message[MESSAGE_LIMIT];
    while ( running ) {

        // Read the command from the client and error if necessary
        int messageStatus = mq_receive(serverQueue, message, sizeof(message), NULL);
        if (messageStatus == -1) {
            running = false;
            continue;
        }

        // Create our reply message to report the status of the command
        bool status = false;
        char replyMessage[MESSAGE_LIMIT];

        // Depending on the first character of the message, we know which command the client ran
        switch (message[0]) {
            case 'm': ; // Empty statement to allow for a declaration to follow the label
                // Create a move struct with the coordinates to allow for easy passing of data
                Move *m = (Move*)malloc(sizeof(Move));
                m->row = message[1];
                m->col = message[2];

                // Pass the game and move to the makeMove() function, which will update the game's state appropriately
                status = makeMove(game, m, true);

                // Determine which status message to send back to the client. To make it easier for the client, just send it in string format.
                if (status == 0) {
                    strcpy(replyMessage, "success");
                } else {
                    strcpy(replyMessage, "error");
                }
                mq_send(clientQueue, replyMessage, strlen(replyMessage), 0);
                break;
            case 'r': ; // This command reports the board
                // Send the game board array. Since it is stored in contiguous memory, it acts like
                // a string. However, we will have to do some post-processing anyways to insert the newlines.
                // Specifically, we have to just work from top-left to bottom-right, inserting the the character at that board location
                // into the message string
                int numCharsWritten = 0;
                for (int i = 0; i < GRID_SIZE; i++) {
                    for (int j = 0; j < GRID_SIZE; j++) {
                        // Write the state of the cell (i, j)
                        replyMessage[numCharsWritten] = game->board[i][j];
                        numCharsWritten++;
                    }
                    
                    // Insert the newline into the message
                    replyMessage[numCharsWritten] = '\n';
                    numCharsWritten++;
                }
                // Add null terminator, since we want to treat it as a string
                replyMessage[numCharsWritten] = '\0';

                // Send the string representation of the board for the client to print
                mq_send(clientQueue, replyMessage, strlen(replyMessage), 0);
                break;
            case 'u': // This is the undo command
                // First, check if an undo operation is allowed
                if (game->undoOK) {
                    // If the undo is allowed, just feed the last move made (according to the game struct) into the makeMove() function,
                    // since undoing a move is just like performing the move again. Also, since we are using the old move stored in
                    // heap memory, tell the makeMove() function to not free the old move, since we will store it in the game struct (but not use it for a future undo)
                    status = makeMove(game, game->lastMove, false);
                    game->undoOK = false;

                    // Determine which status message to send back to the client. To make it easier for the client, just send it in string format.
                    if (status == 0) {
                        strcpy(replyMessage, "success");
                    } else {
                        strcpy(replyMessage, "error");
                    }
                    mq_send(clientQueue, replyMessage, strlen(replyMessage), 0);
                } else {
                    // Send back a failure, since an undo operation is not permitted in this state
                    strcpy(replyMessage, "error");
                    mq_send(clientQueue, replyMessage, strlen(replyMessage), 0);
                }
                break;
            default:
                break;
        }
    }

    // Print out board before terminating
    printf("\n");
    printGame(game);

    // Free heap memory before terminating
    free(game->lastMove);
    free(game);

    // Close our two message queues (and delete them).
    mq_close( clientQueue );
    mq_close( serverQueue );

    mq_unlink( SERVER_QUEUE );
    mq_unlink( CLIENT_QUEUE );

    return 0;
}
