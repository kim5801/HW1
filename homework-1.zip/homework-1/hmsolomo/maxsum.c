#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int calculateSum( int start, int* vList, int count ) {
	int sum = 0;
	int max = INT_MIN;
// 	int end =  0;
// 	int s = 0;
	// search ranges from front forward
	for( int i = start; i < count; i++ ) {
		sum += vList[i];
		if (sum > max) {
			max = sum;
// 			end = i;
// 			s = start;
		}
	}
	sum = 0;
	// search ranges from back backwards
	for( int i = count - 1; i >= start; i-- ) {
		sum += vList[i];
		if (sum > max) {
			max = sum;
// 			end = i;
// 			s = count - 1;
		}
	}
// 	printf("Range from %d to %d, max = %d.\n", s, end, max);

	return max;
}

int largest(int arr[], int n) {
    int i;
    // Initialize maximum element
    int max = arr[0];
    // Traverse array elements from second and
    // compare every element with current max 
    for (i = 1; i < n; i++) {
//     	printf("%d\n", arr[i]);
        if (arr[i] > max) {
            max = arr[i];
        }
	}
    return max;
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // You get to add the rest.
  
  // Create n amount of children based off of workers
  // https://stackoverflow.com/questions/876605/multiple-child-process
 
  // Each child will calculate the sum of various ranges of at least one number
	pid_t pid[workers];
	// Split up work evenly by workers
	int cap = vCount / workers;
	// Keeps track of the max for ranges in worker
	int maxList[workers];
// 	// Keep track of the max for each child
// 	int childMax[workers]
	// Before creating the children, we need to create an anonymous pipe
	int pfd[2];
	if (pipe(pfd) != 0) {
		fail("Cannot create pipe.");
	}
	// https://www.geeksforgeeks.org/largest-sum-contiguous-subarray/
	// Start loop that will go through workers
	for (int i = 0; i < workers; i++) {
		int sumList[cap];
		// Create a child by calling fork()
		if ((pid[i] = fork()) < 0) {
			fail("Could not make child.");
		} 
		if (pid[i] == 0) {
			// If child, calculate sum for this range
			int curr_max = INT_MIN;
			// Each child received a certain amount of work
			
			// Use each index given to calculate sums
			for (int j = 0; j < cap; j++) {
				int index = i * cap + j;
				int temp = calculateSum(index, vList, vCount);
				if( temp > curr_max ) {
					curr_max = temp;
				}
				// Store the max in list
				sumList[j] = curr_max;
// 				printf("range largest = %d\n", sumList[j]);

			}
			// Get the max for this worker
			maxList[i] = largest(sumList, cap);
// 			printf("worker largest = %d\n", maxList[i]);

			// Write the child's max into the writing end of pipe
			int len = sizeof(maxList[i]);
			lockf( *pfd, F_LOCK, 0 );
			write( pfd[1], &maxList[i], len);
			lockf( *pfd, F_ULOCK, 0 );
		
			close(pfd[1]);
// 			close(pfd[0]);
// 			
			exit(0);
		}
		
		wait(NULL);
		// Read output from pipe
		int result;
		read( pfd[0], &result, sizeof(result));
		
// 		printf("largesttt = %d\n", result);
// 		printf("largest = %d\n", largest(maxList, workers));


		if (report)
			printf("I'm child %d. The maximum sum I found is %d\n", pid[i], result);
		maxList[i] = result;
// 		printf("largest = %d\n", maxList[i]);

	}
	printf("Maximum Sum: %d\n", largest(maxList, workers));
  return 0;
}