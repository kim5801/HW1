/**
 * The server program processes the input board and waits for commands from
 * the client to update the board. The state of the board is stored in the
 * server and all changes are made on the server side. The user can ask the
 * server to report the board, make a move, or undo a move from the client.
 * @file server.c
 * @author Isaac Dunn (ijdunn)
 */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/** ASCII decimal value for the asterisks (star) */
#define ASCII_STAR 42

/** ASCII decimal value for the period */
#define ASCII_PERIOD 46

/** ASCII decimal value for a newline character */
#define ASCII_NEWLINE 10

/** Struct definition to hold the grid, undo flag, and the last move */
typedef struct {
  bool board[GRID_SIZE][GRID_SIZE];
  bool undoFlag;
  int lastRow;
  int lastCol;
} LightsBoard ;

/**
 * This function is used to print a custom error message to stderr and exit with
 * a failure status.
 * @param message  The message to print to stderr
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * This function is used to print an error message to stderr when a file is invalid.
 * This will print the name of the file and exit with a failure status.
 * @param filename  The name of the file to include in the error message
 */
static void fileFail( char const *filename ) {
  fprintf( stderr, "Invalid input file: %s\n", filename );
  exit( 1 );
}

/**
 * This creates a string of the current status of the board using asterisks and periods.
 * This function returns a string to send to the client to print.
 * @param board          The pointer to the board struct containing the state of the board
 * @param boardString    The string to hold the current state of the board
 */
void boardReport( LightsBoard *board, char *boardString  ) {
  int strleng = 0;
  for ( int row = 0; row < GRID_SIZE; row++ ) {
    for ( int col = 0; col < GRID_SIZE; col++ ) {
      // If light is on, print star, otherwise print dot
      ( board->board[row][col] ) ? ( boardString[strleng++] = '*' ) : ( boardString[strleng++] = '.' );
    }
    // Print newline for new row, except the last row
    if ( row != 4 ) {
      boardString[strleng++] = '\n';
    }
  }
  boardString[strleng] = '\0';
}

/**
 * Updates the board by playing the move at the row and column. Adjacent lights that
 * are off are turned on, and vise versa.
 * @param board The pointer to the board struct containing the state of the board
 * @param row   The row to play the move from
 * @param col   The column to play the move from
 */
void boardMove( LightsBoard *board, int row, int col ) {
  // Play in top-left corner
  if ( row == 0 && col == 0 ) {
    ( board->board[row][col] ) ? ( board->board[row][col] = false ) : ( board->board[row][col] = true );
    ( board->board[row + 1][col] ) ? ( board->board[row + 1][col] = false ) : ( board->board[row + 1][col] = true );
    ( board->board[row][col + 1] ) ? ( board->board[row][col + 1] = false ) : ( board->board[row][col + 1] = true );
  }
  // Play in top-right corner
  else if ( row == 0 && col == 4 ) {
    ( board->board[row][col] ) ? ( board->board[row][col] = false ) : ( board->board[row][col] = true );
    ( board->board[row + 1][col] ) ? ( board->board[row + 1][col] = false ) : ( board->board[row + 1][col] = true );
    ( board->board[row][col - 1] ) ? ( board->board[row][col - 1] = false ) : ( board->board[row][col - 1] = true );
  }
  // Play in bottom-left corner
  else if ( row == 4 && col == 0 ) {
    ( board->board[row][col] ) ? ( board->board[row][col] = false ) : ( board->board[row][col] = true );
    ( board->board[row - 1][col] ) ? ( board->board[row - 1][col] = false ) : ( board->board[row - 1][col] = true );
    ( board->board[row][col + 1] ) ? ( board->board[row][col + 1] = false ) : ( board->board[row][col + 1] = true );
  }
  // Play in bottom-right corner
  else if ( row == 4 && col == 4 ) {
    ( board->board[row][col] ) ? ( board->board[row][col] = false ) : ( board->board[row][col] = true );
    ( board->board[row - 1][col] ) ? ( board->board[row - 1][col] = false ) : ( board->board[row - 1][col] = true );
    ( board->board[row][col - 1] ) ? ( board->board[row][col - 1] = false ) : ( board->board[row][col - 1] = true );
  }
  // Play on top edge
  else if ( row == 0 && col > 0 && col < 4 ) {
    ( board->board[row][col] ) ? ( board->board[row][col] = false ) : ( board->board[row][col] = true );
    ( board->board[row][col - 1] ) ? ( board->board[row][col - 1] = false ) : ( board->board[row][col - 1] = true );
    ( board->board[row][col + 1] ) ? ( board->board[row][col + 1] = false ) : ( board->board[row][col + 1] = true );
    ( board->board[row + 1][col] ) ? ( board->board[row + 1][col] = false ) : ( board->board[row + 1][col] = true );
  }
  // Play on left edge
  else if ( row > 0 && row < 4 && col == 0 ) {
    ( board->board[row][col] ) ? ( board->board[row][col] = false ) : ( board->board[row][col] = true );
    ( board->board[row][col + 1] ) ? ( board->board[row][col + 1] = false ) : ( board->board[row][col + 1] = true );
    ( board->board[row - 1][col] ) ? ( board->board[row - 1][col] = false ) : ( board->board[row - 1][col] = true );
    ( board->board[row + 1][col] ) ? ( board->board[row + 1][col] = false ) : ( board->board[row + 1][col] = true );
  }
  // Play on right edge
  else if ( row > 0 && row < 4 && col == 4 ) {
    ( board->board[row][col] ) ? ( board->board[row][col] = false ) : ( board->board[row][col] = true );
    ( board->board[row][col - 1] ) ? ( board->board[row][col - 1] = false ) : ( board->board[row][col - 1] = true );
    ( board->board[row - 1][col] ) ? ( board->board[row - 1][col] = false ) : ( board->board[row - 1][col] = true );
    ( board->board[row + 1][col] ) ? ( board->board[row + 1][col] = false ) : ( board->board[row + 1][col] = true );
  }
  // Play on bottom edge
  else if ( row == 4 && col < 4 && col > 0 ) {
    ( board->board[row][col] ) ? ( board->board[row][col] = false ) : ( board->board[row][col] = true );
    ( board->board[row][col - 1] ) ? ( board->board[row][col - 1] = false ) : ( board->board[row][col - 1] = true );
    ( board->board[row - 1][col] ) ? ( board->board[row - 1][col] = false ) : ( board->board[row - 1][col] = true );
    ( board->board[row + 1][col] ) ? ( board->board[row + 1][col] = false ) : ( board->board[row + 1][col] = true );
  }
  // All other plays in the middle of the board
  else {
    ( board->board[row][col] ) ? ( board->board[row][col] = false ) : ( board->board[row][col] = true );
    ( board->board[row][col - 1] ) ? ( board->board[row][col - 1] = false ) : ( board->board[row][col - 1] = true );
    ( board->board[row][col + 1] ) ? ( board->board[row][col + 1] = false ) : ( board->board[row][col + 1] = true );
    ( board->board[row - 1][col] ) ? ( board->board[row - 1][col] = false ) : ( board->board[row - 1][col] = true );
    ( board->board[row + 1][col] ) ? ( board->board[row + 1][col] = false ) : ( board->board[row + 1][col] = true );
  }
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

/**
 * This function acts as the signal handler when the server receives the termination signal.
 * @param sig  The signal to receive from the terminal
 */
void terminationHandler( int sig ) {
  running = 0;
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Prepate structure for the signal handling
  struct sigaction act;
  act.sa_handler = terminationHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 ) {
    fail( "Can't create the needed message queues" );
  }

  // Parse command-line arguments
  // Must be exactly two command-line arguments
  if ( argc != 2 ) {
    fail( "usage: server <board-file>" );
  }
  // Unable to open file
  char *filename = argv[1];
  FILE *fd = fopen( filename, "r" );
  if ( !fd ) {
    fileFail( filename );
  }

  // Create the struct to store the game state, initialize fields
  LightsBoard *board = ( LightsBoard * )malloc( sizeof ( LightsBoard ) );
  // Unable to undo before first move
  board->undoFlag = false;
  // No moves are stored when board is initialized
  board->lastRow = -1;
  board->lastCol = -1;

  // Read input for the starting state of the board
  for ( int row = 0; row < GRID_SIZE; row++ ) {
    for ( int col = 0; col < GRID_SIZE; col++ ) {
      char ch = fgetc( fd );
      // Checking for valid characters
      if ( ch == ASCII_PERIOD || ch == ASCII_STAR ) {
        // Store star as true in the board, light is on
        if ( ch == ASCII_STAR ) {
          board->board[row][col] = true;
        }
      } else {
        // Invalid character in file, free board, print to stderr and exit
        free( board );
        fileFail( filename );
      }
    }
    // After five columns, next char should be a newline
    char ch = fgetc( fd );
    if ( ch != ASCII_NEWLINE ) {
      // Invalid character in file, free board, print to stderr and exit
      free( board );
      fileFail( filename );
    }
  }
  // Last input read should be EOF
  if ( fgetc( fd ) != EOF ) {
    // Invalid character in file, free board, print to stderr and exit
    free( board );
    fileFail( filename );
  }

  // Repeatedly read and process client messages.
  while ( running ) {

    // Receive the message from the client
    char qRecMessage[MESSAGE_LIMIT];
    mq_receive( serverQueue, qRecMessage, sizeof( qRecMessage ), NULL );

    // Create buffer for the message to send back to the client
    char qSendMessage[MESSAGE_LIMIT];
    qSendMessage[0] = '\0';

    // Read the message to determine what to do
    // Received move command, parse the integers and change the board
    if ( strstr( qRecMessage, "move" ) != NULL ) {
      int rowNum, colNum;
      if ( sscanf( qRecMessage, "move %d %d", &rowNum, &colNum ) != 2 ) {
        // If cannot parse integers from received command, send back error message
        strcpy( qSendMessage, "error" );
      }
      else {
        // Make the move on the board
        boardMove( board, rowNum, colNum );
      
        // Update undo flag and last moves
        board->undoFlag = true;
        board->lastRow = rowNum;
        board->lastCol = colNum;

        // Send success message to client
        strcpy( qSendMessage, "success" );
      }
    }
    // Received report command, send the board status to the client
    else if ( strstr( qRecMessage, "report" ) != NULL ) {
      char boardString[MESSAGE_LIMIT];
      boardReport( board, boardString );
      strcpy( qSendMessage, boardString );
    }
    // Received undo command
    else if ( strstr( qRecMessage, "undo" ) != NULL ) {
      // If undo command is invalid (no moves have been made), send error message to client
      if ( !board->undoFlag ) {
        strcpy( qSendMessage, "error" );
      } 
      // Undo move is valid, play the last move to undo
      else {
        boardMove( board, board->lastRow, board->lastCol );
        // Update undo flag and last moves to avoid undo operation again
        board->undoFlag = false;
        board->lastRow = -1;
        board->lastCol = -1;
        // Send success message to client
        strcpy( qSendMessage, "success" );
      }
    }
    // Send message to the client
    mq_send( clientQueue, qSendMessage, strlen(qSendMessage), 0 );
  }

  // Print final board state when server is terminated
  printf( "\n" );
  char boardString[MESSAGE_LIMIT];
  boardReport( board, boardString );
  printf( "%s\n", boardString );
  free( board );

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
