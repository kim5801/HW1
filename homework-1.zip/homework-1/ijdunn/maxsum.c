/**
 * The maxsum program finds the maximum sum from a given set of positive and negative integers.
 * The program can use processes with IPC to speed up calculations. The parent process will
 * print the maximum sum found to standard output.
 * @file maxsum.c
 * @author Isaac Dunn (ijdunn)
 */

#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

/**
 * Function to print out a message to stderr and exit the program
 * @param message  The message to print to stderr
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * Prints a usage message to stdout if the user tries to run the program
 * with invalid command-line arguments. Exits with failure status
 */
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

/**
 * Reads a list of integers from stdin and places them into an allocated array.
 */
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

/**
 * The main function parses command-line arguments, calls the readList() function, creates worker
 * processes, and the anonymous pipe. The children/worker processes find the the maximum sum and
 * send the largest sum to the parent process, which will print the largest sum found. The user
 * has the option to specify the number of worker processes and to have the processes report its 
 * pid and the largest sum it found using command-line arguments.
 * @param argc  The number of command-line arguments
 * @param argv  The values of the command-line arguments.
 * @return      The exit status of the program, 0 for success, 1 for failure.
 */ 
int main( int argc, char *argv[] ) {
  // Initialize variables
  bool report = false;
  int workers = 4;
  int maxSum = 0;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  // Read numbers from input
  readList();

  // Create pipe before forking, handle errors
  int pfd[2];
  if ( pipe( pfd ) != 0 ) {
    fail( "Unable to create pipe" );
  }

  // Create processes based on number of workers
  for (int i = 0; i < workers; i++ ) {
    
    // Fork, handle errors
    pid_t pid = fork();
    if ( pid == -1 ) {
      fail( "Unable to create child process" );
    }
    
    // Child process
    if ( pid == 0 ) {
      // Close reading end of pipe
      close( pfd[0] );

      // Variables to hold the current maximum sum found in this process
      int childMaxSum = 0;
      // Find the max sum
      for ( int j = i; j < vCount; j += workers ) {
        int sum = 0;
        for ( int k = j; k < vCount; k++ ) {
          sum += vList[k];
          if ( sum > childMaxSum ) {
            childMaxSum = sum;
          }
        }
      }
      
      // Write childMaxSum to the pipe, lock and unlock pipe
      lockf( pfd[1], F_LOCK, 0 );
      write( pfd[1], &childMaxSum, sizeof( int ) );
      lockf( pfd[1], F_ULOCK, 0 );
      
      // Report if report arg is on
      if ( report ) {
        printf( "I'm process %d. The maximum sum I found is %d.\n", getpid(), childMaxSum );
      }

      // Child exits
      exit( EXIT_SUCCESS );
    } 
  }
  
  // Parent process
  // Close writing end of pipe
  close( pfd[1] );

  for ( int i = 0; i < workers; i++ ) {
    // Read maxSum from children
    int childSum;
    read( pfd[0], &childSum, sizeof( int ) );
      
    // Update maxSum if new sum is found
    if ( childSum > maxSum ) {
      maxSum = childSum;
    }
      
    // Wait for children to exit
    wait( NULL );
  }

  // After all children have exited, print maxSum, exit program
  printf( "Maximum Sum: %d\n", maxSum );
  return 0;
}
