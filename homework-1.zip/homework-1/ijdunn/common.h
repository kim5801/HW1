/**
 * The common header file holds constants used for both the client and server.
 * It includes the names of the message queues, lengths for sending messages,
 * and the size of the Lights-Out game grid
 * @file common.h
 * @author Isaac Dunn (ijdunn)
 */

// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/ijdunn-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/ijdunn-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5
