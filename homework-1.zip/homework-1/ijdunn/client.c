/**
 * The client program sends messages to the server using
 * a message queue and asks the server to display, undo,
 * or update the game board with a move.
 * @file client.c
 * @author Isaac Dunn (ijdunn)
 */

#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

/**
 * This function is used to print a custom error message to stderr and exit with
 * a failure status.
 * @param message  The message to print to stderr
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

/**
 * This function is used to print a customer error message to stdout and exit
 * with a failure status. Used for client errors.
 * @param message  The message to print to stdout
 */
static void clientError() {
  printf( "error\n" );
  exit( 1 );
}

/**
 * The main function opens the message queues for the client and server to communicate,
 * Parse command-line arguments, send commands to the server, and print what was sent
 * back from the server
 * @param argc  The number of command-line arguments
 * @param argv  The command-line arguments stored as strings
 * @return      The exit status of the program, 0 for success, 1 for failure
 */
int main( int argc, char *argv[] ) {
  // Open the message queues
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY );
  if ( serverQueue == -1 || clientQueue == -1 ) {
    fail( "Can't open the needed message queues" );
  }

  // Parse command-line arguments
  if ( argc == 4 && strcmp( argv[1], "move" ) == 0 ) { // Move command
    int rowNum, colNum;
    // Unable to parse integer, invalid command-line arguments
    if ( sscanf( argv[2], "%d", &rowNum ) != 1 || sscanf( argv[3], "%d", &colNum ) != 1 ) {
      clientError();
    }
    // Error if row and column are out of bounds
    if ( rowNum < 0 || rowNum > 4 || colNum < 0 || colNum > 4 ) {
      clientError();
    }

    // Send the move command to the server
    char qMessageSend[MESSAGE_LIMIT];
    sprintf( qMessageSend, "move %d %d", rowNum, colNum );
    mq_send( serverQueue, qMessageSend, strlen( qMessageSend ), 0 );

  } else if ( argc == 2 && strcmp( argv[1], "undo" ) == 0 ) { // Undo command
    // Send undo command to the server
    char *qMessageSend = "undo";
    mq_send( serverQueue, qMessageSend, strlen( qMessageSend ), 0 );

  } else if ( argc == 2 && strcmp( argv[1], "report" ) == 0 ) { // Report command
    // Send report command to the server
    char *qMessageSend = "report";
    mq_send( serverQueue, qMessageSend, strlen( qMessageSend ), 0 );

  } else {
    // Invalid command-line argument(s), print to stdout and exit with failure code
    clientError();
  }

  // Receive response from server
  char qRecMessage[MESSAGE_LIMIT];
  mq_receive( clientQueue, qRecMessage, sizeof( qRecMessage ), NULL );

  // Use client error when error sent from server
  if ( strstr( qRecMessage, "error" ) != NULL ) {
    clientError();
  } 
  // Otherwise, print what was sent from the server
  else {
    printf( "%s\n", qRecMessage );
  }
  return 0;
}