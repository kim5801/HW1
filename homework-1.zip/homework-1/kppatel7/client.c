#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include "common.h"

bool validNum(const char number[])
{
    int size = sizeof(number) / sizeof(number[0]);
    // cant be negative
    if (number[0] == '-')
    {
        return false;
    }
    for (int i = 0; i < size; i++)
    {
        // checks if the coordinate is valid (cannot be >= 5 or negative)
        if (number[i] < '5' || number[i] >= '0')
        {
            return true;
        }
    }
    return false;
}

// Print out an error message
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

int main(int argc, char *argv[])
{
    // Structure for maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    if (serverQueue == -1 || clientQueue == -1)
        fail("Can't create the needed message queues");

    // user input buffer
    char buffer[MESSAGE_LIMIT];

    // user commands
    if (strcmp(argv[1], "report") == 0)
    {
        // tell server to report the board
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0);
        // server sends back the board state and print out the board
        int bytes = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
        if (bytes > 0)
        {
            for (int i = 0; i < (GRID_SIZE * GRID_SIZE + 5); i++)
            {
                printf("%c", buffer[i]);
            }
        }
    }
    else if (strcmp(argv[1], "undo") == 0)
    {
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0);
        printf("Sucess");
    }
    //move command
    else if ((strcmp(argv[1], "move") == 0) && validNum(argv[2]) && validNum(argv[3]))
    {   
        //send the command and the row and col
        mq_send(serverQueue, argv[1], strlen(argv[1]), 0);
        mq_send(serverQueue, argv[2], strlen(argv[2]), 0);
        mq_send(serverQueue, argv[3], strlen(argv[3]), 0);

        // server sends back "success" and prints it out in client
        int len = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
        if (len >= 0)
        {
            for (int i = 0; i < len; i++)
            {
                printf("%c", buffer[i]);
            }
        }
        printf("\n");
        printf("Sucess");
    }
    else if (argc == 4){
        fail("error\n");
    }
    else
    {
        fail("error\n");
    }
    // close the queues
    mq_close(clientQueue);
    mq_close(serverQueue);
}