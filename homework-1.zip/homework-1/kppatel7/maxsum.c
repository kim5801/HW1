/**
 * @file maxsum.c
 * @author Kush Patel kppatel7
 * @brief Takes a input file and uses a specified number of children processes to go through and find a contiguous maximum in the list
 */
#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(1);
}

// Print out a usage message, then exit.
static void usage()
{
  printf("usage: maxsum <workers>\n");
  printf("       maxsum <workers> report\n");
  exit(1);
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList()
{
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *)malloc(vCap * sizeof(int));

  // Keep reading as many values as we can.
  int v;
  while (scanf("%d", &v) == 1)
  {
    // Grow the list if needed.
    if (vCount >= vCap)
    {
      vCap *= 2;
      vList = (int *)realloc(vList, vCap * sizeof(int));
    }

    // Store the latest value in the next array slot.
    vList[vCount++] = v;
  }
}

int main(int argc, char *argv[])
{
  bool report = false;
  int workers = 4;

  int maxSum = INT_MIN;

  // Parse command-line arguments.
  if (argc < 2 || argc > 3)
    usage();

  if (sscanf(argv[1], "%d", &workers) != 1 || workers < 1)
    usage();

  // If there's a second argument, it better be the word, report
  if (argc == 3)
  {
    if (strcmp(argv[2], "report") != 0)
      usage();
    report = true;
  }

  readList();

  // make array of workers
  int pid[workers];
  // initialize the pipe
  int pfd[2];

  // make the pipe
  if (pipe(pfd) != 0)
  {
    fail("Can't create pipe");
  }

  // outer loop for forking the workers
  for (int i = 0; i < workers; i++)
  {
    pid[i] = fork();
    if (pid[i] == 0)
    {
      // close reading end of pipe for children
      close(pfd[0]);

      // inner loop that increments by the amount of workers
      int tempMaxSum = 0;
      for (int j = i; j < vCount; j += workers)
      {
        int tempSum = 0;

        // inner most loop that goes from increment to the end of the list
        for (int k = j; k < vCount; k++)
        {
          tempSum += vList[k];
          // check if the tempSum is the childs largest sum till now
          if (tempSum > tempMaxSum)
          {
            tempMaxSum = tempSum;
          }
          // printf("%d: %d", vList[k], tempSum);
        }
      }
      // report if the report option was specified
      if (report)
      {
        printf("I’m process %d. The maximum sum I found is %d.\n", getpid(), tempMaxSum);
      }
      // write to pipe the max sum this child found
      lockf(pfd[1], F_LOCK, 0);
      write(pfd[1], &tempMaxSum, (sizeof(int)));
      lockf(pfd[1], F_ULOCK, 0);
      exit(EXIT_SUCCESS);
      // printf("%d", sum);
    }
  }

  // close writing end for the parent
  close(pfd[1]);

  // array of all the sums that the workers report
  int sums[workers];

  // wait(NULL);
  // wait(NULL);
  // wait(NULL);
  // wait(NULL);

  // wait for all the children to finish
  while (wait(NULL) != -1)
  {
  }

  // read in all the integers the children put in the pipe into sums[] array
  for (int i = 0; i < workers; i++)
  {
    read(pfd[0], &sums[i], (sizeof(int)));
  }

  // figure out waht the largest sum reported was
  maxSum = sums[0];
  for (int i = 0; i < workers; i++)
  {
    // printf("%d", maxSum);
    if (sums[i] > maxSum)
    {
      maxSum = sums[i];
    }
  }

  // print out the max sum found
  printf("Maximum Sum: %d\n", maxSum);

  // wrong implementation that i initially used

  // for (int i = 0; i < workers; i++){
  //   int vListInc = vCount / workers;
  //   int inc = 1;

  //   if (pid[i] == 0){

  //     int sum = 0;
  //     for (int i = ((inc - 1) * vListInc); i < (inc * vListInc); i++){
  //       maxSum += vList[i];

  //     }
  //     inc++;

  //   }
  //   else{
  //     fail("Child One failed to fork");
  //   }
  //}
  return 0;
}
