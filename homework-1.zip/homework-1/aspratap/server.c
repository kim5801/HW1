/**
 * @author Abhinav Pratap, aspratap
 * @file server.c
 * Starts the server for the lights out game
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;
static struct BoardState state;

/**
 * Prints the current grid in a formatted manner
 */
void printGrid()
{
    for (int i = 0; i < GRID_SIZE; i++)
    {
        for (int j = 0; j < GRID_SIZE; j++)
        {
            printf("%c", state.currGrid[i][j]);
        }

        printf("\n");
    }
}

/**
 * singal handler for termination. Prints out game board state
 * @param sig singal information
 */
void sigHandler(int sig)
{
    printf("\n");
    printGrid();
    exit(EXIT_SUCCESS);
}

/**
 * Reads in a file and updated the board state
 * @param fileName name of the file to read from
 */
void readFileState(char *fileName)
{
    FILE *fp = fopen(fileName, "r");

    if (fp == NULL)
    {
        fprintf(stderr, "Invalid input file: %s\n", fileName);
        exit(1);
    }

    for (int i = 0; i < GRID_SIZE; i++)
    {
        for (int j = 0; j < GRID_SIZE; j++)
        {
            int input = fgetc(fp);
            if (input != '*' && input != '.')
            {
                fprintf(stderr, "Invalid input file: %s\n", fileName);
                exit(1);
            }

            state.currGrid[i][j] = input;
        }

        int input = fgetc(fp);
        if (input != '\n' && i != GRID_SIZE - 1)
        {
            fprintf(stderr, "Invalid input file: %s\n", fileName);
            exit(1);
        }
    }

    int input = fgetc(fp);
    if (input != '\n' && input != EOF)
    {
        fprintf(stderr, "Invalid input file: %s\n", fileName);
        exit(1);
    }

    state.undoAvailable = false;
}

/**
 * Updates the prev game state so that it reflects the current game state.
 * Copies the current grid into the prev grid so that undos are possible.
 */
void updatePrevBoard()
{
    for (int i = 0; i < GRID_SIZE; i++)
    {
        for (int j = 0; j < GRID_SIZE; j++)
        {
            state.prevGrid[i][j] = state.currGrid[i][j];
        }
    }
}

/**
 * flips the light at specific location of the board.
 * returns without making changes if invalid row and column is provided.
 * @param r row number
 * @param c column number
 */
void flip(int r, int c)
{
    if (r > GRID_SIZE - 1 || r < 0 || c < 0 || c > GRID_SIZE - 1)
        return;
    if (state.currGrid[r][c] == '*')
    {
        state.currGrid[r][c] = '.';
    }
    else
    {
        state.currGrid[r][c] = '*';
    }
}

/**
 * plays a move on the gameboard
 * @param r the row of the light
 * @param c the column of the light
 */
void move(int r, int c)
{
    updatePrevBoard();

    flip(r, c);
    flip(r - 1, c);
    flip(r, c + 1);
    flip(r, c - 1);
    flip(r + 1, c);
    state.undoAvailable = true;
}

/**
 * Play undo and copy previous board into current board
 */
void undoBoard()
{
    for (int i = 0; i < GRID_SIZE; i++)
    {
        for (int j = 0; j < GRID_SIZE; j++)
        {
            state.currGrid[i][j] = state.prevGrid[i][j];
        }
    }

    state.undoAvailable = false;
}

/**
 * starts the server for light out
 * @param argc the number of command line arguments
 * @param argv the arguments provided from the command line
 * @return exit status
 */
int main(int argc, char *argv[])
{
    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
    if (serverQueue == -1 || clientQueue == -1)
        fail("Can't create the needed message queues");

    if (argc != 2)
    {
        fail("usage: server <board-file>");
    }

    struct sigaction act;

    // Fill in a structure to redirect the int signal.
    act.sa_handler = sigHandler;
    sigemptyset(&(act.sa_mask));
    act.sa_flags = 0;
    sigaction(SIGINT, &act, 0);

    readFileState(argv[1]);

    // Repeatedly read and process client messages.
    while (running)
    {
        char buffer[MESSAGE_LIMIT];
        int len = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);
        if (len == -1)
        {
            fail("unable to receive message");
        }

        char actionChar = buffer[0];
        if (actionChar == 'm')
        {
            int row = buffer[1];
            int col = buffer[2];

            move(row, col);
            char clientBuffer[MESSAGE_LIMIT] = "success\n";
            mq_send(clientQueue, clientBuffer, sizeof(clientBuffer), 0);
        }
        else if (actionChar == 'u')
        {
            if (state.undoAvailable == false)
            {
                char clientBuffer[MESSAGE_LIMIT] = "error\n";
                mq_send(clientQueue, clientBuffer, sizeof(clientBuffer), 0);
            }
            else
            {
                undoBoard();
                char clientBuffer[MESSAGE_LIMIT] = "success\n";
                mq_send(clientQueue, clientBuffer, sizeof(clientBuffer), 0);
            }
        }
        else if (actionChar == 'r')
        {
            // printf("reporting\n");
            int counter = 0;
            char clientBuffer[MESSAGE_LIMIT];
            for (int i = 0; i < GRID_SIZE; i++)
            {
                for (int j = 0; j < GRID_SIZE; j++)
                {
                    clientBuffer[counter] = state.currGrid[i][j];
                    counter++;
                }
                clientBuffer[counter] = '\n';
                counter++;
            }
            clientBuffer[counter] = '\0';
            // printf("sending\n");
            mq_send(clientQueue, clientBuffer, sizeof(clientBuffer), 0);
            // printf("sent\n");
        }
    }

    // Close our two message queues (and delete them).
    mq_close(clientQueue);
    mq_close(serverQueue);

    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    return 0;
}
