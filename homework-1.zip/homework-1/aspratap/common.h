#include <stdbool.h>
// Name for the queue of messages going to the server.
#define SERVER_QUEUE "/aspratap-server-queue"

// Name for the queue of messages going to the current client.
#define CLIENT_QUEUE "/aspratap-client-queue"

// Maximum length for a message in the queue
// (Long enough to hold any server request or response)
#define MESSAGE_LIMIT 1024

// Height and width of the playing area.
#define GRID_SIZE 5

struct BoardState {
    char currGrid[GRID_SIZE][GRID_SIZE];
    char prevGrid[GRID_SIZE][GRID_SIZE];
    bool undoAvailable;
};
