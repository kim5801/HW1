/**
 * @author Abhinav Pratap, aspratap
 * @file client.c
 * Start the client for the lights out game
 */
#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stdout, "%s\n", message);
    exit(1);
}

/**
 * starts the client for lights out
 * @param argc the number of command line arguments
 * @param argv the arguments provided from the command line
 * @return exit status
 */
int main(int argc, char *argv[])
{
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY);
    if (serverQueue == -1 || clientQueue == -1)
        fail("Can't open the needed message queues");

    if (argc < 2 || argc > 4)
    {
        fail("Invalid arguments");
    }

    if (strcmp(argv[1], "move") == 0)
    {
        if (argc != 4 || strlen(argv[2]) != 1 || strlen(argv[3]) != 1)
            fail("Invalid arguments for move");

        int r = *argv[2] - '0';
        int c = *argv[3] - '0';

        if (r > GRID_SIZE - 1 || r < 0 || c < 0 || c > GRID_SIZE - 1)
            fail("Invalid arguments for move");
        // printf("row: %d\n", r);
        // printf("col: %d\n", c);

        char buffer[MESSAGE_LIMIT];
        buffer[0] = 'm';
        buffer[1] = r;
        buffer[2] = c;
        mq_send(serverQueue, buffer, sizeof(buffer), 0);
    }
    else if (strcmp(argv[1], "undo") == 0)
    {
        if (argc != 2)
        {
            fail("Too many arguments for undo");
        }

        char buffer[MESSAGE_LIMIT];
        buffer[0] = 'u';
        mq_send(serverQueue, buffer, sizeof(buffer), 0);
    }
    else if (strcmp(argv[1], "report") == 0)
    {
        if (argc != 2)
        {
            fail("Too many arguments for report");
        }

        char buffer[MESSAGE_LIMIT];
        buffer[0] = 'r';
        mq_send(serverQueue, buffer, sizeof(buffer), 0);
    }
    else {
        fail("error");
    }

    char buffer[MESSAGE_LIMIT];
    int len = mq_receive(clientQueue, buffer, sizeof(buffer), NULL);

    if (len == -1) {
        fail("message receive error");
    }
    
    printf("%s", buffer);

    // Close our two message queues (and delete them).
    mq_close(clientQueue);
    mq_close(serverQueue);

    return 0;
}