#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//preps the board's integer representation for a string to be
//sent to the client
static void turnBoardIntoMessage( char message[], int board[GRID_SIZE][GRID_SIZE]){
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      int cell = board[i][j];
      //translate 0 to .
      if (cell == 0) {
        strncat(message, ".", 1);
      // 1 goes to *
      } else {
        strncat(message, "*", 1);
      }
    }
  }
  //make it a good string
  strncat(message, "\0", 1);
}

//uses the Client queue to send the passed in message
static void send(mqd_t outBound, char message[]) {
  mq_send( outBound, message, MESSAGE_LIMIT, 0 );
}

//performs a move given the board and a message from the client
static void move(int board[GRID_SIZE][GRID_SIZE], mqd_t outBound, char message[]) {
  //get rows and columns get getting character and subtracting
  //ascii difference
  int r = message[4] - 48;
  int c = message[5] - 48;
 
  //change exact spot
  board[r][c] = (board[r][c] == 0) ? 1 : 0;

  //get spot above if it is within bounds
  if (r > 0) {
    board[r - 1][c] = (board[r - 1][c] == 0) ? 1 : 0;
  }
  //get spot below if it is within bounds
  if (r < GRID_SIZE - 1) {
    board[r + 1][c] = (board[r + 1][c] == 0) ? 1 : 0;
  }
  //get spot to left if it is within bounds
  if (c > 0) {
    board[r][c - 1] = (board[r][c - 1] == 0) ? 1 : 0;
  }
  //get spot to right if it is within bounds
  if (c < GRID_SIZE - 1) {
    board[r][c + 1] = (board[r][c + 1] == 0) ? 1 : 0;
  }

  //send a success message back to client
  char *response = "success\n";
  send(outBound, response);
}

//Reads in the file and fills the 2D array with 0's and 1's
void initializeBoard(int board[GRID_SIZE][GRID_SIZE], int argc, char *argv[]) {
  //open the file from the second command line argument
  FILE *fp = fopen(argv[1], "r");
  if (!fp) {
    fail("usage: server <board-file>");
  }

  //should only have 2 command line args
  if (argc != 2) {
    fail("usage: server <board-file>");
  }

  //the character being read
  int ch;
  //outer index of the 2D array
  int outerIndex = 0;
  //inner index of the 2D array
  int innerIndex = 0;
  //read in each character until end of file
  while ((ch = fgetc(fp)) != EOF) {
    // * -> 1
    if (ch == '*') {
      board[outerIndex][innerIndex] = 1;
    // . -> 1
    } else if (ch == '.') {
      board[outerIndex][innerIndex] = 0;
    //if we hit new line, move down array and start from left
    } else if (ch == '\n') {
      //not in correct dimmensions
      if (innerIndex != GRID_SIZE) {
        char message[] = "Invalid input file: ";
        strcat(message, argv[1]);
        fail(message);
      }
      //reset for next row of 2D array
      outerIndex++;
      innerIndex = -1;
    //bad character
    } else {
      char message[] = "Invalid input file: ";
      strcat(message, argv[1]);
      fail(message);
    }
    //go from left to right within the row
    innerIndex++;
  }
}
// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

// Function called when SIGINT is enters
void alarmHandler( int sig ) {
  // When server is quit, print newline and board
  printf( "\n" );
  running = 0;
}

//given a string, it prints it out in board format
static void displayBoard(int board[GRID_SIZE][GRID_SIZE]) {
  //iterate through both dimmensions
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      if (board[i][j] == 0) printf("%c", '.');
      else printf("%c", '*');
    }
    //start new row
    printf("\n");
  }
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  // Prepare structure to redirect the sigint signal.
  struct sigaction act;
  act.sa_handler = alarmHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 ) {
    printf("%s\n", strerror(errno));
    fail( "Can't create the needed message queues" );
    
  }

  //game board represented by 2D array
  int board[GRID_SIZE][GRID_SIZE] = {{0}};

  //set up the game board with the given parameters
  initializeBoard(board, argc, argv);

  //boolean tracking if an undo is possible.
  //Starts as false and only becomes true after a move
  //After an undo, it becomes false again.
  int canUndo = 0;

  //string that tracks the last moved done for undoing
  char lastMove[] = "move55";
  
  // Repeatedly read and process client messages.
  while ( running ) {
    
    char buffer[MESSAGE_LIMIT + 1] = "";
    mq_receive(serverQueue, buffer, sizeof(buffer), NULL);

    //user wants report
    if (strcmp( buffer, "report" ) == 0 ) {
      char message[MESSAGE_LIMIT] = "";
      turnBoardIntoMessage(message, board);
      send(clientQueue, message);
    }

    //user wants a move
    else if (strncmp(buffer, "move", 4) == 0) {
      //copy this command to last one
      strcpy(lastMove, buffer);
      canUndo = 1;
      move(board, clientQueue, buffer);
    }

    //user wants an undo
    else if (strcmp(buffer, "undo" ) == 0) {
      if (!canUndo) {
        char *message = "error\n";
        send(clientQueue, message);
      } else {
        //cause the undo flag to be false so you can't go back to back
        canUndo = 0;
        //an undo is really just doing the last move again
        move(board, clientQueue, lastMove);
      }
    
    }
    
  }
 
  //Ctr-C has been hit, so display board
  displayBoard(board);

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
