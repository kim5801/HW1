#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>
#include <errno.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//finds the maximum sum for a subarray of vlist
int findMaxSumForRange(int *vlist, int count, int startingIndexes[count], int listSize) {
  //keeps track of the largest sum from all traversals of this chunk
  int maxSum = 0;
  //iterate through the array of indexes to start search from
  for (int i = 0; i < count; i++) {
    //keep track of sum starting at one of the indexes
    int currentSum = 0;
    //go from starting index to end of list
    for (int j = startingIndexes[i]; j < listSize; j++) {
      //update current sum and max sum if appropriate
      currentSum += vlist[j];
      if (currentSum > maxSum) {
        maxSum = currentSum;
      }
    }
  }
  return maxSum;
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  //read numbers from input text file to vList
  readList();

  //holds the sum maxes from each worker
  int totalMax = INT_MIN;

  //for pipe
  int pfd[2];

  //create pipe
  if (pipe(pfd) != 0) {
    fail("Cannot create pipe");
  }

  //create a child for each worker and make it look for sum
  for (int i = 0; i < workers; i++) {

    //make a new child
    int pid = fork();
    if (pid == -1) {
      fail( "Can't create child process" );
    }

    //child process, make it find its max sum
    if (pid == 0) {

      //size of below list. Some won't fill all buckets if evenly divisible
      int sizeArray = vCount / workers + 1;
      //array of indexes to traverse vList with
      int startingIndexes[sizeArray];
      //above array's index
      int index = 0;

      //Go through vList and add indexes evenly spaced
      for (int j = i; j < vCount; j+= workers){
        startingIndexes[index] = j;
        index++;
      }
     
      //max is the maximum sum found in the child's subrange
      int max = findMaxSumForRange(vList, index, startingIndexes, vCount);
      
      //report flag means we give process info 
      if (report) {
        printf("I'm process %d. The maximum sum I found is %d.\n", getpid(), max);
      }

      //write max sum found to the pipe
      lockf(pfd[1], F_LOCK, 0 );
      write(pfd[1], &max, sizeof(int));
      lockf(pfd[1], F_ULOCK, 0 );

      //exit child
      exit(EXIT_SUCCESS);
    }
  }

  //max sum found from this subarray
  int subMax = 0;
  for (int i = 0; i < workers; i++) {
    read(pfd[0], &subMax, sizeof(int));
    if (subMax > totalMax) {
      totalMax = subMax;
    }
  }

  //wait for all children to finish
  for (int i = 0; i < workers; i++) {
    wait(NULL);
  }

  //print the max found and return
  printf( "Maximum Sum: %d\n", totalMax);
  return 0;
}
