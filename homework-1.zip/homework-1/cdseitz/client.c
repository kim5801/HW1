#include <stdio.h>
#include <stdlib.h>
#include <mqueue.h>
#include "common.h"
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

//if the client detects one of the error conditions, print error and
//exit unsuccessfully 
static void error() {
  printf("error\n");
  exit(EXIT_FAILURE);
}

//given a string, it prints it out in board format
static void displayBoard(char unformattedBoardString[]) {
  //iterate through both dimmensions
  for (int i = 0; i < GRID_SIZE; i++) {
    for (int j = 0; j < GRID_SIZE; j++) {
      //multiplication by i and 5 moves the character along string
      printf("%c", unformattedBoardString[j + i*GRID_SIZE]);
    }
    //start new row
    printf("\n");
  }
}

//get message back from server
static void receive() {

  //open message from server to client
  mqd_t inBound = mq_open( CLIENT_QUEUE, O_RDONLY );

  //take in string
  char buffer[MESSAGE_LIMIT + 1];
  int len = mq_receive(inBound, buffer, sizeof(buffer), NULL);
  //error
  if (len == -1) {
    fail("cannot receive message from server");
  }

  //received good string
  else {

    //server sent us a report back
    if (buffer[0] == '*' || buffer[0] == '.') {
      displayBoard(buffer);
    }
    //server sent back request or error
    else {
      printf("%s", buffer);
    }
  }
}

//Sends the client's requested message to server
static void send(mqd_t outBound, int argc, char *argv[]) {

  //report or undo
  if (argc == 2) {
    char *message = argv[1];
    //send the string as a message
    mq_send( outBound, message, strlen( message ), 0 );

  //move command
  } else {
    //combine the move with the numbers into one string
    char *message = argv[1];
    strcat(message, argv[2]);
    strcat(message, argv[3]);

    //send the string as a message
    mq_send( outBound, message, strlen( message ), 0 );
  }
}

int main( int argc, char *argv[] ) {
  mqd_t outBound = mq_open( SERVER_QUEUE, O_WRONLY );
  if ( outBound == -1 )
    fail( "Can't open message queue" );
  
  //user wants a report
  if (argc == 2 && (strcmp( argv[ 1 ], "report" ) == 0 )) {
    send(outBound, argc, argv);
  
  //user wants a move
  } else if (argc == 4 && (strcmp( argv[ 1 ], "move" ) == 0 )) {
    int r, c;
    int status1 = sscanf(argv[2], "%d", &r);
    int status2 = sscanf(argv[3], "%d", &c);
    if (status1 != -1 && status2 != -1 && r >= 0 && r < GRID_SIZE && c >= 0 && c < GRID_SIZE ) {
      send(outBound, argc, argv);
    }

    //error
    else {
      error();
    }
  
  //user wants an undo
  }
  else if (argc == 2 && (strcmp( argv[ 1 ], "undo" ) == 0 )) {
    send(outBound, argc, argv);
  }

  //not one of the allowed messages, so error it
  else {
    error();
  }

  //receive message back from server
  receive();

  return EXIT_SUCCESS;
}