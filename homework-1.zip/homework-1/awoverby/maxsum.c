#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

#define MIN -1000000000

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: maxsum <workers>\n" );
  printf( "       maxsum <workers> report\n" );
  exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
  // Set up initial list and capacity.
  vCap = 5;
  vList = (int *) malloc( vCap * sizeof( int ) );

  // Keep reading as many values as we can.
  int v;
  while ( scanf( "%d", &v ) == 1 ) {
    // Grow the list if needed.
    if ( vCount >= vCap ) {
      vCap *= 2;
      vList = (int *) realloc( vList, vCap * sizeof( int ) );
    }

    // Store the latest value in the next array slot.
    vList[ vCount++ ] = v;
  }
}

int main( int argc, char *argv[] ) {
  bool report = false;
  int workers = 4;

  // Parse command-line arguments.
  if ( argc < 2 || argc > 3 )
    usage();

  if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 ||
       workers < 1 )
    usage();

  // If there's a second argument, it better be the word, report
  if ( argc == 3 ) {
    if ( strcmp( argv[ 2 ], "report" ) != 0 )
      usage();
    report = true;
  }

  readList();

  // Create a pipe for parent child communication
  int pfd[ 2 ];
  if ( pipe( pfd ) != 0 ) {
    fail( "Can't create pipe" );
  }

  // One iteration for each worker
  for ( int i = 0; i < workers; i++ ) {
    int pid = fork();
    // Child does its work inside this iteration of the loop
    if ( pid == 0 ) {
      close( pfd[ 0 ] );
      // Determine the highest sum
      int highestCurrent = MIN;
      int highest = MIN;
      for( int j = 0; j < vCount; j++ ) {
        if ( j % workers == i ) {
          highestCurrent = MIN;
          int current = 0;
          for( int k = j; k < vCount; k++ ) {
            current += vList[ k ];
            if ( current > highestCurrent ) {
              highestCurrent = current;
            }
          }
          if ( highestCurrent > highest ) {
            highest = highestCurrent;
          }
        }
      }
      // Print highest for this worker if report flag was used
      if ( report ) {
        int myId = getpid();
        printf( "I'm process %d. The maximum sum I found is %d.\n", myId, highest );
      }
      // Send the highest value to the parent through the pipe
      lockf( pfd[ 1 ], F_LOCK, 0 );
      write( pfd[ 1 ], &highest, sizeof( int ) );
      lockf( pfd[ 1 ], F_ULOCK, 0 );
      exit( EXIT_SUCCESS );
    }
  }

  // Determine the highest out of the worker's sent values
  close( pfd[ 1 ] );
  int highest = MIN;
  for ( int i = 0; i < workers; i++ ) {
    wait( NULL );
    int current;
    read( pfd[ 0 ], &current, sizeof( int ) );
    if ( current > highest ) {
      highest = current;
    }
  }
  close( pfd[ 0 ] );
  
  printf( "Maximum Sum: %d\n", highest );
  
  return 0;
}
