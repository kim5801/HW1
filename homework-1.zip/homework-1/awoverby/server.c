#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( 1 );
}

// Make or undo a move on the board and set the last move.
void move( bool board[ GRID_SIZE ][ GRID_SIZE ], int last[ 2 ], int loc[ MOVE_SIZE ], bool undo ) {
  board[ loc[ 0 ] ][ loc[ 1 ] ] = board[ loc[ 0 ] ][ loc[ 1 ] ] != 1;
  if ( loc[ 0 ] != 0 ) {
    board[ loc[ 0 ] - 1 ][ loc[ 1 ] ] = board[ loc[ 0 ] - 1 ][ loc[ 1 ] ] != 1;
  }
  if ( loc[ 0 ] != GRID_SIZE - 1 ) {
    board[ loc[ 0 ] + 1 ][ loc[ 1 ] ] = board[ loc[ 0 ] + 1 ][ loc[ 1 ] ] != 1;
  }
  if ( loc[ 1 ] != 0 ) {
    board[ loc[ 0 ] ][ loc[ 1 ] - 1 ] = board[ loc[ 0 ] ][ loc[ 1 ] - 1 ] != 1;
  }
  if ( loc[ 1 ] != GRID_SIZE - 1 ) {
    board[ loc[ 0 ] ][ loc[ 1 ] + 1 ] = board[ loc[ 0 ] ][ loc[ 1 ] + 1 ] != 1;
  }
  if ( undo ) {
    last[ 0 ] = -1;
    last[ 1 ] = -1;
  } else {
    last[ 0 ] = loc[ 0 ];
    last[ 1 ] = loc[ 1 ];
  }
}

// Create a string representing the board.
void boardString( bool board[ GRID_SIZE ][ GRID_SIZE ], char str[ 31 ] ) {
  for( int i = 0; i < GRID_SIZE; i++ ) {
    for( int j = 0; j < GRID_SIZE; j++ ) {
      if ( board[ i ][ j ] ) {
        str[ ( ( GRID_SIZE + 1 ) * i ) + j ] = '*';
      } else {
        str[ ( ( GRID_SIZE + 1 ) * i ) + j ] = '.';
      }
    }
  }
  for( int i = GRID_SIZE; i < GRID_SIZE * ( GRID_SIZE + 1 ); i += ( GRID_SIZE + 1 ) ) {
    str[ i ] = '\n';
  }
  str[ 31 ] = '\0';
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

void interruptHandler( int sig ) {
  running = 0;
}

int main( int argc, char *argv[] ) {
  // Remove both queues, in case, last time, this program terminated
  // abnormally with some queued messages still queued.
  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );
  
  // Create the board and last move state
  if( argc != 2 ) {
    fail( "usage: server <board-file>" );
  }
  FILE *fp = fopen( argv[ 1 ], "r" );
  if ( !fp ) {
    fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
    return 1;
  }
  // 2D array representing the board.
  bool board[ GRID_SIZE ][ GRID_SIZE ];
  // Two integer array representing the last move.
  int last[ 2 ] = { -1, -1 };
  for ( int i = 0; i < GRID_SIZE; i++ ) {
    char ch = fgetc( fp );
    for ( int j = 0; j < GRID_SIZE; j++ ) {
      if ( ch == '.' ) {
        board[ i ][ j ] = false;
      } else if ( ch == '*' ) {
        board[ i ][ j ] = true;
      } else {
        fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
        return 1;
      }
      ch = fgetc( fp );
    }
    if ( ch != '\n' ) {
      fprintf( stderr, "Invalid input file: %s\n", argv[ 1 ] );
      return 1;
    }
  }

  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );

  struct sigaction act;
  act.sa_handler = interruptHandler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Repeatedly read and process client messages.
  while ( running ) {

    char msg[ 3 ];
    int msgRec = -1;
    msgRec = mq_receive( serverQueue, msg, MESSAGE_LIMIT + 1, NULL );
    if( msgRec != -1 ) {
      if ( msg[ 0 ] == 'r' ) {
        char report[ 31 ];
        boardString( board, report );
        mq_send( clientQueue, report, 31, 0 );
      } else if ( msg[ 0 ] == 'u' ) {
        if ( last[ 0 ] == -1 ) {
          mq_send( clientQueue, "0", 1, 0 );
        } else {
          move( board, last, last, true );
          mq_send( clientQueue, "1", 1, 0 );
        }
      } else if ( msg[ 0 ] == 'm' ) {
        int loc[ MOVE_SIZE ] = { ( int )( msg[ 1 ] - '0' ), ( int )( msg[ 2 ] - '0' ) };
        move( board, last, loc, false );
      }
    }
    
  }

  printf( "\n" );
  char str[ 31 ];
  boardString( board, str );
  printf( "%s", str );

  // Close our two message queues (and delete them).
  mq_close( clientQueue );
  mq_close( serverQueue );

  mq_unlink( SERVER_QUEUE );
  mq_unlink( CLIENT_QUEUE );

  return 0;
}
