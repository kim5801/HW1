#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

// Print out an error message and exit.
static void fail() {
  fprintf( stderr, "error\n" );
  exit( 1 );
}

int main( int argc, char *argv[] ) {
  // Prepare structure indicating maximum queue and message sizes.
  struct mq_attr attr;
  attr.mq_flags = 0;
  attr.mq_maxmsg = 1;
  attr.mq_msgsize = MESSAGE_LIMIT;

  // Make both the server and client message queues.
  mqd_t serverQueue = mq_open( SERVER_QUEUE, O_WRONLY | O_CREAT, 0600, &attr );
  mqd_t clientQueue = mq_open( CLIENT_QUEUE, O_RDONLY | O_CREAT, 0600, &attr );
  if ( serverQueue == -1 || clientQueue == -1 )
    fail( "Can't create the needed message queues" );
    
  if( strcmp( argv[ 1 ], "report" ) == 0 ) {
    if( argc != 2 ) {
      mq_close( clientQueue );
      mq_close( serverQueue );
      fail();
    }
    mq_send( serverQueue, "r", 1, 0 );
    char msg[ 31 ];
    mq_receive( clientQueue, msg, MESSAGE_LIMIT + 1, 0);
    printf( "%s", msg );
  } else if( strcmp( argv[ 1 ], "undo" ) == 0 ) {
    if( argc != 2 ) {
      mq_close( clientQueue );
      mq_close( serverQueue );
      fail();
    }
    mq_send( serverQueue, "u", 1, 0 );
    char msg[ 1 ];
    mq_receive( clientQueue, msg, MESSAGE_LIMIT + 1, 0);
    if ( msg[ 0 ] == '1' ) {
      printf( "success\n" );
    } else {
      mq_close( clientQueue );
      mq_close( serverQueue );
      fail();
    }
  } else if( strcmp( argv[ 1 ], "move" ) == 0 ) {
    if( argc != 4 || strlen( argv[ 2 ] ) != 1 || strlen( argv[ 3 ] ) != 1 || argv[ 2 ][ 0 ] < '0' || argv[ 2 ][ 0 ] > '4' || argv[ 3 ][ 0 ] < '0' || argv[ 3 ][ 0 ] > '4' ) {
      mq_close( clientQueue );
      mq_close( serverQueue );
      fail();
    }
    char msg[ 3 ] = { 'm', argv[ 2 ][ 0 ], argv[ 3 ][ 0 ] };
    mq_send( serverQueue, msg, 3, 0);
    printf( "success\n" );
  } else {
    mq_close( clientQueue );
    mq_close( serverQueue );
    fail();
  }
  mq_close( clientQueue );
  mq_close( serverQueue );
  return 0;
}