#include "common.h"
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <mqueue.h>
#include <signal.h>
#include <errno.h>
#include <string.h>

typedef struct BoardStruct {
    char grid[GRID_SIZE][GRID_SIZE];
    int lastX;
    int lastY;
}Board;

//Variable to detect the ctrl+C signal (SIGINT)
static bool gotSignal = false;

// Function called when the alarm goes off.
void signalHandler(int sig) {
    gotSignal = true;
}

// Print out an error message and exit.
static void fail(char const *message) {
    fprintf(stderr, "%s\n", message);
    exit(1);
}
/**  Function to make a move on the board, toggling the lights on or off based on their
  *  previous state.
  */
static void toggleLights(Board* b, int x, int y) {

    //Toggles the desired location on the grid.
    (b->grid[x][y] == '.') ? (b->grid[x][y] = '*') : (b->grid[x][y] = '.');

    //All subsequent checks toggle the positions adjacent to the desired location if it exists.
    if (x + 1 < GRID_SIZE) {
        (b->grid[x + 1][y] == '.') ? (b->grid[x + 1][y] = '*') : (b->grid[x + 1][y] = '.');
    }
    if (x - 1 >= 0) {
        (b->grid[x - 1][y] == '.') ? (b->grid[x - 1][y] = '*') : (b->grid[x - 1][y] = '.');
    }

    if (y + 1 < GRID_SIZE) {
        (b->grid[x][y + 1] == '.') ? (b->grid[x][y + 1] = '*') : (b->grid[x][y + 1] = '.');
    }

    if (y - 1 >= 0) {
        (b->grid[x][y - 1] == '.') ? (b->grid[x][y - 1] = '*') : (b->grid[x][y - 1] = '.');
    }
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

int main(int argc, char *argv[]) {
    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    struct sigaction act;

    act.sa_handler = signalHandler;
    sigemptyset(&(act.sa_mask));
    act.sa_flags = 0;
    sigaction(SIGINT, &act, 0);

    //Opens and reads the board file.
    FILE *in;
    if (argc == 2) {
        in = fopen(argv[1], "r");
        if (!in) {
            fprintf(stderr, "Invalid input file: %s\n", argv[1]);
            exit(1);
        }
    }

    else {
        fail("usage: server <board-file>");
    }

    //Takes the data from the text file and converts it into something acceptable by the board structure
    Board b;
    b.lastX = -1;
    b.lastY = -1;
    char c;
    int x = 0;
    int y = 0;

    while (c = fgetc(in), c != EOF) {
        if (c == '\n')
            c = fgetc(in);

        //c can only be '*' or '.'. If the file carries on after reaching the maximum size of the board, the file is invalid.
        if ((c != '*' && c != '.') && (x >= GRID_SIZE && c != EOF)) {
            fprintf(stderr, "Invalid input file: %s\n", argv[1]);
            exit(1);
        }

        b.grid[x][y] = c;
        y++;
        //Reset y as if it were a while loop.
        if (y == GRID_SIZE) {
            y = 0;
            x++;
        }
    }

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;

    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
    if (serverQueue == -1 || clientQueue == -1)
        fail("Can't create the needed message queues");

    char buffer[MESSAGE_LIMIT];
    char command[MESSAGE_LIMIT];

  // Repeatedly read and process client messages.
    while (running) {

        if (gotSignal) {
            printf("\n");
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    printf("%c", b.grid[i][j]);
                }
                printf("\n");
            }
            printf("\n");
            break;
        }
        int len = mq_receive(serverQueue, buffer, sizeof(buffer), NULL);
        buffer[len] = '\0';
        int count = 0;
        char c;
        //Identifies which command has been passed by the client.
        while (c = buffer[count], c != ' ' && c != '\0') {
            command[count] = c;
            count++;
        }
        command[count] = '\0';

        if (strcmp(command, "move") == 0) {
            //The buffer has been properly aligned by the client, no error checking required at this point.
            int x = buffer[count + 1] - '0';
            int y = buffer[count + MAX_ARGS - 1] - '0';

            toggleLights(&b, x, y);
            //Last move is updated to reflect this move.
            b.lastX = x;
            b.lastY = y;
            strcpy(buffer, "success");
            mq_send(clientQueue, buffer, strlen(buffer), 0);
        }

        else if (strcmp(command, "undo") == 0) {
            //A value of -1 means that either this is the first move or the previous move was an undo.
            if (b.lastX == -1 || b.lastY == -1) {
                strcpy(buffer, "error");
                mq_send(clientQueue, buffer, strlen(buffer), 0);
            }
            else {
                toggleLights(&b, b.lastX, b.lastY);
                b.lastX = -1;
                b.lastY = -1;
                strcpy(buffer, "success");
                mq_send(clientQueue, buffer, strlen(buffer), 0);
            }
        }

        else if (strcmp(command, "report") == 0) {
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    buffer[i * GRID_SIZE + j] = b.grid[i][j];
                }
            }
            buffer[GRID_SIZE * GRID_SIZE] = '\0';
            mq_send(clientQueue, buffer, strlen(buffer), 0);
        }
  }

  // Close our two message queues (and delete them).
    mq_close(clientQueue);
    mq_close(serverQueue);

    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    return 0;
}
