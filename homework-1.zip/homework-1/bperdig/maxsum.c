#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>
#include <stdbool.h>

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( 1 );
}

// Print out a usage message, then exit.
static void usage() {
    printf( "usage: maxsum <workers>\n" );
    printf( "       maxsum <workers> report\n" );
    exit( 1 );
}

// Input sequence of values.
int *vList;

// Number of values on the list.
int vCount = 0;

// Capacity of the list of values.
int vCap = 0;

// Read the list of values.
void readList() {
    // Set up initial list and capacity.
    vCap = 5;
    vList = (int *) malloc( vCap * sizeof( int ) );

    // Keep reading as many values as we can.
    int v;
    while ( scanf( "%d", &v ) == 1 ) {
        // Grow the list if needed.
        if ( vCount >= vCap ) {
            vCap *= 2;
            vList = (int *) realloc( vList, vCap * sizeof( int ) );
        }

    // Store the latest value in the next array slot.
        vList[ vCount++ ] = v;
    }
}

int main( int argc, char *argv[] ) {
    bool report = false;
    int workers = 4;

    // Parse command-line arguments.
    if ( argc < 2 || argc > 3 )
        usage();

    if ( sscanf( argv[ 1 ], "%d", &workers ) != 1 || workers < 1 )
        usage();

    // If there's a second argument, it better be the word, report
    if ( argc == 3 ) {
        if ( strcmp( argv[ 2 ], "report" ) != 0 )
            usage();
        report = true;
    }

    readList();

    // You get to add the rest.

    int sum = 0;
    int startIdx = 0;
    int max = vList[0];
    int pid;

    int pfd[2];
    if(pipe(pfd) != 0)
        fail("Failed to create pipe");

    //Forks the process as many times as there are workers.
    for (int i = 0; i < workers; i++) {
        pid = fork();
        if (pid < 0)
            fail("Can't create child process");

        //Every child subsequently breaks containment
        else if (pid == 0) {
            break;
        }
        //The starting index gets incremented each time a child is made
        else {
            startIdx++;
        }

    }
    if (pid == 0) {
        //The child doesn't need to read from the pipe.
        close(pfd[0]);

        //The j index increases by the number of workers to optimize the reading process, dividing it more evenly among the children.
        for (int j = startIdx; j < vCount; j += workers) {
            for (int k = 0; k < vCount - j; k++) {
                //Elements from the array are added to the current total sum and compared to the max value each time.
                sum += vList[j + k];
                if (sum > max)
                    max = sum;
            }
            sum = 0;
        }
        if(report)
            printf("I'm process %d. The maximum sum I found is %d\n", getpid(), max);

        //Locks the pipe, writes to it, unlocks the pipe, and the child exits.
        lockf(pfd[1], F_LOCK, 0);
        write(pfd[1], &max, sizeof(int));

        lockf(pfd[1], F_ULOCK, 0);
        exit(EXIT_SUCCESS);
    }

    else {
        //The parent waits for all the children to finish their job.
        for (int i = 0; i < workers; i++) {
            wait(NULL);
        }
        //The parent does not need to write to the pipe.
        close(pfd[1]);
        int temp;
        //Reads each value from the pipe and assign a max value accordingly.
        for (int i = 0; i < workers; i++) {
            read(pfd[0], &temp, sizeof(int));
            if (max < temp) {
                max = temp;
            }
        }

        //Closes the pipe for good measure and writes the maximum sum on the screen.
        close(pfd[0]);
        printf("Maximum sum: %d\n", max);
        free(vList);
        return 0;
    }
}
