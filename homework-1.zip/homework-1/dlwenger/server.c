/**
 * @file server.c
 * @author Daniel Wenger (dlwenger@ncsu.edu)
 * Source file for the server component of the Lights Out game. This program creates and opens server and client
 * message queues and responds to client commands. The server closes with Ctrl C and will print out the final version
 * of the board before exiting.
 * 
 */
#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <mqueue.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

/**
 * Struct containing the board that is being played and the last move the player took.
 * 
 */
typedef struct {
    char board[GRID_SIZE][GRID_SIZE];
    int lastMove[2];
} Board;

/**
 * Prints out a message to standard error and exits with an exit status of 1.
 * 
 * @param message the message that will be printed to stderr
 */
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}
/**
 * Reads in a board from a file and stores it in a board struct
 * 
 * @param b the board struct
 * @param file the name of the file
 */
static void readFile(Board *b, char *file)
{
    FILE *inFile = fopen(file, "r");
    if (inFile == NULL) {
        char message[strlen("Invalid input file: ") + strlen(file)];
        strcpy(message, "Invalid input file: ");
        strcat(message, file);
        fail(message);
    }

    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE + 1; j++) {
            char c = fgetc(inFile);
            if (j != GRID_SIZE && (c == '.' || c == '*')) {
                b->board[i][j] = c;
            }
            else if (j == GRID_SIZE && c == '\n') {
                continue;
            }
            else {
                char message[strlen("Invalid input file: ") + strlen(file)];
                strcpy(message, "Invalid input file: ");
                strcat(message, file);
                fclose(inFile);
                fail(message);
            }
        }
    }
    fclose(inFile);
}
/**
 * Converts the 2D array of the board in the board struct to a string that can be used for printing.
 * 
 * @param b the board struct containing the 2D array
 * @param buffer the string that the board will be entered into
 */
static void boardToString(Board *b, char *buffer)
{
    int idx = 0;
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            buffer[idx] = b->board[i][j];
            idx++;
        }
        buffer[idx] = '\n';
        idx++;
    }
}
/**
 * Function for changing the board when the client provides a valid move command
 * 
 * @param b the struct containing the board
 * @param r the row of the tile that will be changed
 * @param c the column of the tile that will be changed
 */
static void moveBoard(Board *b, int r, int c)
{
    b->board[r][c] = b->board[r][c] == '.' ? '*' : '.';
    if (r != 0) {
        b->board[r - 1][c] = b->board[r - 1][c] == '.' ? '*' : '.';
    }
    if (c != 0) {
        b->board[r][c - 1] = b->board[r][c - 1] == '.' ? '*' : '.';
    }
    if (r != GRID_SIZE - 1) {
        b->board[r + 1][c] = b->board[r + 1][c] == '.' ? '*' : '.';
    }
    if (c != GRID_SIZE - 1) {
        b->board[r][c + 1] = b->board[r][c + 1] == '.' ? '*' : '.';
    }

    b->lastMove[0] = r;
    b->lastMove[1] = c;
}


// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;
/**
 * Function that handles what the program does when it encounters SIGINT
 * 
 * @param sig 
 */
void sigHandler(int sig) {
    running = 0;
}
/**
 * Main function that takes a filename as a command argument, loads tbe board from the file, and responds to 
 * client 
 * 
 * @param argc number of command line arguments
 * @param argv the strings of the command line arguments
 * @return int exit status
 */
int main(int argc, char *argv[])
{
    if (argc != 2) {fail("usage: server <board-file>"); }
    // Remove both queues, in case, last time, this program terminated
    // abnormally with some queued messages still queued.
    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    // Prepare structure indicating maximum queue and message sizes.
    struct mq_attr attr;
    attr.mq_flags = 0;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = MESSAGE_LIMIT;


    // Make both the server and client message queues.
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_RDONLY | O_CREAT, 0600, &attr);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_WRONLY | O_CREAT, 0600, &attr);
    if (serverQueue == -1 || clientQueue == -1)
        fail("Can't create the needed message queues");

    Board b = {{}, {}};
    readFile(&b, argv[1]);
    bool undid = false;

    // Sigaction struct
    struct sigaction act;

    // Fill in a structure to redirect the alarm signal.
    act.sa_handler = sigHandler;
    sigemptyset(&(act.sa_mask));
    act.sa_flags = 0;
    sigaction(SIGINT, &act, 0);

        // Repeatedly read and process client messages.
    while (running) {
        char buffer[MESSAGE_LIMIT] = {};
        mq_receive(serverQueue, buffer, sizeof(buffer), NULL);

        if (strncmp("move", buffer, 4) == 0) {
            if (buffer[4] < '0' || buffer[4] > '9' || buffer[5] < '0' || buffer[5] > '9') {
                mq_send(clientQueue, "error", sizeof("error"), 0);
            }
            else if (buffer[4] - '0' > GRID_SIZE - 1 || buffer[5] - '0' > GRID_SIZE - 1) {
                mq_send(clientQueue, "error", sizeof("error"), 0);
            }
            else {
                moveBoard(&b, buffer[4] - '0', buffer[5] - '0');
                undid = true;
                mq_send(clientQueue, "success", sizeof("success"), 0);
            }
        }
        else if (strncmp("undo", buffer, 4) == 0) {
            if (undid) {
                moveBoard(&b, b.lastMove[0], b.lastMove[1]);
                mq_send(clientQueue, "success", sizeof("success"), 0);
                undid = false;
            }
            else {
                mq_send(clientQueue, "error", sizeof("error"), 0);
            }
        }
        else if (strcmp("report", buffer) == 0) {
            char message[MESSAGE_LIMIT] = {};
            boardToString(&b, message);
            mq_send(clientQueue, message, sizeof(message), 0);
        }
        else {
            mq_send(clientQueue, "error", sizeof("error"), 0);
        }
    }

    char sigbuffer[MESSAGE_LIMIT] = {};
    boardToString(&b, sigbuffer);
    printf("\n%s", sigbuffer);

    // Close our two message queues (and delete them).
    mq_close(clientQueue);
    mq_close(serverQueue);

    mq_unlink(SERVER_QUEUE);
    mq_unlink(CLIENT_QUEUE);

    return 0;
}
