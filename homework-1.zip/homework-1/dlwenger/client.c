/**
 * @file client.c
 * @author Daniel Wenger (dlwenger@ncsu.edu)
 * Source file for the client component of the Lights Out game. The client sends commands to the server, and if valid
 * the server will update the board or send back the current board.
 * 
 */
#include "common.h"
#include <errno.h>
#include <fcntl.h>
#include <mqueue.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
/**
 * Prints out a message to standard error and exits with an exit status of 1.
 * 
 * @param message the message that will be printed to stderr
 */
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(1);
}

/**
 * The main function for client parses the command line arguments and sends the message to 
 * to the running server through a message queue
 * 
 * @param argc the number of command line arguments
 * @param argv the strings representing the command line arguments
 * @return int the exit status
 */
int main(int argc, char *argv[])
{
    mqd_t serverQueue = mq_open(SERVER_QUEUE, O_WRONLY);
    mqd_t clientQueue = mq_open(CLIENT_QUEUE, O_RDONLY);
    if (serverQueue == -1 || clientQueue == -1)
        fail("Can't create the needed message queues");


    char buffer[MESSAGE_LIMIT] = {};
    if (strcmp(argv[1], "move") == 0) {
        if (argc != 4) {
            fail("Incorrect number of arguments for the move command.");
        }
        if (strlen(argv[2]) > 1 || strlen(argv[3]) > 1){
            fail("Rows and columns must be single digit values.");
        }
        strcpy(buffer, argv[1]);
        strcat(buffer, argv[2]);
        strcat(buffer, argv[3]);
        mq_send(serverQueue, buffer, sizeof(buffer), 0);
        mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
        if (strcmp(buffer, "error") == 0) {
            fail(buffer);
        }
        printf("%s\n", buffer);
    }
    else if (strcmp(argv[1], "report") == 0 || strcmp(argv[1], "undo") == 0) {
        strcpy(buffer, argv[1]);
        mq_send(serverQueue, buffer, sizeof(buffer), 0);
        mq_receive(clientQueue, buffer, sizeof(buffer), NULL);
        if (strcmp(buffer, "error") == 0) {
            fail(buffer);
        }
        printf("%s\n", buffer);
    }
    else {
        fail("Invalid command.");
    }

    mq_close(serverQueue);
    mq_close(clientQueue);
}
