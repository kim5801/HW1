#include <mqueue.h>
#include "common.h"
#include <sys/stat.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    mqd_t myQueue = mq_open(SERVER_QUEUE, O_WRONLY);
    mqd_t myClientQueue = mq_open(CLIENT_QUEUE, O_RDONLY);

    // if user enters a move request
    if (strcmp(argv[1], "move") == 0) {
        if (argc < 4 || (atoi(argv[2]) < 0 || atoi(argv[2]) > 4) || (atoi(argv[3]) < 0 || atoi(argv[3]) > 4)) {
            printf("error");
            exit( EXIT_FAILURE );
        }
        
        char buffer[8];
        sscanf(argv[1], "%s", buffer);
        buffer[4] = ' '; 
        sscanf(argv[2], "%s", buffer + 5);
        buffer[6] = ' ';
        sscanf(argv[3], "%s", buffer + 7);
        buffer[8] = '\0';
        mq_send( myQueue, buffer, strlen(buffer) + 1, 0);
        char result[8];
        mq_receive(myClientQueue, result, sizeof(result) + 1, NULL);
        printf("%s\n", result);
    }

    mq_close( myQueue );
    mq_close( myClientQueue );
    return 0;
}